﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Encrypt
{
	// Token: 0x020000BA RID: 186
	public class DEncrypt
	{
		// Token: 0x060005EE RID: 1518 RVA: 0x0015A819 File Offset: 0x0015A819
		public static string Decrypt(string original)
		{
			return DEncrypt.Decrypt(original, "ZENGNN711", Encoding.Default);
		}

		// Token: 0x060005EF RID: 1519 RVA: 0x0017E1BC File Offset: 0x0017E1BC
		public static byte[] Decrypt(byte[] encrypted)
		{
			byte[] bytes = Encoding.Default.GetBytes("ZENGNN711");
			return DEncrypt.Decrypt(encrypted, bytes);
		}

		// Token: 0x060005F0 RID: 1520 RVA: 0x0015A82B File Offset: 0x0015A82B
		public static string Decrypt(string original, string key)
		{
			return DEncrypt.Decrypt(original, key, Encoding.Default);
		}

		// Token: 0x060005F1 RID: 1521 RVA: 0x0017E1E0 File Offset: 0x0017E1E0
		public static byte[] Decrypt(byte[] encrypted, byte[] key)
		{
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider
			{
				Key = DEncrypt.MakeMD5(key),
				Mode = CipherMode.ECB
			};
			return tripleDESCryptoServiceProvider.CreateDecryptor().TransformFinalBlock(encrypted, 0, encrypted.Length);
		}

		// Token: 0x060005F2 RID: 1522 RVA: 0x0017E218 File Offset: 0x0017E218
		public static string Decrypt(string encrypted, string key, Encoding encoding)
		{
			byte[] encrypted2 = Convert.FromBase64String(encrypted);
			byte[] bytes = Encoding.Default.GetBytes(key);
			return encoding.GetString(DEncrypt.Decrypt(encrypted2, bytes));
		}

		// Token: 0x060005F3 RID: 1523 RVA: 0x0015A839 File Offset: 0x0015A839
		public static string Encrypt(string original)
		{
			return DEncrypt.Encrypt(original, "ZENGNN711");
		}

		// Token: 0x060005F4 RID: 1524 RVA: 0x0017E248 File Offset: 0x0017E248
		public static byte[] Encrypt(byte[] original)
		{
			byte[] bytes = Encoding.Default.GetBytes("ZENGNN711");
			return DEncrypt.Encrypt(original, bytes);
		}

		// Token: 0x060005F5 RID: 1525 RVA: 0x0017E26C File Offset: 0x0017E26C
		public static string Encrypt(string original, string key)
		{
			byte[] bytes = Encoding.Default.GetBytes(original);
			byte[] bytes2 = Encoding.Default.GetBytes(key);
			return Convert.ToBase64String(DEncrypt.Encrypt(bytes, bytes2));
		}

		// Token: 0x060005F6 RID: 1526 RVA: 0x0017E2A0 File Offset: 0x0017E2A0
		public static byte[] Encrypt(byte[] original, byte[] key)
		{
			TripleDESCryptoServiceProvider tripleDESCryptoServiceProvider = new TripleDESCryptoServiceProvider
			{
				Key = DEncrypt.MakeMD5(key),
				Mode = CipherMode.ECB
			};
			return tripleDESCryptoServiceProvider.CreateEncryptor().TransformFinalBlock(original, 0, original.Length);
		}

		// Token: 0x060005F7 RID: 1527 RVA: 0x0017E2D8 File Offset: 0x0017E2D8
		public static byte[] MakeMD5(byte[] original)
		{
			return new MD5CryptoServiceProvider().ComputeHash(original);
		}
	}
}
