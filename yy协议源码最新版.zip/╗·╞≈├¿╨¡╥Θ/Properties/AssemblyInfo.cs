﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("1.11.0.0")]
[assembly: InternalsVisibleTo("FluentData.UnitTests")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTitle("机器猫专业版111")]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: CLSCompliant(true)]
[assembly: AssemblyKeyName("")]
[assembly: Guid("e1492ac4-1629-48c8-953a-532d9572d859")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyDescription("")]
[assembly: ComVisible(false)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyFileVersion("1.11.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyProduct("机器猫专业版1111")]
[assembly: AssemblyInformationalVersion("10.0.3")]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyCompany("")]
[assembly: SecurityRules(SecurityRuleSet.Level1)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
