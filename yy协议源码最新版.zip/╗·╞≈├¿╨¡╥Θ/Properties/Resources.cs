﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Properties
{
	// Token: 0x02000090 RID: 144
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000495 RID: 1173 RVA: 0x0015804A File Offset: 0x0015804A
		internal Resources()
		{
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x06000496 RID: 1174 RVA: 0x0016F400 File Offset: 0x0016F400
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					ResourceManager resourceManager = new ResourceManager("Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000497 RID: 1175 RVA: 0x00159FF9 File Offset: 0x00159FF9
		// (set) Token: 0x06000498 RID: 1176 RVA: 0x0015A000 File Offset: 0x0015A000
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x040003CC RID: 972
		private static ResourceManager resourceMan;

		// Token: 0x040003CD RID: 973
		private static CultureInfo resourceCulture;
	}
}
