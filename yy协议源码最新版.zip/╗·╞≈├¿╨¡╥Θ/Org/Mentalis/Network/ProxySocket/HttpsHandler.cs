﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000092 RID: 146
	internal sealed class HttpsHandler : SocksHandler
	{
		// Token: 0x0600049D RID: 1181 RVA: 0x0015A008 File Offset: 0x0015A008
		public HttpsHandler(Socket server) : this(server, "")
		{
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x0015A016 File Offset: 0x0015A016
		public HttpsHandler(Socket server, string user) : this(server, user, "")
		{
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x0015A025 File Offset: 0x0015A025
		public HttpsHandler(Socket server, string user, string pass) : base(server, user)
		{
			this.method_8(pass);
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x0016F43C File Offset: 0x0016F43C
		private byte[] method_0(string string_2, int int_2)
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine(string.Format("CONNECT {0}:{1} HTTP/1.1", string_2, int_2));
			stringBuilder.AppendLine(string.Format("Host: {0}:{1}", string_2, int_2));
			if (!string.IsNullOrEmpty(base.Username))
			{
				string arg = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", base.Username, this.method_7())));
				stringBuilder.AppendLine(string.Format("Proxy-Authorization: Basic {0}", arg));
			}
			stringBuilder.AppendLine();
			return Encoding.ASCII.GetBytes(stringBuilder.ToString());
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x0016F4DC File Offset: 0x0016F4DC
		private void method_1(byte[] byte_1)
		{
			string @string = Encoding.ASCII.GetString(byte_1);
			if ((!@string.StartsWith("HTTP/1.1 ", StringComparison.OrdinalIgnoreCase) && !@string.StartsWith("HTTP/1.0 ", StringComparison.OrdinalIgnoreCase)) || !@string.EndsWith(" "))
			{
				throw new ProtocolViolationException();
			}
			string text = @string.Substring(9, 3);
			if (text != "200")
			{
				throw new ProxyException("Invalid HTTP status. Code: " + text);
			}
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x0015A036 File Offset: 0x0015A036
		public override void Negotiate(IPEndPoint remoteEP)
		{
			if (remoteEP == null)
			{
				throw new ArgumentNullException();
			}
			this.Negotiate(remoteEP.Address.ToString(), remoteEP.Port);
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x0016F54C File Offset: 0x0016F54C
		public override void Negotiate(string host, int port)
		{
			if (host == null)
			{
				throw new ArgumentNullException();
			}
			if (port <= 0 || port > 65535 || host.Length > 255)
			{
				throw new ArgumentException();
			}
			byte[] array = this.method_0(host, port);
			if (base.Server.Send(array, 0, array.Length, SocketFlags.None) < array.Length)
			{
				throw new SocketException(10054);
			}
			array = base.ReadBytes(13);
			this.method_1(array);
			int i = 0;
			array = new byte[1];
			while (i < 4)
			{
				if (base.Server.Receive(array, 0, 1, SocketFlags.None) == 0)
				{
					throw new SocketException(10054);
				}
				byte b = array[0];
				i = ((b != ((i % 2 == 0) ? 13 : 10)) ? ((b == 13) ? 1 : 0) : (i + 1));
			}
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x0015A058 File Offset: 0x0015A058
		public override IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			return this.BeginNegotiate(remoteEP.Address.ToString(), remoteEP.Port, callback, proxyEndPoint);
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x0016F614 File Offset: 0x0016F614
		public override IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			base.Buffer = this.method_0(host, port);
			base.Server.BeginConnect(proxyEndPoint, new AsyncCallback(this.method_2), base.Server);
			base.AsyncResult = new IAsyncProxyResult(null);
			return base.AsyncResult;
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x0016F668 File Offset: 0x0016F668
		private void method_2(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.Server.EndConnect(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Server.BeginSend(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_3), null);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x0016F6EC File Offset: 0x0016F6EC
		private void method_3(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndSend(iasyncResult_0, base.Buffer.Length);
				base.Buffer = new byte[13];
				base.Received = 0;
				base.Server.BeginReceive(base.Buffer, 0, 13, SocketFlags.None, new AsyncCallback(this.method_4), base.Server);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
			}
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x0016F768 File Offset: 0x0016F768
		private void method_4(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				if (base.Received < 13)
				{
					base.Server.BeginReceive(base.Buffer, base.Received, 13 - base.Received, SocketFlags.None, new AsyncCallback(this.method_4), base.Server);
				}
				else
				{
					this.method_1(base.Buffer);
					this.method_5(true);
				}
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x0016F810 File Offset: 0x0016F810
		private void method_5(bool bool_0)
		{
			while (base.Server.Available > 0 && this.int_1 < 4)
			{
				if (!bool_0)
				{
					bool_0 = false;
				}
				else if (base.Server.Receive(base.Buffer, 0, 1, SocketFlags.None) == 0)
				{
					throw new SocketException(10054);
				}
				if (base.Buffer[0] == ((this.int_1 % 2 == 0) ? 13 : 10))
				{
					this.int_1++;
				}
				else
				{
					this.int_1 = ((base.Buffer[0] == 13) ? 1 : 0);
				}
			}
			if (this.int_1 == 4)
			{
				this.ProtocolComplete(null);
				return;
			}
			base.Server.BeginReceive(base.Buffer, 0, 1, SocketFlags.None, new AsyncCallback(this.method_6), base.Server);
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x0016F8E0 File Offset: 0x0016F8E0
		private void method_6(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
				this.method_5(false);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
			}
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x0015A073 File Offset: 0x0015A073
		private string method_7()
		{
			return this.string_1;
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0015A07B File Offset: 0x0015A07B
		private void method_8(string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException();
			}
			this.string_1 = value;
		}

		// Token: 0x040003CE RID: 974
		private string string_1;

		// Token: 0x040003CF RID: 975
		private int int_1;
	}
}
