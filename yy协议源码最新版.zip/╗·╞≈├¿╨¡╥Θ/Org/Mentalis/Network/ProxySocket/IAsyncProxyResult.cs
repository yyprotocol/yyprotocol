﻿using System;
using System.Threading;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000093 RID: 147
	internal class IAsyncProxyResult : IAsyncResult
	{
		// Token: 0x17000103 RID: 259
		// (get) Token: 0x060004AD RID: 1197 RVA: 0x0015A08D File Offset: 0x0015A08D
		public bool IsCompleted
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x060004AE RID: 1198 RVA: 0x0015A095 File Offset: 0x0015A095
		public bool CompletedSynchronously
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x060004AF RID: 1199 RVA: 0x0015A098 File Offset: 0x0015A098
		public object AsyncState
		{
			get
			{
				return this.object_0;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x060004B0 RID: 1200 RVA: 0x0015A0A0 File Offset: 0x0015A0A0
		public WaitHandle AsyncWaitHandle
		{
			get
			{
				if (this.manualResetEvent_0 == null)
				{
					this.manualResetEvent_0 = new ManualResetEvent(false);
				}
				return this.manualResetEvent_0;
			}
		}

		// Token: 0x060004B1 RID: 1201 RVA: 0x0015A0BC File Offset: 0x0015A0BC
		internal IAsyncProxyResult(object stateObject = null)
		{
			this.object_0 = stateObject;
			this.bool_0 = false;
			if (this.manualResetEvent_0 != null)
			{
				this.manualResetEvent_0.Reset();
			}
		}

		// Token: 0x060004B2 RID: 1202 RVA: 0x0015A0E6 File Offset: 0x0015A0E6
		internal void Reset()
		{
			this.object_0 = null;
			this.bool_0 = true;
			if (this.manualResetEvent_0 != null)
			{
				this.manualResetEvent_0.Set();
			}
		}

		// Token: 0x040003D0 RID: 976
		private bool bool_0;

		// Token: 0x040003D1 RID: 977
		private object object_0;

		// Token: 0x040003D2 RID: 978
		private ManualResetEvent manualResetEvent_0;
	}
}
