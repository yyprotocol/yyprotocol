﻿using System;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x0200009B RID: 155
	internal sealed class AuthNone : AuthMethod
	{
		// Token: 0x06000512 RID: 1298 RVA: 0x0015A427 File Offset: 0x0015A427
		public AuthNone(Socket server) : base(server)
		{
		}

		// Token: 0x06000513 RID: 1299 RVA: 0x00158048 File Offset: 0x00158048
		public override void Authenticate()
		{
		}

		// Token: 0x06000514 RID: 1300 RVA: 0x0015A430 File Offset: 0x0015A430
		public override void BeginAuthenticate(HandShakeComplete callback)
		{
			callback(null);
		}
	}
}
