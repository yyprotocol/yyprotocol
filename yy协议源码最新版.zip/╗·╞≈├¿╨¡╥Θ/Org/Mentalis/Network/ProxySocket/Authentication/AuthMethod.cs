﻿using System;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x0200009A RID: 154
	internal abstract class AuthMethod
	{
		// Token: 0x17000110 RID: 272
		// (get) Token: 0x06000509 RID: 1289 RVA: 0x0015A3DC File Offset: 0x0015A3DC
		// (set) Token: 0x0600050A RID: 1290 RVA: 0x0015A3E4 File Offset: 0x0015A3E4
		protected Socket Server
		{
			get
			{
				return this.socket_0;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.socket_0 = value;
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x0600050B RID: 1291 RVA: 0x0015A3F6 File Offset: 0x0015A3F6
		// (set) Token: 0x0600050C RID: 1292 RVA: 0x0015A3FE File Offset: 0x0015A3FE
		protected byte[] Buffer
		{
			get
			{
				return this.byte_0;
			}
			set
			{
				this.byte_0 = value;
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x0600050D RID: 1293 RVA: 0x0015A407 File Offset: 0x0015A407
		// (set) Token: 0x0600050E RID: 1294 RVA: 0x0015A40F File Offset: 0x0015A40F
		protected int Received
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x0600050F RID: 1295 RVA: 0x0015A418 File Offset: 0x0015A418
		public AuthMethod(Socket server)
		{
			this.Server = server;
		}

		// Token: 0x06000510 RID: 1296
		public abstract void Authenticate();

		// Token: 0x06000511 RID: 1297
		public abstract void BeginAuthenticate(HandShakeComplete callback);

		// Token: 0x040003E9 RID: 1001
		private byte[] byte_0;

		// Token: 0x040003EA RID: 1002
		private Socket socket_0;

		// Token: 0x040003EB RID: 1003
		protected HandShakeComplete CallBack;

		// Token: 0x040003EC RID: 1004
		private int int_0;
	}
}
