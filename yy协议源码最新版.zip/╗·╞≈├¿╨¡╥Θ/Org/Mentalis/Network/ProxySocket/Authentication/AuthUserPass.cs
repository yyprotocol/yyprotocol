﻿using System;
using System.Net.Sockets;
using System.Text;

namespace Org.Mentalis.Network.ProxySocket.Authentication
{
	// Token: 0x0200009C RID: 156
	internal sealed class AuthUserPass : AuthMethod
	{
		// Token: 0x06000515 RID: 1301 RVA: 0x0015A439 File Offset: 0x0015A439
		public AuthUserPass(Socket server, string user, string pass) : base(server)
		{
			this.Username(user);
			this.Password(pass);
		}

		// Token: 0x06000516 RID: 1302 RVA: 0x00170B6C File Offset: 0x00170B6C
		private byte[] method_0()
		{
			byte[] array = new byte[3 + this.method_4().Length + this.method_6().Length];
			array[0] = 1;
			array[1] = (byte)this.method_4().Length;
			Array.Copy(Encoding.ASCII.GetBytes(this.method_4()), 0, array, 2, this.method_4().Length);
			array[this.method_4().Length + 2] = (byte)this.method_6().Length;
			Array.Copy(Encoding.ASCII.GetBytes(this.method_6()), 0, array, this.method_4().Length + 3, this.method_6().Length);
			return array;
		}

		// Token: 0x06000517 RID: 1303 RVA: 0x0015A450 File Offset: 0x0015A450
		private int method_1()
		{
			return 3 + this.method_4().Length + this.method_6().Length;
		}

		// Token: 0x06000518 RID: 1304 RVA: 0x00170C1C File Offset: 0x00170C1C
		public override void Authenticate()
		{
			if (base.Server.Send(this.method_0()) < this.method_1())
			{
				throw new SocketException(10054);
			}
			byte[] array = new byte[2];
			int num2;
			for (int num = 0; num != 2; num += num2)
			{
				num2 = base.Server.Receive(array, num, 2 - num, SocketFlags.None);
				if (num2 == 0)
				{
					throw new SocketException(10054);
				}
			}
			if (array[1] != 0)
			{
				base.Server.Close();
				throw new ProxyException("Username/password combination rejected.");
			}
		}

		// Token: 0x06000519 RID: 1305 RVA: 0x0015A46B File Offset: 0x0015A46B
		public override void BeginAuthenticate(HandShakeComplete callback)
		{
			this.CallBack = callback;
			base.Server.BeginSend(this.method_0(), 0, this.method_1(), SocketFlags.None, new AsyncCallback(this.method_2), base.Server);
		}

		// Token: 0x0600051A RID: 1306 RVA: 0x00170C9C File Offset: 0x00170C9C
		private void method_2(IAsyncResult iasyncResult_0)
		{
			try
			{
				if (base.Server.EndSend(iasyncResult_0) < this.method_1())
				{
					throw new SocketException(10054);
				}
				base.Buffer = new byte[2];
				base.Server.BeginReceive(base.Buffer, 0, 2, SocketFlags.None, new AsyncCallback(this.method_3), base.Server);
			}
			catch (Exception error)
			{
				this.CallBack(error);
			}
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00170D1C File Offset: 0x00170D1C
		private void method_3(IAsyncResult iasyncResult_0)
		{
			try
			{
				int num = base.Server.EndReceive(iasyncResult_0);
				if (num <= 0)
				{
					throw new SocketException(10054);
				}
				base.Received += num;
				if (base.Received == base.Buffer.Length)
				{
					if (base.Buffer[1] != 0)
					{
						throw new ProxyException("Username/password combination not accepted.");
					}
					this.CallBack(null);
				}
				else
				{
					base.Server.BeginReceive(base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.method_3), base.Server);
				}
			}
			catch (Exception error)
			{
				this.CallBack(error);
			}
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x0015A4A0 File Offset: 0x0015A4A0
		private string method_4()
		{
			return this.string_0;
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x0015A4A8 File Offset: 0x0015A4A8
		private void Username(string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException();
			}
			this.string_0 = value;
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x0015A4BA File Offset: 0x0015A4BA
		private string method_6()
		{
			return this.string_1;
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0015A4C2 File Offset: 0x0015A4C2
		private void Password(string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException();
			}
			this.string_1 = value;
		}

		// Token: 0x040003ED RID: 1005
		private string string_0;

		// Token: 0x040003EE RID: 1006
		private string string_1;
	}
}
