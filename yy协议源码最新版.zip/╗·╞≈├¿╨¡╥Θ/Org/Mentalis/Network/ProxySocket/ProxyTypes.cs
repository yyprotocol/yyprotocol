﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000096 RID: 150
	public enum ProxyTypes
	{
		// Token: 0x040003DD RID: 989
		None,
		// Token: 0x040003DE RID: 990
		Https,
		// Token: 0x040003DF RID: 991
		Socks4,
		// Token: 0x040003E0 RID: 992
		Socks5
	}
}
