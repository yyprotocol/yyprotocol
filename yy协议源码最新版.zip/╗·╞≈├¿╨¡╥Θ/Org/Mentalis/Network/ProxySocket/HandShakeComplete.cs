﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000091 RID: 145
	// (Invoke) Token: 0x0600049A RID: 1178
	internal delegate void HandShakeComplete(Exception error);
}
