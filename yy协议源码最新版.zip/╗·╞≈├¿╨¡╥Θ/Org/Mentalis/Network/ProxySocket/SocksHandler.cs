﻿using System;
using System.Net;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000099 RID: 153
	internal abstract class SocksHandler
	{
		// Token: 0x1700010B RID: 267
		// (get) Token: 0x060004F5 RID: 1269 RVA: 0x0015A325 File Offset: 0x0015A325
		// (set) Token: 0x060004F6 RID: 1270 RVA: 0x0015A32D File Offset: 0x0015A32D
		protected Socket Server
		{
			get
			{
				return this.socket_0;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.socket_0 = value;
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x060004F7 RID: 1271 RVA: 0x0015A33F File Offset: 0x0015A33F
		// (set) Token: 0x060004F8 RID: 1272 RVA: 0x0015A347 File Offset: 0x0015A347
		protected string Username
		{
			get
			{
				return this.string_0;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.string_0 = value;
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x060004F9 RID: 1273 RVA: 0x0015A359 File Offset: 0x0015A359
		// (set) Token: 0x060004FA RID: 1274 RVA: 0x0015A361 File Offset: 0x0015A361
		protected IAsyncProxyResult AsyncResult
		{
			get
			{
				return this.iasyncProxyResult_0;
			}
			set
			{
				this.iasyncProxyResult_0 = value;
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x060004FB RID: 1275 RVA: 0x0015A36A File Offset: 0x0015A36A
		// (set) Token: 0x060004FC RID: 1276 RVA: 0x0015A372 File Offset: 0x0015A372
		protected byte[] Buffer
		{
			get
			{
				return this.byte_0;
			}
			set
			{
				this.byte_0 = value;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x060004FD RID: 1277 RVA: 0x0015A37B File Offset: 0x0015A37B
		// (set) Token: 0x060004FE RID: 1278 RVA: 0x0015A383 File Offset: 0x0015A383
		protected int Received
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x0015A38C File Offset: 0x0015A38C
		public SocksHandler(Socket server, string user)
		{
			this.Server = server;
			this.Username = user;
		}

		// Token: 0x06000500 RID: 1280 RVA: 0x0015A3A2 File Offset: 0x0015A3A2
		protected byte[] PortToBytes(int port)
		{
			return new byte[]
			{
				(byte)(port / 256),
				(byte)(port % 256)
			};
		}

		// Token: 0x06000501 RID: 1281 RVA: 0x00170A80 File Offset: 0x00170A80
		protected byte[] AddressToBytes(long address)
		{
			return new byte[]
			{
				(byte)(address % 256L),
				(byte)(address / 256L % 256L),
				(byte)(address / 65536L % 256L),
				(byte)(address / 16777216L)
			};
		}

		// Token: 0x06000502 RID: 1282 RVA: 0x00170AE4 File Offset: 0x00170AE4
		protected byte[] ReadBytes(int count)
		{
			if (count <= 0)
			{
				throw new ArgumentException();
			}
			byte[] array = new byte[count];
			int num2;
			for (int num = 0; num != count; num += num2)
			{
				num2 = this.Server.Receive(array, num, count - num, SocketFlags.None);
				if (num2 == 0)
				{
					throw new SocketException(10054);
				}
			}
			return array;
		}

		// Token: 0x06000503 RID: 1283 RVA: 0x00170B34 File Offset: 0x00170B34
		protected void HandleEndReceive(IAsyncResult ar)
		{
			int num = this.Server.EndReceive(ar);
			if (num <= 0)
			{
				throw new SocketException(10054);
			}
			this.Received += num;
		}

		// Token: 0x06000504 RID: 1284 RVA: 0x0015A3C0 File Offset: 0x0015A3C0
		protected void HandleEndSend(IAsyncResult ar, int expectedLength)
		{
			if (this.Server.EndSend(ar) < expectedLength)
			{
				throw new SocketException(10054);
			}
		}

		// Token: 0x06000505 RID: 1285
		public abstract void Negotiate(string host, int port);

		// Token: 0x06000506 RID: 1286
		public abstract void Negotiate(IPEndPoint remoteEP);

		// Token: 0x06000507 RID: 1287
		public abstract IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint);

		// Token: 0x06000508 RID: 1288
		public abstract IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint);

		// Token: 0x040003E3 RID: 995
		private Socket socket_0;

		// Token: 0x040003E4 RID: 996
		private string string_0;

		// Token: 0x040003E5 RID: 997
		private IAsyncProxyResult iasyncProxyResult_0;

		// Token: 0x040003E6 RID: 998
		private byte[] byte_0;

		// Token: 0x040003E7 RID: 999
		private int int_0;

		// Token: 0x040003E8 RID: 1000
		protected HandShakeComplete ProtocolComplete;
	}
}
