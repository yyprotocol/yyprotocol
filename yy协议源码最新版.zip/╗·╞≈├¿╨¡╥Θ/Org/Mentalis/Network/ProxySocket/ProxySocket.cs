﻿using System;
using System.Net;
using System.Net.Sockets;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000095 RID: 149
	public class ProxySocket : Socket
	{
		// Token: 0x17000107 RID: 263
		// (get) Token: 0x060004B7 RID: 1207 RVA: 0x0015A12E File Offset: 0x0015A12E
		// (set) Token: 0x060004B8 RID: 1208 RVA: 0x0015A136 File Offset: 0x0015A136
		public IPEndPoint ProxyEndPoint
		{
			get
			{
				return this.ipendPoint_0;
			}
			set
			{
				this.ipendPoint_0 = value;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x060004B9 RID: 1209 RVA: 0x0015A13F File Offset: 0x0015A13F
		// (set) Token: 0x060004BA RID: 1210 RVA: 0x0015A147 File Offset: 0x0015A147
		public ProxyTypes ProxyType
		{
			get
			{
				return this.proxyTypes_0;
			}
			set
			{
				this.proxyTypes_0 = value;
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x060004BB RID: 1211 RVA: 0x0015A150 File Offset: 0x0015A150
		// (set) Token: 0x060004BC RID: 1212 RVA: 0x0015A158 File Offset: 0x0015A158
		public string ProxyUser
		{
			get
			{
				return this.string_0;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.string_0 = value;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x060004BD RID: 1213 RVA: 0x0015A16A File Offset: 0x0015A16A
		// (set) Token: 0x060004BE RID: 1214 RVA: 0x0015A172 File Offset: 0x0015A172
		public string ProxyPass
		{
			get
			{
				return this.string_1;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException();
				}
				this.string_1 = value;
			}
		}

		// Token: 0x060004BF RID: 1215 RVA: 0x0015A184 File Offset: 0x0015A184
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType) : this(addressFamily, socketType, protocolType, "")
		{
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0015A194 File Offset: 0x0015A194
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType, string proxyUsername) : this(addressFamily, socketType, protocolType, proxyUsername, "")
		{
		}

		// Token: 0x060004C1 RID: 1217 RVA: 0x0015A1A6 File Offset: 0x0015A1A6
		public ProxySocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType, string proxyUsername, string proxyPassword) : base(addressFamily, socketType, protocolType)
		{
			this.ProxyUser = proxyUsername;
			this.ProxyPass = proxyPassword;
			this.method_8(new InvalidOperationException());
		}

		// Token: 0x060004C2 RID: 1218 RVA: 0x0016F990 File Offset: 0x0016F990
		public new void Connect(EndPoint remoteEP)
		{
			if (remoteEP == null)
			{
				throw new ArgumentNullException("<remoteEP> cannot be null.");
			}
			if (base.ProtocolType == ProtocolType.Tcp && this.ProxyType != ProxyTypes.None && this.ProxyEndPoint != null)
			{
				base.Connect(this.ProxyEndPoint);
				if (this.ProxyType == ProxyTypes.Https)
				{
					new HttpsHandler(this, this.ProxyUser, this.ProxyPass).Negotiate((IPEndPoint)remoteEP);
					return;
				}
				if (this.ProxyType == ProxyTypes.Socks4)
				{
					new Socks4Handler(this, this.ProxyUser).Negotiate((IPEndPoint)remoteEP);
					return;
				}
				if (this.ProxyType == ProxyTypes.Socks5)
				{
					new Socks5Handler(this, this.ProxyUser, this.ProxyPass).Negotiate((IPEndPoint)remoteEP);
					return;
				}
			}
			else
			{
				base.Connect(remoteEP);
			}
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0016FA4C File Offset: 0x0016FA4C
		public new void Connect(string host, int port)
		{
			if (host == null)
			{
				throw new ArgumentNullException("<host> cannot be null.");
			}
			if (port > 0 && port <= 65535)
			{
				if (base.ProtocolType == ProtocolType.Tcp && this.ProxyType != ProxyTypes.None && this.ProxyEndPoint != null)
				{
					base.Connect(this.ProxyEndPoint);
					if (this.ProxyType == ProxyTypes.Https)
					{
						new HttpsHandler(this, this.ProxyUser, this.ProxyPass).Negotiate(host, port);
						return;
					}
					if (this.ProxyType == ProxyTypes.Socks4)
					{
						new Socks4Handler(this, this.ProxyUser).Negotiate(host, port);
						return;
					}
					if (this.ProxyType == ProxyTypes.Socks5)
					{
						new Socks5Handler(this, this.ProxyUser, this.ProxyPass).Negotiate(host, port);
						return;
					}
				}
				else
				{
					base.Connect(new IPEndPoint(Dns.GetHostEntry(host).AddressList[0], port));
				}
				return;
			}
			throw new ArgumentException("Invalid port.");
		}

		// Token: 0x060004C4 RID: 1220 RVA: 0x0016FB28 File Offset: 0x0016FB28
		public new IAsyncResult BeginConnect(EndPoint remoteEP, AsyncCallback callback, object state)
		{
			if (remoteEP == null)
			{
				throw new ArgumentNullException();
			}
			if (base.ProtocolType != ProtocolType.Tcp || this.ProxyType == ProxyTypes.None || this.ProxyEndPoint == null)
			{
				return base.BeginConnect(remoteEP, callback, state);
			}
			this.asyncCallback_0 = callback;
			if (this.ProxyType == ProxyTypes.Https)
			{
				this.method_6(new HttpsHandler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate((IPEndPoint)remoteEP, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			if (this.ProxyType == ProxyTypes.Socks4)
			{
				this.method_6(new Socks4Handler(this, this.ProxyUser).BeginNegotiate((IPEndPoint)remoteEP, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			if (this.ProxyType == ProxyTypes.Socks5)
			{
				this.method_6(new Socks5Handler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate((IPEndPoint)remoteEP, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			return null;
		}

		// Token: 0x060004C5 RID: 1221 RVA: 0x0016FC3C File Offset: 0x0016FC3C
		public new IAsyncResult BeginConnect(string host, int port, AsyncCallback callback, object state)
		{
			if (host == null)
			{
				throw new ArgumentNullException();
			}
			if (port <= 0 || port > 65535)
			{
				throw new ArgumentException();
			}
			this.asyncCallback_0 = callback;
			if (base.ProtocolType != ProtocolType.Tcp || this.ProxyType == ProxyTypes.None || this.ProxyEndPoint == null)
			{
				this.method_10(port);
				this.method_6(this.BeginDns(host, new HandShakeComplete(this.method_2)));
				return this.method_5();
			}
			if (this.ProxyType == ProxyTypes.Https)
			{
				this.method_6(new HttpsHandler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate(host, port, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			if (this.ProxyType == ProxyTypes.Socks4)
			{
				this.method_6(new Socks4Handler(this, this.ProxyUser).BeginNegotiate(host, port, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			if (this.ProxyType == ProxyTypes.Socks5)
			{
				this.method_6(new Socks5Handler(this, this.ProxyUser, this.ProxyPass).BeginNegotiate(host, port, new HandShakeComplete(this.method_2), this.ProxyEndPoint));
				return this.method_5();
			}
			return null;
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0015A1CC File Offset: 0x0015A1CC
		public new void EndConnect(IAsyncResult asyncResult)
		{
			if (asyncResult == null)
			{
				throw new ArgumentNullException();
			}
			if (!(asyncResult is IAsyncProxyResult))
			{
				base.EndConnect(asyncResult);
				return;
			}
			if (!asyncResult.IsCompleted)
			{
				asyncResult.AsyncWaitHandle.WaitOne();
			}
			if (this.method_7() != null)
			{
				throw this.method_7();
			}
		}

		// Token: 0x060004C7 RID: 1223 RVA: 0x0016FD78 File Offset: 0x0016FD78
		internal IAsyncProxyResult BeginDns(string host, HandShakeComplete callback)
		{
			IAsyncProxyResult result;
			try
			{
				Dns.BeginGetHostEntry(host, new AsyncCallback(this.method_0), this);
				result = new IAsyncProxyResult(null);
			}
			catch
			{
				throw new SocketException();
			}
			return result;
		}

		// Token: 0x060004C8 RID: 1224 RVA: 0x0016FDBC File Offset: 0x0016FDBC
		private void method_0(IAsyncResult iasyncResult_0)
		{
			try
			{
				IPHostEntry iphostEntry = Dns.EndGetHostEntry(iasyncResult_0);
				base.BeginConnect(new IPEndPoint(iphostEntry.AddressList[0], this.method_9()), new AsyncCallback(this.method_1), this.method_3());
			}
			catch (Exception exception_)
			{
				this.method_2(exception_);
			}
		}

		// Token: 0x060004C9 RID: 1225 RVA: 0x0016FE18 File Offset: 0x0016FE18
		private void method_1(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.EndConnect(iasyncResult_0);
				this.method_2(null);
			}
			catch (Exception exception_)
			{
				this.method_2(exception_);
			}
		}

		// Token: 0x060004CA RID: 1226 RVA: 0x0015A20A File Offset: 0x0015A20A
		private void method_2(Exception exception_1)
		{
			if (exception_1 != null)
			{
				base.Close();
			}
			this.method_8(exception_1);
			this.method_5().Reset();
			if (this.asyncCallback_0 != null)
			{
				this.asyncCallback_0(this.method_5());
			}
		}

		// Token: 0x060004CB RID: 1227 RVA: 0x0015A240 File Offset: 0x0015A240
		private object method_3()
		{
			return this.object_0;
		}

		// Token: 0x060004CC RID: 1228 RVA: 0x0015A248 File Offset: 0x0015A248
		private void method_4(object value)
		{
			this.object_0 = value;
		}

		// Token: 0x060004CD RID: 1229 RVA: 0x0015A251 File Offset: 0x0015A251
		private IAsyncProxyResult method_5()
		{
			return this.zoSqudwCqh;
		}

		// Token: 0x060004CE RID: 1230 RVA: 0x0015A259 File Offset: 0x0015A259
		private void method_6(IAsyncProxyResult value)
		{
			this.zoSqudwCqh = value;
		}

		// Token: 0x060004CF RID: 1231 RVA: 0x0015A262 File Offset: 0x0015A262
		private Exception method_7()
		{
			return this.exception_0;
		}

		// Token: 0x060004D0 RID: 1232 RVA: 0x0015A26A File Offset: 0x0015A26A
		private void method_8(Exception value)
		{
			this.exception_0 = value;
		}

		// Token: 0x060004D1 RID: 1233 RVA: 0x0015A273 File Offset: 0x0015A273
		private int method_9()
		{
			return this.int_0;
		}

		// Token: 0x060004D2 RID: 1234 RVA: 0x0015A27B File Offset: 0x0015A27B
		private void method_10(int value)
		{
			this.int_0 = value;
		}

		// Token: 0x040003D3 RID: 979
		private object object_0;

		// Token: 0x040003D4 RID: 980
		private IPEndPoint ipendPoint_0;

		// Token: 0x040003D5 RID: 981
		private ProxyTypes proxyTypes_0;

		// Token: 0x040003D6 RID: 982
		private string string_0;

		// Token: 0x040003D7 RID: 983
		private string string_1;

		// Token: 0x040003D8 RID: 984
		private AsyncCallback asyncCallback_0;

		// Token: 0x040003D9 RID: 985
		private IAsyncProxyResult zoSqudwCqh;

		// Token: 0x040003DA RID: 986
		private Exception exception_0;

		// Token: 0x040003DB RID: 987
		private int int_0;
	}
}
