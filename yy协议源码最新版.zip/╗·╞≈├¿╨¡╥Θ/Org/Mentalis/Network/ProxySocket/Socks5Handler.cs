﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Org.Mentalis.Network.ProxySocket.Authentication;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000098 RID: 152
	internal sealed class Socks5Handler : SocksHandler
	{
		// Token: 0x060004DE RID: 1246 RVA: 0x0015A2AD File Offset: 0x0015A2AD
		public Socks5Handler(Socket server) : this(server, "")
		{
		}

		// Token: 0x060004DF RID: 1247 RVA: 0x0015A2BB File Offset: 0x0015A2BB
		public Socks5Handler(Socket server, string user) : this(server, user, "")
		{
		}

		// Token: 0x060004E0 RID: 1248 RVA: 0x0015A2CA File Offset: 0x0015A2CA
		public Socks5Handler(Socket server, string user, string pass) : base(server, user)
		{
			this.method_13(pass);
		}

		// Token: 0x060004E1 RID: 1249 RVA: 0x001702A8 File Offset: 0x001702A8
		private void method_0()
		{
			if (base.Server.Send(new byte[]
			{
				5,
				2,
				0,
				2
			}) < 4)
			{
				throw new SocketException(10054);
			}
			byte[] array = base.ReadBytes(2);
			if (array[1] == 255)
			{
				throw new ProxyException("No authentication method accepted.");
			}
			byte b = array[1];
			AuthMethod authMethod;
			if (b != 0)
			{
				if (b != 2)
				{
					throw new ProtocolViolationException();
				}
				authMethod = new AuthUserPass(base.Server, base.Username, this.method_12());
			}
			else
			{
				authMethod = new AuthNone(base.Server);
			}
			authMethod.Authenticate();
		}

		// Token: 0x060004E2 RID: 1250 RVA: 0x0017033C File Offset: 0x0017033C
		private byte[] method_1(string string_2, int int_1)
		{
			if (string_2 == null)
			{
				throw new ArgumentNullException();
			}
			if (int_1 <= 0 || int_1 > 65535 || string_2.Length > 255)
			{
				throw new ArgumentException();
			}
			byte[] array = new byte[7 + string_2.Length];
			array[0] = 5;
			array[1] = 1;
			array[2] = 0;
			array[3] = 3;
			array[4] = (byte)string_2.Length;
			Array.Copy(Encoding.ASCII.GetBytes(string_2), 0, array, 5, string_2.Length);
			Array.Copy(base.PortToBytes(int_1), 0, array, string_2.Length + 5, 2);
			return array;
		}

		// Token: 0x060004E3 RID: 1251 RVA: 0x001703CC File Offset: 0x001703CC
		private byte[] method_2(IPEndPoint ipendPoint_0)
		{
			if (ipendPoint_0 == null)
			{
				throw new ArgumentNullException();
			}
			byte[] array = new byte[]
			{
				5,
				1,
				0,
				1,
				0,
				0,
				0,
				0,
				0,
				0
			};
			Array.Copy(ipendPoint_0.Address.GetAddressBytes(), 0, array, 4, 4);
			Array.Copy(base.PortToBytes(ipendPoint_0.Port), 0, array, 8, 2);
			return array;
		}

		// Token: 0x060004E4 RID: 1252 RVA: 0x0015A2DB File Offset: 0x0015A2DB
		public override void Negotiate(string host, int port)
		{
			this.method_3(this.method_1(host, port));
		}

		// Token: 0x060004E5 RID: 1253 RVA: 0x0015A2EB File Offset: 0x0015A2EB
		public override void Negotiate(IPEndPoint remoteEP)
		{
			this.method_3(this.method_2(remoteEP));
		}

		// Token: 0x060004E6 RID: 1254 RVA: 0x00170420 File Offset: 0x00170420
		private void method_3(byte[] byte_2)
		{
			this.method_0();
			if (base.Server.Send(byte_2) < byte_2.Length)
			{
				throw new SocketException(10054);
			}
			byte[] array = base.ReadBytes(4);
			if (array[1] != 0)
			{
				base.Server.Close();
				throw new ProxyException((int)array[1]);
			}
			switch (array[3])
			{
			case 1:
				base.ReadBytes(6);
				return;
			case 3:
				array = base.ReadBytes(1);
				base.ReadBytes((int)(array[0] + 2));
				return;
			case 4:
				base.ReadBytes(18);
				return;
			}
			base.Server.Close();
			throw new ProtocolViolationException();
		}

		// Token: 0x060004E7 RID: 1255 RVA: 0x001704C8 File Offset: 0x001704C8
		public override IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			this.BdyqsvugsT(this.method_1(host, port));
			base.Server.BeginConnect(proxyEndPoint, new AsyncCallback(this.method_4), base.Server);
			base.AsyncResult = new IAsyncProxyResult(null);
			return base.AsyncResult;
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x0017051C File Offset: 0x0017051C
		public override IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			this.BdyqsvugsT(this.method_2(remoteEP));
			base.Server.BeginConnect(proxyEndPoint, new AsyncCallback(this.method_4), base.Server);
			base.AsyncResult = new IAsyncProxyResult(null);
			return base.AsyncResult;
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x00170570 File Offset: 0x00170570
		private void method_4(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.Server.EndConnect(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Server.BeginSend(new byte[]
				{
					5,
					2,
					0,
					2
				}, 0, 4, SocketFlags.None, new AsyncCallback(this.method_5), base.Server);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x001705FC File Offset: 0x001705FC
		private void method_5(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndSend(iasyncResult_0, 4);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Buffer = new byte[1024];
				base.Received = 0;
				base.Server.BeginReceive(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_6), base.Server);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x00170698 File Offset: 0x00170698
		private void method_6(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				if (base.Received < 2)
				{
					base.Server.BeginReceive(base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.method_6), base.Server);
				}
				else
				{
					byte b = base.Buffer[1];
					AuthMethod authMethod;
					if (b != 0)
					{
						if (b != 2)
						{
							this.ProtocolComplete(new SocketException());
							return;
						}
						authMethod = new AuthUserPass(base.Server, base.Username, this.method_12());
					}
					else
					{
						authMethod = new AuthNone(base.Server);
					}
					authMethod.BeginAuthenticate(new HandShakeComplete(this.method_7));
				}
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x00170790 File Offset: 0x00170790
		private void method_7(Exception exception_0)
		{
			if (exception_0 == null)
			{
				try
				{
					base.Server.BeginSend(this.method_14(), 0, this.method_14().Length, SocketFlags.None, new AsyncCallback(this.method_8), base.Server);
					return;
				}
				catch (Exception error)
				{
					this.ProtocolComplete(error);
					return;
				}
			}
			this.ProtocolComplete(exception_0);
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x001707FC File Offset: 0x001707FC
		private void method_8(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndSend(iasyncResult_0, this.method_14().Length);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Buffer = new byte[5];
				base.Received = 0;
				base.Server.BeginReceive(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_9), base.Server);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x00170898 File Offset: 0x00170898
		private void method_9(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				if (base.Received == base.Buffer.Length)
				{
					this.method_10(base.Buffer);
				}
				else
				{
					base.Server.BeginReceive(base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.method_9), base.Server);
				}
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x00170944 File Offset: 0x00170944
		private void method_10(byte[] byte_2)
		{
			switch (byte_2[3])
			{
			case 1:
				base.Buffer = new byte[5];
				goto IL_4D;
			case 3:
				base.Buffer = new byte[(int)(byte_2[4] + 2)];
				goto IL_4D;
			case 4:
				byte_2 = new byte[17];
				goto IL_4D;
			}
			throw new ProtocolViolationException();
			IL_4D:
			base.Received = 0;
			base.Server.BeginReceive(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_11), base.Server);
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x001709D4 File Offset: 0x001709D4
		private void method_11(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				if (base.Received == base.Buffer.Length)
				{
					this.ProtocolComplete(null);
				}
				else
				{
					base.Server.BeginReceive(base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.method_11), base.Server);
				}
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x0015A2FA File Offset: 0x0015A2FA
		private string method_12()
		{
			return this.string_1;
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x0015A302 File Offset: 0x0015A302
		private void method_13(string value)
		{
			if (value == null)
			{
				throw new ArgumentNullException();
			}
			this.string_1 = value;
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0015A314 File Offset: 0x0015A314
		private byte[] method_14()
		{
			return this.byte_1;
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x0015A31C File Offset: 0x0015A31C
		private void BdyqsvugsT(byte[] value)
		{
			this.byte_1 = value;
		}

		// Token: 0x040003E1 RID: 993
		private string string_1;

		// Token: 0x040003E2 RID: 994
		private byte[] byte_1;
	}
}
