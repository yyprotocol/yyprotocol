﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000097 RID: 151
	internal sealed class Socks4Handler : SocksHandler
	{
		// Token: 0x060004D3 RID: 1235 RVA: 0x0015A284 File Offset: 0x0015A284
		public Socks4Handler(Socket server, string user) : base(server, user)
		{
		}

		// Token: 0x060004D4 RID: 1236 RVA: 0x0016FE50 File Offset: 0x0016FE50
		private byte[] method_0(string string_1, int int_1)
		{
			if (string_1 == null)
			{
				throw new ArgumentNullException();
			}
			if (int_1 <= 0 || int_1 > 65535)
			{
				throw new ArgumentException();
			}
			byte[] array = new byte[10 + base.Username.Length + string_1.Length];
			array[0] = 4;
			array[1] = 1;
			Array.Copy(base.PortToBytes(int_1), 0, array, 2, 2);
			byte[] array2 = array;
			byte[] array3 = array;
			array[6] = 0;
			array3[5] = 0;
			array2[4] = 0;
			array[7] = 1;
			Array.Copy(Encoding.ASCII.GetBytes(base.Username), 0, array, 8, base.Username.Length);
			array[8 + base.Username.Length] = 0;
			Array.Copy(Encoding.ASCII.GetBytes(string_1), 0, array, 9 + base.Username.Length, string_1.Length);
			array[9 + base.Username.Length + string_1.Length] = 0;
			return array;
		}

		// Token: 0x060004D5 RID: 1237 RVA: 0x0016FF34 File Offset: 0x0016FF34
		private byte[] method_1(IPEndPoint ipendPoint_0)
		{
			if (ipendPoint_0 == null)
			{
				throw new ArgumentNullException();
			}
			byte[] array = new byte[9 + base.Username.Length];
			array[0] = 4;
			array[1] = 1;
			Array.Copy(base.PortToBytes(ipendPoint_0.Port), 0, array, 2, 2);
			Array.Copy(ipendPoint_0.Address.GetAddressBytes(), 0, array, 4, 4);
			Array.Copy(Encoding.ASCII.GetBytes(base.Username), 0, array, 8, base.Username.Length);
			array[8 + base.Username.Length] = 0;
			return array;
		}

		// Token: 0x060004D6 RID: 1238 RVA: 0x0015A28E File Offset: 0x0015A28E
		public override void Negotiate(string host, int port)
		{
			this.method_2(this.method_0(host, port));
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x0015A29E File Offset: 0x0015A29E
		public override void Negotiate(IPEndPoint remoteEP)
		{
			this.method_2(this.method_1(remoteEP));
		}

		// Token: 0x060004D8 RID: 1240 RVA: 0x0016FFC4 File Offset: 0x0016FFC4
		private void method_2(byte[] byte_1)
		{
			if (byte_1 == null)
			{
				throw new ArgumentNullException();
			}
			if (byte_1.Length < 2)
			{
				throw new ArgumentException();
			}
			if (base.Server.Send(byte_1) < byte_1.Length)
			{
				throw new SocketException(10054);
			}
			if (base.ReadBytes(8)[1] != 90)
			{
				base.Server.Close();
				throw new ProxyException("Negotiation failed.");
			}
		}

		// Token: 0x060004D9 RID: 1241 RVA: 0x00170028 File Offset: 0x00170028
		public override IAsyncProxyResult BeginNegotiate(string host, int port, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			base.Buffer = this.method_0(host, port);
			base.Server.BeginConnect(proxyEndPoint, new AsyncCallback(this.method_3), base.Server);
			base.AsyncResult = new IAsyncProxyResult(null);
			return base.AsyncResult;
		}

		// Token: 0x060004DA RID: 1242 RVA: 0x0017007C File Offset: 0x0017007C
		public override IAsyncProxyResult BeginNegotiate(IPEndPoint remoteEP, HandShakeComplete callback, IPEndPoint proxyEndPoint)
		{
			this.ProtocolComplete = callback;
			base.Buffer = this.method_1(remoteEP);
			base.Server.BeginConnect(proxyEndPoint, new AsyncCallback(this.method_3), base.Server);
			base.AsyncResult = new IAsyncProxyResult(null);
			return base.AsyncResult;
		}

		// Token: 0x060004DB RID: 1243 RVA: 0x001700D0 File Offset: 0x001700D0
		private void method_3(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.Server.EndConnect(iasyncResult_0);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Server.BeginSend(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_4), base.Server);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004DC RID: 1244 RVA: 0x00170158 File Offset: 0x00170158
		private void method_4(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndSend(iasyncResult_0, base.Buffer.Length);
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
				return;
			}
			try
			{
				base.Buffer = new byte[8];
				base.Received = 0;
				base.Server.BeginReceive(base.Buffer, 0, base.Buffer.Length, SocketFlags.None, new AsyncCallback(this.method_5), base.Server);
			}
			catch (Exception error2)
			{
				this.ProtocolComplete(error2);
			}
		}

		// Token: 0x060004DD RID: 1245 RVA: 0x001701F4 File Offset: 0x001701F4
		private void method_5(IAsyncResult iasyncResult_0)
		{
			try
			{
				base.HandleEndReceive(iasyncResult_0);
				if (base.Received == 8)
				{
					if (base.Buffer[1] == 90)
					{
						this.ProtocolComplete(null);
					}
					else
					{
						base.Server.Close();
						this.ProtocolComplete(new ProxyException("Negotiation failed."));
					}
				}
				else
				{
					base.Server.BeginReceive(base.Buffer, base.Received, base.Buffer.Length - base.Received, SocketFlags.None, new AsyncCallback(this.method_5), base.Server);
				}
			}
			catch (Exception error)
			{
				this.ProtocolComplete(error);
			}
		}
	}
}
