﻿using System;

namespace Org.Mentalis.Network.ProxySocket
{
	// Token: 0x02000094 RID: 148
	[Serializable]
	public class ProxyException : Exception
	{
		// Token: 0x060004B3 RID: 1203 RVA: 0x0015A10A File Offset: 0x0015A10A
		public ProxyException() : this("An error occured while talking to the proxy server.")
		{
		}

		// Token: 0x060004B4 RID: 1204 RVA: 0x0015A117 File Offset: 0x0015A117
		public ProxyException(string message) : base(message)
		{
		}

		// Token: 0x060004B5 RID: 1205 RVA: 0x0015A120 File Offset: 0x0015A120
		public ProxyException(int int_0) : this(ProxyException.Socks5ToString(int_0))
		{
		}

		// Token: 0x060004B6 RID: 1206 RVA: 0x0016F91C File Offset: 0x0016F91C
		public static string Socks5ToString(int int_0)
		{
			switch (int_0)
			{
			case 0:
				return "Connection succeeded.";
			case 1:
				return "General SOCKS server failure.";
			case 2:
				return "Connection not allowed by ruleset.";
			case 3:
				return "Network unreachable.";
			case 4:
				return "Host unreachable.";
			case 5:
				return "Connection refused.";
			case 6:
				return "TTL expired.";
			case 7:
				return "Command not supported.";
			case 8:
				return "Address type not supported.";
			default:
				return "Unspecified SOCKS error.";
			}
		}
	}
}
