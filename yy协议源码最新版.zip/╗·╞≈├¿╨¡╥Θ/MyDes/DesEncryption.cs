﻿using System;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace MyDes
{
	// Token: 0x020000B1 RID: 177
	public class DesEncryption
	{
		// Token: 0x060005E3 RID: 1507 RVA: 0x0017DAC8 File Offset: 0x0017DAC8
		public static string EncryptDES(string encryptString, string encryptKey)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.ASCII.GetBytes(encryptKey.Substring(0, 8));
				byte[] rgbIV = bytes;
				byte[] bytes2 = Encoding.UTF8.GetBytes(encryptString);
				DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateEncryptor(bytes, rgbIV), CryptoStreamMode.Write);
				cryptoStream.Write(bytes2, 0, bytes2.Length);
				cryptoStream.FlushFinalBlock();
				StringBuilder stringBuilder = new StringBuilder();
				foreach (byte b in memoryStream.ToArray())
				{
					stringBuilder.AppendFormat("{0:X2}", b);
				}
				stringBuilder.ToString();
				result = stringBuilder.ToString();
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060005E4 RID: 1508 RVA: 0x0017DB94 File Offset: 0x0017DB94
		public static string DecryptDES(string decryptString, string decryptKey)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.ASCII.GetBytes(decryptKey);
				byte[] rgbIV = bytes;
				byte[] array = new byte[decryptString.Length / 2];
				for (int i = 0; i < decryptString.Length / 2; i++)
				{
					int num = Convert.ToInt32(decryptString.Substring(i * 2, 2), 16);
					array[i] = (byte)num;
				}
				DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
				MemoryStream memoryStream = new MemoryStream();
				CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateDecryptor(bytes, rgbIV), CryptoStreamMode.Write);
				cryptoStream.Write(array, 0, array.Length);
				cryptoStream.FlushFinalBlock();
				result = Encoding.UTF8.GetString(memoryStream.ToArray());
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060005E5 RID: 1509 RVA: 0x0017DC50 File Offset: 0x0017DC50
		public static DateTime GetBeijingTime()
		{
			WebRequest webRequest = null;
			WebResponse webResponse = null;
			DateTime result;
			try
			{
				webRequest = WebRequest.Create("http://www.time.ac.cn/timeflash.asp?user=flash");
				webRequest.Credentials = CredentialCache.DefaultCredentials;
				webResponse = webRequest.GetResponse();
				StreamReader streamReader = new StreamReader(webResponse.GetResponseStream(), Encoding.UTF8);
				string text = streamReader.ReadToEnd();
				streamReader.Close();
				webResponse.Close();
				int num = text.IndexOf("<year>") + 6;
				int num2 = text.IndexOf("<month>") + 7;
				int num3 = text.IndexOf("<day>") + 5;
				int num4 = text.IndexOf("<hour>") + 6;
				int num5 = text.IndexOf("<minite>") + 8;
				int num6 = text.IndexOf("<second>") + 8;
				string text2 = text.Substring(num, text.IndexOf("</year>") - num);
				string text3 = text.Substring(num2, text.IndexOf("</month>") - num2);
				string text4 = text.Substring(num3, text.IndexOf("</day>") - num3);
				string text5 = text.Substring(num4, text.IndexOf("</hour>") - num4);
				string text6 = text.Substring(num5, text.IndexOf("</minite>") - num5);
				string text7 = text.Substring(num6, text.IndexOf("</second>") - num6);
				string s = string.Format("{0}-{1}-{2} {3}:{4}:{5}", new object[]
				{
					text2,
					text3,
					text4,
					text5,
					text6,
					text7
				});
				return DateTime.Parse(s);
			}
			catch (WebException)
			{
				result = DateTime.Parse("2011-1-1");
			}
			catch (Exception)
			{
				result = DateTime.Parse("2011-1-1");
			}
			finally
			{
				if (webResponse != null)
				{
					webResponse.Close();
				}
				if (webRequest != null)
				{
					webRequest.Abort();
				}
			}
			return result;
		}
	}
}
