﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace JIQIMAO.Common
{
	// Token: 0x02000083 RID: 131
	public class loghelper
	{
		// Token: 0x06000443 RID: 1091 RVA: 0x0016E2C4 File Offset: 0x0016E2C4
		static loghelper()
		{
			Task.Factory.StartNew(delegate()
			{
				for (;;)
				{
					try
					{
						if (loghelper.concurrentQueue_0.Count > 0)
						{
							logobj logobj;
							loghelper.concurrentQueue_0.TryDequeue(out logobj);
							if (logobj != null)
							{
								loghelper.log(logobj.path, logobj.msg);
							}
						}
					}
					catch
					{
					}
					Thread.Sleep(10);
				}
			});
			Task.Factory.StartNew(delegate()
			{
				for (;;)
				{
					try
					{
						if (loghelper.concurrentQueue_1.Count > 0)
						{
							logobj logobj;
							loghelper.concurrentQueue_1.TryDequeue(out logobj);
							if (logobj != null)
							{
								loghelper.logappend(logobj.path, logobj.msg);
							}
						}
					}
					catch
					{
					}
					Thread.Sleep(10);
				}
			});
		}

		// Token: 0x06000444 RID: 1092 RVA: 0x0016E31C File Offset: 0x0016E31C
		private static void smethod_0(object object_0, object object_1)
		{
			try
			{
				if (loghelper.concurrentQueue_0.Count > 0)
				{
					logobj logobj;
					loghelper.concurrentQueue_0.TryDequeue(out logobj);
					if (logobj != null)
					{
						loghelper.log(logobj.path, logobj.msg);
					}
				}
				if (loghelper.concurrentQueue_1.Count > 0)
				{
					logobj logobj2;
					loghelper.concurrentQueue_1.TryDequeue(out logobj2);
					if (logobj2 != null)
					{
						loghelper.logappend(logobj2.path, logobj2.msg);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000445 RID: 1093 RVA: 0x0016E39C File Offset: 0x0016E39C
		public static void logcacge(string path, string msg)
		{
			try
			{
				loghelper.concurrentQueue_0.Enqueue(new logobj
				{
					path = path,
					msg = msg
				});
			}
			catch
			{
			}
		}

		// Token: 0x06000446 RID: 1094 RVA: 0x0016E3DC File Offset: 0x0016E3DC
		public static void loglogs(string path, string msg)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(path))
				{
					loghelper.concurrentQueue_1.Enqueue(new logobj
					{
						path = path,
						msg = msg
					});
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x0016E424 File Offset: 0x0016E424
		public static void logappend(string path, string msg)
		{
			try
			{
				using (FileStream fileStream = new FileStream(path, FileMode.Append, FileAccess.Write))
				{
					using (StreamWriter streamWriter = new StreamWriter(fileStream))
					{
						streamWriter.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " ---- " + msg);
						streamWriter.Flush();
						streamWriter.Close();
						streamWriter.Dispose();
					}
					fileStream.Close();
					fileStream.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x0016E4C8 File Offset: 0x0016E4C8
		public static bool log(string path, string msg)
		{
			bool result;
			try
			{
				using (FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write))
				{
					using (StreamWriter streamWriter = new StreamWriter(fileStream))
					{
						streamWriter.Write(msg);
						streamWriter.Flush();
						streamWriter.Close();
						streamWriter.Dispose();
					}
					fileStream.Close();
					fileStream.Dispose();
				}
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x040003B0 RID: 944
		private static ConcurrentQueue<logobj> concurrentQueue_0 = new ConcurrentQueue<logobj>();

		// Token: 0x040003B1 RID: 945
		private static ConcurrentQueue<logobj> concurrentQueue_1 = new ConcurrentQueue<logobj>();
	}
}
