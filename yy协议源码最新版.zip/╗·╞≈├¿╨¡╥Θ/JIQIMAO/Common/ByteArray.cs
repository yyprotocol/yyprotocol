﻿using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x02000072 RID: 114
	public class ByteArray : IDisposable
	{
		// Token: 0x170000EC RID: 236
		public byte this[int index]
		{
			get
			{
				if (index < this.length)
				{
					return this.Buffer[index];
				}
				return 0;
			}
			set
			{
				int position = this.position;
				this.position = index;
				if (value.GetType().IsValueType)
				{
					this.writeByte(Convert.ToByte(value));
				}
				this.position = position;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x060003EF RID: 1007 RVA: 0x00159C9A File Offset: 0x00159C9A
		// (set) Token: 0x060003F0 RID: 1008 RVA: 0x00159CA8 File Offset: 0x00159CA8
		public int length
		{
			get
			{
				return (int)this.memoryStream_0.Length;
			}
			set
			{
				this.memoryStream_0.SetLength((long)value);
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x060003F1 RID: 1009 RVA: 0x00159CB7 File Offset: 0x00159CB7
		public int bytesAvailable
		{
			get
			{
				return this.length - this.position;
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x00159CC6 File Offset: 0x00159CC6
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x00159CCE File Offset: 0x00159CCE
		public Endian endian
		{
			get
			{
				return this.endian_0;
			}
			set
			{
				this.endian_0 = value;
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x00159CD7 File Offset: 0x00159CD7
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x00159CE5 File Offset: 0x00159CE5
		public int position
		{
			get
			{
				return (int)this.memoryStream_0.Position;
			}
			set
			{
				this.memoryStream_0.Position = (long)value;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x00159CF4 File Offset: 0x00159CF4
		public byte[] Buffer
		{
			get
			{
				return this.memoryStream_0.ToArray();
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x060003F7 RID: 1015 RVA: 0x00159D01 File Offset: 0x00159D01
		public MemoryStream MemoryStream
		{
			get
			{
				return this.memoryStream_0;
			}
		}

		// Token: 0x060003F8 RID: 1016 RVA: 0x0016D5BC File Offset: 0x0016D5BC
		~ByteArray()
		{
			this.Dispose(false);
		}

		// Token: 0x060003F9 RID: 1017 RVA: 0x0016D5EC File Offset: 0x0016D5EC
		protected virtual void Dispose(bool disposing)
		{
			if (!this.bool_0)
			{
				if (disposing)
				{
					this.memoryStream_0.Close();
					this.memoryStream_0.Dispose();
					this.memoryStream_0 = null;
					this.binaryReader_0.Dispose();
					this.binaryWriter_0.Dispose();
					this.binaryReader_0 = null;
					this.binaryWriter_0 = null;
				}
				this.bool_0 = true;
			}
		}

		// Token: 0x060003FA RID: 1018 RVA: 0x00159D09 File Offset: 0x00159D09
		public void Dispose()
		{
			this.Dispose(true);
			GC.SuppressFinalize(this);
		}

		// Token: 0x060003FB RID: 1019 RVA: 0x00159D18 File Offset: 0x00159D18
		public ByteArray()
		{
			this.memoryStream_0 = new MemoryStream();
			this.method_0();
		}

		// Token: 0x060003FC RID: 1020 RVA: 0x00159D31 File Offset: 0x00159D31
		public ByteArray(MemoryStream ms)
		{
			this.memoryStream_0 = new MemoryStream();
			this.memoryStream_0 = ms;
			this.method_0();
		}

		// Token: 0x060003FD RID: 1021 RVA: 0x00159D51 File Offset: 0x00159D51
		public ByteArray(byte[] buffer)
		{
			this.memoryStream_0 = new MemoryStream();
			this.memoryStream_0 = new MemoryStream(buffer);
			this.method_0();
		}

		// Token: 0x060003FE RID: 1022 RVA: 0x00159D76 File Offset: 0x00159D76
		private void method_0()
		{
			this.endian_0 = Endian.BIG_ENDIAN;
			this.binaryWriter_0 = new BinaryWriter(this.memoryStream_0);
			this.binaryReader_0 = new BinaryReader(this.memoryStream_0);
		}

		// Token: 0x060003FF RID: 1023 RVA: 0x0016D64C File Offset: 0x0016D64C
		public void clear()
		{
			long position = this.memoryStream_0.Position;
			this.memoryStream_0.SetLength(0L);
			this.memoryStream_0.Position = position;
		}

		// Token: 0x06000400 RID: 1024 RVA: 0x00159DA1 File Offset: 0x00159DA1
		public bool ReadBoolean()
		{
			return this.binaryReader_0.ReadBoolean();
		}

		// Token: 0x06000401 RID: 1025 RVA: 0x00159DAE File Offset: 0x00159DAE
		public byte readByte()
		{
			return this.binaryReader_0.ReadByte();
		}

		// Token: 0x06000402 RID: 1026 RVA: 0x0016D688 File Offset: 0x0016D688
		public void readBytes(ByteArray bytes, uint offset = 0u, uint length = 0u)
		{
			if (length == 0u)
			{
				length = (uint)this.bytesAvailable;
			}
			byte[] array = this.binaryReader_0.ReadBytes((int)length);
			for (int i = 0; i < array.Length; i++)
			{
				bytes[i + (int)offset] = array[i];
			}
		}

		// Token: 0x06000403 RID: 1027 RVA: 0x00159DBB File Offset: 0x00159DBB
		public double ReadDouble()
		{
			return this.binaryReader_0.ReadDouble();
		}

		// Token: 0x06000404 RID: 1028 RVA: 0x0016D6C8 File Offset: 0x0016D6C8
		public float ReadFloat()
		{
			byte[] array = this.binaryReader_0.ReadBytes(4);
			byte[] array2 = new byte[4];
			int i = 3;
			int num = 0;
			while (i >= 0)
			{
				array2[num] = array[i];
				i--;
				num++;
			}
			return BitConverter.ToSingle(array2, 0);
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00159DC8 File Offset: 0x00159DC8
		public int ReadInt()
		{
			return this.binaryReader_0.ReadInt32();
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00159DD5 File Offset: 0x00159DD5
		public short ReadShort()
		{
			return this.binaryReader_0.ReadInt16();
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00159DAE File Offset: 0x00159DAE
		public byte readUnsignedByte()
		{
			return this.binaryReader_0.ReadByte();
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00159DE2 File Offset: 0x00159DE2
		public uint readUnsignedInt()
		{
			return this.binaryReader_0.ReadUInt32();
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x00159DEF File Offset: 0x00159DEF
		public ushort readUnsignedShort()
		{
			return this.binaryReader_0.ReadUInt16();
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00159DFC File Offset: 0x00159DFC
		public string readUTF()
		{
			return this.binaryReader_0.ReadString();
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x0016D708 File Offset: 0x0016D708
		public string readUTFBytes(uint length)
		{
			if (length == 0u)
			{
				return string.Empty;
			}
			UTF8Encoding utf8Encoding = new UTF8Encoding(false, true);
			byte[] array = this.binaryReader_0.ReadBytes((int)length);
			return utf8Encoding.GetString(array, 0, array.Length);
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00159E09 File Offset: 0x00159E09
		public void writeBoolean(bool value)
		{
			this.binaryWriter_0.BaseStream.WriteByte(value ? 1 : 0);
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x00159E23 File Offset: 0x00159E23
		public void writeByte(byte value)
		{
			this.binaryWriter_0.BaseStream.WriteByte(value);
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0016D740 File Offset: 0x0016D740
		public void writeBytes(byte[] buffer)
		{
			int num = 0;
			while (buffer != null && num < buffer.Length)
			{
				this.binaryWriter_0.BaseStream.WriteByte(buffer[num]);
				num++;
			}
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x0016D774 File Offset: 0x0016D774
		public void writeBytes(byte[] bytes, int offset, int length)
		{
			for (int i = offset; i < offset + length; i++)
			{
				this.binaryWriter_0.BaseStream.WriteByte(bytes[i]);
			}
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x0016D7A4 File Offset: 0x0016D7A4
		public void writeDouble(double value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.method_1(bytes);
		}

		// Token: 0x06000411 RID: 1041 RVA: 0x0016D7C0 File Offset: 0x0016D7C0
		public void writeFloat(float value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.method_1(bytes);
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0016D7DC File Offset: 0x0016D7DC
		private void method_1(byte[] byte_0)
		{
			if (byte_0 != null)
			{
				if (this.endian_0 == Endian.BIG_ENDIAN)
				{
					for (int i = byte_0.Length - 1; i >= 0; i--)
					{
						this.binaryWriter_0.BaseStream.WriteByte(byte_0[i]);
					}
					return;
				}
				for (int j = 0; j < byte_0.Length; j++)
				{
					this.binaryWriter_0.BaseStream.WriteByte(byte_0[j]);
				}
			}
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x0016D83C File Offset: 0x0016D83C
		public void method_2(int value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.method_1(bytes);
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00159E36 File Offset: 0x00159E36
		public void method_3(uint value)
		{
			this.writeUnsignedInt(value);
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00159E3F File Offset: 0x00159E3F
		public void writeInt(int value)
		{
			this.method_2(value);
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0016D858 File Offset: 0x0016D858
		public void writeShort(int value)
		{
			byte[] bytes = BitConverter.GetBytes((ushort)value);
			this.method_1(bytes);
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x0016D874 File Offset: 0x0016D874
		public void writeUnsignedInt(uint value)
		{
			byte[] bytes = BitConverter.GetBytes(value);
			this.method_1(bytes);
		}

		// Token: 0x06000418 RID: 1048 RVA: 0x0016D890 File Offset: 0x0016D890
		public void writeUTF(string value)
		{
			UTF8Encoding utf8Encoding = new UTF8Encoding();
			int byteCount = utf8Encoding.GetByteCount(value);
			byte[] bytes = utf8Encoding.GetBytes(value);
			this.writeShort(byteCount);
			if (bytes.Length != 0)
			{
				this.binaryWriter_0.Write(bytes);
			}
		}

		// Token: 0x06000419 RID: 1049 RVA: 0x0016D8CC File Offset: 0x0016D8CC
		public void writeUTFBytes(string value)
		{
			byte[] bytes = new UTF8Encoding().GetBytes(value);
			if (bytes.Length != 0)
			{
				this.binaryWriter_0.Write(bytes);
			}
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x0016D8F8 File Offset: 0x0016D8F8
		public void Compress()
		{
			byte[] buffer = this.memoryStream_0.GetBuffer();
			DeflateStream deflateStream = new DeflateStream(this.memoryStream_0, CompressionMode.Compress, true);
			deflateStream.Write(buffer, 0, buffer.Length);
			deflateStream.Close();
			this.method_0();
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x0016D938 File Offset: 0x0016D938
		public void Uncompress()
		{
			DeflateStream deflateStream = new DeflateStream(this.memoryStream_0, CompressionMode.Decompress, false);
			MemoryStream memoryStream = new MemoryStream();
			byte[] array = new byte[1024];
			this.memoryStream_0.ReadByte();
			this.memoryStream_0.ReadByte();
			for (;;)
			{
				int num = deflateStream.Read(array, 0, array.Length);
				if (num <= 0)
				{
					break;
				}
				memoryStream.Write(array, 0, num);
			}
			deflateStream.Close();
			this.memoryStream_0.Close();
			this.memoryStream_0.Dispose();
			this.memoryStream_0 = memoryStream;
			this.memoryStream_0.Position = 0L;
			this.method_0();
		}

		// Token: 0x0400035F RID: 863
		private MemoryStream memoryStream_0;

		// Token: 0x04000360 RID: 864
		private BinaryReader binaryReader_0;

		// Token: 0x04000361 RID: 865
		private BinaryWriter binaryWriter_0;

		// Token: 0x04000362 RID: 866
		private Endian endian_0;

		// Token: 0x04000363 RID: 867
		private bool bool_0;
	}
}
