﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x02000076 RID: 118
	public class HardwareInfo
	{
		// Token: 0x0600042E RID: 1070 RVA: 0x0016DBC4 File Offset: 0x0016DBC4
		public static string GetInfo()
		{
			StringBuilder stringBuilder = new StringBuilder("tempip");
			List<IPAddress> list = (from ip in Dns.GetHostAddresses(Dns.GetHostName())
			where ip.AddressFamily == AddressFamily.InterNetwork
			select ip).ToList<IPAddress>();
			if (list != null && list.Count > 0)
			{
				using (List<IPAddress>.Enumerator enumerator = list.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						IPAddress ipaddress = enumerator.Current;
						stringBuilder.Append(ipaddress.ToString());
					}
				}
			}
			stringBuilder.Append("LZQ123LMH4QWER");
			stringBuilder.Append(HardwareInfo.GetMacAddress());
			stringBuilder.Append("llz");
			stringBuilder.Append(HardwareInfo.GetHardDiskID());
			stringBuilder.Append("lzq");
			stringBuilder.Append(HardwareInfo.GetCpuID());
			stringBuilder.Append("lmh");
			stringBuilder.Append(HardwareInfo.GetMacAddress());
			stringBuilder.Append("zsn");
			return MyEncryptMacCode.GetMD5(stringBuilder.ToString());
		}

		// Token: 0x0600042F RID: 1071 RVA: 0x0016DCD8 File Offset: 0x0016DCD8
		public static string GetMotherBoardSerialNumber()
		{
			ManagementObjectCollection instances = new ManagementClass("WIN32_BaseBoard").GetInstances();
			string text = "";
			string result;
			using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = instances.GetEnumerator())
			{
				if (enumerator.MoveNext())
				{
					result = ((ManagementObject)enumerator.Current)["SerialNumber"].ToString();
				}
				else
				{
					result = text;
				}
			}
			return result;
		}

		// Token: 0x06000430 RID: 1072 RVA: 0x0016DD48 File Offset: 0x0016DD48
		public static string GetCpuID()
		{
			string result;
			try
			{
				ManagementObjectCollection instances = new ManagementClass("Win32_Processor").GetInstances();
				string text = null;
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = instances.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						text = ((ManagementObject)enumerator.Current).Properties["ProcessorId"].Value.ToString();
					}
				}
				result = text;
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000431 RID: 1073 RVA: 0x0016DDD4 File Offset: 0x0016DDD4
		public static string GetHardDiskID()
		{
			string result;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
				string text = null;
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						text = ((ManagementObject)enumerator.Current)["SerialNumber"].ToString().Trim();
					}
				}
				result = text;
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000432 RID: 1074 RVA: 0x0016DE58 File Offset: 0x0016DE58
		public static string GetMacAddress()
		{
			string text = "";
			try
			{
				HardwareInfo.NCB ncb = default(HardwareInfo.NCB);
				ncb.ncb_command = 55;
				int num = Marshal.SizeOf(typeof(HardwareInfo.LANA_ENUM));
				ncb.ncb_buffer = Marshal.AllocHGlobal(num);
				ncb.ncb_length = (ushort)num;
				char c = HardwareInfo.Win32API.Netbios(ref ncb);
				HardwareInfo.LANA_ENUM lana_ENUM = (HardwareInfo.LANA_ENUM)Marshal.PtrToStructure(ncb.ncb_buffer, typeof(HardwareInfo.LANA_ENUM));
				Marshal.FreeHGlobal(ncb.ncb_buffer);
				if (c != '\0')
				{
					return "";
				}
				for (int i = 0; i < (int)lana_ENUM.length; i++)
				{
					ncb.ncb_command = 50;
					ncb.ncb_lana_num = lana_ENUM.lana[i];
					if (HardwareInfo.Win32API.Netbios(ref ncb) != '\0')
					{
						return "";
					}
					ncb.ncb_command = 51;
					ncb.ncb_lana_num = lana_ENUM.lana[i];
					ncb.ncb_callname[0] = 42;
					num = Marshal.SizeOf(typeof(HardwareInfo.ADAPTER_STATUS)) + Marshal.SizeOf(typeof(HardwareInfo.NAME_BUFFER)) * 30;
					ncb.ncb_buffer = Marshal.AllocHGlobal(num);
					ncb.ncb_length = (ushort)num;
					char c2 = HardwareInfo.Win32API.Netbios(ref ncb);
					HardwareInfo.ASTAT astat = default(HardwareInfo.ASTAT);
					astat.adapt = (HardwareInfo.ADAPTER_STATUS)Marshal.PtrToStructure(ncb.ncb_buffer, typeof(HardwareInfo.ADAPTER_STATUS));
					Marshal.FreeHGlobal(ncb.ncb_buffer);
					if (c2 == '\0')
					{
						if (i > 0)
						{
							text += ":";
						}
						text = string.Format("{0,2:X}{1,2:X}{2,2:X}{3,2:X}{4,2:X}{5,2:X}", new object[]
						{
							astat.adapt.adapter_address[0],
							astat.adapt.adapter_address[1],
							astat.adapt.adapter_address[2],
							astat.adapt.adapter_address[3],
							astat.adapt.adapter_address[4],
							astat.adapt.adapter_address[5]
						});
					}
				}
			}
			catch
			{
			}
			return text.Replace(' ', '0');
		}

		// Token: 0x02000077 RID: 119
		public enum NCBCONST
		{
			// Token: 0x04000372 RID: 882
			NCBNAMSZ = 16,
			// Token: 0x04000373 RID: 883
			MAX_LANA = 254,
			// Token: 0x04000374 RID: 884
			NCBENUM = 55,
			// Token: 0x04000375 RID: 885
			NRC_GOODRET = 0,
			// Token: 0x04000376 RID: 886
			NCBRESET = 50,
			// Token: 0x04000377 RID: 887
			NCBASTAT,
			// Token: 0x04000378 RID: 888
			NUM_NAMEBUF = 30
		}

		// Token: 0x02000078 RID: 120
		public struct ADAPTER_STATUS
		{
			// Token: 0x04000379 RID: 889
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public byte[] adapter_address;

			// Token: 0x0400037A RID: 890
			public byte rev_major;

			// Token: 0x0400037B RID: 891
			public byte reserved0;

			// Token: 0x0400037C RID: 892
			public byte adapter_type;

			// Token: 0x0400037D RID: 893
			public byte rev_minor;

			// Token: 0x0400037E RID: 894
			public ushort duration;

			// Token: 0x0400037F RID: 895
			public ushort frmr_recv;

			// Token: 0x04000380 RID: 896
			public ushort frmr_xmit;

			// Token: 0x04000381 RID: 897
			public ushort iframe_recv_err;

			// Token: 0x04000382 RID: 898
			public ushort xmit_aborts;

			// Token: 0x04000383 RID: 899
			public uint xmit_success;

			// Token: 0x04000384 RID: 900
			public uint recv_success;

			// Token: 0x04000385 RID: 901
			public ushort iframe_xmit_err;

			// Token: 0x04000386 RID: 902
			public ushort recv_buff_unavail;

			// Token: 0x04000387 RID: 903
			public ushort t1_timeouts;

			// Token: 0x04000388 RID: 904
			public ushort ti_timeouts;

			// Token: 0x04000389 RID: 905
			public uint reserved1;

			// Token: 0x0400038A RID: 906
			public ushort free_ncbs;

			// Token: 0x0400038B RID: 907
			public ushort max_cfg_ncbs;

			// Token: 0x0400038C RID: 908
			public ushort max_ncbs;

			// Token: 0x0400038D RID: 909
			public ushort xmit_buf_unavail;

			// Token: 0x0400038E RID: 910
			public ushort max_dgram_size;

			// Token: 0x0400038F RID: 911
			public ushort pending_sess;

			// Token: 0x04000390 RID: 912
			public ushort max_cfg_sess;

			// Token: 0x04000391 RID: 913
			public ushort max_sess;

			// Token: 0x04000392 RID: 914
			public ushort max_sess_pkt_size;

			// Token: 0x04000393 RID: 915
			public ushort name_count;
		}

		// Token: 0x02000079 RID: 121
		public struct NAME_BUFFER
		{
			// Token: 0x04000394 RID: 916
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] name;

			// Token: 0x04000395 RID: 917
			public byte name_num;

			// Token: 0x04000396 RID: 918
			public byte name_flags;
		}

		// Token: 0x0200007A RID: 122
		public struct NCB
		{
			// Token: 0x04000397 RID: 919
			public byte ncb_command;

			// Token: 0x04000398 RID: 920
			public byte ncb_retcode;

			// Token: 0x04000399 RID: 921
			public byte ncb_lsn;

			// Token: 0x0400039A RID: 922
			public byte ncb_num;

			// Token: 0x0400039B RID: 923
			public IntPtr ncb_buffer;

			// Token: 0x0400039C RID: 924
			public ushort ncb_length;

			// Token: 0x0400039D RID: 925
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] ncb_callname;

			// Token: 0x0400039E RID: 926
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] ncb_name;

			// Token: 0x0400039F RID: 927
			public byte ncb_rto;

			// Token: 0x040003A0 RID: 928
			public byte ncb_sto;

			// Token: 0x040003A1 RID: 929
			public IntPtr ncb_post;

			// Token: 0x040003A2 RID: 930
			public byte ncb_lana_num;

			// Token: 0x040003A3 RID: 931
			public byte ncb_cmd_cplt;

			// Token: 0x040003A4 RID: 932
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
			public byte[] ncb_reserve;

			// Token: 0x040003A5 RID: 933
			public IntPtr ncb_event;
		}

		// Token: 0x0200007B RID: 123
		public struct LANA_ENUM
		{
			// Token: 0x040003A6 RID: 934
			public byte length;

			// Token: 0x040003A7 RID: 935
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 254)]
			public byte[] lana;
		}

		// Token: 0x0200007C RID: 124
		[StructLayout(LayoutKind.Auto)]
		public struct ASTAT
		{
			// Token: 0x040003A8 RID: 936
			public HardwareInfo.ADAPTER_STATUS adapt;

			// Token: 0x040003A9 RID: 937
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
			public HardwareInfo.NAME_BUFFER[] NameBuff;
		}

		// Token: 0x0200007D RID: 125
		public class Win32API
		{
			// Token: 0x06000434 RID: 1076
			[DllImport("NETAPI32.DLL")]
			public static extern char Netbios(ref HardwareInfo.NCB ncb);
		}
	}
}
