﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Common
{
	// Token: 0x0200008C RID: 140
	public class savewebuser
	{
		// Token: 0x170000FE RID: 254
		// (get) Token: 0x0600047D RID: 1149 RVA: 0x00159FC6 File Offset: 0x00159FC6
		// (set) Token: 0x0600047E RID: 1150 RVA: 0x00159FCE File Offset: 0x00159FCE
		public string username { get; set; }

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600047F RID: 1151 RVA: 0x00159FD7 File Offset: 0x00159FD7
		// (set) Token: 0x06000480 RID: 1152 RVA: 0x00159FDF File Offset: 0x00159FDF
		public string pwd { get; set; }

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x06000481 RID: 1153 RVA: 0x00159FE8 File Offset: 0x00159FE8
		// (set) Token: 0x06000482 RID: 1154 RVA: 0x00159FF0 File Offset: 0x00159FF0
		public string uid { get; set; }

		// Token: 0x040003C6 RID: 966
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040003C7 RID: 967
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040003C8 RID: 968
		[CompilerGenerated]
		private string string_2;
	}
}
