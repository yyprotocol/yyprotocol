﻿using System;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x0200008F RID: 143
	public class xxtea2
	{
		// Token: 0x0600048C RID: 1164 RVA: 0x0016EF44 File Offset: 0x0016EF44
		public static string Encrypt(string source, string key)
		{
			string result;
			try
			{
				Encoding ascii = Encoding.ASCII;
				byte[] bytes = ascii.GetBytes(source);
				byte[] bytes2 = ascii.GetBytes(key);
				if (bytes.Length != 0)
				{
					result = Convert.ToBase64String(xxtea2.smethod_3(xxtea2.smethod_0(xxtea2.smethod_2(bytes, true), xxtea2.smethod_2(bytes2, false)), false));
				}
				else
				{
					result = "";
				}
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0600048D RID: 1165 RVA: 0x0016EFB0 File Offset: 0x0016EFB0
		public static string Decrypt(string source, string key)
		{
			if (source.Length == 0)
			{
				return "";
			}
			Encoding utf = Encoding.UTF8;
			byte[] object_ = Convert.FromBase64String(source);
			byte[] bytes = utf.GetBytes(key);
			return xxtea2.base64Decode(utf.GetString(xxtea2.smethod_3(xxtea2.smethod_1(xxtea2.smethod_2(object_, false), xxtea2.smethod_2(bytes, false)), true)));
		}

		// Token: 0x0600048E RID: 1166 RVA: 0x0016F004 File Offset: 0x0016F004
		private static uint[] smethod_0(object object_0, Array array_0)
		{
			int num = ((Array)object_0).Length - 1;
			if (num < 1)
			{
				return (uint[])object_0;
			}
			if (array_0.Length < 4)
			{
				uint[] array = new uint[4];
				array_0.CopyTo(array, 0);
				array_0 = array;
			}
			uint num2 = ((uint[])object_0)[num];
			uint num3 = 2654435769u;
			uint num4 = 0u;
			int num5 = 6 + 52 / (num + 1);
			while (num5-- > 0)
			{
				num4 += num3;
				uint num6 = num4 >> 2 & 3u;
				int i;
				uint num7;
				for (i = 0; i < num; i++)
				{
					num7 = ((uint[])object_0)[i + 1];
					num2 = (((uint[])object_0)[i] += ((num2 >> 5 ^ num7 << 2) + (num7 >> 3 ^ num2 << 4) ^ (num4 ^ num7) + (((uint[])array_0)[(int)(checked((IntPtr)(unchecked((long)(i & 3) ^ (long)((ulong)num6)))))] ^ num2)));
				}
				num7 = ((uint[])object_0)[0];
				num2 = (((uint[])object_0)[num] += ((num2 >> 5 ^ num7 << 2) + (num7 >> 3 ^ num2 << 4) ^ (num4 ^ num7) + (((uint[])array_0)[(int)(checked((IntPtr)(unchecked((long)(i & 3) ^ (long)((ulong)num6)))))] ^ num2)));
			}
			return (uint[])object_0;
		}

		// Token: 0x0600048F RID: 1167 RVA: 0x0016F134 File Offset: 0x0016F134
		private static uint[] smethod_1(object object_0, Array array_0)
		{
			int num = ((Array)object_0).Length - 1;
			if (num < 1)
			{
				return (uint[])object_0;
			}
			if (array_0.Length < 4)
			{
				uint[] array = new uint[4];
				array_0.CopyTo(array, 0);
				array_0 = array;
			}
			uint num2 = ((uint[])object_0)[0];
			uint num3 = 2654435769u;
			for (uint num4 = (uint)((long)(6 + 52 / (num + 1)) * 2654435769L); num4 != 0u; num4 -= num3)
			{
				uint num5 = num4 >> 2 & 3u;
				int i;
				uint num6;
				for (i = num; i > 0; i--)
				{
					num6 = ((uint[])object_0)[i - 1];
					num2 = (((uint[])object_0)[i] -= ((num6 >> 5 ^ num2 << 2) + (num2 >> 3 ^ num6 << 4) ^ (num4 ^ num2) + (((uint[])array_0)[(int)(checked((IntPtr)(unchecked((long)(i & 3) ^ (long)((ulong)num5)))))] ^ num6)));
				}
				num6 = ((uint[])object_0)[num];
				num2 = (((uint[])object_0)[0] -= ((num6 >> 5 ^ num2 << 2) + (num2 >> 3 ^ num6 << 4) ^ (num4 ^ num2) + (((uint[])array_0)[(int)(checked((IntPtr)(unchecked((long)(i & 3) ^ (long)((ulong)num5)))))] ^ num6)));
			}
			return (uint[])object_0;
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x0016F268 File Offset: 0x0016F268
		private static uint[] smethod_2(object object_0, bool bool_0)
		{
			int num = ((((Array)object_0).Length & 3) == 0) ? (((Array)object_0).Length >> 2) : ((((Array)object_0).Length >> 2) + 1);
			uint[] array;
			if (bool_0)
			{
				array = new uint[num + 1];
				array[num] = (uint)((Array)object_0).Length;
			}
			else
			{
				array = new uint[num];
			}
			num = ((Array)object_0).Length;
			for (int i = 0; i < num; i++)
			{
				array[i >> 2] |= (uint)((uint)((byte[])object_0)[i] << ((i & 3) << 3));
			}
			return array;
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x0016F300 File Offset: 0x0016F300
		private static byte[] smethod_3(object object_0, bool bool_0)
		{
			int num = (!bool_0) ? (((Array)object_0).Length << 2) : ((int)((uint[])object_0)[((Array)object_0).Length - 1]);
			byte[] array = new byte[num];
			for (int i = 0; i < num; i++)
			{
				array[i] = (byte)(((uint[])object_0)[i >> 2] >> ((i & 3) << 3));
			}
			return array;
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x0016F360 File Offset: 0x0016F360
		public static string base64Decode(string data)
		{
			string @string;
			try
			{
				Encoding utf = Encoding.UTF8;
				byte[] bytes = Convert.FromBase64String(data);
				@string = utf.GetString(bytes);
			}
			catch (Exception ex)
			{
				throw new Exception("Error in base64Decode" + ex.Message);
			}
			return @string;
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x0016F3AC File Offset: 0x0016F3AC
		public static string base64Encode(string data)
		{
			string result;
			try
			{
				new byte[data.Length];
				result = Convert.ToBase64String(Encoding.UTF8.GetBytes(data));
			}
			catch (Exception ex)
			{
				throw new Exception("Error in base64Encode" + ex.Message);
			}
			return result;
		}
	}
}
