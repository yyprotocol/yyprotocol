﻿using System;
using System.Runtime.InteropServices;

namespace JIQIMAO.Common
{
	// Token: 0x02000082 RID: 130
	public class krbtool
	{
		// Token: 0x06000441 RID: 1089
		[DllImport("login.dll")]
		public static extern int Out(byte[] linkd, int linkd_len, byte[] fhzzz, byte[] krbtgt, int krbtgt_len, string user, string pwdhash, int nui);
	}
}
