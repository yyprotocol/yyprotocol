﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Common
{
	// Token: 0x0200008B RID: 139
	public class savepcbuser
	{
		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000474 RID: 1140 RVA: 0x00159F82 File Offset: 0x00159F82
		// (set) Token: 0x06000475 RID: 1141 RVA: 0x00159F8A File Offset: 0x00159F8A
		public string uid { get; set; }

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x00159F93 File Offset: 0x00159F93
		// (set) Token: 0x06000477 RID: 1143 RVA: 0x00159F9B File Offset: 0x00159F9B
		public string username { get; set; }

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000478 RID: 1144 RVA: 0x00159FA4 File Offset: 0x00159FA4
		// (set) Token: 0x06000479 RID: 1145 RVA: 0x00159FAC File Offset: 0x00159FAC
		public string cookie { get; set; }

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x00159FB5 File Offset: 0x00159FB5
		// (set) Token: 0x0600047B RID: 1147 RVA: 0x00159FBD File Offset: 0x00159FBD
		public string at { get; set; }

		// Token: 0x040003BE RID: 958
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040003BF RID: 959
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040003C0 RID: 960
		[CompilerGenerated]
		private string string_2;

		// Token: 0x040003C1 RID: 961
		[CompilerGenerated]
		private string string_3;
	}
}
