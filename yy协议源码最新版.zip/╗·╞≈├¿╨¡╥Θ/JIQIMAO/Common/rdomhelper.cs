﻿using System;

namespace JIQIMAO.Common
{
	// Token: 0x02000089 RID: 137
	public class rdomhelper
	{
		// Token: 0x0600046B RID: 1131 RVA: 0x0016EC14 File Offset: 0x0016EC14
		public static int getrandom(int start, int end)
		{
			int result;
			try
			{
				result = rdomhelper.random_0.Next(start, end);
			}
			catch
			{
				result = new Random().Next(start, end);
			}
			return result;
		}

		// Token: 0x0600046C RID: 1132 RVA: 0x0016EC54 File Offset: 0x0016EC54
		public static string GetRandom()
		{
			string result;
			try
			{
				result = rdomhelper.random_0.NextDouble().ToString();
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x040003B9 RID: 953
		private static Random random_0 = new Random();
	}
}
