﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Common
{
	// Token: 0x02000074 RID: 116
	public class c_Data
	{
		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000423 RID: 1059 RVA: 0x00159E48 File Offset: 0x00159E48
		// (set) Token: 0x06000424 RID: 1060 RVA: 0x00159E50 File Offset: 0x00159E50
		public byte[] Data { get; set; }

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000425 RID: 1061 RVA: 0x00159E59 File Offset: 0x00159E59
		// (set) Token: 0x06000426 RID: 1062 RVA: 0x00159E61 File Offset: 0x00159E61
		public byte[] Data1 { get; set; }

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000427 RID: 1063 RVA: 0x00159E6A File Offset: 0x00159E6A
		// (set) Token: 0x06000428 RID: 1064 RVA: 0x00159E72 File Offset: 0x00159E72
		public int intd { get; set; }

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000429 RID: 1065 RVA: 0x00159E7B File Offset: 0x00159E7B
		// (set) Token: 0x0600042A RID: 1066 RVA: 0x00159E83 File Offset: 0x00159E83
		public string str { get; set; }

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600042B RID: 1067 RVA: 0x00159E8C File Offset: 0x00159E8C
		// (set) Token: 0x0600042C RID: 1068 RVA: 0x00159E94 File Offset: 0x00159E94
		public int Len { get; set; }

		// Token: 0x04000364 RID: 868
		[CompilerGenerated]
		private byte[] byte_0;

		// Token: 0x04000365 RID: 869
		[CompilerGenerated]
		private byte[] byte_1;

		// Token: 0x04000366 RID: 870
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000367 RID: 871
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000368 RID: 872
		[CompilerGenerated]
		private int int_1;
	}
}
