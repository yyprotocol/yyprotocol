﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x0200008D RID: 141
	public class sha1
	{
		// Token: 0x06000484 RID: 1156 RVA: 0x0016ED98 File Offset: 0x0016ED98
		public static string hash(string content, Encoding encode)
		{
			string result;
			try
			{
				SHA1CryptoServiceProvider sha1CryptoServiceProvider = new SHA1CryptoServiceProvider();
				byte[] bytes = encode.GetBytes(content);
				byte[] value = sha1CryptoServiceProvider.ComputeHash(bytes);
				sha1CryptoServiceProvider.Dispose();
				result = BitConverter.ToString(value).Replace("-", "");
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}
	}
}
