﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x02000087 RID: 135
	public class MyEncrypt
	{
		// Token: 0x0600045E RID: 1118 RVA: 0x0016E8A8 File Offset: 0x0016E8A8
		public static string GetMD5(string str)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(str)))
			{
				stringBuilder.Append(b.ToString("X2"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600045F RID: 1119 RVA: 0x0016E8FC File Offset: 0x0016E8FC
		public static string AesEncryptor(string str)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(str);
			return Convert.ToBase64String(new AesManaged
			{
				Key = Encoding.UTF8.GetBytes(MyEncrypt.GetMD5(MyEncrypt.string_0)),
				IV = Encoding.UTF8.GetBytes(MyEncrypt.GetMD5(MyEncrypt.string_0).Substring(8, 16)),
				Mode = CipherMode.CBC,
				Padding = PaddingMode.PKCS7
			}.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length));
		}

		// Token: 0x06000460 RID: 1120 RVA: 0x0016E978 File Offset: 0x0016E978
		public static string AesDecryptor(string str)
		{
			byte[] array = Convert.FromBase64String(str);
			ICryptoTransform cryptoTransform = new AesManaged
			{
				Key = Encoding.UTF8.GetBytes(MyEncrypt.GetMD5(MyEncrypt.string_0)),
				IV = Encoding.UTF8.GetBytes(MyEncrypt.GetMD5(MyEncrypt.string_0).Substring(8, 16)),
				Mode = CipherMode.CBC,
				Padding = PaddingMode.PKCS7
			}.CreateDecryptor();
			return Encoding.UTF8.GetString(cryptoTransform.TransformFinalBlock(array, 0, array.Length));
		}

		// Token: 0x06000461 RID: 1121 RVA: 0x0016E9F8 File Offset: 0x0016E9F8
		public static string Encrypt(string str)
		{
			DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
			byte[] bytes = Encoding.Unicode.GetBytes(MyEncrypt.string_0);
			byte[] bytes2 = Encoding.Unicode.GetBytes(str);
			string result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
				cryptoStream.Write(bytes2, 0, bytes2.Length);
				cryptoStream.FlushFinalBlock();
				result = Convert.ToBase64String(memoryStream.ToArray());
			}
			return result;
		}

		// Token: 0x06000462 RID: 1122 RVA: 0x0016EA7C File Offset: 0x0016EA7C
		public static string Decrypt(string str)
		{
			DESCryptoServiceProvider descryptoServiceProvider = new DESCryptoServiceProvider();
			byte[] bytes = Encoding.Unicode.GetBytes(MyEncrypt.string_0);
			byte[] array = Convert.FromBase64String(str);
			string @string;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (CryptoStream cryptoStream = new CryptoStream(memoryStream, descryptoServiceProvider.CreateDecryptor(bytes, bytes), CryptoStreamMode.Write))
				{
					cryptoStream.Write(array, 0, array.Length);
					cryptoStream.FlushFinalBlock();
					@string = Encoding.Unicode.GetString(memoryStream.ToArray());
				}
			}
			return @string;
		}

		// Token: 0x040003B7 RID: 951
		private static string string_0 = "1234QWER!@#$!QAZ";
	}
}
