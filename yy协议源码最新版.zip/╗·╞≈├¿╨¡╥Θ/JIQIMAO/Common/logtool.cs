﻿using System;
using System.IO;
using System.Windows.Forms;

namespace JIQIMAO.Common
{
	// Token: 0x02000086 RID: 134
	public class logtool
	{
		// Token: 0x06000453 RID: 1107 RVA: 0x0016E60C File Offset: 0x0016E60C
		public static void delusercache_w(string passport)
		{
			try
			{
				string path = string.Format(Application.StartupPath + "\\Cache2\\{0}.txt", passport);
				if (File.Exists(path))
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000454 RID: 1108 RVA: 0x0016E654 File Offset: 0x0016E654
		public static void delusercache_p(string passport)
		{
			try
			{
				string path = string.Format(Application.StartupPath + "\\Cache1\\{0}.txt", passport);
				if (File.Exists(path))
				{
					File.Delete(path);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x0016E69C File Offset: 0x0016E69C
		public static void logusercache_w(string passport, string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Cache2\\{0}.txt", passport), msg);
			}
			catch
			{
			}
		}

		// Token: 0x06000456 RID: 1110 RVA: 0x0016E6DC File Offset: 0x0016E6DC
		public static void logusercache_p(string passport, string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Cache1\\{0}.txt", passport), msg);
			}
			catch
			{
			}
		}

		// Token: 0x06000457 RID: 1111 RVA: 0x0016E71C File Offset: 0x0016E71C
		public static void logips_w(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format("C:\\Windows\\wips.txt", new object[0]), msg);
			}
			catch
			{
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x0016E754 File Offset: 0x0016E754
		public static void logips_p(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Help\\pips.txt", new object[0]), msg);
			}
			catch
			{
			}
		}

		// Token: 0x06000459 RID: 1113 RVA: 0x0016E798 File Offset: 0x0016E798
		public static void logproxy_http(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Help\\remotehttp.txt", new object[0]), msg);
			}
			catch
			{
			}
		}

		// Token: 0x0600045A RID: 1114 RVA: 0x0016E7DC File Offset: 0x0016E7DC
		public static void logproxy_s5(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Help\\remotespoof.txt", new object[0]), msg);
			}
			catch
			{
			}
		}

		// Token: 0x0600045B RID: 1115 RVA: 0x0016E820 File Offset: 0x0016E820
		public static void logauth(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Help\\macinfo.txt", new object[0]), msg);
			}
			catch
			{
			}
		}

		// Token: 0x0600045C RID: 1116 RVA: 0x0016E864 File Offset: 0x0016E864
		public static void logauthgift(string msg)
		{
			try
			{
				loghelper.logcacge(string.Format(Application.StartupPath + "\\Help\\gmacinfo.txt", new object[0]), msg);
			}
			catch
			{
			}
		}
	}
}
