﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using ns0;

namespace JIQIMAO.Common
{
	// Token: 0x0200007F RID: 127
	public class imagetool
	{
		// Token: 0x06000439 RID: 1081 RVA: 0x00159EB4 File Offset: 0x00159EB4
		private imagetool()
		{
			ChannelServices.RegisterChannel(new TcpClientChannel("shibie", new BinaryClientFormatterSinkProvider()), false);
			this.UjYdAtsjXq = (Get51Code)Activator.GetObject(typeof(Get51Code), "tcp://localhost:80/Get51Code");
		}

		// Token: 0x0600043A RID: 1082 RVA: 0x00159EF0 File Offset: 0x00159EF0
		public static imagetool CreateInstance()
		{
			if (imagetool.imagetool_0 == null)
			{
				imagetool.imagetool_0 = new imagetool();
			}
			return imagetool.imagetool_0;
		}

		// Token: 0x0600043B RID: 1083 RVA: 0x0016E0A0 File Offset: 0x0016E0A0
		public string hqCode(byte[] bytes, int imageType = 1)
		{
			string result;
			try
			{
				result = this.UjYdAtsjXq.HQCode(bytes, imageType);
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}

		// Token: 0x0600043C RID: 1084 RVA: 0x0016E0D8 File Offset: 0x0016E0D8
		public byte[] method_0(Bitmap bitmap)
		{
			byte[] result;
			try
			{
				using (MemoryStream memoryStream = new MemoryStream())
				{
					bitmap.Save(memoryStream, ImageFormat.Bmp);
					byte[] array = new byte[memoryStream.Length];
					memoryStream.Seek(0L, SeekOrigin.Begin);
					memoryStream.Read(array, 0, Convert.ToInt32(memoryStream.Length));
					bitmap.Dispose();
					memoryStream.Close();
					memoryStream.Dispose();
					result = array;
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x040003AC RID: 940
		private static imagetool imagetool_0;

		// Token: 0x040003AD RID: 941
		private Get51Code UjYdAtsjXq;
	}
}
