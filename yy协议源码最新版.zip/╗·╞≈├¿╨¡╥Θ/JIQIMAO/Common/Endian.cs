﻿using System;

namespace JIQIMAO.Common
{
	// Token: 0x02000075 RID: 117
	public enum Endian
	{
		// Token: 0x0400036F RID: 879
		LITTLE_ENDIAN,
		// Token: 0x04000370 RID: 880
		BIG_ENDIAN
	}
}
