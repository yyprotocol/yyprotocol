﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Common
{
	// Token: 0x02000085 RID: 133
	public class logobj
	{
		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600044E RID: 1102 RVA: 0x00159F14 File Offset: 0x00159F14
		// (set) Token: 0x0600044F RID: 1103 RVA: 0x00159F1C File Offset: 0x00159F1C
		public string path { get; set; }

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x06000450 RID: 1104 RVA: 0x00159F25 File Offset: 0x00159F25
		// (set) Token: 0x06000451 RID: 1105 RVA: 0x00159F2D File Offset: 0x00159F2D
		public string msg { get; set; }

		// Token: 0x040003B3 RID: 947
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040003B4 RID: 948
		[CompilerGenerated]
		private string string_1;
	}
}
