﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace JIQIMAO.Common
{
	// Token: 0x02000088 RID: 136
	public class MyEncryptMacCode
	{
		// Token: 0x06000465 RID: 1125 RVA: 0x0016E8A8 File Offset: 0x0016E8A8
		public static string GetMD5(string str)
		{
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in MD5.Create().ComputeHash(Encoding.UTF8.GetBytes(str)))
			{
				stringBuilder.Append(b.ToString("X2"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000466 RID: 1126 RVA: 0x0016EB18 File Offset: 0x0016EB18
		public static string AesEncryptor(string str)
		{
			byte[] bytes = Encoding.UTF8.GetBytes(str);
			return Convert.ToBase64String(new AesManaged
			{
				Key = Encoding.UTF8.GetBytes(MyEncryptMacCode.GetMD5(MyEncryptMacCode.string_0)),
				IV = Encoding.UTF8.GetBytes(MyEncryptMacCode.GetMD5(MyEncryptMacCode.string_0).Substring(8, 16)),
				Mode = CipherMode.CBC,
				Padding = PaddingMode.PKCS7
			}.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length));
		}

		// Token: 0x06000467 RID: 1127 RVA: 0x0016EB94 File Offset: 0x0016EB94
		public static string AesDecryptor(string str)
		{
			byte[] array = Convert.FromBase64String(str);
			ICryptoTransform cryptoTransform = new AesManaged
			{
				Key = Encoding.UTF8.GetBytes(MyEncryptMacCode.GetMD5(MyEncryptMacCode.string_0)),
				IV = Encoding.UTF8.GetBytes(MyEncryptMacCode.GetMD5(MyEncryptMacCode.string_0).Substring(8, 16)),
				Mode = CipherMode.CBC,
				Padding = PaddingMode.PKCS7
			}.CreateDecryptor();
			return Encoding.UTF8.GetString(cryptoTransform.TransformFinalBlock(array, 0, array.Length));
		}

		// Token: 0x040003B8 RID: 952
		private static string string_0 = "LZQ123LMH4QWER!@#ZSN$!QAZ";
	}
}
