﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000033 RID: 51
	public class yongjiobj
	{
		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x06000308 RID: 776 RVA: 0x001590B5 File Offset: 0x001590B5
		// (set) Token: 0x06000309 RID: 777 RVA: 0x001590BD File Offset: 0x001590BD
		public bool isyongji { get; set; }

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x0600030A RID: 778 RVA: 0x001590C6 File Offset: 0x001590C6
		// (set) Token: 0x0600030B RID: 779 RVA: 0x001590CE File Offset: 0x001590CE
		public DateTime ctime { get; set; }

		// Token: 0x0600030C RID: 780 RVA: 0x001590D7 File Offset: 0x001590D7
		public yongjiobj()
		{
			this.isyongji = false;
			this.ctime = DateTime.MinValue;
		}

		// Token: 0x04000241 RID: 577
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x04000242 RID: 578
		[CompilerGenerated]
		private DateTime dateTime_0;
	}
}
