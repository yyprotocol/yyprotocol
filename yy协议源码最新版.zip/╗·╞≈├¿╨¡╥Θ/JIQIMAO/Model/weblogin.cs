﻿using System;
using System.IO;
using System.Linq.Expressions;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using JIQIMAO.Common;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;

namespace JIQIMAO.Model
{
	// Token: 0x02000031 RID: 49
	public class weblogin
	{
		// Token: 0x06000305 RID: 773 RVA: 0x00169EBC File Offset: 0x00169EBC
		public weblogin(MyUser1225 u, string dl = "")
		{
			this.string_0 = "";
			this.string_1 = "";
			this.string_2 = "";
			this.string_3 = "";
			this.myUser1225_0 = u;
			this.cookieContainer_0 = new CookieContainer();
			this.string_0 = dl;
			this.cookieContainer_0.Add(new Cookie("hiido_ui", rdomhelper.GetRandom(), "/", "www.yy.com"));
			this.cookieContainer_0.Add(new Cookie("hd_newui", rdomhelper.GetRandom(), "/", ".yy.com"));
			this.cookieContainer_0.Add(new Cookie("hdjs_session_id", rdomhelper.GetRandom(), "/", "www.yy.com"));
			this.cookieContainer_0.Add(new Cookie("hdjs_session_time", timetool.GetTms(), "/", "www.yy.com"));
			this.cookieContainer_0.Add(new Cookie("Hm_lvt_ce8c6560ab1225fc5d2f56ded20e175c", timetool.GetTs(), "/", "www.yy.com"));
			this.cookieContainer_0.Add(new Cookie("Hm_lpvt_ce8c6560ab1225fc5d2f56ded20e175c", timetool.GetTs(), "/", "www.yy.com"));
			this.cookieContainer_0.Add(new Cookie("wyy", Guid.NewGuid().ToString("N"), "/", "www.yy.com"));
		}

		// Token: 0x06000306 RID: 774 RVA: 0x0016A020 File Offset: 0x0016A020
		private void method_0(HttpWebRequest httpWebRequest_0)
		{
			if (this.string_0.Length > 0)
			{
				string[] array = this.string_0.Split(new char[]
				{
					':'
				});
				httpWebRequest_0.Proxy = new WebProxy(array[0], Convert.ToInt32(array[1]));
				httpWebRequest_0.Timeout = 3000;
				return;
			}
			httpWebRequest_0.Proxy = null;
			httpWebRequest_0.Timeout = 3000;
		}

		// Token: 0x06000307 RID: 775 RVA: 0x0016A088 File Offset: 0x0016A088
		public bool userlogin(loginret ret)
		{
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			Stream stream = null;
			StreamReader streamReader = null;
			string text = string.Empty;
			bool result;
			try
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
					httpWebRequest = null;
				}
				string text2 = string.Format("http://www.yy.com/index/wakeudblogin", new object[0]);
				httpWebRequest = (WebRequest.Create(text2) as HttpWebRequest);
				httpWebRequest.Host = "www.yy.com";
				httpWebRequest.KeepAlive = false;
				httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36";
				httpWebRequest.Accept = "application/json, text/javascript, */*; q=0.01";
				httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
				httpWebRequest.Method = "POST";
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
				this.method_0(httpWebRequest);
				HttpWebResponse httpWebResponse2;
				httpWebResponse = (httpWebResponse2 = (httpWebRequest.GetResponse() as HttpWebResponse));
				try
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						return false;
					}
					Stream responseStream;
					stream = (responseStream = httpWebResponse.GetResponseStream());
					try
					{
						StreamReader streamReader2;
						streamReader = (streamReader2 = new StreamReader(stream));
						try
						{
							text = streamReader.ReadToEnd();
						}
						finally
						{
							if (streamReader2 != null)
							{
								((IDisposable)streamReader2).Dispose();
							}
						}
					}
					finally
					{
						if (responseStream != null)
						{
							((IDisposable)responseStream).Dispose();
						}
					}
					object arg = JsonConvert.DeserializeObject<object>(text);
					if (weblogin.<>o__8.<>p__1 == null)
					{
						weblogin.<>o__8.<>p__1 = CallSite<Func<CallSite, object, int, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					Func<CallSite, object, int, object> target = weblogin.<>o__8.<>p__1.Target;
					CallSite <>p__ = weblogin.<>o__8.<>p__1;
					if (weblogin.<>o__8.<>p__0 == null)
					{
						weblogin.<>o__8.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "success", typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					object obj = target(<>p__, weblogin.<>o__8.<>p__0.Target(weblogin.<>o__8.<>p__0, arg), 1);
					if (weblogin.<>o__8.<>p__2 == null)
					{
						weblogin.<>o__8.<>p__2 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					object obj2;
					if (!weblogin.<>o__8.<>p__2.Target(weblogin.<>o__8.<>p__2, obj))
					{
						if (weblogin.<>o__8.<>p__5 == null)
						{
							weblogin.<>o__8.<>p__5 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Or, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Func<CallSite, object, object, object> target2 = weblogin.<>o__8.<>p__5.Target;
						CallSite <>p__2 = weblogin.<>o__8.<>p__5;
						object arg2 = obj;
						if (weblogin.<>o__8.<>p__4 == null)
						{
							weblogin.<>o__8.<>p__4 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target3 = weblogin.<>o__8.<>p__4.Target;
						CallSite <>p__3 = weblogin.<>o__8.<>p__4;
						if (weblogin.<>o__8.<>p__3 == null)
						{
							weblogin.<>o__8.<>p__3 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "success", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						obj2 = target2(<>p__2, arg2, target3(<>p__3, weblogin.<>o__8.<>p__3.Target(weblogin.<>o__8.<>p__3, arg), "1"));
					}
					else
					{
						obj2 = obj;
					}
					object obj3 = obj2;
					if (weblogin.<>o__8.<>p__6 == null)
					{
						weblogin.<>o__8.<>p__6 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					if (!weblogin.<>o__8.<>p__6.Target(weblogin.<>o__8.<>p__6, obj3))
					{
						if (weblogin.<>o__8.<>p__10 == null)
						{
							weblogin.<>o__8.<>p__10 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Func<CallSite, object, bool> target4 = weblogin.<>o__8.<>p__10.Target;
						CallSite <>p__4 = weblogin.<>o__8.<>p__10;
						if (weblogin.<>o__8.<>p__9 == null)
						{
							weblogin.<>o__8.<>p__9 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Or, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Func<CallSite, object, object, object> target5 = weblogin.<>o__8.<>p__9.Target;
						CallSite <>p__5 = weblogin.<>o__8.<>p__9;
						object arg3 = obj3;
						if (weblogin.<>o__8.<>p__8 == null)
						{
							weblogin.<>o__8.<>p__8 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target6 = weblogin.<>o__8.<>p__8.Target;
						CallSite <>p__6 = weblogin.<>o__8.<>p__8;
						if (weblogin.<>o__8.<>p__7 == null)
						{
							weblogin.<>o__8.<>p__7 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "success", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						if (!target4(<>p__4, target5(<>p__5, arg3, target6(<>p__6, weblogin.<>o__8.<>p__7.Target(weblogin.<>o__8.<>p__7, arg), "true"))))
						{
							return false;
						}
					}
					if (weblogin.<>o__8.<>p__12 == null)
					{
						weblogin.<>o__8.<>p__12 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
					}
					Func<CallSite, object, string> target7 = weblogin.<>o__8.<>p__12.Target;
					CallSite <>p__7 = weblogin.<>o__8.<>p__12;
					if (weblogin.<>o__8.<>p__11 == null)
					{
						weblogin.<>o__8.<>p__11 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "url", typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					text2 = target7(<>p__7, weblogin.<>o__8.<>p__11.Target(weblogin.<>o__8.<>p__11, arg));
					if (weblogin.<>o__8.<>p__14 == null)
					{
						weblogin.<>o__8.<>p__14 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
					}
					Func<CallSite, object, string> target8 = weblogin.<>o__8.<>p__14.Target;
					CallSite <>p__8 = weblogin.<>o__8.<>p__14;
					if (weblogin.<>o__8.<>p__13 == null)
					{
						weblogin.<>o__8.<>p__13 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "ttokensec", typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					string value = target8(<>p__8, weblogin.<>o__8.<>p__13.Target(weblogin.<>o__8.<>p__13, arg));
					this.cookieContainer_0.Add(new Cookie("udboauthtmptokensec", value, "/", "www.yy.com"));
				}
				finally
				{
					if (httpWebResponse2 != null)
					{
						((IDisposable)httpWebResponse2).Dispose();
					}
				}
				this.string_1 = text2;
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
					httpWebRequest = null;
				}
				text2 = (this.string_1 += string.Format("&rdm={0}&UIStyle=xqlogin", new Random().NextDouble().ToString()));
				string text3 = text2.Substring(text2.IndexOf("oauth_token="), text2.IndexOf("&denyCallbackURL") - text2.IndexOf("oauth_token="));
				this.string_2 = text3.Replace("oauth_token=", "");
				httpWebRequest = (WebRequest.Create(text2) as HttpWebRequest);
				httpWebRequest.Host = "lgn.yy.com";
				httpWebRequest.KeepAlive = false;
				httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36";
				httpWebRequest.Accept = "application/json, text/javascript, */*";
				httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
				httpWebRequest.Method = "GET";
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
				this.method_0(httpWebRequest);
				HttpWebResponse httpWebResponse3;
				httpWebResponse = (httpWebResponse3 = (httpWebRequest.GetResponse() as HttpWebResponse));
				try
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						return false;
					}
					string text4 = httpWebResponse.Headers["Set-Cookie"];
					if (text4 != null)
					{
						string[] array = text4.Split(new char[]
						{
							','
						});
						for (int i = 0; i < array.Length; i++)
						{
							string[] array2 = array[i].Split(new char[]
							{
								';'
							});
							foreach (string text5 in array2)
							{
								if (text5.Contains("token"))
								{
									this.cookieContainer_0.Add(new Cookie("token", text5.Replace("token=", "").Trim(), "/", "lgn.yy.com"));
								}
								else if (text5.Contains("LGNJSESSIONID"))
								{
									this.cookieContainer_0.Add(new Cookie("LGNJSESSIONID", text5.Replace("LGNJSESSIONID=", "").Trim(), "/", "lgn.yy.com"));
								}
							}
						}
					}
				}
				finally
				{
					if (httpWebResponse3 != null)
					{
						((IDisposable)httpWebResponse3).Dispose();
					}
				}
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
					httpWebRequest = null;
				}
				string referer = this.string_1;
				text2 = "https://lgn.yy.com/lgn/oauth/x2/s/login_asyn.do";
				httpWebRequest = (WebRequest.Create(text2) as HttpWebRequest);
				httpWebRequest.Host = "lgn.yy.com";
				httpWebRequest.KeepAlive = true;
				httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36";
				httpWebRequest.Accept = "*/*";
				httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
				httpWebRequest.Headers.Add("X-Requested-With", "XMLHttpRequest");
				httpWebRequest.ContentType = "application/x-www-form-urlencoded";
				httpWebRequest.Method = "POST";
				httpWebRequest.CookieContainer = this.cookieContainer_0;
				httpWebRequest.Referer = referer;
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
				this.method_0(httpWebRequest);
				string s = string.Format("username={0}&pwdencrypt={1}&oauth_token={2}&denyCallbackURL=&UIStyle=xqlogin&appid=5077&cssid=5077&mxc=&vk=&isRemMe=0&mmc=&vv=&hiido=1", this.myUser1225_0.passport, jstool.Encrypt(this.myUser1225_0.pwd), this.string_2);
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				Stream requestStream;
				stream = (requestStream = httpWebRequest.GetRequestStream());
				try
				{
					stream.Write(bytes, 0, bytes.Length);
				}
				finally
				{
					if (requestStream != null)
					{
						((IDisposable)requestStream).Dispose();
					}
				}
				HttpWebResponse httpWebResponse4;
				httpWebResponse = (httpWebResponse4 = (httpWebRequest.GetResponse() as HttpWebResponse));
				try
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						return false;
					}
					Stream responseStream2;
					stream = (responseStream2 = httpWebResponse.GetResponseStream());
					try
					{
						StreamReader streamReader3;
						streamReader = (streamReader3 = new StreamReader(stream));
						try
						{
							text = streamReader.ReadToEnd();
						}
						finally
						{
							if (streamReader3 != null)
							{
								((IDisposable)streamReader3).Dispose();
							}
						}
					}
					finally
					{
						if (responseStream2 != null)
						{
							((IDisposable)responseStream2).Dispose();
						}
					}
				}
				finally
				{
					if (httpWebResponse4 != null)
					{
						((IDisposable)httpWebResponse4).Dispose();
					}
				}
				if (!string.IsNullOrWhiteSpace(text))
				{
					object arg4 = JsonConvert.DeserializeObject<object>(text);
					if (weblogin.<>o__8.<>p__17 == null)
					{
						weblogin.<>o__8.<>p__17 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					Func<CallSite, object, bool> target9 = weblogin.<>o__8.<>p__17.Target;
					CallSite <>p__9 = weblogin.<>o__8.<>p__17;
					if (weblogin.<>o__8.<>p__16 == null)
					{
						weblogin.<>o__8.<>p__16 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					Func<CallSite, object, string, object> target10 = weblogin.<>o__8.<>p__16.Target;
					CallSite <>p__10 = weblogin.<>o__8.<>p__16;
					if (weblogin.<>o__8.<>p__15 == null)
					{
						weblogin.<>o__8.<>p__15 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					if (!target9(<>p__9, target10(<>p__10, weblogin.<>o__8.<>p__15.Target(weblogin.<>o__8.<>p__15, arg4), "0")))
					{
						if (weblogin.<>o__8.<>p__19 == null)
						{
							weblogin.<>o__8.<>p__19 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
							}));
						}
						Func<CallSite, object, string, object> target11 = weblogin.<>o__8.<>p__19.Target;
						CallSite <>p__11 = weblogin.<>o__8.<>p__19;
						if (weblogin.<>o__8.<>p__18 == null)
						{
							weblogin.<>o__8.<>p__18 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						object obj4 = target11(<>p__11, weblogin.<>o__8.<>p__18.Target(weblogin.<>o__8.<>p__18, arg4), "1000004");
						if (weblogin.<>o__8.<>p__20 == null)
						{
							weblogin.<>o__8.<>p__20 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						if (!weblogin.<>o__8.<>p__20.Target(weblogin.<>o__8.<>p__20, obj4))
						{
							if (weblogin.<>o__8.<>p__24 == null)
							{
								weblogin.<>o__8.<>p__24 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
								}));
							}
							Func<CallSite, object, bool> target12 = weblogin.<>o__8.<>p__24.Target;
							CallSite <>p__12 = weblogin.<>o__8.<>p__24;
							if (weblogin.<>o__8.<>p__23 == null)
							{
								weblogin.<>o__8.<>p__23 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Or, typeof(weblogin), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
								}));
							}
							Func<CallSite, object, object, object> target13 = weblogin.<>o__8.<>p__23.Target;
							CallSite <>p__13 = weblogin.<>o__8.<>p__23;
							object arg5 = obj4;
							if (weblogin.<>o__8.<>p__22 == null)
							{
								weblogin.<>o__8.<>p__22 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
								}));
							}
							Func<CallSite, object, string, object> target14 = weblogin.<>o__8.<>p__22.Target;
							CallSite <>p__14 = weblogin.<>o__8.<>p__22;
							if (weblogin.<>o__8.<>p__21 == null)
							{
								weblogin.<>o__8.<>p__21 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
								{
									CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
								}));
							}
							if (!target12(<>p__12, target13(<>p__13, arg5, target14(<>p__14, weblogin.<>o__8.<>p__21.Target(weblogin.<>o__8.<>p__21, arg4), "1000010"))))
							{
								if (weblogin.<>o__8.<>p__26 == null)
								{
									weblogin.<>o__8.<>p__26 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
									}));
								}
								Func<CallSite, object, string, object> target15 = weblogin.<>o__8.<>p__26.Target;
								CallSite <>p__15 = weblogin.<>o__8.<>p__26;
								if (weblogin.<>o__8.<>p__25 == null)
								{
									weblogin.<>o__8.<>p__25 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
									}));
								}
								obj4 = target15(<>p__15, weblogin.<>o__8.<>p__25.Target(weblogin.<>o__8.<>p__25, arg4), "1000001");
								if (weblogin.<>o__8.<>p__32 == null)
								{
									weblogin.<>o__8.<>p__32 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
									}));
								}
								Func<CallSite, object, bool> target16 = weblogin.<>o__8.<>p__32.Target;
								CallSite <>p__16 = weblogin.<>o__8.<>p__32;
								if (weblogin.<>o__8.<>p__27 == null)
								{
									weblogin.<>o__8.<>p__27 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(weblogin), new CSharpArgumentInfo[]
									{
										CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
									}));
								}
								object arg7;
								if (weblogin.<>o__8.<>p__27.Target(weblogin.<>o__8.<>p__27, obj4))
								{
									if (weblogin.<>o__8.<>p__31 == null)
									{
										weblogin.<>o__8.<>p__31 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.And, typeof(weblogin), new CSharpArgumentInfo[]
										{
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
										}));
									}
									Func<CallSite, object, object, object> target17 = weblogin.<>o__8.<>p__31.Target;
									CallSite <>p__17 = weblogin.<>o__8.<>p__31;
									object arg6 = obj4;
									if (weblogin.<>o__8.<>p__30 == null)
									{
										weblogin.<>o__8.<>p__30 = CallSite<Func<CallSite, object, string, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(weblogin), new CSharpArgumentInfo[]
										{
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null)
										}));
									}
									Func<CallSite, object, string, object> target18 = weblogin.<>o__8.<>p__30.Target;
									CallSite <>p__18 = weblogin.<>o__8.<>p__30;
									if (weblogin.<>o__8.<>p__29 == null)
									{
										weblogin.<>o__8.<>p__29 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "vk", typeof(weblogin), new CSharpArgumentInfo[]
										{
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
										}));
									}
									Func<CallSite, object, object> target19 = weblogin.<>o__8.<>p__29.Target;
									CallSite <>p__19 = weblogin.<>o__8.<>p__29;
									if (weblogin.<>o__8.<>p__28 == null)
									{
										weblogin.<>o__8.<>p__28 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "obj", typeof(weblogin), new CSharpArgumentInfo[]
										{
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
										}));
									}
									arg7 = target17(<>p__17, arg6, target18(<>p__18, target19(<>p__19, weblogin.<>o__8.<>p__28.Target(weblogin.<>o__8.<>p__28, arg4)), "sv"));
								}
								else
								{
									arg7 = obj4;
								}
								if (!target16(<>p__16, arg7))
								{
									try
									{
										MyUser1225 myUser = this.myUser1225_0;
										if (weblogin.<>o__8.<>p__38 == null)
										{
											weblogin.<>o__8.<>p__38 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
										}
										Func<CallSite, object, string> target20 = weblogin.<>o__8.<>p__38.Target;
										CallSite <>p__20 = weblogin.<>o__8.<>p__38;
										if (weblogin.<>o__8.<>p__37 == null)
										{
											weblogin.<>o__8.<>p__37 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof(weblogin), new CSharpArgumentInfo[]
											{
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
											}));
										}
										Func<CallSite, object, object, object> target21 = weblogin.<>o__8.<>p__37.Target;
										CallSite <>p__21 = weblogin.<>o__8.<>p__37;
										if (weblogin.<>o__8.<>p__34 == null)
										{
											weblogin.<>o__8.<>p__34 = CallSite<Func<CallSite, string, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Add, typeof(weblogin), new CSharpArgumentInfo[]
											{
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.UseCompileTimeType | CSharpArgumentInfoFlags.Constant, null),
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
											}));
										}
										Func<CallSite, string, object, object> target22 = weblogin.<>o__8.<>p__34.Target;
										CallSite <>p__22 = weblogin.<>o__8.<>p__34;
										string arg8 = "webl:3-temp:";
										if (weblogin.<>o__8.<>p__33 == null)
										{
											weblogin.<>o__8.<>p__33 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
											{
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
											}));
										}
										object arg9 = target22(<>p__22, arg8, weblogin.<>o__8.<>p__33.Target(weblogin.<>o__8.<>p__33, arg4));
										if (weblogin.<>o__8.<>p__36 == null)
										{
											weblogin.<>o__8.<>p__36 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "vk", typeof(weblogin), new CSharpArgumentInfo[]
											{
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
											}));
										}
										Func<CallSite, object, object> target23 = weblogin.<>o__8.<>p__36.Target;
										CallSite <>p__23 = weblogin.<>o__8.<>p__36;
										if (weblogin.<>o__8.<>p__35 == null)
										{
											weblogin.<>o__8.<>p__35 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "obj", typeof(weblogin), new CSharpArgumentInfo[]
											{
												CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
											}));
										}
										myUser.mytrace = target20(<>p__20, target21(<>p__21, arg9, target23(<>p__23, weblogin.<>o__8.<>p__35.Target(weblogin.<>o__8.<>p__35, arg4))));
									}
									catch
									{
									}
									if (weblogin.<>o__8.<>p__40 == null)
									{
										weblogin.<>o__8.<>p__40 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
									}
									Func<CallSite, object, string> target24 = weblogin.<>o__8.<>p__40.Target;
									CallSite <>p__24 = weblogin.<>o__8.<>p__40;
									if (weblogin.<>o__8.<>p__39 == null)
									{
										weblogin.<>o__8.<>p__39 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "code", typeof(weblogin), new CSharpArgumentInfo[]
										{
											CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
										}));
									}
									ret.ucode = target24(<>p__24, weblogin.<>o__8.<>p__39.Target(weblogin.<>o__8.<>p__39, arg4));
									return false;
								}
								ret.ucode = "1000001";
								return false;
							}
						}
						this.myUser1225_0.status = 3;
						result = false;
					}
					else
					{
						if (weblogin.<>o__8.<>p__43 == null)
						{
							weblogin.<>o__8.<>p__43 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
						}
						Func<CallSite, object, string> target25 = weblogin.<>o__8.<>p__43.Target;
						CallSite <>p__25 = weblogin.<>o__8.<>p__43;
						if (weblogin.<>o__8.<>p__42 == null)
						{
							weblogin.<>o__8.<>p__42 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "yyuid", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Func<CallSite, object, object> target26 = weblogin.<>o__8.<>p__42.Target;
						CallSite <>p__26 = weblogin.<>o__8.<>p__42;
						if (weblogin.<>o__8.<>p__41 == null)
						{
							weblogin.<>o__8.<>p__41 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "obj", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						ret.uid = target25(<>p__25, target26(<>p__26, weblogin.<>o__8.<>p__41.Target(weblogin.<>o__8.<>p__41, arg4)));
						ret.ucode = "0";
						if (weblogin.<>o__8.<>p__46 == null)
						{
							weblogin.<>o__8.<>p__46 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(weblogin)));
						}
						Func<CallSite, object, string> target27 = weblogin.<>o__8.<>p__46.Target;
						CallSite <>p__27 = weblogin.<>o__8.<>p__46;
						if (weblogin.<>o__8.<>p__45 == null)
						{
							weblogin.<>o__8.<>p__45 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "callbackURL", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						Func<CallSite, object, object> target28 = weblogin.<>o__8.<>p__45.Target;
						CallSite <>p__28 = weblogin.<>o__8.<>p__45;
						if (weblogin.<>o__8.<>p__44 == null)
						{
							weblogin.<>o__8.<>p__44 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "obj", typeof(weblogin), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						text2 = target27(<>p__27, target28(<>p__28, weblogin.<>o__8.<>p__44.Target(weblogin.<>o__8.<>p__44, arg4)));
						if (httpWebRequest != null)
						{
							httpWebRequest.Abort();
							httpWebRequest = null;
						}
						httpWebRequest = (WebRequest.Create(text2) as HttpWebRequest);
						httpWebRequest.Host = "www.yy.com";
						httpWebRequest.KeepAlive = false;
						httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36";
						httpWebRequest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
						httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
						httpWebRequest.Method = "GET";
						httpWebRequest.CookieContainer = this.cookieContainer_0;
						httpWebRequest.ServicePoint.Expect100Continue = false;
						httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
						this.method_0(httpWebRequest);
						HttpWebResponse httpWebResponse5;
						httpWebResponse = (httpWebResponse5 = (httpWebRequest.GetResponse() as HttpWebResponse));
						try
						{
							if (httpWebResponse.StatusCode != HttpStatusCode.OK)
							{
								return false;
							}
							Stream responseStream3;
							stream = (responseStream3 = httpWebResponse.GetResponseStream());
							try
							{
								StreamReader streamReader4;
								streamReader = (streamReader4 = new StreamReader(stream));
								try
								{
									text = streamReader.ReadToEnd();
								}
								finally
								{
									if (streamReader4 != null)
									{
										((IDisposable)streamReader4).Dispose();
									}
								}
							}
							finally
							{
								if (responseStream3 != null)
								{
									((IDisposable)responseStream3).Dispose();
								}
							}
						}
						finally
						{
							if (httpWebResponse5 != null)
							{
								((IDisposable)httpWebResponse5).Dispose();
							}
						}
						if (!string.IsNullOrWhiteSpace(text))
						{
							if (text.Contains("wck_n.do"))
							{
								int num = text.IndexOf("writeCrossmainCookieWithCallBack");
								int num2 = text.IndexOf("',function");
								this.string_3 = text.Substring(num, num2 - num);
								this.string_3 = this.string_3.Replace("writeCrossmainCookieWithCallBack('", "");
								this.string_3 += string.Format("&rdm={0}", new Random().NextDouble());
								if (httpWebRequest != null)
								{
									httpWebRequest.Abort();
									httpWebRequest = null;
								}
								httpWebRequest = (WebRequest.Create(this.string_3) as HttpWebRequest);
								httpWebRequest.Host = "lgn.yy.com";
								httpWebRequest.KeepAlive = true;
								httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.75 Safari/537.36";
								httpWebRequest.Accept = "*/*";
								httpWebRequest.Headers.Add("Accept-Language", "zh-CN,zh;q=0.8");
								httpWebRequest.Method = "GET";
								httpWebRequest.ServicePoint.Expect100Continue = false;
								httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
								this.method_0(httpWebRequest);
								httpWebRequest.CookieContainer = this.cookieContainer_0;
								HttpWebResponse httpWebResponse6;
								httpWebResponse = (httpWebResponse6 = (httpWebRequest.GetResponse() as HttpWebResponse));
								try
								{
									if (httpWebResponse.StatusCode != HttpStatusCode.OK)
									{
										return false;
									}
									string text6 = httpWebResponse.Headers["Set-Cookie"];
									if (text6 != null)
									{
										string[] array4 = text6.Split(new char[]
										{
											','
										});
										for (int k = 0; k < array4.Length; k++)
										{
											string[] array5 = array4[k].Split(new char[]
											{
												';'
											});
											foreach (string text7 in array5)
											{
												if (text7.Contains("udb_l"))
												{
													ret.ck_udb_l = text7.Replace("udb_l=", "").Trim();
												}
												else if (text7.Contains("udb_n"))
												{
													ret.ck_udb_n = text7.Replace("udb_n=", "").Trim();
												}
												else if (text7.Contains("username"))
												{
													ret.ck_username = text7.Replace("username=", "").Trim();
													this.cookieContainer_0.Add(new Cookie("username", text7.Replace("username=", "").Trim(), "/", ".yy.com"));
												}
												else if (text7.Contains("password"))
												{
													this.cookieContainer_0.Add(new Cookie("password", text7.Replace("password=", "").Trim(), "/", ".yy.com"));
												}
												else if (text7.Contains("osinfo"))
												{
													this.cookieContainer_0.Add(new Cookie("osinfo", text7.Replace("osinfo=", "").Trim(), "/", ".yy.com"));
												}
												else if (text7.Contains("yyuid"))
												{
													this.cookieContainer_0.Add(new Cookie("yyuid", text7.Replace("yyuid=", "").Trim(), "/", ".yy.com"));
												}
												else if (text7.Contains("udb_oar"))
												{
													this.cookieContainer_0.Add(new Cookie("udb_oar", text7.Replace("udb_oar=", "").Trim(), "/", ".yy.com"));
												}
											}
										}
									}
								}
								finally
								{
									if (httpWebResponse6 != null)
									{
										((IDisposable)httpWebResponse6).Dispose();
									}
								}
								ret.issuccess = true;
								result = true;
							}
							else
							{
								result = false;
							}
						}
						else
						{
							result = false;
						}
					}
				}
				else
				{
					result = false;
				}
			}
			catch
			{
				result = false;
			}
			finally
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Dispose();
				}
				if (stream != null)
				{
					stream.Close();
					stream.Dispose();
				}
				if (streamReader != null)
				{
					streamReader.Close();
					streamReader.Dispose();
				}
			}
			return result;
		}

		// Token: 0x0400020C RID: 524
		private CookieContainer cookieContainer_0;

		// Token: 0x0400020D RID: 525
		private MyUser1225 myUser1225_0;

		// Token: 0x0400020E RID: 526
		private string string_0;

		// Token: 0x0400020F RID: 527
		private string string_1;

		// Token: 0x04000210 RID: 528
		private string string_2;

		// Token: 0x04000211 RID: 529
		private string string_3;
	}
}
