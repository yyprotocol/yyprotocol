﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using JIQIMAO.Common;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;

namespace JIQIMAO.Model
{
	// Token: 0x0200000A RID: 10
	public class initip
	{
		// Token: 0x06000036 RID: 54 RVA: 0x0015AA30 File Offset: 0x0015AA30
		public initip(int ic, ConcurrentBag<myip> il)
		{
			this.string_0 = "87b652d1fca54f57c525nf22fc6c44f5";
			this.string_1 = "8.45.0.0";
			this.string_2 = "0000D082";
			this.string_3 = "yy";
			this.random_0 = new Random();
			this.string_4 = "";
			this.int_0 = ic;
			this.concurrentBag_0 = il;
		}

		// Token: 0x06000037 RID: 55 RVA: 0x0015AA98 File Offset: 0x0015AA98
		public initip(ConcurrentBag<myip> il)
		{
			this.string_0 = "87b652d1fca54f57c525nf22fc6c44f5";
			this.string_1 = "8.45.0.0";
			this.string_2 = "0000D082";
			this.string_3 = "yy";
			this.random_0 = new Random();
			this.string_4 = "";
			this.concurrentBag_0 = il;
		}

		// Token: 0x06000038 RID: 56 RVA: 0x0015AAF4 File Offset: 0x0015AAF4
		public initip(string mcode)
		{
			this.string_0 = "87b652d1fca54f57c525nf22fc6c44f5";
			this.string_1 = "8.45.0.0";
			this.string_2 = "0000D082";
			this.string_3 = "yy";
			this.random_0 = new Random();
			this.string_4 = "";
			this.string_4 = mcode;
		}

		// Token: 0x06000039 RID: 57 RVA: 0x0015AB50 File Offset: 0x0015AB50
		public void getwebipsnew(string sid, string subid)
		{
			try
			{
				string string_ = string.Format("http://123.207.144.61:8888/pro/88881", new object[0]);
				string text = JsonConvert.SerializeObject(new prorequest
				{
					sid = sid,
					subid = subid
				});
				text = MyEncrypt.AesEncryptor(text);
				string string_2 = JsonConvert.SerializeObject(new sendrequest
				{
					json = text
				});
				object arg = JsonConvert.DeserializeObject<object>(this.method_0(string_, string_2));
				if (initip.<>o__11.<>p__1 == null)
				{
					initip.<>o__11.<>p__1 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(initip)));
				}
				Func<CallSite, object, string> target = initip.<>o__11.<>p__1.Target;
				CallSite <>p__ = initip.<>o__11.<>p__1;
				if (initip.<>o__11.<>p__0 == null)
				{
					initip.<>o__11.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "ret", typeof(initip), new CSharpArgumentInfo[]
					{
						CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
					}));
				}
				List<myip> list = JsonConvert.DeserializeObject<List<myip>>(MyEncrypt.AesDecryptor(target(<>p__, initip.<>o__11.<>p__0.Target(initip.<>o__11.<>p__0, arg))));
				if (list != null)
				{
					foreach (myip item in list)
					{
						this.concurrentBag_0.Add(item);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600003A RID: 58 RVA: 0x0015ACC0 File Offset: 0x0015ACC0
		private string method_0(string string_5, string string_6 = null)
		{
			string text = string.Empty;
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			Stream stream = null;
			StreamReader streamReader = null;
			string result;
			try
			{
				httpWebRequest = (HttpWebRequest)WebRequest.Create(string_5);
				httpWebRequest.Method = "POST";
				httpWebRequest.ContentType = "application/json";
				httpWebRequest.ReadWriteTimeout = 30000;
				byte[] bytes = Encoding.UTF8.GetBytes(string_6);
				httpWebRequest.ContentLength = (long)bytes.Length;
				Stream requestStream;
				stream = (requestStream = httpWebRequest.GetRequestStream());
				try
				{
					stream.Write(bytes, 0, bytes.Length);
					stream.Close();
				}
				finally
				{
					if (requestStream != null)
					{
						((IDisposable)requestStream).Dispose();
					}
				}
				httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				StreamReader streamReader2;
				streamReader = (streamReader2 = new StreamReader(httpWebResponse.GetResponseStream(), Encoding.UTF8));
				try
				{
					text = streamReader.ReadToEnd();
					result = text;
				}
				finally
				{
					if (streamReader2 != null)
					{
						((IDisposable)streamReader2).Dispose();
					}
				}
			}
			catch (Exception)
			{
				result = text;
			}
			finally
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Dispose();
				}
				if (stream != null)
				{
					stream.Close();
					stream.Dispose();
				}
				if (streamReader != null)
				{
					streamReader.Close();
					streamReader.Dispose();
				}
			}
			return result;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x0015ADF8 File Offset: 0x0015ADF8
		public void getapips()
		{
			IPAddress[] lips = Dns.GetHostEntry("aplbs.yy.com").AddressList;
			if (lips != null && lips.Count<IPAddress>() != 0)
			{
				int[] lports = new int[]
				{
					8088,
					8084,
					8080,
					8091,
					8082,
					8083,
					80,
					4002,
					20800,
					23,
					32004,
					28,
					4002,
					5002,
					6002,
					23,
					80,
					87,
					3001,
					8080,
					8008,
					6001
				};
				while (this.concurrentBag_0.Count < this.int_0)
				{
					Task.Factory.StartNew(delegate()
					{
						string ip = lips[this.random_0.Next(0, lips.Length)].ToString();
						int port = lports[this.random_0.Next(0, lports.Length)];
						InitTcp initTcp = new InitTcp(ip, port);
						if (initTcp.connect())
						{
							this.Send_1E73(initTcp);
							return;
						}
						initTcp.dispose();
					});
					Thread.Sleep(1000);
				}
				return;
			}
			throw new Exception("DNS 解析错误");
		}

		// Token: 0x0600003C RID: 60 RVA: 0x0015AE9C File Offset: 0x0015AE9C
		public void Send_1E73(InitTcp tcp)
		{
			try
			{
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 4;
					byteArray.writeBytes(bytetool.strToToHexByte("1E730000"));
					byteArray.writeShort(200);
					byteArray.method_2(-1);
					byteArray.method_2(-1);
					byteArray.writeBytes(bytetool.strToToHexByte("03010000"));
					byteArray.method_2(0);
					byteArray.writeUTF(Guid.NewGuid().ToString("N"));
					byteArray.writeBytes(bytetool.strToToHexByte(this.string_2));
					byteArray.writeUTF(this.string_1);
					byteArray.writeUTF(this.string_3);
					byteArray.method_2(0);
					byteArray.method_2(0);
					byteArray.writeBytes(bytetool.strToToHexByte("00000408"));
					byteArray.method_2(0);
					byteArray.method_2(0);
					byteArray.position = 0;
					byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
					bytes = byteArray.Buffer;
					byteArray.Dispose();
				}
				tcp.send(bytes);
				Thread.Sleep(200);
				this.processdata(tcp);
			}
			catch (Exception)
			{
				tcp.dispose();
			}
		}

		// Token: 0x0600003D RID: 61 RVA: 0x0015AFF8 File Offset: 0x0015AFF8
		public void Recv_1E74(byte[] data, InitTcp tcp)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(data))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedShort();
					uint num = byteArray.readUnsignedInt();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						int length = (int)byteArray.readUnsignedShort();
						string ip = byteArray.readUTFBytes((uint)length);
						byteArray.readUnsignedInt();
						uint num3 = byteArray.readUnsignedInt();
						myip mi = new myip();
						mi.ip = ip;
						mi.ports = new int[num3];
						int num4 = 0;
						while ((long)num4 < (long)((ulong)num3))
						{
							ushort num5 = byteArray.readUnsignedShort();
							mi.ports[num4] = (int)num5;
							num4++;
						}
						if (this.concurrentBag_0.Count((myip p) => p.ip == ip && p.ports[0] == mi.ports[0]) == 0 && num3 == 2u)
						{
							this.concurrentBag_0.Add(mi);
						}
						num2++;
					}
				}
			}
			catch (Exception)
			{
			}
			finally
			{
				if (tcp != null)
				{
					tcp.dispose();
				}
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x0015B16C File Offset: 0x0015B16C
		public void processdata(InitTcp tcp)
		{
			try
			{
				byte[] array = tcp.recive();
				if (array == null || array.Length == 0)
				{
					throw new Exception("接收数据为空");
				}
				if (bytetool.fromArray(array, false).Substring(8, 4).ToUpper() == "1E74")
				{
					this.Recv_1E74(array, tcp);
				}
			}
			catch (Exception)
			{
				tcp.dispose();
			}
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0015B1D8 File Offset: 0x0015B1D8
		[return: Dynamic]
		public dynamic auth()
		{
			object result;
			try
			{
				string string_ = string.Format("{0}/newauth/19999", "http://118.89.226.148:7788");
				string string_2 = JsonConvert.SerializeObject(new authrequest
				{
					MDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
					MAC = MyEncrypt.AesEncryptor(this.string_4)
				});
				result = JsonConvert.DeserializeObject<object>(this.method_0(string_, string_2));
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000040 RID: 64 RVA: 0x0015B250 File Offset: 0x0015B250
		[return: Dynamic]
		public dynamic authgift()
		{
			object result;
			try
			{
				string string_ = string.Format("{0}/newauth/12345", "http://118.89.226.148:7788");
				string string_2 = JsonConvert.SerializeObject(new authrequest
				{
					MDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
					MAC = MyEncrypt.AesEncryptor(this.string_4)
				});
				result = JsonConvert.DeserializeObject<object>(this.method_0(string_, string_2));
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x04000027 RID: 39
		private string string_0;

		// Token: 0x04000028 RID: 40
		private string string_1;

		// Token: 0x04000029 RID: 41
		private string string_2;

		// Token: 0x0400002A RID: 42
		private string string_3;

		// Token: 0x0400002B RID: 43
		private volatile int int_0;

		// Token: 0x0400002C RID: 44
		private ConcurrentBag<myip> concurrentBag_0;

		// Token: 0x0400002D RID: 45
		private Random random_0;

		// Token: 0x0400002E RID: 46
		private string string_4;
	}
}
