﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000009 RID: 9
	public class duoip
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600002F RID: 47 RVA: 0x001581A8 File Offset: 0x001581A8
		// (set) Token: 0x06000030 RID: 48 RVA: 0x001581B0 File Offset: 0x001581B0
		public uint sid { get; set; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000031 RID: 49 RVA: 0x001581B9 File Offset: 0x001581B9
		// (set) Token: 0x06000032 RID: 50 RVA: 0x001581C1 File Offset: 0x001581C1
		public string ip { get; set; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000033 RID: 51 RVA: 0x001581CA File Offset: 0x001581CA
		// (set) Token: 0x06000034 RID: 52 RVA: 0x001581D2 File Offset: 0x001581D2
		public List<int> ports { get; set; }

		// Token: 0x06000035 RID: 53 RVA: 0x001581DB File Offset: 0x001581DB
		public duoip()
		{
			this.ports = new List<int>();
		}

		// Token: 0x04000021 RID: 33
		[CompilerGenerated]
		private uint uint_0;

		// Token: 0x04000022 RID: 34
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000023 RID: 35
		[CompilerGenerated]
		private List<int> list_0;
	}
}
