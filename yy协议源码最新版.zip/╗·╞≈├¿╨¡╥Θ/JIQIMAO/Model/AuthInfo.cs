﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000004 RID: 4
	public class AuthInfo
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000D RID: 13 RVA: 0x001580BA File Offset: 0x001580BA
		// (set) Token: 0x0600000E RID: 14 RVA: 0x001580C2 File Offset: 0x001580C2
		public int Id { get; set; }

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600000F RID: 15 RVA: 0x001580CB File Offset: 0x001580CB
		// (set) Token: 0x06000010 RID: 16 RVA: 0x001580D3 File Offset: 0x001580D3
		public string MacCode { get; set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000011 RID: 17 RVA: 0x001580DC File Offset: 0x001580DC
		// (set) Token: 0x06000012 RID: 18 RVA: 0x001580E4 File Offset: 0x001580E4
		public string AuthTxt { get; set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000013 RID: 19 RVA: 0x001580ED File Offset: 0x001580ED
		// (set) Token: 0x06000014 RID: 20 RVA: 0x001580F5 File Offset: 0x001580F5
		public int CreateTime { get; set; }

		// Token: 0x04000005 RID: 5
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000006 RID: 6
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000007 RID: 7
		[CompilerGenerated]
		private string string_1;

		// Token: 0x04000008 RID: 8
		[CompilerGenerated]
		private int int_1;
	}
}
