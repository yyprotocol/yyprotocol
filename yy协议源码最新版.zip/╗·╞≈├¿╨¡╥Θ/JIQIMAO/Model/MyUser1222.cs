﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Timers;
using JIQIMAO.Common;
using JIQIMAO.Model.YYModel;
using Newtonsoft.Json;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x02000021 RID: 33
	public class MyUser1222
	{
		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000169 RID: 361 RVA: 0x001587B9 File Offset: 0x001587B9
		// (set) Token: 0x0600016A RID: 362 RVA: 0x001587C1 File Offset: 0x001587C1
		public int index { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x0600016B RID: 363 RVA: 0x001587CA File Offset: 0x001587CA
		// (set) Token: 0x0600016C RID: 364 RVA: 0x001587D2 File Offset: 0x001587D2
		public int id { get; set; }

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600016D RID: 365 RVA: 0x001587DB File Offset: 0x001587DB
		// (set) Token: 0x0600016E RID: 366 RVA: 0x001587E3 File Offset: 0x001587E3
		public string passport { get; set; }

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600016F RID: 367 RVA: 0x001587EC File Offset: 0x001587EC
		// (set) Token: 0x06000170 RID: 368 RVA: 0x001587F4 File Offset: 0x001587F4
		public string pwd { get; set; }

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x06000171 RID: 369 RVA: 0x001587FD File Offset: 0x001587FD
		// (set) Token: 0x06000172 RID: 370 RVA: 0x00158805 File Offset: 0x00158805
		public string pwden { get; set; }

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000173 RID: 371 RVA: 0x0015880E File Offset: 0x0015880E
		// (set) Token: 0x06000174 RID: 372 RVA: 0x00158816 File Offset: 0x00158816
		public int logintype { get; set; }

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000175 RID: 373 RVA: 0x0015881F File Offset: 0x0015881F
		// (set) Token: 0x06000176 RID: 374 RVA: 0x00158827 File Offset: 0x00158827
		public bool isfenghao { get; set; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000177 RID: 375 RVA: 0x00158830 File Offset: 0x00158830
		// (set) Token: 0x06000178 RID: 376 RVA: 0x00158838 File Offset: 0x00158838
		public int loginstatus { get; set; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000179 RID: 377 RVA: 0x00158841 File Offset: 0x00158841
		// (set) Token: 0x0600017A RID: 378 RVA: 0x00158849 File Offset: 0x00158849
		public int joinstatus { get; set; }

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600017B RID: 379 RVA: 0x00158852 File Offset: 0x00158852
		// (set) Token: 0x0600017C RID: 380 RVA: 0x0015885A File Offset: 0x0015885A
		public int status { get; set; }

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x0600017D RID: 381 RVA: 0x00160770 File Offset: 0x00160770
		public string statusstr
		{
			get
			{
				if (this.isfenghao)
				{
					if (this.status != 33)
					{
						return "封号";
					}
					if (this.mytrace == "MMCW")
					{
						return "密码错误";
					}
					return "频道不存在";
				}
				else
				{
					if (this.status == 0)
					{
						return "";
					}
					string str = this.loginstatus.ToString();
					return str + "-" + this.joinstatus.ToString();
				}
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x0600017E RID: 382 RVA: 0x00158863 File Offset: 0x00158863
		// (set) Token: 0x0600017F RID: 383 RVA: 0x0015886B File Offset: 0x0015886B
		public uint uid { get; set; }

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000180 RID: 384 RVA: 0x00158874 File Offset: 0x00158874
		// (set) Token: 0x06000181 RID: 385 RVA: 0x0015887C File Offset: 0x0015887C
		public string username { get; set; }

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00158885 File Offset: 0x00158885
		// (set) Token: 0x06000183 RID: 387 RVA: 0x0015888D File Offset: 0x0015888D
		public string qianming { get; set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000184 RID: 388 RVA: 0x00158896 File Offset: 0x00158896
		// (set) Token: 0x06000185 RID: 389 RVA: 0x0015889E File Offset: 0x0015889E
		public uint sid { get; set; }

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x06000186 RID: 390 RVA: 0x001588A7 File Offset: 0x001588A7
		// (set) Token: 0x06000187 RID: 391 RVA: 0x001588AF File Offset: 0x001588AF
		public uint subid { get; set; }

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x06000188 RID: 392 RVA: 0x001588B8 File Offset: 0x001588B8
		// (set) Token: 0x06000189 RID: 393 RVA: 0x001588C0 File Offset: 0x001588C0
		public uint sidnew { get; set; }

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600018A RID: 394 RVA: 0x001588C9 File Offset: 0x001588C9
		// (set) Token: 0x0600018B RID: 395 RVA: 0x001588D1 File Offset: 0x001588D1
		public uint subidnew { get; set; }

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600018C RID: 396 RVA: 0x001588DA File Offset: 0x001588DA
		// (set) Token: 0x0600018D RID: 397 RVA: 0x001588E2 File Offset: 0x001588E2
		public string nicheng { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600018E RID: 398 RVA: 0x001588EB File Offset: 0x001588EB
		// (set) Token: 0x0600018F RID: 399 RVA: 0x001588F3 File Offset: 0x001588F3
		public OldTcp logintcp { get; set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000190 RID: 400 RVA: 0x001588FC File Offset: 0x001588FC
		// (set) Token: 0x06000191 RID: 401 RVA: 0x00158904 File Offset: 0x00158904
		public OldTcp servicetcp { get; set; }

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000192 RID: 402 RVA: 0x0015890D File Offset: 0x0015890D
		// (set) Token: 0x06000193 RID: 403 RVA: 0x00158915 File Offset: 0x00158915
		public string apip { get; set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000194 RID: 404 RVA: 0x0015891E File Offset: 0x0015891E
		// (set) Token: 0x06000195 RID: 405 RVA: 0x00158926 File Offset: 0x00158926
		public int apport { get; set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000196 RID: 406 RVA: 0x0015892F File Offset: 0x0015892F
		// (set) Token: 0x06000197 RID: 407 RVA: 0x00158937 File Offset: 0x00158937
		public int heartbeat { get; set; }

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000198 RID: 408 RVA: 0x00158940 File Offset: 0x00158940
		// (set) Token: 0x06000199 RID: 409 RVA: 0x00158948 File Offset: 0x00158948
		public ProxyTypes pt { get; set; }

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00158951 File Offset: 0x00158951
		// (set) Token: 0x0600019B RID: 411 RVA: 0x00158959 File Offset: 0x00158959
		public string daili { get; set; }

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600019C RID: 412 RVA: 0x00158962 File Offset: 0x00158962
		public string dailistr
		{
			get
			{
				if (this.logintype == 1)
				{
					return "";
				}
				return this.daili;
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600019D RID: 413 RVA: 0x00158979 File Offset: 0x00158979
		// (set) Token: 0x0600019E RID: 414 RVA: 0x00158981 File Offset: 0x00158981
		public string yanzhengma { get; set; }

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600019F RID: 415 RVA: 0x0015898A File Offset: 0x0015898A
		// (set) Token: 0x060001A0 RID: 416 RVA: 0x00158992 File Offset: 0x00158992
		public int currentflag { get; set; }

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060001A1 RID: 417 RVA: 0x0015899B File Offset: 0x0015899B
		// (set) Token: 0x060001A2 RID: 418 RVA: 0x001589A3 File Offset: 0x001589A3
		public bool isinqueue { get; set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060001A3 RID: 419 RVA: 0x001589AC File Offset: 0x001589AC
		// (set) Token: 0x060001A4 RID: 420 RVA: 0x001589B4 File Offset: 0x001589B4
		public bool isudblogin { get; set; }

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x001589BD File Offset: 0x001589BD
		// (set) Token: 0x060001A6 RID: 422 RVA: 0x001589C5 File Offset: 0x001589C5
		public byte[] yycookie { get; set; }

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x001589CE File Offset: 0x001589CE
		// (set) Token: 0x060001A8 RID: 424 RVA: 0x001589D6 File Offset: 0x001589D6
		public string mytrace { get; set; }

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x001589DF File Offset: 0x001589DF
		// (set) Token: 0x060001AA RID: 426 RVA: 0x001589E7 File Offset: 0x001589E7
		public int jointimes { get; set; }

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060001AB RID: 427 RVA: 0x001589F0 File Offset: 0x001589F0
		// (set) Token: 0x060001AC RID: 428 RVA: 0x001589F8 File Offset: 0x001589F8
		public string loseconreason { get; set; }

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060001AD RID: 429 RVA: 0x00158A01 File Offset: 0x00158A01
		// (set) Token: 0x060001AE RID: 430 RVA: 0x00158A09 File Offset: 0x00158A09
		public DateTime startlogintime { get; set; }

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x060001AF RID: 431 RVA: 0x00158A12 File Offset: 0x00158A12
		// (set) Token: 0x060001B0 RID: 432 RVA: 0x00158A1A File Offset: 0x00158A1A
		public DateTime weblogintime { get; set; }

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x060001B1 RID: 433 RVA: 0x00158A23 File Offset: 0x00158A23
		// (set) Token: 0x060001B2 RID: 434 RVA: 0x00158A2B File Offset: 0x00158A2B
		public DateTime startjointime { get; set; }

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x060001B3 RID: 435 RVA: 0x00158A34 File Offset: 0x00158A34
		// (set) Token: 0x060001B4 RID: 436 RVA: 0x00158A3C File Offset: 0x00158A3C
		public DateTime joinchanneltime { get; set; }

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x00158A45 File Offset: 0x00158A45
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x00158A4D File Offset: 0x00158A4D
		public DateTime lasthearttime { get; set; }

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x00158A56 File Offset: 0x00158A56
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x00158A5E File Offset: 0x00158A5E
		public DateTime lastsendhearttime { get; set; }

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x060001B9 RID: 441 RVA: 0x00158A67 File Offset: 0x00158A67
		// (set) Token: 0x060001BA RID: 442 RVA: 0x00158A6F File Offset: 0x00158A6F
		public DateTime lastsendtime { get; set; }

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x060001BB RID: 443 RVA: 0x00158A78 File Offset: 0x00158A78
		// (set) Token: 0x060001BC RID: 444 RVA: 0x00158A80 File Offset: 0x00158A80
		public DateTime buhaotime { get; set; }

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x060001BD RID: 445 RVA: 0x00158A89 File Offset: 0x00158A89
		// (set) Token: 0x060001BE RID: 446 RVA: 0x00158A91 File Offset: 0x00158A91
		public DateTime checkinchaneltime { get; set; }

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x060001BF RID: 447 RVA: 0x00158A9A File Offset: 0x00158A9A
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x00158AA2 File Offset: 0x00158AA2
		public DateTime lastonlinetime { get; set; }

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x00158AAB File Offset: 0x00158AAB
		// (set) Token: 0x060001C2 RID: 450 RVA: 0x00158AB3 File Offset: 0x00158AB3
		public DateTime startloginservicetime { get; set; }

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x001607EC File Offset: 0x001607EC
		public string mcki
		{
			get
			{
				if (this.lasthearttime == DateTime.MinValue)
				{
					return "";
				}
				return this.lasthearttime.ToString("HHmm");
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x060001C4 RID: 452 RVA: 0x00160824 File Offset: 0x00160824
		public string lol
		{
			get
			{
				if (this.lastonlinetime == DateTime.MinValue)
				{
					return "";
				}
				return this.lastonlinetime.ToString("HHmm");
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x00158ABC File Offset: 0x00158ABC
		// (set) Token: 0x060001C6 RID: 454 RVA: 0x00158AC4 File Offset: 0x00158AC4
		public bool isgongneng { get; set; }

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x00158ACD File Offset: 0x00158ACD
		// (set) Token: 0x060001C8 RID: 456 RVA: 0x00158AD5 File Offset: 0x00158AD5
		public bool isxianche { get; set; }

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x060001C9 RID: 457 RVA: 0x00158ADE File Offset: 0x00158ADE
		// (set) Token: 0x060001CA RID: 458 RVA: 0x00158AE6 File Offset: 0x00158AE6
		public bool isqutubiao { get; set; }

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x060001CB RID: 459 RVA: 0x00158AEF File Offset: 0x00158AEF
		// (set) Token: 0x060001CC RID: 460 RVA: 0x00158AF7 File Offset: 0x00158AF7
		public bool isloginservice { get; set; }

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x060001CD RID: 461 RVA: 0x00158B00 File Offset: 0x00158B00
		// (set) Token: 0x060001CE RID: 462 RVA: 0x00158B08 File Offset: 0x00158B08
		public string serviceip { get; set; }

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060001CF RID: 463 RVA: 0x00158B11 File Offset: 0x00158B11
		// (set) Token: 0x060001D0 RID: 464 RVA: 0x00158B19 File Offset: 0x00158B19
		public int serviceport { get; set; }

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x00158B22 File Offset: 0x00158B22
		// (set) Token: 0x060001D2 RID: 466 RVA: 0x00158B2A File Offset: 0x00158B2A
		public DateTime lastservicehearttime { get; set; }

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060001D3 RID: 467 RVA: 0x0016085C File Offset: 0x0016085C
		// (remove) Token: 0x060001D4 RID: 468 RVA: 0x00160894 File Offset: 0x00160894
		public event MyUser1222.OnGetUserCount GetUserCountEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser1222.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser1222.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser1222.OnGetUserCount value2 = (MyUser1222.OnGetUserCount)Delegate.Combine(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser1222.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser1222.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser1222.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser1222.OnGetUserCount value2 = (MyUser1222.OnGetUserCount)Delegate.Remove(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser1222.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060001D5 RID: 469 RVA: 0x001608CC File Offset: 0x001608CC
		// (remove) Token: 0x060001D6 RID: 470 RVA: 0x00160904 File Offset: 0x00160904
		public event MyUser1222.OnGetUserList GetUserListEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser1222.OnGetUserList onGetUserList = this.onGetUserList_0;
				MyUser1222.OnGetUserList onGetUserList2;
				do
				{
					onGetUserList2 = onGetUserList;
					MyUser1222.OnGetUserList value2 = (MyUser1222.OnGetUserList)Delegate.Combine(onGetUserList2, value);
					onGetUserList = Interlocked.CompareExchange<MyUser1222.OnGetUserList>(ref this.onGetUserList_0, value2, onGetUserList2);
				}
				while (onGetUserList != onGetUserList2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser1222.OnGetUserList onGetUserList = this.onGetUserList_0;
				MyUser1222.OnGetUserList onGetUserList2;
				do
				{
					onGetUserList2 = onGetUserList;
					MyUser1222.OnGetUserList value2 = (MyUser1222.OnGetUserList)Delegate.Remove(onGetUserList2, value);
					onGetUserList = Interlocked.CompareExchange<MyUser1222.OnGetUserList>(ref this.onGetUserList_0, value2, onGetUserList2);
				}
				while (onGetUserList != onGetUserList2);
			}
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0016093C File Offset: 0x0016093C
		private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				if (this.status == 2)
				{
					if (this.uint_4 % 15u == 0u)
					{
						this.Send_041E();
					}
					this.uint_4 += 1u;
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x00160988 File Offset: 0x00160988
		private void timer_1_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				if (this.logintcp != null)
				{
					byte[] array = this.logintcp.recive();
					if (array != null && array.Length != 0)
					{
						if (array[8] == 200 && array[9] == 0)
						{
							this.byteArray_0 = null;
							this.byteArray_0 = new ByteArray();
							using (ByteArray byteArray = new ByteArray(array))
							{
								this.int_11 = byteArray.ReadInt();
							}
							this.byteArray_0.writeBytes(array);
						}
						else if (this.byteArray_0 != null && this.byteArray_0.length > 0 && this.byteArray_0.length < this.int_11)
						{
							this.byteArray_0.writeBytes(array);
						}
						if (this.byteArray_0 != null && this.byteArray_0.length >= this.int_11)
						{
							this.int_11 = 0;
							this.method_2(this.byteArray_0.Buffer);
						}
					}
				}
			}
			catch
			{
				this.byteArray_0 = null;
				this.int_11 = 0;
			}
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x00160AA0 File Offset: 0x00160AA0
		public void SendSH()
		{
			try
			{
				byte[] bytes = new byte[]
				{
					14,
					0,
					0,
					0,
					4,
					30,
					12,
					0,
					200,
					0,
					0,
					0,
					0,
					0
				};
				this.servicetcp.Send(bytes);
				this.lastservicehearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001DA RID: 474 RVA: 0x00160AEC File Offset: 0x00160AEC
		public MyUser1222()
		{
			DateTime joinchanneltime = this.lasthearttime = DateTime.MinValue;
			DateTime startjointime = this.joinchanneltime = joinchanneltime;
			DateTime weblogintime = this.startjointime = startjointime;
			DateTime startlogintime = this.weblogintime = weblogintime;
			DateTime lastservicehearttime = this.startlogintime = startlogintime;
			DateTime lastsendtime = this.lastservicehearttime = lastservicehearttime;
			DateTime buhaotime = this.lastsendtime = lastsendtime;
			DateTime checkinchaneltime = this.buhaotime = buhaotime;
			DateTime lastonlinetime = this.checkinchaneltime = checkinchaneltime;
			DateTime startloginservicetime = this.lastonlinetime = lastonlinetime;
			this.lastsendhearttime = (this.startloginservicetime = startloginservicetime);
			this.isxianche = false;
			this.isqutubiao = false;
			this.isudblogin = false;
			this.isfenghao = false;
			this.isloginservice = false;
			this.isinqueue = false;
			this.isgongneng = false;
			this.currentflag = 10000;
			string yanzhengma = this.username = "";
			string mytrace = this.yanzhengma = yanzhengma;
			this.daili = (this.mytrace = mytrace);
			this.timer_0 = new System.Timers.Timer(1000.0);
			this.timer_0.Elapsed += this.timer_0_Elapsed;
			this.timer_0.AutoReset = true;
			this.timer_0.Enabled = true;
			this.timer_0.Start();
			this.timer_1 = new System.Timers.Timer(50.0);
			this.timer_1.Elapsed += this.timer_1_Elapsed;
			this.timer_1.AutoReset = true;
			this.timer_1.Enabled = true;
			this.timer_1.Start();
		}

		// Token: 0x060001DB RID: 475 RVA: 0x00160CB8 File Offset: 0x00160CB8
		public void resend()
		{
			try
			{
				if (this.lastsendtime != DateTime.MinValue && this.lastsendtime.AddSeconds(3.0) < DateTime.Now)
				{
					this.lastsendtime = DateTime.Now;
					if (this.currentflag >= 20001 && this.currentflag < 21000)
					{
						this.method_3();
					}
					else if (this.currentflag >= 40001 && this.currentflag < 41000)
					{
						this.method_8();
					}
					else if (this.currentflag >= 50001 && this.currentflag < 51000)
					{
						this.Send_0BD0_0307();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001DC RID: 476 RVA: 0x00160D84 File Offset: 0x00160D84
		public void join()
		{
			try
			{
				if (this.logintype == 2)
				{
					this.pt = ProxyTypes.None;
					this.daili = "";
				}
				else if (this.logintype == 1 && this.isudblogin)
				{
					this.pt = ProxyTypes.None;
					this.daili = "";
				}
				this.heartbeat = 0;
				this.isinqueue = false;
				this.startjointime = DateTime.Now;
				this.currentflag = rdomhelper.getrandom(10001, 11000);
				this.logintcp = new OldTcp(this.apip, this.apport, this.daili, this.pt, "");
				if (this.logintcp.connect(""))
				{
					this.method_3();
				}
				else
				{
					this.OnConnected(false, false);
				}
			}
			catch
			{
				this.joinstatus = 0;
			}
		}

		// Token: 0x060001DD RID: 477 RVA: 0x00160E68 File Offset: 0x00160E68
		public void OnConnected(bool issuccess, bool iszhongduan = false)
		{
			if (!issuccess)
			{
				try
				{
					if (this.status != 0)
					{
						this.status = 1;
					}
					this.joinstatus = 0;
					this.currentflag = 10000;
					this.isinqueue = false;
					this.heartbeat = 0;
					this.isloginservice = false;
					this.startjointime = DateTime.MinValue;
					this.lastonlinetime = DateTime.MinValue;
					if (iszhongduan)
					{
						this.isudblogin = false;
						this.checkinchaneltime = DateTime.MinValue;
					}
					if (this.logintcp != null)
					{
						this.logintcp.Dispose();
					}
					return;
				}
				catch
				{
					return;
				}
			}
			this.method_3();
		}

		// Token: 0x060001DE RID: 478 RVA: 0x00160F08 File Offset: 0x00160F08
		private void method_0(byte[] byte_1)
		{
			try
			{
				if (byte_1[8] == 200 && byte_1[9] == 0)
				{
					this.byteArray_0 = null;
					this.byteArray_0 = new ByteArray();
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						this.int_11 = byteArray.ReadInt();
					}
					this.byteArray_0.writeBytes(byte_1);
				}
				else if (this.byteArray_0 != null && this.byteArray_0.length > 0 && this.byteArray_0.length < this.int_11)
				{
					this.byteArray_0.writeBytes(byte_1);
				}
				if (this.byteArray_0 != null && this.byteArray_0.length >= this.int_11)
				{
					this.int_11 = 0;
					this.method_2(this.byteArray_0.Buffer);
				}
			}
			catch
			{
				this.byteArray_0 = null;
				this.int_11 = 0;
			}
		}

		// Token: 0x060001DF RID: 479 RVA: 0x00158048 File Offset: 0x00158048
		private void method_1()
		{
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x00160FFC File Offset: 0x00160FFC
		private void method_2(byte[] byte_1)
		{
			try
			{
				if (byte_1 != null && byte_1.Length >= 10 && byte_1[8] == 200)
				{
					string text = bytetool.fromArray(byte_1, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2) && !(text2 == "1E74"))
					{
						if (!(text2 == "0412") && !(text2 == "0415") && !(text2 == "0287") && !(text2 == "0433"))
						{
							if (text2 == "04E5")
							{
								this.method_7(byte_1);
							}
							else if (text2 == "04D7")
							{
								this.method_9(byte_1);
							}
							else if (text2 == "0422")
							{
								this.mytrace = "FO";
								this.OnConnected(false, true);
								this.isudblogin = false;
							}
							else if (text2 == "0BD0")
							{
								string text3;
								string a;
								try
								{
									text3 = text.Substring(24, 4).ToUpper();
									a = text.Substring(24, 6).ToUpper();
								}
								catch
								{
									return;
								}
								if (text3 == "1E74")
								{
									this.Recv_Service_1E74(byte_1);
								}
								else if (text3 == "0308")
								{
									this.method_10(byte_1);
								}
								else if (!(text3 == "0868"))
								{
									if (text3 == "0242" && a == "02421F")
									{
										this.method_11(byte_1);
									}
									else if (!(text3 == "0302"))
									{
										if (!(text3 == "024D") && !(text3 == "0235") && !(text3 == "0240") && !(text3 == "020C") && !(text3 == "0422"))
										{
											if (text3 == "022C")
											{
												this.mytrace = "YDD";
											}
											else if (!(text3 == "0239"))
											{
												if (text3 == "041F")
												{
													this.method_12(byte_1);
												}
												else if (text3 == "02D1")
												{
													this.method_13(byte_1);
												}
												else if (text3 == "02B1")
												{
													this.method_14(byte_1);
												}
												else if (text3 == "02B3")
												{
													this.checkinchaneltime = DateTime.Now;
												}
												else if (text3 == "02B5")
												{
													this.method_15(byte_1);
												}
												else if (text3 == "0248")
												{
													this.OnConnected(false, true);
												}
											}
										}
										else
										{
											this.loseconreason = "KO:" + text3;
											this.OnConnected(false, true);
											this.isudblogin = false;
										}
									}
								}
							}
							else if (text2 == "041F")
							{
								this.method_12(byte_1);
							}
							else if (text2 == "024D" || text2 == "0235" || text2 == "0240" || text2 == "020C")
							{
								this.loseconreason = "OKO:" + text2;
								this.OnConnected(false, true);
							}
						}
						else
						{
							this.method_4(byte_1);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001E1 RID: 481 RVA: 0x001613A8 File Offset: 0x001613A8
		private void method_3()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(20001, 21000);
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] bytes = ProtoPacket.pack<PExchangeKeyExt>(new PExchangeKeyExt(publicKey, exponent));
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x0016141C File Offset: 0x0016141C
		private void method_4(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 30000)
				{
					byte[] array = null;
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
						if (num != 0u)
						{
							using (ByteArray byteArray2 = new ByteArray())
							{
								protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
								array = byteArray2.Buffer;
								byteArray2.Dispose();
							}
						}
						byteArray.Dispose();
					}
					if (array == null || array.Length == 0)
					{
						throw new Exception("rsa fail");
					}
					byte[] array2 = rsautil.getInstance().decrypt(array);
					if (array2 == null)
					{
						throw new Exception("DEC");
					}
					this.logintcp.setarc(array2);
					if (this.logintype == 1)
					{
						if (this.isudblogin)
						{
							this.method_8();
						}
						else
						{
							this.method_5(false, null, null);
						}
					}
					else
					{
						this.method_6();
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00161538 File Offset: 0x00161538
		private void method_5(bool bool_7 = false, byte[] byte_1 = null, byte[] byte_2 = null)
		{
			try
			{
				if (!bool_7)
				{
					this.currentflag = rdomhelper.getrandom(30001, 31000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(31000, 32000);
				}
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 1u;
				udbyyloginReq._user = bytetool.String2Bytes(this.passport);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				string s = xxtea2.Encrypt(sha1.hash(this.pwd, Encoding.ASCII).ToLower(), (this.passport + "275d0ff676c0d65114acdefbd2ad87a3").Substring(0, 16));
				udbyyloginReq._user_token = Convert.FromBase64String(s);
				if (bool_7)
				{
					udbyyloginReq._pic_id = byte_1;
					int imageType = 1;
					using (MemoryStream memoryStream = new MemoryStream(byte_2))
					{
						ImageFormat rawFormat = Image.FromStream(memoryStream).RawFormat;
						if (rawFormat.Equals(ImageFormat.Jpeg))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Png))
						{
							imageType = 4;
						}
						else if (rawFormat.Equals(ImageFormat.Bmp))
						{
							imageType = 1;
						}
						else if (rawFormat.Equals(ImageFormat.Gif))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Icon))
						{
							imageType = 5;
						}
					}
					string text = this.yanzhengma = imagetool.CreateInstance().hqCode(byte_2, imageType);
					string s2 = text;
					udbyyloginReq._pic_code = Encoding.UTF8.GetBytes(s2);
				}
				byte[] bytes = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00161744 File Offset: 0x00161744
		private void method_6()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(30001, 31000);
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 9u;
				udbyyloginReq._user = bytetool.String2Bytes(this.username);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				udbyyloginReq._user_token = ProtoPacket.packNoHeader<CombAcctinfo>(new CombAcctinfo
				{
					acctinfo = bytetool.String2Bytes(this.pwden),
					appid_type = bytetool.String2Bytes("yycomscene")
				});
				byte[] bytes = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0016184C File Offset: 0x0016184C
		private void method_7(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 40000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_CliAPLoginAuth2Res pcs_CliAPLoginAuth2Res = new PCS_CliAPLoginAuth2Res();
						pcs_CliAPLoginAuth2Res.unmarshall(protoPacket.getBuffer());
						if (pcs_CliAPLoginAuth2Res.rescode != 200u)
						{
							throw new Exception(pcs_CliAPLoginAuth2Res.rescode.ToString());
						}
						protoPacket = ProtoPacket.unpackNoHeader(pcs_CliAPLoginAuth2Res.payLoad, pcs_CliAPLoginAuth2Res.ruri, pcs_CliAPLoginAuth2Res.rescode);
						UDBYYLoginRes udbyyloginRes = new UDBYYLoginRes();
						LoginData loginData = new LoginData();
						udbyyloginRes.unmarshall(protoPacket.getBuffer());
						if (udbyyloginRes._rescode == 18u)
						{
							this.isfenghao = true;
							this.status = 3;
						}
						else
						{
							string @string = Encoding.UTF8.GetString(udbyyloginRes._reason);
							if (!(@string.ToLower() == "success"))
							{
								if (@string.ToLower() == "user frozen")
								{
									throw new Exception("UF");
								}
								if (!(@string.ToLower() == "static_verify") && !(@string.ToLower() == "invalid piccode"))
								{
									if (!@string.Contains("invalid user"))
									{
										throw new Exception(@string);
									}
									this.OnConnected(false, false);
									this.mytrace = "MMCW";
									this.status = 33;
									this.isfenghao = true;
									this.joinstatus = 0;
								}
								else
								{
									this.mytrace = "YZM";
									this.method_5(true, udbyyloginRes._pic_id, udbyyloginRes._pic_data);
								}
							}
							else
							{
								using (ByteArray byteArray2 = new ByteArray(udbyyloginRes._login_data))
								{
									loginData.unmarshall(byteArray2);
									byteArray2.Dispose();
								}
								this.username = Encoding.UTF8.GetString(loginData._passport);
								this.yycookie = loginData._yycookie;
								this.uid = udbyyloginRes._yyuid.low;
								string cookie = Hex.fromArray(new ByteArray(this.yycookie), false);
								if (this.logintype == 1)
								{
									savepcbuser savepcbuser = new savepcbuser();
									savepcbuser.username = this.username;
									savepcbuser.cookie = cookie;
									savepcbuser.uid = this.uid.ToString();
									try
									{
										string msg = MyEncrypt.AesEncryptor(JsonConvert.SerializeObject(savepcbuser));
										logtool.logusercache_p(this.passport, msg);
									}
									catch
									{
									}
								}
								if (this.logintype == 1 && !this.isudblogin && this.pt != ProxyTypes.None)
								{
									this.isudblogin = true;
									this.OnConnected(false, false);
									this.joinstatus = -1;
									goto IL_280;
								}
								this.method_8();
							}
							byteArray.Dispose();
						}
						IL_280:;
					}
				}
			}
			catch (Exception ex)
			{
				this.mytrace = ex.Message;
			}
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x00161B5C File Offset: 0x00161B5C
		private void method_8()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(40001, 41000);
				byte[] bytes = (this.logintype != 1) ? ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
				{
					m_strAccount = bytetool.String2Bytes(this.username),
					m_strPassword = bytetool.String2Bytes(this.pwden),
					m_bRelogin = (this.currentflag == 40005),
					m_uAppID = 259u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					},
					m_strCookie = this.yycookie,
					m_uCliType = 2u,
					m_strFrom = bytetool.String2Bytes("yymwebflsh"),
					m_strCliVer = bytetool.String2Bytes("yymwebflsh")
				}) : ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
				{
					m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower()),
					m_bRelogin = false,
					m_uAppID = 259u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					},
					m_strCookie = this.yycookie,
					m_strAccount = Encoding.UTF8.GetBytes(this.username),
					m_uCliType = 2u,
					m_strFrom = bytetool.String2Bytes("8.45.0.0"),
					m_strCliVer = bytetool.String2Bytes("8.45.0.0")
				});
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x00161CF8 File Offset: 0x00161CF8
		private void method_9(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 50000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
						pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
						byteArray.Dispose();
						if (pcs_APLoginRes.m_uResCode != 200u)
						{
							if (this.logintype == 1)
							{
								this.isudblogin = false;
							}
							throw new Exception(pcs_APLoginRes.m_uResCode.ToString());
						}
						this.Send_0BD0_0307();
					}
				}
			}
			catch (Exception)
			{
				if (this.logintype == 1)
				{
					logtool.delusercache_p(this.passport);
					this.isudblogin = false;
				}
			}
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00161DBC File Offset: 0x00161DBC
		public void Send_0BD0_0307()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(50001, 51000);
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.method_2(0);
					byteArray.writeUnsignedInt(this.uid);
					byte[] array2 = bytetool.strToToHexByte(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					byteArray.method_2(array2.Length);
					byteArray.writeBytes(array2);
					byteArray.method_2(0);
					array = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array3 = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeBytes(bytetool.strToToHexByte("08000001030700001000000203010000"));
					byteArray2.writeUnsignedInt(this.uid);
					byteArray2.writeBytes(bytetool.strToToHexByte("0000000015000006DCCC1B00120B00000000050055496E666F1200000701000000010000000400000000001E0000081800030000000000000001003201000000010030030000000000787878FF"));
					array3 = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] bytes = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003070000C800"));
					byteArray3.method_2(array.Length);
					byteArray3.writeBytes(array);
					byteArray3.method_2(array3.Length);
					byteArray3.writeBytes(array3);
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					bytes = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00161FB4 File Offset: 0x00161FB4
		private void method_10(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 60000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						int num = (int)byteArray.readUnsignedInt();
						c_Data[] array = new c_Data[num];
						for (int i = 0; i < num; i++)
						{
							array[i] = new c_Data();
							array[i].intd = (int)byteArray.readUnsignedShort();
							ushort num2 = byteArray.readUnsignedShort();
							array[i].Data = new byte[(int)num2];
							for (int j = 0; j < (int)num2; j++)
							{
								array[i].Data[j] = byteArray.readByte();
							}
							if (array[i].intd == 2)
							{
								this.nicheng = Encoding.UTF8.GetString(array[i].Data);
							}
						}
						byteArray.Dispose();
					}
					this.currentflag = rdomhelper.getrandom(60001, 61000);
					this.isinqueue = true;
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060001EA RID: 490 RVA: 0x001620E0 File Offset: 0x001620E0
		public void Send_0BD0_02411F(bool ismuti = false)
		{
			try
			{
				if (ismuti)
				{
					this.currentflag = rdomhelper.getrandom(70001, 71000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(60001, 61000);
				}
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq();
				pjoinChannelReq.uid = this.uid;
				pjoinChannelReq.topsid = this.sid;
				pjoinChannelReq.subSid = this.subid;
				MYHashMap props = pjoinChannelReq.props;
				props.put(2u.ToString(), bytetool.String2Bytes("0"));
				if (ismuti)
				{
					MYHashMap props2 = pjoinChannelReq.props;
					props2.put(3u.ToString(), bytetool.String2Bytes("1"));
				}
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PJoinChannelReq>(pjoinChannelReq)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
				this.lastsendtime = DateTime.Now;
				this.buhaotime = DateTime.Now;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00162370 File Offset: 0x00162370
		private void method_11(byte[] byte_1)
		{
			try
			{
				if (this.status != 2)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						if (byte_1[8] != 200)
						{
							throw new Exception("ERR");
						}
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						uint num = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint subidnew = byteArray.readUnsignedInt();
						uint num2 = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint num3 = (uint)byteArray.readByte();
						if (num3 <= 7u)
						{
							if (num3 != 4u)
							{
								if (num3 == 7u)
								{
									this.mytrace = "M-J";
									this.Send_0BD0_02411F(true);
									goto IL_21D;
								}
							}
							else
							{
								if (this.sid != num2 && this.sid != num)
								{
									this.mytrace = "GOON";
									goto IL_21D;
								}
								this.mytrace = "SUC";
								this.currentflag = rdomhelper.getrandom(90001, 91000);
								this.joinchanneltime = DateTime.Now;
								this.lasthearttime = DateTime.Now;
								this.checkinchaneltime = DateTime.Now;
								this.joinstatus = 2;
								this.status = 2;
								this.isinqueue = false;
								int jointimes = this.jointimes;
								this.jointimes = jointimes + 1;
								if (this.sidnew == 0u)
								{
									this.sidnew = num;
								}
								if (this.subidnew == 0u)
								{
									this.subidnew = subidnew;
								}
								if (this.isgongneng)
								{
									this.Send_Service_1E73();
									goto IL_21D;
								}
								goto IL_21D;
							}
						}
						else if (num3 != 11u)
						{
							if (num3 == 12u)
							{
								this.OnConnected(false, false);
								this.isfenghao = true;
								this.status = 33;
								this.mytrace = "频道不存在";
								goto IL_21D;
							}
						}
						else
						{
							this.mytrace = "Y-J";
							this.currentflag = rdomhelper.getrandom(98001, 99000);
							this.joinchanneltime = DateTime.Now;
							this.lasthearttime = DateTime.Now;
							this.checkinchaneltime = DateTime.Now;
							this.joinstatus = 1;
							this.status = 1;
							if (this.sidnew == 0u)
							{
								this.sidnew = num;
							}
							if (this.subidnew == 0u)
							{
								this.subidnew = subidnew;
								goto IL_21D;
							}
							goto IL_21D;
						}
						throw new Exception("JERR:" + num3);
						IL_21D:
						byteArray.Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				this.mytrace = ex.Message;
			}
		}

		// Token: 0x060001EC RID: 492 RVA: 0x001625F4 File Offset: 0x001625F4
		public void Send_041E()
		{
			try
			{
				this.lasthearttime = DateTime.Now;
				byte[] bytes = ProtoPacket.pack<PCS_APPing>(new PCS_APPing());
				this.logintcp.Send(bytes);
				this.lastsendhearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001ED RID: 493 RVA: 0x00162644 File Offset: 0x00162644
		private void method_12(byte[] byte_1)
		{
			try
			{
				int heartbeat = this.heartbeat;
				this.heartbeat = heartbeat + 1;
				this.lasthearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00162684 File Offset: 0x00162684
		public void Send_Service_1E73()
		{
			try
			{
				this.startloginservicetime = DateTime.Now;
				PCS_GetAPInfo obj = new PCS_GetAPInfo
				{
					m_uAppId = 260u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					}
				};
				byte[] serverName = bytetool.String2Bytes("aplbs_webyy");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PCS_GetAPInfo>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = Convert.ToUInt32(this.uid);
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0016287C File Offset: 0x0016287C
		public void Recv_Service_1E74(byte[] data)
		{
			try
			{
				byte[] bytes = data.Skip(38).Take((int)data[36]).ToArray<byte>();
				using (ByteArray byteArray = new ByteArray(data.Skip((int)(36 + data[36] + 10)).Take(5).ToArray<byte>()))
				{
					this.serviceport = (int)byteArray.ReadShort();
				}
				this.serviceip = Encoding.Default.GetString(bytes);
				this.connect_s();
			}
			catch
			{
			}
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x00162914 File Offset: 0x00162914
		public void GetMicList()
		{
			try
			{
				PGetMaixuListReq obj = new PGetMaixuListReq
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelMaixu");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PGetMaixuListReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x0015F12C File Offset: 0x0015F12C
		private void method_13(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					new PGetMaixuListRes().unmarshall(protoPacket.getBuffer());
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x00162B10 File Offset: 0x00162B10
		public void GetUserCount()
		{
			try
			{
				GClass1 obj = new GClass1
				{
					topSid = this.sidnew,
					sidlist = 
					{
						this.sidnew,
						this.subidnew
					}
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass1>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x00162D18 File Offset: 0x00162D18
		private void method_14(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint count = byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						if (this.subidnew == byteArray.readUnsignedInt())
						{
							count = byteArray.readUnsignedInt();
							IL_71:
							MyUser1222.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
							if (onGetUserCount != null)
							{
								onGetUserCount(count);
							}
							goto IL_8E;
						}
						num2++;
					}
					goto IL_71;
				}
				IL_8E:;
			}
			catch
			{
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x00162DD4 File Offset: 0x00162DD4
		public void GetUserList(uint count, uint pos = 0u)
		{
			try
			{
				GClass3 obj = new GClass3
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					pos = pos,
					num = count
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass3>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x00162FD4 File Offset: 0x00162FD4
		private void method_15(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					List<uint> list = new List<uint>();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						list.Add(byteArray.readUnsignedInt());
						uint num3 = byteArray.readUnsignedInt();
						int num4 = 0;
						while ((long)num4 < (long)((ulong)num3))
						{
							byteArray.readByte();
							byteArray.readUnsignedInt();
							num4++;
						}
						uint num5 = byteArray.readUnsignedInt();
						int num6 = 0;
						while ((long)num6 < (long)((ulong)num5))
						{
							byteArray.readByte();
							short num7 = byteArray.ReadShort();
							byteArray.position += (int)num7;
							num6++;
						}
						num2++;
					}
					list.Add(this.uid);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x001630EC File Offset: 0x001630EC
		public byte[] GetUserInfo()
		{
			byte[] result;
			try
			{
				List<uint> list = new List<uint>();
				list.Add(this.uid);
				PQueryUserInfoReq obj = new PQueryUserInfoReq
				{
					uidlist = list,
					topSid = this.sidnew,
					type = 0u
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PQueryUserInfoReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					array = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				result = array;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0015F96C File Offset: 0x0015F96C
		private void method_16(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x001632F0 File Offset: 0x001632F0
		public void LeaveChanel()
		{
			try
			{
				new List<uint>().Add(this.uid);
				PLeaveChannelReq obj = new PLeaveChannelReq
				{
					topsid = this.sidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PLeaveChannelReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					bytes = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x00158048 File Offset: 0x00158048
		public void connect_s()
		{
		}

		// Token: 0x060001FA RID: 506 RVA: 0x00158B33 File Offset: 0x00158B33
		public void OnConnected_s(bool issuccess, bool isduankai = false)
		{
			if (issuccess)
			{
				this.Send_0411_s();
				return;
			}
			if (this.status == 2)
			{
				this.Send_Service_1E73();
			}
		}

		// Token: 0x060001FB RID: 507 RVA: 0x001634F0 File Offset: 0x001634F0
		private void method_17(byte[] byte_1)
		{
			try
			{
				if (byte_1[8] == 200 && byte_1[9] == 0)
				{
					this.byteArray_1 = null;
					this.byteArray_1 = new ByteArray();
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						this.int_12 = byteArray.ReadInt();
					}
					this.byteArray_1.writeBytes(byte_1);
				}
				else if (this.byteArray_1 != null && this.byteArray_1.length > 0 && this.byteArray_1.length < this.int_12)
				{
					this.byteArray_1.writeBytes(byte_1);
				}
				if (this.byteArray_1 != null && this.byteArray_1.length >= this.int_12)
				{
					this.int_12 = 0;
					this.method_18(this.byteArray_1.Buffer);
				}
			}
			catch
			{
				this.byteArray_1 = null;
				this.int_12 = 0;
			}
		}

		// Token: 0x060001FC RID: 508 RVA: 0x0015FDC0 File Offset: 0x0015FDC0
		private void method_18(byte[] byte_1)
		{
			try
			{
				if (byte_1 != null && byte_1.Length >= 10 && byte_1[8] == 200)
				{
					string text = bytetool.fromArray(byte_1, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2) && !(text2 == "1E74") && text2 == "0BD0")
					{
						try
						{
							text.Substring(24, 4).ToUpper();
							text.Substring(24, 6).ToUpper();
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060001FD RID: 509 RVA: 0x001635E4 File Offset: 0x001635E4
		public void Send_0411_s()
		{
			try
			{
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] bytes = ProtoPacket.pack<PExchangeKey>(new PExchangeKey(publicKey, exponent));
				this.servicetcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00163638 File Offset: 0x00163638
		public void Recv_0412_s(byte[] data)
		{
			try
			{
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray(data))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
					if (num != 0u)
					{
						using (ByteArray byteArray2 = new ByteArray())
						{
							protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
							array = byteArray2.Buffer;
							byteArray2.Dispose();
						}
					}
					byteArray.Dispose();
				}
				if (array == null || array.Length == 0)
				{
					throw new Exception("rsa fail");
				}
				byte[] bytes = rsautil.getInstance().decrypt(array);
				this.servicetcp.setarc(bytes);
				this.method_19();
			}
			catch
			{
			}
		}

		// Token: 0x060001FF RID: 511 RVA: 0x00163710 File Offset: 0x00163710
		private void method_19()
		{
			try
			{
				byte[] bytes;
				if (this.logintype == 1)
				{
					PCS_APLogin pcs_APLogin = new PCS_APLogin();
					pcs_APLogin.m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					if (this.yycookie != null && this.yycookie.Length != 0)
					{
						pcs_APLogin.m_bRelogin = true;
					}
					else
					{
						pcs_APLogin.m_bRelogin = false;
					}
					pcs_APLogin.m_uAppID = 260u;
					pcs_APLogin.m_uUid.low = Convert.ToUInt32(this.uid);
					pcs_APLogin.m_strCookie = this.yycookie;
					pcs_APLogin.m_strAccount = Encoding.UTF8.GetBytes(this.username);
					pcs_APLogin.m_uCliType = 2u;
					pcs_APLogin.m_strFrom = bytetool.String2Bytes("8.45.0.0");
					pcs_APLogin.m_strCliVer = bytetool.String2Bytes("8.45.0.0");
					bytes = ProtoPacket.pack<PCS_APLogin>(pcs_APLogin);
				}
				else
				{
					bytes = ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
					{
						m_strAccount = bytetool.String2Bytes(this.username),
						m_strPassword = bytetool.String2Bytes(this.pwden),
						m_bRelogin = false,
						m_uAppID = 260u,
						m_uUid = 
						{
							low = Convert.ToUInt32(this.uid)
						},
						m_strCookie = this.yycookie,
						m_uCliType = 2u,
						m_strFrom = bytetool.String2Bytes("yymwebflsh"),
						m_strCliVer = bytetool.String2Bytes("yymwebflsh")
					});
				}
				this.servicetcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x06000200 RID: 512 RVA: 0x0016389C File Offset: 0x0016389C
		public void Recv_04D7_s(byte[] data)
		{
			using (ByteArray byteArray = new ByteArray(data))
			{
				ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
				PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
				pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
				byteArray.Dispose();
				if (pcs_APLoginRes.m_uResCode != 200u)
				{
					this.isudblogin = false;
					this.OnConnected_s(false, false);
				}
				else
				{
					this.lastservicehearttime = DateTime.Now;
					this.isloginservice = true;
					if (this.isqutubiao)
					{
						this.method_20();
					}
					if (this.isxianche)
					{
						this.method_21();
					}
				}
			}
		}

		// Token: 0x06000201 RID: 513 RVA: 0x0016393C File Offset: 0x0016393C
		private void method_20()
		{
			try
			{
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray2 = byteArray;
					byte[] array = new byte[16];
					array[4] = 2;
					array[8] = 1;
					byteArray2.writeBytes(array);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray3 = byteArray;
					byte[] array2 = new byte[12];
					array2[4] = 2;
					byteArray3.writeBytes(array2);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						172,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						207,
						9,
						0,
						0,
						0,
						46,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray4 = byteArray;
					byte[] array3 = new byte[16];
					array3[4] = 2;
					array3[8] = 1;
					byteArray4.writeBytes(array3);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray5 = byteArray;
					byte[] array4 = new byte[12];
					array4[4] = 2;
					byteArray5.writeBytes(array4);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						207,
						9,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray6 = byteArray;
					byte[] array5 = new byte[16];
					array5[4] = 2;
					array5[8] = 1;
					byteArray6.writeBytes(array5);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray7 = byteArray;
					byte[] array6 = new byte[12];
					array6[4] = 2;
					byteArray7.writeBytes(array6);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						203,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						77,
						0,
						0,
						0,
						22,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						45,
						0,
						0,
						0,
						45,
						0,
						0,
						0,
						88,
						228,
						5,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						17,
						0,
						2,
						0,
						0,
						0,
						1,
						0,
						1,
						0,
						48,
						2,
						0,
						4,
						0
					});
					byteArray.writeBytes(Encoding.Default.GetBytes("4000"));
					byteArray.writeBytes(new byte[6]);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						168,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						42,
						0,
						0,
						0,
						155,
						58
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						10,
						0,
						0,
						0,
						11,
						0,
						0,
						0,
						232,
						3,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue
					});
					bytes = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x06000202 RID: 514 RVA: 0x00163DE0 File Offset: 0x00163DE0
		private void method_21()
		{
			try
			{
				byte[] bytes = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 4;
					byteArray.writeBytes(bytetool.strToToHexByte("0BD00700C800000058380100C8002E000000A43A"));
					byteArray.writeUnsignedInt(this.sidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0A0000000B0000004C0400000000000000000100"));
					byteArray.writeUnsignedInt(this.subidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0001000000000000370000000800000158380100100000020401000033A49F43000000001B00000702000000FF030000050031353031320004000002003336787878FF"));
					byteArray.position = 0;
					byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
					bytes = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x040000F2 RID: 242
		[CompilerGenerated]
		private MyUser1222.OnGetUserCount onGetUserCount_0;

		// Token: 0x040000F3 RID: 243
		[CompilerGenerated]
		private MyUser1222.OnGetUserList onGetUserList_0;

		// Token: 0x040000F4 RID: 244
		[CompilerGenerated]
		private int int_0;

		// Token: 0x040000F5 RID: 245
		[CompilerGenerated]
		private int int_1;

		// Token: 0x040000F6 RID: 246
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040000F7 RID: 247
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040000F8 RID: 248
		[CompilerGenerated]
		private string string_2;

		// Token: 0x040000F9 RID: 249
		[CompilerGenerated]
		private int int_2;

		// Token: 0x040000FA RID: 250
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x040000FB RID: 251
		[CompilerGenerated]
		private int int_3;

		// Token: 0x040000FC RID: 252
		[CompilerGenerated]
		private int int_4;

		// Token: 0x040000FD RID: 253
		[CompilerGenerated]
		private int int_5;

		// Token: 0x040000FE RID: 254
		[CompilerGenerated]
		private uint uint_0;

		// Token: 0x040000FF RID: 255
		[CompilerGenerated]
		private string string_3;

		// Token: 0x04000100 RID: 256
		[CompilerGenerated]
		private string string_4;

		// Token: 0x04000101 RID: 257
		[CompilerGenerated]
		private uint fsiRbrvbWl;

		// Token: 0x04000102 RID: 258
		[CompilerGenerated]
		private uint uint_1;

		// Token: 0x04000103 RID: 259
		[CompilerGenerated]
		private uint uint_2;

		// Token: 0x04000104 RID: 260
		[CompilerGenerated]
		private uint uint_3;

		// Token: 0x04000105 RID: 261
		[CompilerGenerated]
		private string string_5;

		// Token: 0x04000106 RID: 262
		[CompilerGenerated]
		private OldTcp oldTcp_0;

		// Token: 0x04000107 RID: 263
		[CompilerGenerated]
		private OldTcp oldTcp_1;

		// Token: 0x04000108 RID: 264
		[CompilerGenerated]
		private string string_6;

		// Token: 0x04000109 RID: 265
		[CompilerGenerated]
		private int int_6;

		// Token: 0x0400010A RID: 266
		[CompilerGenerated]
		private int int_7;

		// Token: 0x0400010B RID: 267
		[CompilerGenerated]
		private ProxyTypes proxyTypes_0;

		// Token: 0x0400010C RID: 268
		[CompilerGenerated]
		private string string_7;

		// Token: 0x0400010D RID: 269
		[CompilerGenerated]
		private string ifuRrxyhGr;

		// Token: 0x0400010E RID: 270
		[CompilerGenerated]
		private int int_8;

		// Token: 0x0400010F RID: 271
		[CompilerGenerated]
		private bool bool_1;

		// Token: 0x04000110 RID: 272
		[CompilerGenerated]
		private bool bool_2;

		// Token: 0x04000111 RID: 273
		[CompilerGenerated]
		private byte[] byte_0;

		// Token: 0x04000112 RID: 274
		[CompilerGenerated]
		private string string_8;

		// Token: 0x04000113 RID: 275
		[CompilerGenerated]
		private int int_9;

		// Token: 0x04000114 RID: 276
		[CompilerGenerated]
		private string string_9;

		// Token: 0x04000115 RID: 277
		[CompilerGenerated]
		private DateTime dateTime_0;

		// Token: 0x04000116 RID: 278
		[CompilerGenerated]
		private DateTime dateTime_1;

		// Token: 0x04000117 RID: 279
		[CompilerGenerated]
		private DateTime dateTime_2;

		// Token: 0x04000118 RID: 280
		[CompilerGenerated]
		private DateTime dateTime_3;

		// Token: 0x04000119 RID: 281
		[CompilerGenerated]
		private DateTime dateTime_4;

		// Token: 0x0400011A RID: 282
		[CompilerGenerated]
		private DateTime dateTime_5;

		// Token: 0x0400011B RID: 283
		[CompilerGenerated]
		private DateTime dateTime_6;

		// Token: 0x0400011C RID: 284
		[CompilerGenerated]
		private DateTime dateTime_7;

		// Token: 0x0400011D RID: 285
		[CompilerGenerated]
		private DateTime dateTime_8;

		// Token: 0x0400011E RID: 286
		[CompilerGenerated]
		private DateTime dateTime_9;

		// Token: 0x0400011F RID: 287
		[CompilerGenerated]
		private DateTime dateTime_10;

		// Token: 0x04000120 RID: 288
		[CompilerGenerated]
		private bool bool_3;

		// Token: 0x04000121 RID: 289
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x04000122 RID: 290
		[CompilerGenerated]
		private bool bool_5;

		// Token: 0x04000123 RID: 291
		[CompilerGenerated]
		private bool bool_6;

		// Token: 0x04000124 RID: 292
		[CompilerGenerated]
		private string string_10;

		// Token: 0x04000125 RID: 293
		[CompilerGenerated]
		private int int_10;

		// Token: 0x04000126 RID: 294
		[CompilerGenerated]
		private DateTime dateTime_11;

		// Token: 0x04000127 RID: 295
		private System.Timers.Timer timer_0;

		// Token: 0x04000128 RID: 296
		private System.Timers.Timer timer_1;

		// Token: 0x04000129 RID: 297
		private uint uint_4;

		// Token: 0x0400012A RID: 298
		private ByteArray byteArray_0;

		// Token: 0x0400012B RID: 299
		private int int_11;

		// Token: 0x0400012C RID: 300
		private ByteArray byteArray_1;

		// Token: 0x0400012D RID: 301
		private int int_12;

		// Token: 0x02000022 RID: 34
		// (Invoke) Token: 0x06000204 RID: 516
		public delegate void OnGetUserCount(uint count);

		// Token: 0x02000023 RID: 35
		// (Invoke) Token: 0x06000208 RID: 520
		public delegate void OnGetUserList(uint pos);
	}
}
