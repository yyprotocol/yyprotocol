﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000005 RID: 5
	public class authrequest
	{
		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000016 RID: 22 RVA: 0x001580FE File Offset: 0x001580FE
		// (set) Token: 0x06000017 RID: 23 RVA: 0x00158106 File Offset: 0x00158106
		public string MDate { get; set; }

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000018 RID: 24 RVA: 0x0015810F File Offset: 0x0015810F
		// (set) Token: 0x06000019 RID: 25 RVA: 0x00158117 File Offset: 0x00158117
		public string MAC { get; set; }

		// Token: 0x0400000D RID: 13
		[CompilerGenerated]
		private string string_0;

		// Token: 0x0400000E RID: 14
		[CompilerGenerated]
		private string string_1;
	}
}
