﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000014 RID: 20
	public class myip
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x0600007F RID: 127 RVA: 0x00158372 File Offset: 0x00158372
		// (set) Token: 0x06000080 RID: 128 RVA: 0x0015837A File Offset: 0x0015837A
		public string ip { get; set; }

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000081 RID: 129 RVA: 0x00158383 File Offset: 0x00158383
		// (set) Token: 0x06000082 RID: 130 RVA: 0x0015838B File Offset: 0x0015838B
		public int[] ports { get; set; }

		// Token: 0x0400005C RID: 92
		[CompilerGenerated]
		private string string_0;

		// Token: 0x0400005D RID: 93
		[CompilerGenerated]
		private int[] int_0;
	}
}
