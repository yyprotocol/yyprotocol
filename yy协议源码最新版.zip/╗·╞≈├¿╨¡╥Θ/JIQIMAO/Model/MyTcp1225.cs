﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x0200001A RID: 26
	public class MyTcp1225 : IDisposable
	{
		// Token: 0x14000006 RID: 6
		// (add) Token: 0x060000AB RID: 171 RVA: 0x0015C6BC File Offset: 0x0015C6BC
		// (remove) Token: 0x060000AC RID: 172 RVA: 0x0015C6F4 File Offset: 0x0015C6F4
		public event MyTcp1225.OnSend SendEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp1225.OnSend onSend = this.onSend_0;
				MyTcp1225.OnSend onSend2;
				do
				{
					onSend2 = onSend;
					MyTcp1225.OnSend value2 = (MyTcp1225.OnSend)Delegate.Combine(onSend2, value);
					onSend = Interlocked.CompareExchange<MyTcp1225.OnSend>(ref this.onSend_0, value2, onSend2);
				}
				while (onSend != onSend2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp1225.OnSend onSend = this.onSend_0;
				MyTcp1225.OnSend onSend2;
				do
				{
					onSend2 = onSend;
					MyTcp1225.OnSend value2 = (MyTcp1225.OnSend)Delegate.Remove(onSend2, value);
					onSend = Interlocked.CompareExchange<MyTcp1225.OnSend>(ref this.onSend_0, value2, onSend2);
				}
				while (onSend != onSend2);
			}
		}

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x060000AD RID: 173 RVA: 0x0015C72C File Offset: 0x0015C72C
		// (remove) Token: 0x060000AE RID: 174 RVA: 0x0015C764 File Offset: 0x0015C764
		public event MyTcp1225.OnRecive ReciveEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp1225.OnRecive onRecive = this.onRecive_0;
				MyTcp1225.OnRecive onRecive2;
				do
				{
					onRecive2 = onRecive;
					MyTcp1225.OnRecive value2 = (MyTcp1225.OnRecive)Delegate.Combine(onRecive2, value);
					onRecive = Interlocked.CompareExchange<MyTcp1225.OnRecive>(ref this.onRecive_0, value2, onRecive2);
				}
				while (onRecive != onRecive2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp1225.OnRecive onRecive = this.onRecive_0;
				MyTcp1225.OnRecive onRecive2;
				do
				{
					onRecive2 = onRecive;
					MyTcp1225.OnRecive value2 = (MyTcp1225.OnRecive)Delegate.Remove(onRecive2, value);
					onRecive = Interlocked.CompareExchange<MyTcp1225.OnRecive>(ref this.onRecive_0, value2, onRecive2);
				}
				while (onRecive != onRecive2);
			}
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x060000AF RID: 175 RVA: 0x0015C79C File Offset: 0x0015C79C
		// (remove) Token: 0x060000B0 RID: 176 RVA: 0x0015C7D4 File Offset: 0x0015C7D4
		public event MyTcp1225.OnCloseCon CloseConEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp1225.OnCloseCon onCloseCon = this.onCloseCon_0;
				MyTcp1225.OnCloseCon onCloseCon2;
				do
				{
					onCloseCon2 = onCloseCon;
					MyTcp1225.OnCloseCon value2 = (MyTcp1225.OnCloseCon)Delegate.Combine(onCloseCon2, value);
					onCloseCon = Interlocked.CompareExchange<MyTcp1225.OnCloseCon>(ref this.onCloseCon_0, value2, onCloseCon2);
				}
				while (onCloseCon != onCloseCon2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp1225.OnCloseCon onCloseCon = this.onCloseCon_0;
				MyTcp1225.OnCloseCon onCloseCon2;
				do
				{
					onCloseCon2 = onCloseCon;
					MyTcp1225.OnCloseCon value2 = (MyTcp1225.OnCloseCon)Delegate.Remove(onCloseCon2, value);
					onCloseCon = Interlocked.CompareExchange<MyTcp1225.OnCloseCon>(ref this.onCloseCon_0, value2, onCloseCon2);
				}
				while (onCloseCon != onCloseCon2);
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x060000B1 RID: 177 RVA: 0x0015C80C File Offset: 0x0015C80C
		// (remove) Token: 0x060000B2 RID: 178 RVA: 0x0015C844 File Offset: 0x0015C844
		public event MyTcp1225.OnCon ConEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp1225.OnCon onCon = this.onCon_0;
				MyTcp1225.OnCon onCon2;
				do
				{
					onCon2 = onCon;
					MyTcp1225.OnCon value2 = (MyTcp1225.OnCon)Delegate.Combine(onCon2, value);
					onCon = Interlocked.CompareExchange<MyTcp1225.OnCon>(ref this.onCon_0, value2, onCon2);
				}
				while (onCon != onCon2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp1225.OnCon onCon = this.onCon_0;
				MyTcp1225.OnCon onCon2;
				do
				{
					onCon2 = onCon;
					MyTcp1225.OnCon value2 = (MyTcp1225.OnCon)Delegate.Remove(onCon2, value);
					onCon = Interlocked.CompareExchange<MyTcp1225.OnCon>(ref this.onCon_0, value2, onCon2);
				}
				while (onCon != onCon2);
			}
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0015C87C File Offset: 0x0015C87C
		public MyTcp1225(string ip, int port, ProxyTypes pt = ProxyTypes.None, string daili = "", string localip = "")
		{
			this.mySocketEventArgs_0 = new MySocketEventArgs();
			this.ipendPoint_0 = new IPEndPoint(IPAddress.Parse(ip), port);
			this.clientSocket = new ProxySocket(this.ipendPoint_0.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
			this.clientSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, new LingerOption(true, 0));
			IPAddress address;
			if (!string.IsNullOrWhiteSpace(localip) && IPAddress.TryParse(localip, out address))
			{
				IPEndPoint localEP = new IPEndPoint(address, 0);
				this.clientSocket.Bind(localEP);
			}
			if (!string.IsNullOrWhiteSpace(daili) && daili.Trim().Length > 0)
			{
				string[] array = daili.Split(new char[]
				{
					'|'
				});
				if (pt == ProxyTypes.Https)
				{
					array = daili.Split(new char[]
					{
						':'
					});
				}
				this.clientSocket.ProxyEndPoint = new IPEndPoint(IPAddress.Parse(array[0]), Convert.ToInt32(array[1]));
				if (array.Length > 2)
				{
					this.clientSocket.ProxyUser = array[2];
					this.clientSocket.ProxyPass = array[3];
				}
			}
			this.clientSocket.ProxyType = pt;
			this.list_0 = new List<byte>();
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x0015841B File Offset: 0x0015841B
		public void setarc(byte[] bytes)
		{
			if (this.arc4_0 == null)
			{
				this.arc4_0 = new ARC4(bytes, false);
				this.arc4_1 = new ARC4(bytes, true);
			}
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x0015C9A4 File Offset: 0x0015C9A4
		public void Connect()
		{
			try
			{
				this.clientSocket.BeginConnect(this.ipendPoint_0, new AsyncCallback(this.VvVnOpsTju), null);
			}
			catch
			{
				try
				{
					MyTcp1225.OnCloseCon onCloseCon = this.onCloseCon_0;
					if (onCloseCon != null)
					{
						onCloseCon();
					}
				}
				catch
				{
				}
				this.Dispose();
			}
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0015CA0C File Offset: 0x0015CA0C
		public void initArgs()
		{
			try
			{
				byte[] buffer = new byte[8196];
				this.mySocketEventArgs_0.Completed += this.method_1;
				this.mySocketEventArgs_0.UserToken = this.clientSocket;
				this.mySocketEventArgs_0.ArgsTag = 0;
				this.mySocketEventArgs_0.SetBuffer(buffer, 0, 8196);
				if (!this.clientSocket.ReceiveAsync(this.mySocketEventArgs_0))
				{
					this.method_3(this.mySocketEventArgs_0);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0015CAA0 File Offset: 0x0015CAA0
		private MySocketEventArgs method_0()
		{
			MySocketEventArgs mySocketEventArgs = new MySocketEventArgs();
			mySocketEventArgs.Completed += this.method_1;
			mySocketEventArgs.UserToken = this.clientSocket;
			mySocketEventArgs.RemoteEndPoint = this.ipendPoint_0;
			mySocketEventArgs.IsUsing = false;
			Interlocked.Increment(ref this.int_0);
			mySocketEventArgs.ArgsTag = this.int_0;
			return mySocketEventArgs;
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x0015CB00 File Offset: 0x0015CB00
		private void method_1(object sender, SocketAsyncEventArgs e)
		{
			try
			{
				SocketAsyncOperation lastOperation = e.LastOperation;
				if (lastOperation != SocketAsyncOperation.Receive)
				{
					if (lastOperation != SocketAsyncOperation.Send)
					{
						throw new ArgumentException("The last operation completed on the socket was not a receive or send");
					}
					this.method_2(e);
				}
				else
				{
					this.method_3(e);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x0015CB4C File Offset: 0x0015CB4C
		public void Send(byte[] sendBuffer, bool issync = false)
		{
			MySocketEventArgs mySocketEventArgs = this.method_0();
			try
			{
				if (this.arc4_0 != null)
				{
					this.arc4_0.encrypt(sendBuffer);
				}
				mySocketEventArgs.IsUsing = true;
				mySocketEventArgs.SetBuffer(sendBuffer, 0, sendBuffer.Length);
				if (this.clientSocket != null && !this.clientSocket.SendAsync(mySocketEventArgs))
				{
					this.method_2(mySocketEventArgs);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0015CBB8 File Offset: 0x0015CBB8
		private void method_2(SocketAsyncEventArgs socketAsyncEventArgs_0)
		{
			SocketError socketError = SocketError.Success;
			try
			{
				MySocketEventArgs mySocketEventArgs = (MySocketEventArgs)socketAsyncEventArgs_0;
				socketError = mySocketEventArgs.SocketError;
				mySocketEventArgs.IsUsing = false;
				mySocketEventArgs.SetBuffer(null, 0, 0);
				mySocketEventArgs.Completed -= this.method_1;
				mySocketEventArgs.Dispose();
			}
			catch
			{
			}
			try
			{
				if (socketError != SocketError.Success)
				{
					this.method_4();
				}
				else if (this.onSend_0 != null)
				{
					this.onSend_0();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000BB RID: 187 RVA: 0x0015CC44 File Offset: 0x0015CC44
		private void method_3(SocketAsyncEventArgs socketAsyncEventArgs_0)
		{
			try
			{
				Socket socket = (Socket)socketAsyncEventArgs_0.UserToken;
				if (socketAsyncEventArgs_0.SocketError == SocketError.Success && socketAsyncEventArgs_0.BytesTransferred > 0)
				{
					byte[] array = new byte[socketAsyncEventArgs_0.BytesTransferred];
					Array.Copy(socketAsyncEventArgs_0.Buffer, socketAsyncEventArgs_0.Offset, array, 0, socketAsyncEventArgs_0.BytesTransferred);
					if (this.arc4_1 != null)
					{
						this.arc4_1.decrypt(array);
					}
					List<byte> obj = this.list_0;
					lock (obj)
					{
						this.list_0.AddRange(array);
						goto IL_ED;
					}
					IL_85:
					int num;
					byte[] data = this.list_0.GetRange(0, num).ToArray();
					List<byte> obj2 = this.list_0;
					lock (obj2)
					{
						this.list_0.RemoveRange(0, num);
					}
					if (this.onRecive_0 != null)
					{
						this.onRecive_0(data);
					}
					if (this.list_0.Count <= 4)
					{
						goto IL_119;
					}
					IL_ED:
					num = BitConverter.ToInt32(this.list_0.GetRange(0, 4).ToArray(), 0);
					if (num <= this.list_0.Count)
					{
						goto IL_85;
					}
					IL_119:
					if (!socket.ReceiveAsync(socketAsyncEventArgs_0))
					{
						this.method_3(socketAsyncEventArgs_0);
					}
				}
				else
				{
					this.method_4();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x0015CDD4 File Offset: 0x0015CDD4
		private void method_4()
		{
			try
			{
				if (this.onCloseCon_0 != null)
				{
					this.onCloseCon_0();
					this.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x0015CE10 File Offset: 0x0015CE10
		public void Dispose()
		{
			try
			{
				this.clientSocket.Shutdown(SocketShutdown.Both);
			}
			catch
			{
			}
			try
			{
				try
				{
					this.mySocketEventArgs_0.Completed -= this.method_1;
					this.mySocketEventArgs_0.SetBuffer(null, 0, 0);
					this.mySocketEventArgs_0.Dispose();
				}
				catch
				{
					if (this.mySocketEventArgs_0 != null)
					{
						this.mySocketEventArgs_0.Dispose();
					}
				}
			}
			catch
			{
			}
			try
			{
				this.clientSocket.Close();
				this.list_0 = null;
				this.arc4_0 = (this.arc4_1 = null);
			}
			catch
			{
			}
			try
			{
				this.clientSocket.Dispose();
			}
			catch
			{
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x0015CEF8 File Offset: 0x0015CEF8
		[CompilerGenerated]
		private void VvVnOpsTju(IAsyncResult iasyncResult_0)
		{
			try
			{
				this.clientSocket.EndConnect(iasyncResult_0);
			}
			catch
			{
			}
			if (this.clientSocket.Connected)
			{
				this.initArgs();
				MyTcp1225.OnCon onCon = this.onCon_0;
				if (onCon != null)
				{
					onCon();
					return;
				}
			}
			else
			{
				MyTcp1225.OnCloseCon onCloseCon = this.onCloseCon_0;
				if (onCloseCon != null)
				{
					onCloseCon();
				}
				this.Dispose();
			}
		}

		// Token: 0x0400007C RID: 124
		private ARC4 arc4_0;

		// Token: 0x0400007D RID: 125
		private ARC4 arc4_1;

		// Token: 0x0400007E RID: 126
		private IPEndPoint ipendPoint_0;

		// Token: 0x0400007F RID: 127
		public ProxySocket clientSocket;

		// Token: 0x04000080 RID: 128
		[CompilerGenerated]
		private MyTcp1225.OnSend onSend_0;

		// Token: 0x04000081 RID: 129
		[CompilerGenerated]
		private MyTcp1225.OnRecive onRecive_0;

		// Token: 0x04000082 RID: 130
		[CompilerGenerated]
		private MyTcp1225.OnCloseCon onCloseCon_0;

		// Token: 0x04000083 RID: 131
		[CompilerGenerated]
		private MyTcp1225.OnCon onCon_0;

		// Token: 0x04000084 RID: 132
		private List<byte> list_0;

		// Token: 0x04000085 RID: 133
		private MySocketEventArgs mySocketEventArgs_0;

		// Token: 0x04000086 RID: 134
		private int int_0;

		// Token: 0x0200001B RID: 27
		// (Invoke) Token: 0x060000C0 RID: 192
		public delegate void OnSend();

		// Token: 0x0200001C RID: 28
		// (Invoke) Token: 0x060000C4 RID: 196
		public delegate void OnRecive(byte[] data);

		// Token: 0x0200001D RID: 29
		// (Invoke) Token: 0x060000C8 RID: 200
		public delegate void OnCloseCon();

		// Token: 0x0200001E RID: 30
		// (Invoke) Token: 0x060000CC RID: 204
		public delegate void OnCon();
	}
}
