﻿using System;
using System.Net.Sockets;

namespace JIQIMAO.Model
{
	// Token: 0x0200002E RID: 46
	public static class TcpClientEx
	{
		// Token: 0x060002F8 RID: 760 RVA: 0x00169E34 File Offset: 0x00169E34
		public static bool IsOnline(this TcpClient c)
		{
			bool blocking = c.Client.Blocking;
			bool result;
			try
			{
				byte[] buffer = new byte[1];
				c.Client.Blocking = false;
				c.Client.Send(buffer, 0, SocketFlags.None);
				result = true;
			}
			catch (SocketException ex)
			{
				if (!ex.NativeErrorCode.Equals(10035))
				{
					result = false;
				}
				else
				{
					result = true;
				}
			}
			finally
			{
				c.Client.Blocking = blocking;
			}
			return result;
		}
	}
}
