﻿using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x02000029 RID: 41
	public class OldTcp : IDisposable
	{
		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x060002D4 RID: 724 RVA: 0x00158F50 File Offset: 0x00158F50
		public bool connected
		{
			get
			{
				return this.client != null && this.client.Connected;
			}
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00169AF4 File Offset: 0x00169AF4
		public OldTcp(string ip, int port, string daili = "", ProxyTypes pt = ProxyTypes.None, string localip = "")
		{
			try
			{
				this.client = new TcpClient();
				this.proxySocket_0 = new ProxySocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				this.proxySocket_0.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, new LingerOption(true, 0));
				IPAddress address;
				if (!string.IsNullOrWhiteSpace(localip) && IPAddress.TryParse(localip, out address))
				{
					IPEndPoint localEP = new IPEndPoint(address, 0);
					this.proxySocket_0.Bind(localEP);
				}
				if (daili.Trim().Length > 0)
				{
					string[] array = daili.Split(new char[]
					{
						'|'
					});
					if (pt == ProxyTypes.Https)
					{
						array = daili.Split(new char[]
						{
							':'
						});
					}
					this.proxySocket_0.ProxyEndPoint = new IPEndPoint(IPAddress.Parse(array[0]), Convert.ToInt32(array[1]));
					if (array.Length > 2)
					{
						this.proxySocket_0.ProxyUser = array[2];
						this.proxySocket_0.ProxyPass = array[3];
					}
				}
				this.proxySocket_0.ProxyType = pt;
				this.client.ReceiveTimeout = 3000;
				this.arc4_0 = null;
				this.arc4_1 = null;
				IPAddress address2 = IPAddress.Parse(ip);
				this.ipendPoint_0 = new IPEndPoint(address2, port);
			}
			catch (Exception ex)
			{
				throw new Exception("ctcp:" + ex.Message);
			}
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x00158F67 File Offset: 0x00158F67
		public void setarc(byte[] bytes)
		{
			if (this.arc4_0 == null)
			{
				this.arc4_0 = new ARC4(bytes, false);
				this.arc4_1 = new ARC4(bytes, true);
			}
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x00169C54 File Offset: 0x00169C54
		public bool connect(string msg = "")
		{
			bool result;
			try
			{
				this.proxySocket_0.Connect(this.ipendPoint_0);
				if (!this.proxySocket_0.Connected)
				{
					result = false;
				}
				else
				{
					this.client.Client = this.proxySocket_0;
					this.networkStream_0 = this.client.GetStream();
					result = true;
				}
			}
			catch (Exception ex)
			{
				msg = ex.Message;
				result = false;
			}
			return result;
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00169CC8 File Offset: 0x00169CC8
		public void Send(byte[] bytes)
		{
			try
			{
				if (this.networkStream_0.CanWrite)
				{
					if (this.arc4_0 != null)
					{
						this.arc4_0.encrypt(bytes);
					}
					this.networkStream_0.Write(bytes, 0, bytes.Length);
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x00169D1C File Offset: 0x00169D1C
		public byte[] recive()
		{
			byte[] result;
			try
			{
				if (this.client.Available > 0)
				{
					if (this.networkStream_0.CanRead)
					{
						byte[] array = new byte[16384];
						int num = this.networkStream_0.Read(array, 0, array.Length);
						if (num != 0)
						{
							Thread.Sleep(100);
							byte[] array2 = array.Take(num).ToArray<byte>();
							if (this.arc4_1 != null)
							{
								this.arc4_1.decrypt(array2);
							}
							result = array2;
						}
						else
						{
							result = null;
						}
					}
					else
					{
						result = null;
					}
				}
				else
				{
					result = null;
				}
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x060002DA RID: 730 RVA: 0x00169DB4 File Offset: 0x00169DB4
		protected virtual void Dispose(bool disposing)
		{
			if (!this.bool_0)
			{
				if (disposing && this.client != null)
				{
					try
					{
						this.networkStream_0.Close();
					}
					catch
					{
					}
					try
					{
						this.proxySocket_0.Close();
						this.client.Close();
					}
					catch
					{
					}
					this.arc4_0 = (this.arc4_1 = null);
				}
				this.bool_0 = true;
			}
		}

		// Token: 0x060002DB RID: 731 RVA: 0x00158F8B File Offset: 0x00158F8B
		public void Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x040001E2 RID: 482
		public TcpClient client;

		// Token: 0x040001E3 RID: 483
		private NetworkStream networkStream_0;

		// Token: 0x040001E4 RID: 484
		private ARC4 arc4_0;

		// Token: 0x040001E5 RID: 485
		private ARC4 arc4_1;

		// Token: 0x040001E6 RID: 486
		private IPEndPoint ipendPoint_0;

		// Token: 0x040001E7 RID: 487
		private ProxySocket proxySocket_0;

		// Token: 0x040001E8 RID: 488
		private bool bool_0;
	}
}
