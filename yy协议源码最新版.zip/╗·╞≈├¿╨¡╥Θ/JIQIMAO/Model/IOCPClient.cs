﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Timers;
using JIQIMAO.Model.YYModel;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x0200000F RID: 15
	public class IOCPClient
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x0600004C RID: 76 RVA: 0x0015B5D8 File Offset: 0x0015B5D8
		// (remove) Token: 0x0600004D RID: 77 RVA: 0x0015B610 File Offset: 0x0015B610
		public event IOCPClient.OnConnected ConnectedEvent
		{
			[CompilerGenerated]
			add
			{
				IOCPClient.OnConnected onConnected = this.onConnected_0;
				IOCPClient.OnConnected onConnected2;
				do
				{
					onConnected2 = onConnected;
					IOCPClient.OnConnected value2 = (IOCPClient.OnConnected)Delegate.Combine(onConnected2, value);
					onConnected = Interlocked.CompareExchange<IOCPClient.OnConnected>(ref this.onConnected_0, value2, onConnected2);
				}
				while (onConnected != onConnected2);
			}
			[CompilerGenerated]
			remove
			{
				IOCPClient.OnConnected onConnected = this.onConnected_0;
				IOCPClient.OnConnected onConnected2;
				do
				{
					onConnected2 = onConnected;
					IOCPClient.OnConnected value2 = (IOCPClient.OnConnected)Delegate.Remove(onConnected2, value);
					onConnected = Interlocked.CompareExchange<IOCPClient.OnConnected>(ref this.onConnected_0, value2, onConnected2);
				}
				while (onConnected != onConnected2);
			}
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600004E RID: 78 RVA: 0x0015B648 File Offset: 0x0015B648
		// (remove) Token: 0x0600004F RID: 79 RVA: 0x0015B680 File Offset: 0x0015B680
		public event IOCPClient.OnRecieved RecievedEvent
		{
			[CompilerGenerated]
			add
			{
				IOCPClient.OnRecieved onRecieved = this.onRecieved_0;
				IOCPClient.OnRecieved onRecieved2;
				do
				{
					onRecieved2 = onRecieved;
					IOCPClient.OnRecieved value2 = (IOCPClient.OnRecieved)Delegate.Combine(onRecieved2, value);
					onRecieved = Interlocked.CompareExchange<IOCPClient.OnRecieved>(ref this.onRecieved_0, value2, onRecieved2);
				}
				while (onRecieved != onRecieved2);
			}
			[CompilerGenerated]
			remove
			{
				IOCPClient.OnRecieved onRecieved = this.onRecieved_0;
				IOCPClient.OnRecieved onRecieved2;
				do
				{
					onRecieved2 = onRecieved;
					IOCPClient.OnRecieved value2 = (IOCPClient.OnRecieved)Delegate.Remove(onRecieved2, value);
					onRecieved = Interlocked.CompareExchange<IOCPClient.OnRecieved>(ref this.onRecieved_0, value2, onRecieved2);
				}
				while (onRecieved != onRecieved2);
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x0015B6B8 File Offset: 0x0015B6B8
		public IOCPClient(string ip, int port, bool isservice = true, string daili = "", ProxyTypes pt = ProxyTypes.None)
		{
			try
			{
				this.bool_1 = isservice;
				this.proxySocket_0 = new ProxySocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				this.proxySocket_0.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, new LingerOption(true, 0));
				if (daili.Trim().Length > 0)
				{
					string[] array = daili.Split(new char[]
					{
						'|'
					});
					if (pt == ProxyTypes.Https)
					{
						array = daili.Split(new char[]
						{
							':'
						});
					}
					this.proxySocket_0.ProxyEndPoint = new IPEndPoint(IPAddress.Parse(array[0]), Convert.ToInt32(array[1]));
					if (array.Length > 2)
					{
						this.proxySocket_0.ProxyUser = array[2];
						this.proxySocket_0.ProxyPass = array[3];
					}
				}
				this.proxySocket_0.ProxyType = pt;
				this.arc4_0 = null;
				this.arc4_1 = null;
				IPAddress address = IPAddress.Parse(ip);
				this.ipendPoint_0 = new IPEndPoint(address, port);
				this.timer_0 = new System.Timers.Timer(15000.0);
				this.timer_0.Elapsed += this.timer_0_Elapsed;
				this.timer_0.AutoReset = true;
			}
			catch
			{
				throw new Exception("GJCW");
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00158257 File Offset: 0x00158257
		public void setarc(byte[] bytes)
		{
			if (this.arc4_0 == null)
			{
				this.arc4_0 = new ARC4(bytes, false);
				this.arc4_1 = new ARC4(bytes, true);
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0015B808 File Offset: 0x0015B808
		private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref IOCPClient.int_0, 1) == 0)
			{
				try
				{
					if (this.bool_1)
					{
						this.Send(new byte[]
						{
							14,
							0,
							0,
							0,
							4,
							30,
							12,
							0,
							200,
							0,
							0,
							0,
							0,
							0
						});
					}
					else
					{
						this.Send(ProtoPacket.pack<PCS_APPing>(new PCS_APPing()));
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref IOCPClient.int_0, 0);
				}
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0015827B File Offset: 0x0015827B
		public void startheart()
		{
			this.timer_0.Enabled = true;
			this.timer_0.Start();
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00158294 File Offset: 0x00158294
		public void stopheart()
		{
			this.timer_0.Enabled = false;
			this.timer_0.Stop();
		}

		// Token: 0x06000055 RID: 85 RVA: 0x0015B884 File Offset: 0x0015B884
		public void Connect()
		{
			this.socketAsyncEventArgs_0 = new SocketAsyncEventArgs();
			this.socketAsyncEventArgs_0.UserToken = this.proxySocket_0;
			this.socketAsyncEventArgs_0.RemoteEndPoint = this.ipendPoint_0;
			this.socketAsyncEventArgs_0.Completed += this.method_0;
			if (!this.proxySocket_0.ConnectAsync(this.socketAsyncEventArgs_0))
			{
				this.method_1(this.socketAsyncEventArgs_0);
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x001582AD File Offset: 0x001582AD
		private void method_0(object sender, SocketAsyncEventArgs e)
		{
			this.method_1(e);
		}

		// Token: 0x06000057 RID: 87 RVA: 0x0015B8F4 File Offset: 0x0015B8F4
		private void method_1(SocketAsyncEventArgs socketAsyncEventArgs_2)
		{
			this.bool_0 = (socketAsyncEventArgs_2.SocketError == SocketError.Success);
			IOCPClient.OnConnected onConnected = this.onConnected_0;
			if (onConnected != null)
			{
				onConnected.BeginInvoke(this.bool_0, false, null, null);
			}
			if (this.bool_0)
			{
				this.StartRecive(socketAsyncEventArgs_2);
			}
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0015B93C File Offset: 0x0015B93C
		public void Send(byte[] data)
		{
			if (this.arc4_0 != null)
			{
				this.arc4_0.encrypt(data);
			}
			if (this.socketAsyncEventArgs_1 == null)
			{
				this.socketAsyncEventArgs_1 = new SocketAsyncEventArgs
				{
					RemoteEndPoint = this.ipendPoint_0
				};
				this.socketAsyncEventArgs_1.Completed += this.method_2;
				this.socketAsyncEventArgs_1.UserToken = this.proxySocket_0;
			}
			this.socketAsyncEventArgs_1.SetBuffer(data, 0, data.Length);
			if (!this.proxySocket_0.SendAsync(this.socketAsyncEventArgs_1))
			{
				this.method_3(this.socketAsyncEventArgs_1);
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x001582B6 File Offset: 0x001582B6
		private void method_2(object sender, SocketAsyncEventArgs e)
		{
			this.method_3(e);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00158048 File Offset: 0x00158048
		private void method_3(SocketAsyncEventArgs socketAsyncEventArgs_2)
		{
		}

		// Token: 0x0600005B RID: 91 RVA: 0x0015B9D4 File Offset: 0x0015B9D4
		public void StartRecive(SocketAsyncEventArgs e)
		{
			Socket socket = e.UserToken as Socket;
			SocketAsyncEventArgs socketAsyncEventArgs = new SocketAsyncEventArgs();
			byte[] array = new byte[8192];
			socketAsyncEventArgs.SetBuffer(array, 0, array.Length);
			socketAsyncEventArgs.Completed += this.method_4;
			socketAsyncEventArgs.RemoteEndPoint = this.ipendPoint_0;
			socketAsyncEventArgs.UserToken = e.UserToken;
			if (!socket.ReceiveAsync(socketAsyncEventArgs))
			{
				this.method_5(socketAsyncEventArgs);
			}
		}

		// Token: 0x0600005C RID: 92 RVA: 0x001582BF File Offset: 0x001582BF
		private void method_4(object sender, SocketAsyncEventArgs e)
		{
			this.method_5(e);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x0015BA44 File Offset: 0x0015BA44
		private void method_5(SocketAsyncEventArgs socketAsyncEventArgs_2)
		{
			if (socketAsyncEventArgs_2.SocketError == SocketError.Success)
			{
				if (socketAsyncEventArgs_2.BytesTransferred > 0)
				{
					Socket socket = (Socket)socketAsyncEventArgs_2.UserToken;
					if (socket.Available == 0)
					{
						byte[] array = new byte[socketAsyncEventArgs_2.BytesTransferred];
						Array.Copy(socketAsyncEventArgs_2.Buffer, socketAsyncEventArgs_2.Offset, array, 0, array.Length);
						if (this.arc4_1 != null)
						{
							this.arc4_1.decrypt(array);
						}
						IOCPClient.OnRecieved onRecieved = this.onRecieved_0;
						if (onRecieved != null)
						{
							onRecieved.BeginInvoke(array, null, null);
						}
					}
					if (!socket.ReceiveAsync(socketAsyncEventArgs_2))
					{
						this.method_5(socketAsyncEventArgs_2);
						return;
					}
				}
				else
				{
					this.method_6();
				}
			}
		}

		// Token: 0x0600005E RID: 94 RVA: 0x0015BAD8 File Offset: 0x0015BAD8
		public void DisConnect()
		{
			try
			{
				this.timer_0.Stop();
				this.timer_0.Close();
			}
			catch
			{
			}
			try
			{
				this.proxySocket_0.Shutdown(SocketShutdown.Both);
			}
			catch
			{
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x0015BB30 File Offset: 0x0015BB30
		private void method_6()
		{
			this.arc4_0 = (this.arc4_1 = null);
			if (this.proxySocket_0.Connected)
			{
				this.proxySocket_0.Close();
			}
		}

		// Token: 0x0400003C RID: 60
		[CompilerGenerated]
		private IOCPClient.OnConnected onConnected_0;

		// Token: 0x0400003D RID: 61
		[CompilerGenerated]
		private IOCPClient.OnRecieved onRecieved_0;

		// Token: 0x0400003E RID: 62
		private ProxySocket proxySocket_0;

		// Token: 0x0400003F RID: 63
		private SocketAsyncEventArgs socketAsyncEventArgs_0;

		// Token: 0x04000040 RID: 64
		private SocketAsyncEventArgs socketAsyncEventArgs_1;

		// Token: 0x04000041 RID: 65
		private bool bool_0;

		// Token: 0x04000042 RID: 66
		private ARC4 arc4_0;

		// Token: 0x04000043 RID: 67
		private ARC4 arc4_1;

		// Token: 0x04000044 RID: 68
		private System.Timers.Timer timer_0;

		// Token: 0x04000045 RID: 69
		private bool bool_1;

		// Token: 0x04000046 RID: 70
		private IPEndPoint ipendPoint_0;

		// Token: 0x04000047 RID: 71
		private static int int_0;

		// Token: 0x02000010 RID: 16
		// (Invoke) Token: 0x06000062 RID: 98
		public delegate void OnConnected(bool issuccess, bool iszhongduan = false);

		// Token: 0x02000011 RID: 17
		// (Invoke) Token: 0x06000066 RID: 102
		public delegate void OnRecieved(byte[] bytes);
	}
}
