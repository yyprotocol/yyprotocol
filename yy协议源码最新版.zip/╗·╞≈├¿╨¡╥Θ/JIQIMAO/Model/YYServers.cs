﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000034 RID: 52
	public class YYServers
	{
		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x0600030D RID: 781 RVA: 0x001590F1 File Offset: 0x001590F1
		// (set) Token: 0x0600030E RID: 782 RVA: 0x001590F9 File Offset: 0x001590F9
		public int Id { get; set; }

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x0600030F RID: 783 RVA: 0x00159102 File Offset: 0x00159102
		// (set) Token: 0x06000310 RID: 784 RVA: 0x0015910A File Offset: 0x0015910A
		public string MacCode { get; set; }

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x06000311 RID: 785 RVA: 0x00159113 File Offset: 0x00159113
		// (set) Token: 0x06000312 RID: 786 RVA: 0x0015911B File Offset: 0x0015911B
		public int LoginType { get; set; }

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x06000313 RID: 787 RVA: 0x00159124 File Offset: 0x00159124
		// (set) Token: 0x06000314 RID: 788 RVA: 0x0015912C File Offset: 0x0015912C
		public string IpTxt { get; set; }

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x06000315 RID: 789 RVA: 0x00159135 File Offset: 0x00159135
		// (set) Token: 0x06000316 RID: 790 RVA: 0x0015913D File Offset: 0x0015913D
		public int CreateTime { get; set; }

		// Token: 0x04000245 RID: 581
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000246 RID: 582
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000247 RID: 583
		[CompilerGenerated]
		private int int_1;

		// Token: 0x04000248 RID: 584
		[CompilerGenerated]
		private string string_1;

		// Token: 0x04000249 RID: 585
		[CompilerGenerated]
		private int int_2;
	}
}
