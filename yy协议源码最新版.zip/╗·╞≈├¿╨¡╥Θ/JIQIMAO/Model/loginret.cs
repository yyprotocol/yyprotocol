﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000012 RID: 18
	public class loginret
	{
		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000069 RID: 105 RVA: 0x001582C8 File Offset: 0x001582C8
		// (set) Token: 0x0600006A RID: 106 RVA: 0x001582D0 File Offset: 0x001582D0
		public string uid { get; set; }

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600006B RID: 107 RVA: 0x001582D9 File Offset: 0x001582D9
		// (set) Token: 0x0600006C RID: 108 RVA: 0x001582E1 File Offset: 0x001582E1
		public string ucode { get; set; }

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600006D RID: 109 RVA: 0x001582EA File Offset: 0x001582EA
		// (set) Token: 0x0600006E RID: 110 RVA: 0x001582F2 File Offset: 0x001582F2
		public string vcode { get; set; }

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600006F RID: 111 RVA: 0x001582FB File Offset: 0x001582FB
		// (set) Token: 0x06000070 RID: 112 RVA: 0x00158303 File Offset: 0x00158303
		public string ck_username { get; set; }

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000071 RID: 113 RVA: 0x0015830C File Offset: 0x0015830C
		// (set) Token: 0x06000072 RID: 114 RVA: 0x00158314 File Offset: 0x00158314
		public string ck_udb_l { get; set; }

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000073 RID: 115 RVA: 0x0015831D File Offset: 0x0015831D
		// (set) Token: 0x06000074 RID: 116 RVA: 0x00158325 File Offset: 0x00158325
		public bool isfenghao { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000075 RID: 117 RVA: 0x0015832E File Offset: 0x0015832E
		// (set) Token: 0x06000076 RID: 118 RVA: 0x00158336 File Offset: 0x00158336
		public string ck_udb_n { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000077 RID: 119 RVA: 0x0015833F File Offset: 0x0015833F
		// (set) Token: 0x06000078 RID: 120 RVA: 0x00158347 File Offset: 0x00158347
		public bool issuccess { get; set; }

		// Token: 0x04000048 RID: 72
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000049 RID: 73
		[CompilerGenerated]
		private string string_1;

		// Token: 0x0400004A RID: 74
		[CompilerGenerated]
		private string string_2;

		// Token: 0x0400004B RID: 75
		[CompilerGenerated]
		private string string_3;

		// Token: 0x0400004C RID: 76
		[CompilerGenerated]
		private string string_4;

		// Token: 0x0400004D RID: 77
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x0400004E RID: 78
		[CompilerGenerated]
		private string string_5;

		// Token: 0x0400004F RID: 79
		[CompilerGenerated]
		private bool bool_1;
	}
}
