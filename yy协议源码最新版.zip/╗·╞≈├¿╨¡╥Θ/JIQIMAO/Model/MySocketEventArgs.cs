﻿using System;
using System.Net.Sockets;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000015 RID: 21
	public class MySocketEventArgs : SocketAsyncEventArgs
	{
		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000084 RID: 132 RVA: 0x00158394 File Offset: 0x00158394
		// (set) Token: 0x06000085 RID: 133 RVA: 0x0015839C File Offset: 0x0015839C
		public int ArgsTag { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000086 RID: 134 RVA: 0x001583A5 File Offset: 0x001583A5
		// (set) Token: 0x06000087 RID: 135 RVA: 0x001583AD File Offset: 0x001583AD
		public bool IsUsing { get; set; }

		// Token: 0x04000060 RID: 96
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000061 RID: 97
		[CompilerGenerated]
		private bool bool_0;
	}
}
