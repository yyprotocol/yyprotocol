﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x0200002A RID: 42
	public class pcuserinit
	{
		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x060002DC RID: 732 RVA: 0x00158F94 File Offset: 0x00158F94
		// (set) Token: 0x060002DD RID: 733 RVA: 0x00158F9C File Offset: 0x00158F9C
		public uint uid { get; set; }

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x060002DE RID: 734 RVA: 0x00158FA5 File Offset: 0x00158FA5
		// (set) Token: 0x060002DF RID: 735 RVA: 0x00158FAD File Offset: 0x00158FAD
		public string username { get; set; }

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x00158FB6 File Offset: 0x00158FB6
		// (set) Token: 0x060002E1 RID: 737 RVA: 0x00158FBE File Offset: 0x00158FBE
		public string cookie { get; set; }

		// Token: 0x040001E9 RID: 489
		[CompilerGenerated]
		private uint uint_0;

		// Token: 0x040001EA RID: 490
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040001EB RID: 491
		[CompilerGenerated]
		private string string_1;
	}
}
