﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003F RID: 63
	public class CRouteStackInfo : ProtoBase
	{
		// Token: 0x06000334 RID: 820 RVA: 0x001593AE File Offset: 0x001593AE
		public CRouteStackInfo()
		{
			this.m_vecProxyId = new List<MyUInt64>();
			this.m_vecS2SId = new List<MyUInt64>();
		}

		// Token: 0x06000335 RID: 821 RVA: 0x001593CC File Offset: 0x001593CC
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt64Array(this.m_vecProxyId);
			base.pushInt64Array(this.m_vecS2SId);
		}

		// Token: 0x06000336 RID: 822 RVA: 0x001593ED File Offset: 0x001593ED
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_vecProxyId = base.popInt64Array();
			this.m_vecS2SId = base.popInt64Array();
		}

		// Token: 0x04000268 RID: 616
		public List<MyUInt64> m_vecProxyId;

		// Token: 0x04000269 RID: 617
		public List<MyUInt64> m_vecS2SId;
	}
}
