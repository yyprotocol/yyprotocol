﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004B RID: 75
	public class MYHashMap
	{
		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000355 RID: 853 RVA: 0x0015950F File Offset: 0x0015950F
		public Dictionary<string, object> content
		{
			get
			{
				return this._content;
			}
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00159517 File Offset: 0x00159517
		public MYHashMap()
		{
			this.length = 0;
			this._content = new Dictionary<string, object>();
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00159531 File Offset: 0x00159531
		public int size()
		{
			return this.length;
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00159539 File Offset: 0x00159539
		public bool isEmpty()
		{
			return this.length == 0;
		}

		// Token: 0x06000359 RID: 857 RVA: 0x00159544 File Offset: 0x00159544
		public List<string> keys()
		{
			return this._content.Keys.ToList<string>();
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00159556 File Offset: 0x00159556
		public List<object> values()
		{
			return this._content.Values.ToList<object>();
		}

		// Token: 0x0600035B RID: 859 RVA: 0x00159568 File Offset: 0x00159568
		public bool containsKey(string _arg1)
		{
			return this._content.Keys != null && this._content.Keys.Contains(_arg1);
		}

		// Token: 0x0600035C RID: 860 RVA: 0x0015958D File Offset: 0x0015958D
		public bool containsValue(object _arg1)
		{
			return this._content.Values != null && this._content.Values.Contains(_arg1);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0016C244 File Offset: 0x0016C244
		public object get(string _arg1)
		{
			if (this._content.Keys != null && this._content.Keys.Contains(_arg1))
			{
				object obj = this._content[_arg1];
				if (obj != null)
				{
					return obj;
				}
			}
			return null;
		}

		// Token: 0x0600035E RID: 862 RVA: 0x001595B2 File Offset: 0x001595B2
		public void clear()
		{
			this._content = new Dictionary<string, object>();
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0016C284 File Offset: 0x0016C284
		public object put(string _arg1, object _arg2)
		{
			new object();
			if (_arg1 == null)
			{
				throw new Exception("cannot put a value with undefined or null key!");
			}
			if (!this.containsKey(_arg1))
			{
				this.length++;
			}
			object result = this.get(_arg1);
			this._content[_arg1] = _arg2;
			return result;
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0016C2D4 File Offset: 0x0016C2D4
		public object remove(string _arg1)
		{
			if (!this.containsKey(_arg1))
			{
				return null;
			}
			object result = this._content[_arg1];
			this.content.Remove(_arg1);
			this.length--;
			return result;
		}

		// Token: 0x040002A2 RID: 674
		protected int length;

		// Token: 0x040002A3 RID: 675
		protected Dictionary<string, object> _content;
	}
}
