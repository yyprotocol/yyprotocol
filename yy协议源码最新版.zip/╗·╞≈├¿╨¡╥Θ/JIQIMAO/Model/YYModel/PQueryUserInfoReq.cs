﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000063 RID: 99
	public class PQueryUserInfoReq : ProtoBase
	{
		// Token: 0x06000399 RID: 921 RVA: 0x0015993B File Offset: 0x0015993B
		public PQueryUserInfoReq()
		{
			this.uidlist = new List<uint>();
		}

		// Token: 0x0600039A RID: 922 RVA: 0x0015994E File Offset: 0x0015994E
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(3125762u);
			base.pushInt(this.topSid);
			base.pushIntArray(this.uidlist);
			base.pushInt(this.type);
		}

		// Token: 0x04000317 RID: 791
		public uint topSid;

		// Token: 0x04000318 RID: 792
		public List<uint> uidlist;

		// Token: 0x04000319 RID: 793
		public uint type;
	}
}
