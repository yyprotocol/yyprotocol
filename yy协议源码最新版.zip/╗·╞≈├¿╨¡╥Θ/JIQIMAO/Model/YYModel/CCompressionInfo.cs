﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003A RID: 58
	public class CCompressionInfo : ProtoBase
	{
		// Token: 0x06000328 RID: 808 RVA: 0x001592E8 File Offset: 0x001592E8
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt(this.m_uCodec);
		}

		// Token: 0x06000329 RID: 809 RVA: 0x001592FD File Offset: 0x001592FD
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_uCodec = base.popInt();
		}

		// Token: 0x0400025E RID: 606
		public uint m_uCodec;
	}
}
