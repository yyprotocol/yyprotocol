﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000047 RID: 71
	public class Hex
	{
		// Token: 0x06000346 RID: 838 RVA: 0x0016BDBC File Offset: 0x0016BDBC
		public static string fromString(string _arg1, bool _arg2 = false)
		{
			ByteArray byteArray = new ByteArray();
			byteArray.writeUTFBytes(_arg1);
			return Hex.fromArray(byteArray, _arg2);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0016BDE0 File Offset: 0x0016BDE0
		public static string toString(string _arg1)
		{
			ByteArray byteArray = Hex.toArray(_arg1);
			return byteArray.readUTFBytes((uint)byteArray.length);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0016BE00 File Offset: 0x0016BE00
		public static ByteArray toArray(string _arg1)
		{
			_arg1 = _arg1.Replace(" ", "").Trim();
			ByteArray byteArray = new ByteArray();
			if ((_arg1.Length & 1) == 1)
			{
				_arg1 = "0" + _arg1;
			}
			uint num = 0u;
			while ((ulong)num < (ulong)((long)_arg1.Length))
			{
				byteArray[(int)(num / 2u)] = Convert.ToByte(Convert.ToInt32(_arg1.Substring((int)num, 2), 16));
				num += 2u;
			}
			return byteArray;
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0016BE74 File Offset: 0x0016BE74
		public static string fromArray(ByteArray array, bool colons = false)
		{
			string text = "";
			for (int i = 0; i < array.length; i++)
			{
				string text2 = Hex.ConvertInt((int)array[i], 16);
				if (text2.Length < 2)
				{
					text2 = "0" + text2;
				}
				text += text2;
				if (colons && i < array.length - 1)
				{
					text += ":";
				}
			}
			return text;
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0016BEE0 File Offset: 0x0016BEE0
		public static string ConvertInt(int num, int toBase)
		{
			string text = "0123456789abcdefghijklmnopqrstuvwxyz";
			if (toBase > text.Length)
			{
				throw new IndexOutOfRangeException();
			}
			List<char> list = new List<char>();
			do
			{
				int index = num % toBase;
				list.Add(text[index]);
				num /= toBase;
			}
			while (num != 0);
			list.Reverse();
			return new string(list.ToArray());
		}
	}
}
