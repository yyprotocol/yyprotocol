﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000065 RID: 101
	public class Properties : ProtoBase
	{
		// Token: 0x0600039D RID: 925 RVA: 0x00159986 File Offset: 0x00159986
		public Properties()
		{
			this.props = new MYHashMap();
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00159999 File Offset: 0x00159999
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushHashMapKSVS(this.props);
		}

		// Token: 0x0600039F RID: 927 RVA: 0x001599AE File Offset: 0x001599AE
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.props = base.popHashMapKSVS();
		}

		// Token: 0x0400031E RID: 798
		public MYHashMap props;
	}
}
