﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000046 RID: 70
	public class GClass6 : ProtoBase
	{
		// Token: 0x06000344 RID: 836 RVA: 0x001594F2 File Offset: 0x001594F2
		public GClass6()
		{
			this.suid = new MyUInt64(0u, 0u);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x0016BD30 File Offset: 0x0016BD30
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(79960u);
			base.pushShort(this.serviceType);
			base.pushInt(this.sid);
			base.pushInt(this.uid);
			base.method_1(this.msg);
			base.pushInt(this.uip);
			base.pushByte(this.terminalType);
			base.pushByte(this.statType);
			base.pushInt(this.subsid);
			base.method_0(this.suid);
		}

		// Token: 0x04000286 RID: 646
		public uint serviceType;

		// Token: 0x04000287 RID: 647
		public uint sid;

		// Token: 0x04000288 RID: 648
		public uint uid;

		// Token: 0x04000289 RID: 649
		public byte[] msg;

		// Token: 0x0400028A RID: 650
		public uint uip;

		// Token: 0x0400028B RID: 651
		public uint terminalType;

		// Token: 0x0400028C RID: 652
		public uint statType;

		// Token: 0x0400028D RID: 653
		public uint subsid;

		// Token: 0x0400028E RID: 654
		public MyUInt64 suid;
	}
}
