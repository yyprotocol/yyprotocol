﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000035 RID: 53
	public class APRouterBase : ProtoBase
	{
		// Token: 0x06000319 RID: 793 RVA: 0x0015914E File Offset: 0x0015914E
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushBytes(this.m_strFrom);
			base.pushInt(this.m_ururi);
			base.pushShort(this.m_uResCode);
			base.method_1(this.m_strLoad);
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00159187 File Offset: 0x00159187
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_strFrom = base.popBytes();
			this.m_ururi = base.popInt();
			this.m_uResCode = base.popShort();
			this.m_strLoad = base.method_2();
		}

		// Token: 0x0400024F RID: 591
		public byte[] m_strFrom;

		// Token: 0x04000250 RID: 592
		public uint m_ururi;

		// Token: 0x04000251 RID: 593
		public uint m_uResCode;

		// Token: 0x04000252 RID: 594
		public byte[] m_strLoad;
	}
}
