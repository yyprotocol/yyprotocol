﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006F RID: 111
	public class UDBYYLoginReq : ProtoBase
	{
		// Token: 0x060003E6 RID: 998 RVA: 0x00159BD6 File Offset: 0x00159BD6
		public UDBYYLoginReq()
		{
			this._terminal_type = new MyUInt64(0u, 0u);
			this._yyuid = new MyUInt64(0u, 0u);
			this._jump_appids = new List<ByteArray>();
			this._jump_sessionids = new List<ByteArray>();
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x0016D3B0 File Offset: 0x0016D3B0
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(2281u);
			base.pushBytes(this._context);
			base.pushBytes(this._appid);
			base.pushByte(this._apptype);
			base.pushInt(this._lcid);
			base.method_0(this._terminal_type);
			base.pushBytes(this._device_id);
			base.pushBytes(this._client_ip);
			base.pushInt(this._ver_int);
			base.pushBytes(this._ver_str);
			base.pushBytes(this._version);
			base.method_0(this._yyuid);
			base.pushBytes(this._user);
			base.pushByte(this._user_token_type);
			base.pushBytes(this._user_token);
			base.pushBytes(this._pic_id);
			base.pushBytes(this._pic_code);
			base.pushShort(this._dynamic_token_type);
			base.pushBytes(this._dynamic_token);
			base.pushBytes(this._vmToken);
			base.pushStringArray(this._jump_appids);
			base.pushStringArray(this._jump_sessionids);
			base.pushBytes(this._callback_data);
			base.pushBytes(this._extension);
		}

		// Token: 0x0400033B RID: 827
		public byte[] _context;

		// Token: 0x0400033C RID: 828
		public byte[] _appid;

		// Token: 0x0400033D RID: 829
		public uint _apptype;

		// Token: 0x0400033E RID: 830
		public uint _lcid;

		// Token: 0x0400033F RID: 831
		public MyUInt64 _terminal_type;

		// Token: 0x04000340 RID: 832
		public byte[] _device_id;

		// Token: 0x04000341 RID: 833
		public byte[] _client_ip;

		// Token: 0x04000342 RID: 834
		public uint _ver_int;

		// Token: 0x04000343 RID: 835
		public byte[] _ver_str;

		// Token: 0x04000344 RID: 836
		public byte[] _version;

		// Token: 0x04000345 RID: 837
		public MyUInt64 _yyuid;

		// Token: 0x04000346 RID: 838
		public byte[] _user;

		// Token: 0x04000347 RID: 839
		public uint _user_token_type;

		// Token: 0x04000348 RID: 840
		public byte[] _user_token;

		// Token: 0x04000349 RID: 841
		public byte[] _pic_id;

		// Token: 0x0400034A RID: 842
		public byte[] _pic_code;

		// Token: 0x0400034B RID: 843
		public uint _dynamic_token_type;

		// Token: 0x0400034C RID: 844
		public byte[] _dynamic_token;

		// Token: 0x0400034D RID: 845
		public byte[] _vmToken;

		// Token: 0x0400034E RID: 846
		public List<ByteArray> _jump_appids;

		// Token: 0x0400034F RID: 847
		public List<ByteArray> _jump_sessionids;

		// Token: 0x04000350 RID: 848
		public byte[] _callback_data;

		// Token: 0x04000351 RID: 849
		public byte[] _extension;
	}
}
