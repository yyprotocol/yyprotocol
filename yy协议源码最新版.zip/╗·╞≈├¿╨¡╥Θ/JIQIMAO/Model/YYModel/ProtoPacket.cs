﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000068 RID: 104
	public class ProtoPacket
	{
		// Token: 0x060003D2 RID: 978 RVA: 0x00159B0D File Offset: 0x00159B0D
		public ProtoPacket()
		{
			this.uint_2 = 200u;
			this.byteArray_0 = new ByteArray();
			this.byteArray_0.endian = Endian.LITTLE_ENDIAN;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0016D06C File Offset: 0x0016D06C
		public static byte[] pack<T>(T obj) where T : ProtoBase
		{
			byte[] result;
			using (ByteArray byteArray = new ByteArray())
			{
				byteArray.endian = Endian.LITTLE_ENDIAN;
				byteArray.position = 10;
				obj.marshall(byteArray);
				byteArray.position = 0;
				byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
				byteArray.writeUnsignedInt(obj.getUri());
				byteArray.writeShort(Convert.ToInt32(obj.getRes()));
				byte[] buffer = byteArray.Buffer;
				byteArray.Dispose();
				result = buffer;
			}
			return result;
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0016D108 File Offset: 0x0016D108
		public static byte[] packNoHeader<T>(T obj) where T : ProtoBase
		{
			byte[] result;
			using (ByteArray byteArray = new ByteArray())
			{
				byteArray.endian = Endian.LITTLE_ENDIAN;
				byteArray.position = 0;
				obj.marshall(byteArray);
				byte[] buffer = byteArray.Buffer;
				byteArray.Dispose();
				result = buffer;
			}
			return result;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x0016D164 File Offset: 0x0016D164
		public static ProtoPacket unpack(byte[] _arg0)
		{
			ProtoPacket result;
			using (ByteArray byteArray = new ByteArray(_arg0))
			{
				try
				{
					byteArray.position = 0;
					byteArray.endian = Endian.LITTLE_ENDIAN;
					ProtoPacket protoPacket = new ProtoPacket();
					protoPacket.uint_1 = byteArray.readUnsignedInt();
					protoPacket.uint_0 = byteArray.readUnsignedInt();
					protoPacket.uint_2 = (uint)byteArray.readUnsignedShort();
					byteArray.readBytes(protoPacket.byteArray_0, 0u, 0u);
					result = protoPacket;
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0016D1F0 File Offset: 0x0016D1F0
		public static ProtoPacket unpackNoHeader(byte[] _arg0, uint _arg3, uint _arg4)
		{
			ProtoPacket result;
			using (ByteArray byteArray = new ByteArray(_arg0))
			{
				try
				{
					byteArray.position = 0;
					byteArray.endian = Endian.LITTLE_ENDIAN;
					ProtoPacket protoPacket = new ProtoPacket();
					protoPacket.uint_1 = (uint)byteArray.length;
					protoPacket.uint_0 = _arg3;
					protoPacket.uint_2 = _arg4;
					byteArray.readBytes(protoPacket.byteArray_0, 0u, 0u);
					byteArray.Dispose();
					result = protoPacket;
				}
				catch
				{
					result = null;
				}
			}
			return result;
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00159B37 File Offset: 0x00159B37
		public uint getUri()
		{
			return this.uint_0;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00159B3F File Offset: 0x00159B3F
		public uint getRes()
		{
			return this.uint_2;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x00159B47 File Offset: 0x00159B47
		public ByteArray getBuffer()
		{
			return this.byteArray_0;
		}

		// Token: 0x04000323 RID: 803
		private ByteArray byteArray_0;

		// Token: 0x04000324 RID: 804
		private uint uint_0;

		// Token: 0x04000325 RID: 805
		private uint uint_1;

		// Token: 0x04000326 RID: 806
		private uint uint_2;
	}
}
