﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000041 RID: 65
	public class GClass1 : ProtoBase
	{
		// Token: 0x0600033A RID: 826 RVA: 0x00159438 File Offset: 0x00159438
		public GClass1()
		{
			this.sidlist = new List<uint>();
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0015944B File Offset: 0x0015944B
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(3125250u);
			base.pushInt(this.topSid);
			base.pushIntArray(this.sidlist);
		}

		// Token: 0x0400026B RID: 619
		public uint topSid;

		// Token: 0x0400026C RID: 620
		public List<uint> sidlist;
	}
}
