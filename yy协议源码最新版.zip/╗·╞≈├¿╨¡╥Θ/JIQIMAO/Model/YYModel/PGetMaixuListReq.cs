﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005A RID: 90
	public class PGetMaixuListReq : ProtoBase
	{
		// Token: 0x06000387 RID: 903 RVA: 0x001597CD File Offset: 0x001597CD
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(3854338u);
			base.pushInt(this.topSid);
			base.pushInt(this.subSid);
			base.pushInt(this.uid);
		}

		// Token: 0x040002DD RID: 733
		public uint topSid;

		// Token: 0x040002DE RID: 734
		public uint subSid;

		// Token: 0x040002DF RID: 735
		public uint uid;
	}
}
