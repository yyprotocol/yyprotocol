﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000057 RID: 87
	public class PCS_GetAPInfoRes : ProtoBase
	{
		// Token: 0x06000381 RID: 897 RVA: 0x0016C730 File Offset: 0x0016C730
		public override void unmarshall(ByteArray _arg1)
		{
			_arg1.position = 0;
			base.unmarshall(_arg1);
			this.m_uAreaId = base.popInt();
			this.m_emISPType = base.popShort();
			this.m_uIp = base.popInt();
			this.m_vecApInfo = base.popProtoArray<CAPInfo>();
			this.m_uAppId = base.popInt();
			this.m_uRescode = base.popInt();
			this.m_strExtension = base.popBytes();
			this.m_uApLinkMode = base.popInt();
			this.m_uApLoginMode = base.popInt();
			this.m_strContext = base.popBytes();
		}

		// Token: 0x040002CE RID: 718
		public uint m_uAreaId;

		// Token: 0x040002CF RID: 719
		public uint m_emISPType;

		// Token: 0x040002D0 RID: 720
		public uint m_uIp;

		// Token: 0x040002D1 RID: 721
		public List<CAPInfo> m_vecApInfo;

		// Token: 0x040002D2 RID: 722
		public uint m_uAppId;

		// Token: 0x040002D3 RID: 723
		public uint m_uRescode;

		// Token: 0x040002D4 RID: 724
		public byte[] m_strExtension;

		// Token: 0x040002D5 RID: 725
		public uint m_uApLinkMode;

		// Token: 0x040002D6 RID: 726
		public uint m_uApLoginMode;

		// Token: 0x040002D7 RID: 727
		public byte[] m_strContext;
	}
}
