﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006B RID: 107
	public class PServiceUInfoReq : ProtoBase
	{
		// Token: 0x060003DE RID: 990 RVA: 0x00159B7E File Offset: 0x00159B7E
		public PServiceUInfoReq()
		{
			this.reqUids = new List<uint>();
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0016D2C8 File Offset: 0x0016D2C8
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(61528u);
			base.pushInt(this.uid);
			base.pushInt(this.sid);
			base.pushIntArray(this.reqUids);
			base.pushByte(this.ConnectionType);
		}

		// Token: 0x0400032B RID: 811
		public uint uid;

		// Token: 0x0400032C RID: 812
		public uint sid;

		// Token: 0x0400032D RID: 813
		public List<uint> reqUids;

		// Token: 0x0400032E RID: 814
		public uint ConnectionType;
	}
}
