﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000069 RID: 105
	public class PServiceUInfoExLoginReq : ProtoBase
	{
		// Token: 0x060003DA RID: 986 RVA: 0x00159B4F File Offset: 0x00159B4F
		public PServiceUInfoExLoginReq()
		{
			this.type2ValueMap = new MYHashMap();
		}

		// Token: 0x060003DB RID: 987 RVA: 0x0016D278 File Offset: 0x0016D278
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(385624u);
			base.pushInt(this.uid);
			base.pushInt(this.sid);
			base.pushBytes(this.reserved);
			base.pushHashMapKSVS(this.type2ValueMap);
		}

		// Token: 0x04000327 RID: 807
		public uint uid;

		// Token: 0x04000328 RID: 808
		public uint sid;

		// Token: 0x04000329 RID: 809
		public MYHashMap type2ValueMap;

		// Token: 0x0400032A RID: 810
		public byte[] reserved;
	}
}
