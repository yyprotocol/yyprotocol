﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005E RID: 94
	public class PJoinUserGroup : ProtoBase
	{
		// Token: 0x0600038F RID: 911 RVA: 0x0015984D File Offset: 0x0015984D
		public PJoinUserGroup()
		{
			this.uid = new MyUInt64(0u, 0u);
			this.userGroupIdSet = new List<UserGroupIdType>();
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0015986D File Offset: 0x0015986D
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(642648u);
			base.method_0(this.uid);
			base.pushProtoArray<UserGroupIdType>(this.userGroupIdSet);
			base.pushBytes(this.extraInfo);
		}

		// Token: 0x0400030B RID: 779
		public MyUInt64 uid;

		// Token: 0x0400030C RID: 780
		public List<UserGroupIdType> userGroupIdSet;

		// Token: 0x0400030D RID: 781
		public byte[] extraInfo;
	}
}
