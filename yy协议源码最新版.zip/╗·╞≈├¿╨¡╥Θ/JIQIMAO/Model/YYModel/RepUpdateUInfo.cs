﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006E RID: 110
	public class RepUpdateUInfo : Properties
	{
		// Token: 0x060003E4 RID: 996 RVA: 0x00159BAD File Offset: 0x00159BAD
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.errcode = base.popInt();
			this.limit_end_time = base.popBytes();
		}

		// Token: 0x04000339 RID: 825
		public uint errcode;

		// Token: 0x0400033A RID: 826
		public byte[] limit_end_time;
	}
}
