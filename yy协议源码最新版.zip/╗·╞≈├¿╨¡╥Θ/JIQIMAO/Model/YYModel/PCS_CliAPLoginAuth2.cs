﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000054 RID: 84
	public class PCS_CliAPLoginAuth2 : ProtoBase
	{
		// Token: 0x0600037C RID: 892 RVA: 0x001596A1 File Offset: 0x001596A1
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(779268u);
			base.pushBytes(this.context);
			base.pushInt(this.ruri);
			base.method_1(this.payLoad);
		}

		// Token: 0x040002BA RID: 698
		public byte[] context;

		// Token: 0x040002BB RID: 699
		public uint ruri;

		// Token: 0x040002BC RID: 700
		public byte[] payLoad;
	}
}
