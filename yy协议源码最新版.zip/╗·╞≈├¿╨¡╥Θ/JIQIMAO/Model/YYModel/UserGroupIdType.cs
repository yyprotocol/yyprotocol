﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000071 RID: 113
	public class UserGroupIdType : ProtoBase
	{
		// Token: 0x060003EA RID: 1002 RVA: 0x00159C21 File Offset: 0x00159C21
		public UserGroupIdType()
		{
			this.userGroupType = new MyUInt64(0u, 0u);
			this.userGroupId = new MyUInt64(0u, 0u);
		}

		// Token: 0x060003EB RID: 1003 RVA: 0x00159C43 File Offset: 0x00159C43
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.method_0(this.userGroupType);
			base.method_0(this.userGroupId);
		}

		// Token: 0x060003EC RID: 1004 RVA: 0x00159C64 File Offset: 0x00159C64
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.userGroupType = base.popInt64();
			this.userGroupId = base.popInt64();
		}

		// Token: 0x0400035D RID: 861
		public MyUInt64 userGroupType;

		// Token: 0x0400035E RID: 862
		public MyUInt64 userGroupId;
	}
}
