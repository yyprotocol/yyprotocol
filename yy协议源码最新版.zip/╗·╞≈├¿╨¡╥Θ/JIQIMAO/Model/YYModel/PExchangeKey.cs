﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000058 RID: 88
	public class PExchangeKey : ProtoBase
	{
		// Token: 0x06000383 RID: 899 RVA: 0x0015973D File Offset: 0x0015973D
		public PExchangeKey(byte[] _arg1, byte[] _arg2)
		{
			this.byte_0 = _arg1;
			this.byte_1 = _arg2;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x00159753 File Offset: 0x00159753
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(4356u);
			base.pushBytes(this.byte_0);
			base.pushBytes(this.byte_1);
		}

		// Token: 0x040002D8 RID: 728
		private byte[] byte_0;

		// Token: 0x040002D9 RID: 729
		private byte[] byte_1;
	}
}
