﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000048 RID: 72
	public class LoginAuthInfo : ProtoBaseEx
	{
		// Token: 0x0600034D RID: 845 RVA: 0x0016BF34 File Offset: 0x0016BF34
		public override void vsmarshall(ByteArray _arg1)
		{
			base.vsmarshall(_arg1);
			base.pushBytes(this.m_strAccount);
			base.pushBytes(this.m_strPassword);
			base.pushInt(this.m_uCliType);
			base.pushInt(this.m_uCliVer);
			base.pushInt(this.m_uCliLcid);
			base.pushBytes(this.m_strFrom);
			base.pushBytes(this.m_strCliInfo);
			base.pushBytes(this.m_strReserve);
		}

		// Token: 0x0400028F RID: 655
		public byte[] m_strAccount;

		// Token: 0x04000290 RID: 656
		public byte[] m_strPassword;

		// Token: 0x04000291 RID: 657
		public uint m_uCliType;

		// Token: 0x04000292 RID: 658
		public uint m_uCliVer;

		// Token: 0x04000293 RID: 659
		public byte[] m_strCliVer;

		// Token: 0x04000294 RID: 660
		public uint m_uCliLcid;

		// Token: 0x04000295 RID: 661
		public byte[] m_strFrom;

		// Token: 0x04000296 RID: 662
		public byte[] m_strCliInfo;

		// Token: 0x04000297 RID: 663
		public byte[] m_strReserve;
	}
}
