﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006D RID: 109
	public class PUDBLoginAnonymousRes : ProtoBase
	{
		// Token: 0x060003E2 RID: 994 RVA: 0x0016D318 File Offset: 0x0016D318
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.context = base.popBytes();
			this.rescode = base.popInt();
			this.uid = base.popInt();
			this.yyid = base.popInt();
			this.passport = base.popBytes();
			this.password = base.popBytes();
			this.cookie = base.popBytes();
			this.ticket = base.popBytes();
			if (_arg1.length > 0)
			{
				this._pic_data = base.popBytes();
				this._session_data = base.popBytes();
			}
		}

		// Token: 0x0400032F RID: 815
		public byte[] context;

		// Token: 0x04000330 RID: 816
		public uint rescode;

		// Token: 0x04000331 RID: 817
		public uint uid;

		// Token: 0x04000332 RID: 818
		public uint yyid;

		// Token: 0x04000333 RID: 819
		public byte[] passport;

		// Token: 0x04000334 RID: 820
		public byte[] password;

		// Token: 0x04000335 RID: 821
		public byte[] cookie;

		// Token: 0x04000336 RID: 822
		public byte[] ticket;

		// Token: 0x04000337 RID: 823
		public byte[] _pic_data;

		// Token: 0x04000338 RID: 824
		public byte[] _session_data;
	}
}
