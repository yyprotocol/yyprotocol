﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004D RID: 77
	public class PAPRouter : PAPRouterHdrBase
	{
		// Token: 0x06000369 RID: 873 RVA: 0x001595EC File Offset: 0x001595EC
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(512011u);
		}

		// Token: 0x0600036A RID: 874 RVA: 0x00159600 File Offset: 0x00159600
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
		}

		// Token: 0x040002A4 RID: 676
		public const uint USER_INFO_TOP_SID = 1u;

		// Token: 0x040002A5 RID: 677
		public const uint USER_INFO_SUB_SID = 2u;

		// Token: 0x040002A6 RID: 678
		public const uint USER_INFO_PCINFO = 3u;
	}
}
