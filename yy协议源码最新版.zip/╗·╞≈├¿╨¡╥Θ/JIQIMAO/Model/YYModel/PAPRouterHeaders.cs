﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004F RID: 79
	public class PAPRouterHeaders : ProtoBaseEx
	{
		// Token: 0x0600036F RID: 879 RVA: 0x0016C4D4 File Offset: 0x0016C4D4
		public override void vsmarshall(ByteArray _arg1)
		{
			base.vsmarshall(_arg1);
			base.pushProtoWithTag(1u, this.m_pRoutingKey);
			base.pushProtoWithTag(2u, this.m_pAppUID);
			base.pushProtoWithTag(4u, this.m_pProxyInfo);
			base.pushProtoWithTag(5u, this.m_pCompressionInfo);
			base.pushProtoWithTag(6u, this.m_pClientInfo);
			base.pushProtoWithTag(7u, this.m_pExtentProp);
			base.pushFinishFlag();
		}

		// Token: 0x06000370 RID: 880 RVA: 0x0016C53C File Offset: 0x0016C53C
		public override void vsunmarshall(ByteArray _arg1)
		{
			base.vsunmarshall(_arg1);
			this.m_pRoutingKey = base.popProtoWithTag<CRoutingKey>(1u);
			this.m_pAppUID = base.popProtoWithTag<CAppUID>(2u);
			this.m_pProxyInfo = base.popProtoWithTag<CRouteStackInfo>(4u);
			this.m_pCompressionInfo = base.popProtoWithTag<CCompressionInfo>(5u);
			this.m_pClientInfo = base.popProtoWithTag<CClientInfo>(6u);
			this.m_pExtentProp = base.popProtoWithTag<CExtentProp>(7u);
			base.popFinishFlag();
		}

		// Token: 0x040002A8 RID: 680
		public CRoutingKey m_pRoutingKey;

		// Token: 0x040002A9 RID: 681
		public CAppUID m_pAppUID;

		// Token: 0x040002AA RID: 682
		public CRouteStackInfo m_pProxyInfo;

		// Token: 0x040002AB RID: 683
		public CCompressionInfo m_pCompressionInfo;

		// Token: 0x040002AC RID: 684
		public CClientInfo m_pClientInfo;

		// Token: 0x040002AD RID: 685
		public CExtentProp m_pExtentProp;
	}
}
