﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006C RID: 108
	public class PServiceUInfoReq2 : PServiceUInfoReq
	{
		// Token: 0x060003E0 RID: 992 RVA: 0x00159B91 File Offset: 0x00159B91
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(282968u);
		}
	}
}
