﻿using System;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003D RID: 61
	public static class CharAtExtention
	{
		// Token: 0x06000330 RID: 816 RVA: 0x0015934F File Offset: 0x0015934F
		public static string CharAt(this string s, int index)
		{
			if (index < s.Length && index >= 0)
			{
				return s.Substring(index, 1);
			}
			return "";
		}
	}
}
