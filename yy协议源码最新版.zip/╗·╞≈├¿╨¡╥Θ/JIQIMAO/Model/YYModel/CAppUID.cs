﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000038 RID: 56
	public class CAppUID : ProtoBase
	{
		// Token: 0x06000322 RID: 802 RVA: 0x0015921F File Offset: 0x0015921F
		public CAppUID()
		{
			this.m_uUID = new MyUInt64(0u, 0u);
		}

		// Token: 0x06000323 RID: 803 RVA: 0x00159234 File Offset: 0x00159234
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt(this.m_uAppID);
			base.method_0(this.m_uUID);
		}

		// Token: 0x06000324 RID: 804 RVA: 0x00159255 File Offset: 0x00159255
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_uAppID = base.popInt();
			this.m_uUID = base.popInt64();
		}

		// Token: 0x04000258 RID: 600
		public uint m_uAppID;

		// Token: 0x04000259 RID: 601
		public MyUInt64 m_uUID;
	}
}
