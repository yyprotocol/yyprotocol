﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000055 RID: 85
	public class PCS_CliAPLoginAuth2Res : ProtoBase
	{
		// Token: 0x0600037D RID: 893 RVA: 0x001596D9 File Offset: 0x001596D9
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.context = base.popBytes();
			this.rescode = base.popInt();
			this.ruri = base.popInt();
			this.payLoad = base.method_2();
		}

		// Token: 0x040002BD RID: 701
		public byte[] context;

		// Token: 0x040002BE RID: 702
		public uint rescode;

		// Token: 0x040002BF RID: 703
		public uint ruri;

		// Token: 0x040002C0 RID: 704
		public byte[] payLoad;
	}
}
