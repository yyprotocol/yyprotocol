﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000053 RID: 83
	public class PCS_APPing : ProtoBaseEx
	{
		// Token: 0x06000379 RID: 889 RVA: 0x0015968D File Offset: 0x0015968D
		public override void vsmarshall(ByteArray _arg1)
		{
			base.vsmarshall(_arg1);
			base.setUri(794116u);
		}
	}
}
