﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000045 RID: 69
	public class GClass5 : ProtoBase
	{
		// Token: 0x06000342 RID: 834 RVA: 0x001594DD File Offset: 0x001594DD
		public GClass5()
		{
			this.terminalType = new MyUInt64(0u, 0u);
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0016BC68 File Offset: 0x0016BC68
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(19822u);
			base.pushBytes(this.context);
			base.pushInt(this.versionNum);
			base.pushBytes(this.pcInfo);
			base.pushBytes(this.macAddr);
			base.pushInt(this.clientFrom);
			base.pushBytes(this.clientExtension);
			base.pushBytes(this.bizName);
			base.pushBytes(this.antiCode);
			base.method_0(this.terminalType);
			base.pushInt(this.lcid);
			base.pushBytes(this.versionStr);
			base.pushInt(this._subsid);
			base.pushBytes(this._pic_code);
			base.pushBytes(this._session_data);
		}

		// Token: 0x04000278 RID: 632
		public byte[] context;

		// Token: 0x04000279 RID: 633
		public uint versionNum;

		// Token: 0x0400027A RID: 634
		public byte[] pcInfo;

		// Token: 0x0400027B RID: 635
		public byte[] macAddr;

		// Token: 0x0400027C RID: 636
		public uint clientFrom;

		// Token: 0x0400027D RID: 637
		public byte[] clientExtension;

		// Token: 0x0400027E RID: 638
		public byte[] bizName;

		// Token: 0x0400027F RID: 639
		public byte[] antiCode;

		// Token: 0x04000280 RID: 640
		public MyUInt64 terminalType;

		// Token: 0x04000281 RID: 641
		public uint lcid;

		// Token: 0x04000282 RID: 642
		public byte[] versionStr;

		// Token: 0x04000283 RID: 643
		public uint _subsid;

		// Token: 0x04000284 RID: 644
		public byte[] _pic_code;

		// Token: 0x04000285 RID: 645
		public byte[] _session_data;
	}
}
