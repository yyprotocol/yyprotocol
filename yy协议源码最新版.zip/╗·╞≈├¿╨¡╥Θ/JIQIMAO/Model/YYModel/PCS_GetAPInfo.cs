﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000056 RID: 86
	public class PCS_GetAPInfo : ProtoBase
	{
		// Token: 0x0600037F RID: 895 RVA: 0x00159712 File Offset: 0x00159712
		public PCS_GetAPInfo()
		{
			this.m_uUid = new MyUInt64(0u, 0u);
			this.m_uForbidIp = new List<uint>();
			this.m_mapApSpecReq = new MYHashMap();
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0016C674 File Offset: 0x0016C674
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(29470u);
			base.method_0(this.m_uUid);
			base.pushInt(this.m_uAppId);
			base.pushInt(this.m_uRetry);
			base.pushBytes(this.m_strIMEI);
			base.pushInt(this.m_uSdkVersion);
			base.pushBytes(this.m_uAppVersion);
			base.pushBytes(this.m_strClientFrom);
			base.pushBytes(this.m_strPlatform);
			base.pushIntArray(this.m_uForbidIp);
			base.pushHashMapKIVS(this.m_mapApSpecReq);
			base.pushInt(this.m_lcid);
			base.pushInt(this.m_uAppkey);
			base.pushBytes(this.m_strContext);
		}

		// Token: 0x040002C1 RID: 705
		public MyUInt64 m_uUid;

		// Token: 0x040002C2 RID: 706
		public uint m_uAppId;

		// Token: 0x040002C3 RID: 707
		public uint m_uRetry;

		// Token: 0x040002C4 RID: 708
		public byte[] m_strIMEI;

		// Token: 0x040002C5 RID: 709
		public uint m_uSdkVersion;

		// Token: 0x040002C6 RID: 710
		public byte[] m_uAppVersion;

		// Token: 0x040002C7 RID: 711
		public byte[] m_strClientFrom;

		// Token: 0x040002C8 RID: 712
		public byte[] m_strPlatform;

		// Token: 0x040002C9 RID: 713
		public List<uint> m_uForbidIp;

		// Token: 0x040002CA RID: 714
		public MYHashMap m_mapApSpecReq;

		// Token: 0x040002CB RID: 715
		public uint m_lcid;

		// Token: 0x040002CC RID: 716
		public uint m_uAppkey;

		// Token: 0x040002CD RID: 717
		public byte[] m_strContext;
	}
}
