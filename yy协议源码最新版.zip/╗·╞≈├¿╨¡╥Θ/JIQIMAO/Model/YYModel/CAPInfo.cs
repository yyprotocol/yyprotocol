﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000037 RID: 55
	public class CAPInfo : ProtoBase
	{
		// Token: 0x06000320 RID: 800 RVA: 0x001591F2 File Offset: 0x001591F2
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_strIp = base.popBytes();
			this.m_uGrpId = base.popInt();
			this.m_vecPort = base.popShortArray();
		}

		// Token: 0x04000255 RID: 597
		public uint m_uGrpId;

		// Token: 0x04000256 RID: 598
		public byte[] m_strIp;

		// Token: 0x04000257 RID: 599
		public List<uint> m_vecPort;
	}
}
