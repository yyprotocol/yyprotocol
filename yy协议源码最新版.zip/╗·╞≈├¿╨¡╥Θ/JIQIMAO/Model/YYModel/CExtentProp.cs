﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003B RID: 59
	public class CExtentProp : ProtoBase
	{
		// Token: 0x0600032B RID: 811 RVA: 0x00159312 File Offset: 0x00159312
		public CExtentProp()
		{
			this.m_mapExtentProp = new MYHashMap();
		}

		// Token: 0x0600032C RID: 812 RVA: 0x00159325 File Offset: 0x00159325
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushHashMapKIVS(this.m_mapExtentProp);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x0015933A File Offset: 0x0015933A
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_mapExtentProp = base.popHashMapKIVS();
		}

		// Token: 0x0400025F RID: 607
		public MYHashMap m_mapExtentProp;
	}
}
