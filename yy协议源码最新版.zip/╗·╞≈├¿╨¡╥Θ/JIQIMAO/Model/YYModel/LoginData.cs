﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000049 RID: 73
	public class LoginData : ProtoBase
	{
		// Token: 0x0600034E RID: 846 RVA: 0x0016BFA8 File Offset: 0x0016BFA8
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this._yyid = base.popInt64();
			this._udbuid = base.popInt64();
			this._passport = base.popBytes();
			this._accessToken = base.popBytes();
			this._accountInfo = base.popBytes();
			this._jump_tokens = base.popStringArray();
			this._ticket = base.popBytes();
			this._yycookie = base.popBytes();
			this._cookie = base.popBytes();
		}

		// Token: 0x04000298 RID: 664
		public MyUInt64 _yyid;

		// Token: 0x04000299 RID: 665
		public MyUInt64 _udbuid;

		// Token: 0x0400029A RID: 666
		public byte[] _passport;

		// Token: 0x0400029B RID: 667
		public byte[] _accessToken;

		// Token: 0x0400029C RID: 668
		public byte[] _accountInfo;

		// Token: 0x0400029D RID: 669
		public List<byte[]> _jump_tokens;

		// Token: 0x0400029E RID: 670
		public byte[] _ticket;

		// Token: 0x0400029F RID: 671
		public byte[] _yycookie;

		// Token: 0x040002A0 RID: 672
		public byte[] _cookie;
	}
}
