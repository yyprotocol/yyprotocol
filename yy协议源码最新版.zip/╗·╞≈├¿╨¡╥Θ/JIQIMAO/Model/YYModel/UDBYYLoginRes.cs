﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000070 RID: 112
	public class UDBYYLoginRes : ProtoBase
	{
		// Token: 0x060003E8 RID: 1000 RVA: 0x00159C0E File Offset: 0x00159C0E
		public UDBYYLoginRes()
		{
			this.dynamic_token_reqs = new List<byte[]>();
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x0016D4E4 File Offset: 0x0016D4E4
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this._context = base.popBytes();
			this._rescode = base.popInt();
			this._reason = base.popBytes();
			this._description = base.popBytes();
			this._yyuid = base.popInt64();
			this.dynamic_token_reqs = base.popStringArray();
			this._pic_id = base.popBytes();
			this._pic_data = base.popBytes();
			this._login_data = base.popBytes();
			this._callback_data = base.popBytes();
			this._extension = base.popBytes();
		}

		// Token: 0x04000352 RID: 850
		public byte[] _context;

		// Token: 0x04000353 RID: 851
		public uint _rescode;

		// Token: 0x04000354 RID: 852
		public byte[] _reason;

		// Token: 0x04000355 RID: 853
		public byte[] _description;

		// Token: 0x04000356 RID: 854
		public MyUInt64 _yyuid;

		// Token: 0x04000357 RID: 855
		public List<byte[]> dynamic_token_reqs;

		// Token: 0x04000358 RID: 856
		public byte[] _pic_id;

		// Token: 0x04000359 RID: 857
		public byte[] _pic_data;

		// Token: 0x0400035A RID: 858
		public byte[] _login_data;

		// Token: 0x0400035B RID: 859
		public byte[] _callback_data;

		// Token: 0x0400035C RID: 860
		public byte[] _extension;
	}
}
