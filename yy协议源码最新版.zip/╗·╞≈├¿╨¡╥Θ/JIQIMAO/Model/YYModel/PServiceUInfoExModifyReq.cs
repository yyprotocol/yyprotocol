﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200006A RID: 106
	public class PServiceUInfoExModifyReq : PServiceUInfoExLoginReq
	{
		// Token: 0x060003DC RID: 988 RVA: 0x00159B62 File Offset: 0x00159B62
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(386136u);
		}
	}
}
