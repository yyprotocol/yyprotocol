﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000064 RID: 100
	public class PQueryUserInfoRes : ProtoBase
	{
		// Token: 0x0600039B RID: 923 RVA: 0x0016C87C File Offset: 0x0016C87C
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.topSid = base.popInt();
			this.users = base.popHashMapKIVP<POnlineUser>();
			if (_arg1.bytesAvailable > 0)
			{
				this.type = base.popInt();
				this.leaves = base.popIntArray();
			}
		}

		// Token: 0x0400031A RID: 794
		public uint topSid;

		// Token: 0x0400031B RID: 795
		public MYHashMap users;

		// Token: 0x0400031C RID: 796
		public uint type;

		// Token: 0x0400031D RID: 797
		public List<uint> leaves;
	}
}
