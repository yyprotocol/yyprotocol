﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004C RID: 76
	public sealed class MyUInt64 : Binary64
	{
		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000361 RID: 865 RVA: 0x001595BF File Offset: 0x001595BF
		// (set) Token: 0x06000362 RID: 866 RVA: 0x001595C7 File Offset: 0x001595C7
		public uint high
		{
			get
			{
				return this.internalHigh;
			}
			set
			{
				this.internalHigh = value;
			}
		}

		// Token: 0x06000363 RID: 867 RVA: 0x001595D0 File Offset: 0x001595D0
		public MyUInt64(uint _arg1 = 0u, uint _arg2 = 0u) : base(_arg1, _arg2)
		{
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0016C318 File Offset: 0x0016C318
		public static MyUInt64 smethod_0(string _arg1, uint _arg2 = 0u)
		{
			uint num = 0u;
			if (_arg2 == 0u)
			{
				if (_arg1.IndexOf("0x") == 0)
				{
					_arg2 = 16u;
					num = 2u;
				}
				else
				{
					_arg2 = 10u;
				}
			}
			if (_arg2 >= 2u && _arg2 <= 36u)
			{
				_arg1 = _arg1.ToLower();
				MyUInt64 myUInt = new MyUInt64(0u, 0u);
				char[] array = _arg1.ToCharArray();
				while ((ulong)num < (ulong)((long)_arg1.Length))
				{
					uint num2 = (uint)Convert.ToByte(array[(int)num]);
					if (num2 >= (uint)Convert.ToByte('0') && num2 <= (uint)Convert.ToByte('9'))
					{
						num2 -= (uint)Convert.ToByte('0');
					}
					else
					{
						if (num2 < (uint)Convert.ToByte('a') || num2 > (uint)Convert.ToByte('z'))
						{
							throw new Exception();
						}
						num2 -= (uint)Convert.ToByte('a');
					}
					if (num2 >= _arg2)
					{
						throw new Exception();
					}
					myUInt.mul(_arg2);
					myUInt.add(num2);
					num += 1u;
				}
				return myUInt;
			}
			throw new Exception();
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0016C3E8 File Offset: 0x0016C3E8
		public static int comp(MyUInt64 _arg1, MyUInt64 _arg2)
		{
			if (_arg1.high > _arg2.high)
			{
				return 1;
			}
			if (_arg1.high < _arg2.high)
			{
				return -1;
			}
			if (_arg1.low > _arg2.low)
			{
				return 1;
			}
			if (_arg1.low < _arg2.low)
			{
				return -1;
			}
			return 0;
		}

		// Token: 0x06000366 RID: 870 RVA: 0x001595DA File Offset: 0x001595DA
		public void plus(uint _arg1)
		{
			base.add(_arg1);
		}

		// Token: 0x06000367 RID: 871 RVA: 0x001595E3 File Offset: 0x001595E3
		public void increase()
		{
			base.add(1u);
		}

		// Token: 0x06000368 RID: 872 RVA: 0x0016C438 File Offset: 0x0016C438
		public string toString(uint _arg1 = 10u)
		{
			if (_arg1 < 2u || _arg1 > 36u)
			{
				throw new Exception();
			}
			if (this.low == 0u && this.high == 0u)
			{
				return "0";
			}
			List<string> list = new List<string>();
			MyUInt64 myUInt = new MyUInt64(this.low, this.high);
			do
			{
				uint num = myUInt.div(_arg1);
				list.Add((num >= 10u) ? ((uint)Convert.ToByte('a') + num).ToString() : "0");
			}
			while (myUInt.low != 0u || myUInt.high != 0u);
			list.Reverse();
			new StringBuilder();
			return list.ToString();
		}
	}
}
