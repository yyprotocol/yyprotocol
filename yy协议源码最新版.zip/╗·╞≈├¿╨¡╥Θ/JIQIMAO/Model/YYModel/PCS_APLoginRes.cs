﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000052 RID: 82
	public class PCS_APLoginRes : ProtoBaseEx
	{
		// Token: 0x06000377 RID: 887 RVA: 0x0016C610 File Offset: 0x0016C610
		public override void vsunmarshall(ByteArray _arg1)
		{
			base.vsunmarshall(_arg1);
			this.m_uResCode = base.popInt();
			this.m_strContext = base.popBytes();
			if (_arg1.bytesAvailable > 0)
			{
				this.m_uClientIp = base.popInt();
				this.m_uClientPort = base.popShort();
			}
			if (_arg1.bytesAvailable > 0)
			{
				this.m_compressMode = base.popByte();
			}
		}

		// Token: 0x040002B5 RID: 693
		public uint m_uResCode;

		// Token: 0x040002B6 RID: 694
		public byte[] m_strContext;

		// Token: 0x040002B7 RID: 695
		public uint m_uClientIp;

		// Token: 0x040002B8 RID: 696
		public uint m_uClientPort;

		// Token: 0x040002B9 RID: 697
		public uint m_compressMode;
	}
}
