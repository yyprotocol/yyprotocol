﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000044 RID: 68
	public class GClass4 : ProtoBase
	{
		// Token: 0x06000340 RID: 832 RVA: 0x001594A4 File Offset: 0x001594A4
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.topSid = base.popInt();
			this.subSid = base.popInt();
			this.pos = base.popInt();
			this.users = base.popHashMapKIVP<POnlineUser>();
		}

		// Token: 0x04000274 RID: 628
		public uint topSid;

		// Token: 0x04000275 RID: 629
		public uint subSid;

		// Token: 0x04000276 RID: 630
		public uint pos;

		// Token: 0x04000277 RID: 631
		public MYHashMap users;
	}
}
