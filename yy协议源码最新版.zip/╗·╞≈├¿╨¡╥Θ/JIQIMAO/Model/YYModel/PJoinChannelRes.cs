﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005D RID: 93
	public class PJoinChannelRes : ProtoBase
	{
		// Token: 0x0600038E RID: 910 RVA: 0x0016C814 File Offset: 0x0016C814
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.topsid = base.popInt();
			this.uid = base.popInt();
			this.subSid = base.popInt();
			this.asid = base.popInt();
			this.loginStamp = base.popInt();
			this.loginStatus = base.popByte();
			this.errorInfo = base.popBytes();
		}

		// Token: 0x040002EB RID: 747
		public const uint USER_KICK_OFF = 0u;

		// Token: 0x040002EC RID: 748
		public const uint USER_BAN_ID = 1u;

		// Token: 0x040002ED RID: 749
		public const uint USER_BAN_PC = 3u;

		// Token: 0x040002EE RID: 750
		public const uint USER_LOGIN_SUCCESS = 4u;

		// Token: 0x040002EF RID: 751
		public const uint USER_LOGIN_DUOWAN_LIMIT = 5u;

		// Token: 0x040002F0 RID: 752
		public const uint USER_NEED_PASSWD = 6u;

		// Token: 0x040002F1 RID: 753
		public const uint USER_MUTIJOIN = 7u;

		// Token: 0x040002F2 RID: 754
		public const uint USER_MUTIJOIN_ERR_MODE = 8u;

		// Token: 0x040002F3 RID: 755
		public const uint USER_MUTIJOIN_TIMEOUT = 9u;

		// Token: 0x040002F4 RID: 756
		public const uint CHANNEL_FULL = 10u;

		// Token: 0x040002F5 RID: 757
		public const uint CHANNEL_CONGEST = 11u;

		// Token: 0x040002F6 RID: 758
		public const uint CHANNEL_NOT_EXIST = 12u;

		// Token: 0x040002F7 RID: 759
		public const uint CHANNEL_FROZEN = 13u;

		// Token: 0x040002F8 RID: 760
		public const uint CHANNEL_LOCKED = 14u;

		// Token: 0x040002F9 RID: 761
		public const uint CHANNEL_ASID_RECYLED = 15u;

		// Token: 0x040002FA RID: 762
		public const uint CHANNEL_SUBSID_FULL = 17u;

		// Token: 0x040002FB RID: 763
		public const uint CHANNEL_SUBSID_LIMIT = 18u;

		// Token: 0x040002FC RID: 764
		public const uint GUSET_ACCESS_LIMIT = 19u;

		// Token: 0x040002FD RID: 765
		public const uint CHANNEL_VIP_LIMIT = 20u;

		// Token: 0x040002FE RID: 766
		public const uint CHANNEL_CHARGE_LIMIT = 21u;

		// Token: 0x040002FF RID: 767
		public const uint JOIN_MUTI_MODE_CONTEXT = 1u;

		// Token: 0x04000300 RID: 768
		public const uint JOIN_MUTI_TYPES = 2u;

		// Token: 0x04000301 RID: 769
		public const uint JOIN_MY_ROLER = 3u;

		// Token: 0x04000302 RID: 770
		public uint topsid;

		// Token: 0x04000303 RID: 771
		public uint uid;

		// Token: 0x04000304 RID: 772
		public uint subSid;

		// Token: 0x04000305 RID: 773
		public uint asid;

		// Token: 0x04000306 RID: 774
		public uint loginStamp;

		// Token: 0x04000307 RID: 775
		public uint loginStatus;

		// Token: 0x04000308 RID: 776
		public byte[] errorInfo;

		// Token: 0x04000309 RID: 777
		public uint expiredTime;

		// Token: 0x0400030A RID: 778
		public MYHashMap joinProps;
	}
}
