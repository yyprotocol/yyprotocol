﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000051 RID: 81
	public class PCS_APLogin : LoginAuthInfo
	{
		// Token: 0x06000375 RID: 885 RVA: 0x00159678 File Offset: 0x00159678
		public PCS_APLogin()
		{
			this.m_uUid = new MyUInt64(0u, 0u);
		}

		// Token: 0x06000376 RID: 886 RVA: 0x0016C5A8 File Offset: 0x0016C5A8
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(775684u);
			base.pushInt(this.m_uAppID);
			base.method_0(this.m_uUid);
			base.pushBool(this.m_bRelogin);
			base.pushBytes(this.m_strTicket);
			base.pushBytes(this.m_strCookie);
			base.pushBytes(this.m_strContext);
		}

		// Token: 0x040002AF RID: 687
		public uint m_uAppID;

		// Token: 0x040002B0 RID: 688
		public MyUInt64 m_uUid;

		// Token: 0x040002B1 RID: 689
		public bool m_bRelogin;

		// Token: 0x040002B2 RID: 690
		public byte[] m_strTicket;

		// Token: 0x040002B3 RID: 691
		public byte[] m_strCookie;

		// Token: 0x040002B4 RID: 692
		public byte[] m_strContext;
	}
}
