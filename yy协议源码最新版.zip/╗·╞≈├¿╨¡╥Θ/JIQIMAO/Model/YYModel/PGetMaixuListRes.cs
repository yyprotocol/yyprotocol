﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005B RID: 91
	public class PGetMaixuListRes : ChannelQueueMar
	{
		// Token: 0x06000389 RID: 905 RVA: 0x00159805 File Offset: 0x00159805
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.topSid = base.popInt();
			this.subSid = base.popInt();
			this.choruslist = base.popIntArray();
		}

		// Token: 0x040002E0 RID: 736
		public uint topSid;

		// Token: 0x040002E1 RID: 737
		public uint subSid;

		// Token: 0x040002E2 RID: 738
		public List<uint> choruslist;
	}
}
