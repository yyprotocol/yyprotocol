﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003E RID: 62
	public class CombAcctinfo : ProtoBase
	{
		// Token: 0x06000332 RID: 818 RVA: 0x0015936C File Offset: 0x0015936C
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushBytes(this.acctinfo);
			base.pushBytes(this.appid_type);
		}

		// Token: 0x06000333 RID: 819 RVA: 0x0015938D File Offset: 0x0015938D
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.acctinfo = base.popBytes();
			this.appid_type = base.popBytes();
		}

		// Token: 0x04000266 RID: 614
		public byte[] acctinfo;

		// Token: 0x04000267 RID: 615
		public byte[] appid_type;
	}
}
