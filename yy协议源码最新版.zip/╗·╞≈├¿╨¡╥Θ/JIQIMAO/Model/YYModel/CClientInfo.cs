﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000039 RID: 57
	public class CClientInfo : ProtoBase
	{
		// Token: 0x06000326 RID: 806 RVA: 0x00159276 File Offset: 0x00159276
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt(this.m_uIP);
			base.pushShort(this.m_uPort);
			base.pushInt(this.m_uRouteNum);
			base.pushBytes(this.m_serverName);
		}

		// Token: 0x06000327 RID: 807 RVA: 0x001592AF File Offset: 0x001592AF
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_uIP = base.popInt();
			this.m_uPort = base.popShort();
			this.m_uRouteNum = base.popInt();
			this.m_serverName = base.popBytes();
		}

		// Token: 0x0400025A RID: 602
		public uint m_uIP;

		// Token: 0x0400025B RID: 603
		public uint m_uPort;

		// Token: 0x0400025C RID: 604
		public uint m_uRouteNum;

		// Token: 0x0400025D RID: 605
		public byte[] m_serverName;
	}
}
