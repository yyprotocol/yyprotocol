﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000042 RID: 66
	public class GClass2 : ProtoBase
	{
		// Token: 0x0600033C RID: 828 RVA: 0x00159477 File Offset: 0x00159477
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.topSid = base.popInt();
			this.totalCount = base.popInt();
			this.myhashMap_0 = base.popHashMapKIVI();
		}

		// Token: 0x0400026D RID: 621
		public uint topSid;

		// Token: 0x0400026E RID: 622
		public uint totalCount;

		// Token: 0x0400026F RID: 623
		public MYHashMap myhashMap_0;
	}
}
