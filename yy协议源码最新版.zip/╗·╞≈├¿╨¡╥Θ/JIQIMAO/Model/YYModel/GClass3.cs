﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000043 RID: 67
	public class GClass3 : ProtoBase
	{
		// Token: 0x0600033E RID: 830 RVA: 0x0016BC18 File Offset: 0x0016BC18
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(3126274u);
			base.pushInt(this.topSid);
			base.pushInt(this.subSid);
			base.pushInt(this.num);
			base.pushInt(this.pos);
		}

		// Token: 0x04000270 RID: 624
		public uint topSid;

		// Token: 0x04000271 RID: 625
		public uint subSid;

		// Token: 0x04000272 RID: 626
		public uint num;

		// Token: 0x04000273 RID: 627
		public uint pos;
	}
}
