﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000067 RID: 103
	public class ProtoBaseEx : ProtoBase
	{
		// Token: 0x060003C9 RID: 969 RVA: 0x0016CE98 File Offset: 0x0016CE98
		public override void marshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
			uint position = (uint)this.mBuffer.position;
			this.mBuffer.writeUnsignedInt(0u);
			this.vsmarshall(_arg1);
			uint position2 = (uint)this.mBuffer.position;
			uint num = position2 - position - 4u;
			uint value = this.mProtoVer << 28 | (num & 268435455u);
			this.mBuffer.position = (int)position;
			this.mBuffer.writeUnsignedInt(value);
			this.mBuffer.position = (int)position2;
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0016CF14 File Offset: 0x0016CF14
		public override void unmarshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
			uint position = (uint)this.mBuffer.position;
			uint num = this.mBuffer.readUnsignedInt();
			this.mProtoVer = (num >> 28 & 15u);
			uint num2 = num & 268435455u;
			this.vsunmarshall(_arg1);
			this.mBuffer.position = (int)(position + 4u + num2);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x001599E4 File Offset: 0x001599E4
		public virtual void vsmarshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
		}

		// Token: 0x060003CC RID: 972 RVA: 0x001599E4 File Offset: 0x001599E4
		public virtual void vsunmarshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
		}

		// Token: 0x060003CD RID: 973 RVA: 0x0016CF6C File Offset: 0x0016CF6C
		public void pushProtoWithTag(uint _arg1, ProtoBase _arg2)
		{
			if (_arg2 != null)
			{
				uint position = (uint)this.mBuffer.position;
				this.mBuffer.writeUnsignedInt(0u);
				base.pushProto(_arg2);
				uint position2 = (uint)this.mBuffer.position;
				uint num = position2 - position;
				uint value = _arg1 << 24 | (num & 16777215u);
				this.mBuffer.position = (int)position;
				this.mBuffer.writeUnsignedInt(value);
				this.mBuffer.position = (int)position2;
			}
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00159AFB File Offset: 0x00159AFB
		public void pushFinishFlag()
		{
			this.mBuffer.writeUnsignedInt(4286085240u);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x0016CFDC File Offset: 0x0016CFDC
		public T popProtoWithTag<T>(uint _arg1) where T : ProtoBase, new()
		{
			T result = Activator.CreateInstance<T>();
			uint position = (uint)this.mBuffer.position;
			for (;;)
			{
				uint num = this.mBuffer.readUnsignedInt();
				uint num2 = num >> 24 & 255u;
				uint num3 = (num & 16777215u) - 4u;
				if ((long)this.mBuffer.length < (long)((ulong)num3) || num2 > _arg1)
				{
					goto IL_76;
				}
				if (num2 == _arg1)
				{
					break;
				}
				this.mBuffer.position = (int)((long)this.mBuffer.position + (long)((ulong)num3));
			}
			result = base.popProto<T>();
			IL_76:
			this.mBuffer.position = (int)position;
			return result;
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x00159ADB File Offset: 0x00159ADB
		public uint popFinishFlag()
		{
			return this.mBuffer.readUnsignedInt();
		}

		// Token: 0x04000322 RID: 802
		protected uint mProtoVer;
	}
}
