﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000050 RID: 80
	public class PContextField1 : ProtoBase
	{
		// Token: 0x06000372 RID: 882 RVA: 0x0015964E File Offset: 0x0015964E
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt(this.f1);
		}

		// Token: 0x06000373 RID: 883 RVA: 0x00159663 File Offset: 0x00159663
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.f1 = base.popInt();
		}

		// Token: 0x040002AE RID: 686
		public uint f1;
	}
}
