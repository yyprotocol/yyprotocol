﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200003C RID: 60
	public class ChannelQueueMar : ProtoBase
	{
		// Token: 0x0600032E RID: 814 RVA: 0x0016BBBC File Offset: 0x0016BBBC
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.mute = base.popBool();
			this.disable = base.popBool();
			this.ring = base.popInt();
			this.count = base.popInt();
			this.validring = base.popInt();
			this.userlist = base.popIntArray();
		}

		// Token: 0x04000260 RID: 608
		public bool mute;

		// Token: 0x04000261 RID: 609
		public bool disable;

		// Token: 0x04000262 RID: 610
		public uint ring;

		// Token: 0x04000263 RID: 611
		public uint count;

		// Token: 0x04000264 RID: 612
		public uint validring;

		// Token: 0x04000265 RID: 613
		public List<uint> userlist;
	}
}
