﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004E RID: 78
	public class PAPRouterHdrBase : APRouterBase
	{
		// Token: 0x0600036C RID: 876 RVA: 0x00159611 File Offset: 0x00159611
		public PAPRouterHdrBase()
		{
			this.m_objAPHdr = new PAPRouterHeaders();
		}

		// Token: 0x0600036D RID: 877 RVA: 0x00159624 File Offset: 0x00159624
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushProto(this.m_objAPHdr);
		}

		// Token: 0x0600036E RID: 878 RVA: 0x00159639 File Offset: 0x00159639
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_objAPHdr = base.popProto<PAPRouterHeaders>();
		}

		// Token: 0x040002A7 RID: 679
		public PAPRouterHeaders m_objAPHdr;
	}
}
