﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000059 RID: 89
	public class PExchangeKeyExt : ProtoBase
	{
		// Token: 0x06000385 RID: 901 RVA: 0x0015977F File Offset: 0x0015977F
		public PExchangeKeyExt(byte[] _arg1, byte[] _arg2)
		{
			this.byte_0 = _arg1;
			this.byte_1 = _arg2;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00159795 File Offset: 0x00159795
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(12804u);
			base.pushBytes(this.byte_0);
			base.pushBytes(this.byte_1);
			base.method_1(this.byte_2);
		}

		// Token: 0x040002DA RID: 730
		private byte[] byte_0;

		// Token: 0x040002DB RID: 731
		private byte[] byte_1;

		// Token: 0x040002DC RID: 732
		private byte[] byte_2;
	}
}
