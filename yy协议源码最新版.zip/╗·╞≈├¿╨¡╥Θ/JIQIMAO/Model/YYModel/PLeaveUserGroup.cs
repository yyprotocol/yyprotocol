﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000060 RID: 96
	public class PLeaveUserGroup : PJoinUserGroup
	{
		// Token: 0x06000393 RID: 915 RVA: 0x001598D1 File Offset: 0x001598D1
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(642904u);
		}
	}
}
