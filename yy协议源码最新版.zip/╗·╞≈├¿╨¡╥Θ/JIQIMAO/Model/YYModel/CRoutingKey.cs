﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000040 RID: 64
	public class CRoutingKey : ProtoBase
	{
		// Token: 0x06000337 RID: 823 RVA: 0x0015940E File Offset: 0x0015940E
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.pushInt(this.m_uRealUri);
		}

		// Token: 0x06000338 RID: 824 RVA: 0x00159423 File Offset: 0x00159423
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.m_uRealUri = base.popInt();
		}

		// Token: 0x0400026A RID: 618
		public uint m_uRealUri;
	}
}
