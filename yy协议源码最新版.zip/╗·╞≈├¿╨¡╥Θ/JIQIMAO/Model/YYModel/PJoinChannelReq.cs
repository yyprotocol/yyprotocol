﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005C RID: 92
	public class PJoinChannelReq : ProtoBase
	{
		// Token: 0x0600038B RID: 907 RVA: 0x0015983A File Offset: 0x0015983A
		public PJoinChannelReq()
		{
			this.props = new MYHashMap();
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0016C7C4 File Offset: 0x0016C7C4
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(2048258u);
			base.pushInt(this.uid);
			base.pushInt(this.topsid);
			base.pushInt(this.subSid);
			base.pushHashMapKIVS(this.props);
		}

		// Token: 0x040002E3 RID: 739
		public const uint JOIN_INFO_PASSWD = 1u;

		// Token: 0x040002E4 RID: 740
		public const uint JOIN_INFO_LOGIN_MODE = 2u;

		// Token: 0x040002E5 RID: 741
		public const uint JOIN_MUTI_MODE = 3u;

		// Token: 0x040002E6 RID: 742
		public const uint JOIN_MUTI_MODE_CONTEXT = 4u;

		// Token: 0x040002E7 RID: 743
		public uint uid;

		// Token: 0x040002E8 RID: 744
		public uint topsid;

		// Token: 0x040002E9 RID: 745
		public uint subSid;

		// Token: 0x040002EA RID: 746
		public MYHashMap props;
	}
}
