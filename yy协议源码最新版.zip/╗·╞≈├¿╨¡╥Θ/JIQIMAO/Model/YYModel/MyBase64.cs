﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200004A RID: 74
	public class MyBase64
	{
		// Token: 0x06000351 RID: 849 RVA: 0x0016C028 File Offset: 0x0016C028
		public static string encode(string param1)
		{
			ByteArray byteArray = new ByteArray();
			byteArray.writeUTFBytes(param1);
			return MyBase64.encodeByteArray(byteArray);
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0016C048 File Offset: 0x0016C048
		public static string encodeByteArray(ByteArray param1)
		{
			string text = "";
			List<int> list = new List<int>(4);
			param1.position = 0;
			while (param1.bytesAvailable > 0)
			{
				List<int> list2 = new List<int>();
				int num = 0;
				while (num < 3 && param1.bytesAvailable > 0)
				{
					list2[num] = (int)param1.readUnsignedByte();
					num++;
				}
				list[0] = (list2[0] & 252) >> 2;
				list[1] = ((list2[0] & 3) << 4 | list2[1] >> 4);
				list[2] = ((list2[1] & 15) << 2 | list2[2] >> 6);
				list[3] = (list2[2] & 63);
				for (int i = list2.Count; i < 3; i++)
				{
					list[i + 1] = 64;
				}
				for (int j = 0; j < list.Count; j++)
				{
					text += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=-_".CharAt(list[j]);
				}
			}
			return text;
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0016C154 File Offset: 0x0016C154
		public static string decode(string param1)
		{
			ByteArray byteArray = MyBase64.decodeToByteArray(param1);
			return byteArray.readUTFBytes((uint)byteArray.length);
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0016C174 File Offset: 0x0016C174
		public static ByteArray decodeToByteArray(string param1)
		{
			ByteArray byteArray = new ByteArray();
			int[] array = new int[4];
			int[] array2 = new int[3];
			for (int i = 0; i < param1.Length; i += 4)
			{
				int num = 0;
				while (num < 4 && i + num < param1.Length)
				{
					array[num] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=-_".IndexOf(param1.CharAt(i + num));
					num++;
				}
				array2[0] = (array[0] << 2) + ((array[1] & 48) >> 4);
				array2[1] = ((array[1] & 15) << 4) + ((array[2] & 60) >> 2);
				array2[2] = ((array[2] & 3) << 6) + array[3];
				for (int j = 0; j < array2.Length; j++)
				{
					if (array[j + 1] == 64)
					{
						break;
					}
					byteArray.writeByte((byte)array2[j]);
				}
			}
			byteArray.position = 0;
			return byteArray;
		}

		// Token: 0x040002A1 RID: 673
		public const string version = "1.0.0";
	}
}
