﻿using System;
using System.Collections.Generic;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000066 RID: 102
	public class ProtoBase
	{
		// Token: 0x060003A0 RID: 928 RVA: 0x001599C3 File Offset: 0x001599C3
		public void setUri(uint _arg1)
		{
			this.mUri = _arg1;
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x001599CC File Offset: 0x001599CC
		public uint getUri()
		{
			return this.mUri;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x001599D4 File Offset: 0x001599D4
		public uint getRes()
		{
			return this.mRes;
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x001599DC File Offset: 0x001599DC
		public ByteArray getBuffer()
		{
			return this.mBuffer;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x001599E4 File Offset: 0x001599E4
		public virtual void marshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x001599E4 File Offset: 0x001599E4
		public virtual void unmarshall(ByteArray _arg1)
		{
			this.mBuffer = _arg1;
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x0016C8CC File Offset: 0x0016C8CC
		public void pushBool(bool _arg1)
		{
			uint value = 0u;
			if (_arg1)
			{
				value = 1u;
			}
			this.mBuffer.writeByte(Convert.ToByte(value));
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x001599ED File Offset: 0x001599ED
		public void pushByte(uint _arg1)
		{
			this.mBuffer.writeByte(Convert.ToByte(_arg1));
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x00159A00 File Offset: 0x00159A00
		public void pushShort(uint _arg1)
		{
			this.mBuffer.writeShort((int)Convert.ToUInt16(_arg1));
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x00159A13 File Offset: 0x00159A13
		public void pushInt(uint _arg1)
		{
			this.mBuffer.writeUnsignedInt(_arg1);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00159A21 File Offset: 0x00159A21
		public void method_0(MyUInt64 _arg1)
		{
			this.mBuffer.writeUnsignedInt(_arg1.low);
			this.mBuffer.writeUnsignedInt(_arg1.high);
		}

		// Token: 0x060003AB RID: 939 RVA: 0x00159A45 File Offset: 0x00159A45
		public void pushBytes(byte[] bytes)
		{
			if (bytes == null)
			{
				this.mBuffer.writeShort(0);
				return;
			}
			this.mBuffer.writeShort(bytes.Length);
			this.mBuffer.writeBytes(bytes);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x00159A71 File Offset: 0x00159A71
		public void method_1(byte[] _arg1)
		{
			if (_arg1 != null)
			{
				this.mBuffer.writeInt(_arg1.Length);
				this.mBuffer.writeBytes(_arg1);
				return;
			}
			this.mBuffer.writeInt(0);
		}

		// Token: 0x060003AD RID: 941 RVA: 0x00159A9D File Offset: 0x00159A9D
		public void pushProto(ProtoBase _arg1)
		{
			_arg1.marshall(this.mBuffer);
		}

		// Token: 0x060003AE RID: 942 RVA: 0x0016C8F4 File Offset: 0x0016C8F4
		public void pushProtoArray<T>(List<T> _arg1) where T : ProtoBase, new()
		{
			uint count = (uint)_arg1.Count;
			this.pushInt(count);
			for (uint num = 0u; num < count; num += 1u)
			{
				_arg1[(int)num].marshall(this.mBuffer);
			}
		}

		// Token: 0x060003AF RID: 943 RVA: 0x0016C934 File Offset: 0x0016C934
		public void pushShortArray(List<uint> _arg1)
		{
			uint count = (uint)_arg1.Count;
			this.pushInt(count);
			for (uint num = 0u; num < count; num += 1u)
			{
				this.mBuffer.writeShort((int)_arg1[(int)num]);
			}
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x0016C970 File Offset: 0x0016C970
		public void pushIntArray(List<uint> _arg1)
		{
			uint count = (uint)_arg1.Count;
			this.pushInt(count);
			for (uint num = 0u; num < count; num += 1u)
			{
				this.mBuffer.writeUnsignedInt(_arg1[(int)num]);
			}
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x0016C9AC File Offset: 0x0016C9AC
		public void pushInt64Array(List<MyUInt64> _arg1)
		{
			uint count = (uint)_arg1.Count;
			this.pushInt(count);
			for (uint num = 0u; num < count; num += 1u)
			{
				this.method_0(_arg1[(int)num]);
			}
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x0016C9E0 File Offset: 0x0016C9E0
		public void pushStringArray(List<ByteArray> _arg1)
		{
			uint count = (uint)_arg1.Count;
			this.pushInt(count);
			for (uint num = 0u; num < count; num += 1u)
			{
				this.pushBytes(_arg1[(int)num].Buffer);
			}
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00159AAB File Offset: 0x00159AAB
		public bool popBool()
		{
			return this.mBuffer.readByte() > 0;
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x00159ABB File Offset: 0x00159ABB
		public uint popByte()
		{
			return (uint)(this.mBuffer.readByte() & byte.MaxValue);
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00159ACE File Offset: 0x00159ACE
		public uint popShort()
		{
			return (uint)this.mBuffer.readUnsignedShort();
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00159ADB File Offset: 0x00159ADB
		public uint popInt()
		{
			return this.mBuffer.readUnsignedInt();
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x0016CA1C File Offset: 0x0016CA1C
		public MyUInt64 popInt64()
		{
			uint arg = this.mBuffer.readUnsignedInt();
			uint arg2 = this.mBuffer.readUnsignedInt();
			return new MyUInt64(arg, arg2);
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0016CA48 File Offset: 0x0016CA48
		public List<uint> popIntArray()
		{
			uint num = this.popInt();
			List<uint> list = new List<uint>();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				list[(int)num2] = this.popInt();
			}
			return list;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x0016CA7C File Offset: 0x0016CA7C
		public List<MyUInt64> popInt64Array()
		{
			uint num = this.popInt();
			List<MyUInt64> list = new List<MyUInt64>();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				list[(int)num2] = this.popInt64();
			}
			return list;
		}

		// Token: 0x060003BA RID: 954 RVA: 0x0016CAB0 File Offset: 0x0016CAB0
		public List<uint> popShortArray()
		{
			uint num = this.popInt();
			List<uint> list = new List<uint>();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				list[(int)num2] = this.popShort();
			}
			return list;
		}

		// Token: 0x060003BB RID: 955 RVA: 0x0016CAE4 File Offset: 0x0016CAE4
		public byte[] popBytes()
		{
			uint num = this.popShort();
			byte[] array = null;
			byte[] result;
			using (ByteArray byteArray = new ByteArray())
			{
				if (num == 0u)
				{
					result = array;
				}
				else
				{
					this.mBuffer.readBytes(byteArray, 0u, num);
					byteArray.position = 0;
					result = byteArray.Buffer;
				}
			}
			return result;
		}

		// Token: 0x060003BC RID: 956 RVA: 0x0016CB40 File Offset: 0x0016CB40
		public List<byte[]> popStringArray()
		{
			uint num = this.popInt();
			List<byte[]> list = new List<byte[]>();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				list[(int)num2] = this.popBytes();
			}
			return list;
		}

		// Token: 0x060003BD RID: 957 RVA: 0x0016CB74 File Offset: 0x0016CB74
		public void pushHashMapKIVS(MYHashMap _arg1)
		{
			uint num = (uint)_arg1.size();
			this.pushInt(num);
			List<string> list = _arg1.keys();
			List<object> list2 = _arg1.values();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				this.pushInt((uint)Convert.ToInt32(list[(int)num2]));
				this.pushBytes((byte[])list2[(int)num2]);
			}
		}

		// Token: 0x060003BE RID: 958 RVA: 0x0016CBD0 File Offset: 0x0016CBD0
		public MYHashMap popHashMapKIVS()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				myhashMap.put(this.popInt().ToString(), this.popBytes());
			}
			return myhashMap;
		}

		// Token: 0x060003BF RID: 959 RVA: 0x0016CC14 File Offset: 0x0016CC14
		public MYHashMap popHashMapKIVP<T>() where T : ProtoBase, new()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			int num2 = 0;
			while ((long)num2 < (long)((ulong)num))
			{
				myhashMap.put(this.popInt().ToString(), this.popProto<T>());
				num2++;
			}
			return myhashMap;
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x0016CC60 File Offset: 0x0016CC60
		public MYHashMap popHashMapKBVI()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			int num2 = 0;
			while ((long)num2 < (long)((ulong)num))
			{
				myhashMap.put(this.popByte().ToString(), this.popInt());
				num2++;
			}
			return myhashMap;
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x0016CCAC File Offset: 0x0016CCAC
		public MYHashMap popHashMapKIVI()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			int num2 = 0;
			while ((long)num2 < (long)((ulong)num))
			{
				myhashMap.put(this.popInt().ToString(), this.popInt());
				num2++;
			}
			return myhashMap;
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x0016CCF8 File Offset: 0x0016CCF8
		public MYHashMap popHashMapKBVS()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			int num2 = 0;
			while ((long)num2 < (long)((ulong)num))
			{
				myhashMap.put(this.popByte().ToString(), this.popBytes());
				num2++;
			}
			return myhashMap;
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0016CD3C File Offset: 0x0016CD3C
		public byte[] method_2()
		{
			byte[] array = null;
			uint num = this.popInt();
			byte[] result;
			using (ByteArray byteArray = new ByteArray())
			{
				if (num != 0u)
				{
					this.mBuffer.readBytes(byteArray, 0u, num);
					byteArray.position = 0;
					array = byteArray.Buffer;
				}
				byteArray.Dispose();
				result = array;
			}
			return result;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0016CD9C File Offset: 0x0016CD9C
		public T popProto<T>() where T : ProtoBase, new()
		{
			T t = Activator.CreateInstance<T>();
			t.unmarshall(this.mBuffer);
			return t;
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0016CDC4 File Offset: 0x0016CDC4
		public List<T> popProtoArray<T>() where T : ProtoBase, new()
		{
			uint num = this.popInt();
			List<T> list = new List<T>();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				list[(int)num2] = this.popProto<T>();
			}
			return list;
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0016CDF8 File Offset: 0x0016CDF8
		public void pushHashMapKSVS(MYHashMap _arg1)
		{
			uint num = (uint)_arg1.size();
			this.pushInt(num);
			List<string> list = _arg1.keys();
			List<object> list2 = _arg1.values();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				this.pushShort((uint)Convert.ToInt32(list[(int)num2]));
				this.pushBytes((byte[])list2[(int)num2]);
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0016CE54 File Offset: 0x0016CE54
		public MYHashMap popHashMapKSVS()
		{
			MYHashMap myhashMap = new MYHashMap();
			uint num = this.popInt();
			for (uint num2 = 0u; num2 < num; num2 += 1u)
			{
				myhashMap.put(this.popShort().ToString(), this.popBytes());
			}
			return myhashMap;
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x00159AE8 File Offset: 0x00159AE8
		public ProtoBase()
		{
			this.mRes = 200u;
		}

		// Token: 0x0400031F RID: 799
		protected ByteArray mBuffer;

		// Token: 0x04000320 RID: 800
		protected uint mUri;

		// Token: 0x04000321 RID: 801
		protected uint mRes;
	}
}
