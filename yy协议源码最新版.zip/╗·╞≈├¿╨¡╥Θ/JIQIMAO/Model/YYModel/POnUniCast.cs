﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000062 RID: 98
	public class POnUniCast : ProtoBase
	{
		// Token: 0x06000397 RID: 919 RVA: 0x0015990E File Offset: 0x0015990E
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.type = base.popInt();
			this.topSid = base.popInt();
			this.msg = base.method_2();
		}

		// Token: 0x04000312 RID: 786
		public const uint LOGIN = 0u;

		// Token: 0x04000313 RID: 787
		public const uint SESSION = 1u;

		// Token: 0x04000314 RID: 788
		public uint type;

		// Token: 0x04000315 RID: 789
		public uint topSid;

		// Token: 0x04000316 RID: 790
		public byte[] msg;
	}
}
