﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000061 RID: 97
	public class POnlineUser : ProtoBase
	{
		// Token: 0x06000395 RID: 917 RVA: 0x001598ED File Offset: 0x001598ED
		public override void unmarshall(ByteArray _arg1)
		{
			base.unmarshall(_arg1);
			this.IntProp_t = base.popHashMapKBVI();
			this.StrProp_t = base.popHashMapKBVS();
		}

		// Token: 0x04000310 RID: 784
		public MYHashMap IntProp_t;

		// Token: 0x04000311 RID: 785
		public MYHashMap StrProp_t;
	}
}
