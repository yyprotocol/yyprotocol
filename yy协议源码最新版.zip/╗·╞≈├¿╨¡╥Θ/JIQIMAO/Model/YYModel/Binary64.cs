﻿using System;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x02000036 RID: 54
	public class Binary64
	{
		// Token: 0x0600031B RID: 795 RVA: 0x001591C0 File Offset: 0x001591C0
		public Binary64(uint _arg1 = 0u, uint _arg2 = 0u)
		{
			this.low = _arg1;
			this.internalHigh = _arg2;
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0016BAC4 File Offset: 0x0016BAC4
		protected uint div(uint _arg1)
		{
			uint num = this.internalHigh % _arg1;
			uint result = (this.low % 10u + num * 6u) % 10u;
			this.internalHigh /= _arg1;
			double num2 = (num * 4294967296.0 + this.low) / _arg1;
			this.internalHigh = (uint)(this.internalHigh + num2 / 4294967296.0);
			this.low = (uint)num2;
			return result;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0016BB38 File Offset: 0x0016BB38
		protected void mul(uint _arg1)
		{
			double num = this.low * _arg1;
			this.internalHigh = (uint)(num / 4294967296.0 + this.internalHigh * _arg1);
			this.low = (uint)num;
		}

		// Token: 0x0600031E RID: 798 RVA: 0x0016BB7C File Offset: 0x0016BB7C
		protected void add(uint _arg1)
		{
			double num = this.low + _arg1;
			this.internalHigh = (uint)(num / 4294967296.0 + this.internalHigh);
			this.low = (uint)num;
		}

		// Token: 0x0600031F RID: 799 RVA: 0x001591D6 File Offset: 0x001591D6
		protected void bitwiseNot()
		{
			this.low = ~this.low;
			this.internalHigh = ~this.internalHigh;
		}

		// Token: 0x04000253 RID: 595
		public uint low;

		// Token: 0x04000254 RID: 596
		public uint internalHigh;
	}
}
