﻿using System;
using JIQIMAO.Common;

namespace JIQIMAO.Model.YYModel
{
	// Token: 0x0200005F RID: 95
	public class PLeaveChannelReq : ProtoBase
	{
		// Token: 0x06000391 RID: 913 RVA: 0x001598A5 File Offset: 0x001598A5
		public override void marshall(ByteArray _arg1)
		{
			base.marshall(_arg1);
			base.setUri(2049794u);
			base.pushInt(this.uid);
			base.pushInt(this.topsid);
		}

		// Token: 0x0400030E RID: 782
		public uint uid;

		// Token: 0x0400030F RID: 783
		public uint topsid;
	}
}
