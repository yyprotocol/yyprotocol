﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x0200002C RID: 44
	public class ProxyInfo
	{
		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x060002E8 RID: 744 RVA: 0x00158FE9 File Offset: 0x00158FE9
		// (set) Token: 0x060002E9 RID: 745 RVA: 0x00158FF1 File Offset: 0x00158FF1
		public int Id { get; set; }

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x060002EA RID: 746 RVA: 0x00158FFA File Offset: 0x00158FFA
		// (set) Token: 0x060002EB RID: 747 RVA: 0x00159002 File Offset: 0x00159002
		public string MacCode { get; set; }

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060002EC RID: 748 RVA: 0x0015900B File Offset: 0x0015900B
		// (set) Token: 0x060002ED RID: 749 RVA: 0x00159013 File Offset: 0x00159013
		public string WebProxy { get; set; }

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060002EE RID: 750 RVA: 0x0015901C File Offset: 0x0015901C
		// (set) Token: 0x060002EF RID: 751 RVA: 0x00159024 File Offset: 0x00159024
		public string SocketProxy { get; set; }

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x0015902D File Offset: 0x0015902D
		// (set) Token: 0x060002F1 RID: 753 RVA: 0x00159035 File Offset: 0x00159035
		public int CreateTime1 { get; set; }

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060002F2 RID: 754 RVA: 0x0015903E File Offset: 0x0015903E
		// (set) Token: 0x060002F3 RID: 755 RVA: 0x00159046 File Offset: 0x00159046
		public int CreateTime2 { get; set; }

		// Token: 0x040001F3 RID: 499
		[CompilerGenerated]
		private int int_0;

		// Token: 0x040001F4 RID: 500
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040001F5 RID: 501
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040001F6 RID: 502
		[CompilerGenerated]
		private string string_2;

		// Token: 0x040001F7 RID: 503
		[CompilerGenerated]
		private int int_1;

		// Token: 0x040001F8 RID: 504
		[CompilerGenerated]
		private int int_2;
	}
}
