﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000013 RID: 19
	public class msgbyte
	{
		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600007A RID: 122 RVA: 0x00158350 File Offset: 0x00158350
		// (set) Token: 0x0600007B RID: 123 RVA: 0x00158358 File Offset: 0x00158358
		public int code { get; set; }

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600007C RID: 124 RVA: 0x00158361 File Offset: 0x00158361
		// (set) Token: 0x0600007D RID: 125 RVA: 0x00158369 File Offset: 0x00158369
		public byte[] val { get; set; }

		// Token: 0x04000058 RID: 88
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000059 RID: 89
		[CompilerGenerated]
		private byte[] byte_0;
	}
}
