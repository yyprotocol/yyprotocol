﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000007 RID: 7
	public class c_Data
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000022 RID: 34 RVA: 0x00158153 File Offset: 0x00158153
		// (set) Token: 0x06000023 RID: 35 RVA: 0x0015815B File Offset: 0x0015815B
		public byte[] Data { get; set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000024 RID: 36 RVA: 0x00158164 File Offset: 0x00158164
		// (set) Token: 0x06000025 RID: 37 RVA: 0x0015816C File Offset: 0x0015816C
		public byte[] Data1 { get; set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00158175 File Offset: 0x00158175
		// (set) Token: 0x06000027 RID: 39 RVA: 0x0015817D File Offset: 0x0015817D
		public int intd { get; set; }

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000028 RID: 40 RVA: 0x00158186 File Offset: 0x00158186
		// (set) Token: 0x06000029 RID: 41 RVA: 0x0015818E File Offset: 0x0015818E
		public string str { get; set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00158197 File Offset: 0x00158197
		// (set) Token: 0x0600002B RID: 43 RVA: 0x0015819F File Offset: 0x0015819F
		public int Len { get; set; }

		// Token: 0x04000017 RID: 23
		[CompilerGenerated]
		private byte[] byte_0;

		// Token: 0x04000018 RID: 24
		[CompilerGenerated]
		private byte[] byte_1;

		// Token: 0x04000019 RID: 25
		[CompilerGenerated]
		private int int_0;

		// Token: 0x0400001A RID: 26
		[CompilerGenerated]
		private string string_0;

		// Token: 0x0400001B RID: 27
		[CompilerGenerated]
		private int int_1;
	}
}
