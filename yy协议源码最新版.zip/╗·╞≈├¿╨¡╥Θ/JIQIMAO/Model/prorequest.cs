﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x0200002B RID: 43
	public class prorequest
	{
		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x060002E3 RID: 739 RVA: 0x00158FC7 File Offset: 0x00158FC7
		// (set) Token: 0x060002E4 RID: 740 RVA: 0x00158FCF File Offset: 0x00158FCF
		public string sid { get; set; }

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x060002E5 RID: 741 RVA: 0x00158FD8 File Offset: 0x00158FD8
		// (set) Token: 0x060002E6 RID: 742 RVA: 0x00158FE0 File Offset: 0x00158FE0
		public string subid { get; set; }

		// Token: 0x040001EF RID: 495
		[CompilerGenerated]
		private string string_0;

		// Token: 0x040001F0 RID: 496
		[CompilerGenerated]
		private string string_1;
	}
}
