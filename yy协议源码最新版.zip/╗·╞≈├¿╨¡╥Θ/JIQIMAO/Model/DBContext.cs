﻿using System;
using System.Windows.Forms;
using FluentData;

namespace JIQIMAO.Model
{
	// Token: 0x02000008 RID: 8
	public class DBContext
	{
		// Token: 0x0600002D RID: 45 RVA: 0x0015A9E8 File Offset: 0x0015A9E8
		public static IDbContext GetContext()
		{
			IDbContext result;
			try
			{
				string text = string.Format("Data Source=C:\\Users\\manager\\Desktop\\testsl\\JIQIMAO.db;Pooling=true;FailIfMissing=false", Application.StartupPath);
				result = new DbContext().ConnectionString(text, new SqliteProvider(), null);
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return result;
		}
	}
}
