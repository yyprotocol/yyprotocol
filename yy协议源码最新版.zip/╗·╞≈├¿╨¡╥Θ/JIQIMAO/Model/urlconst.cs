﻿using System;

namespace JIQIMAO.Model
{
	// Token: 0x0200002F RID: 47
	public class urlconst
	{
		// Token: 0x04000201 RID: 513
		public const string authserver = "http://118.89.226.148:7788";
	}
}
