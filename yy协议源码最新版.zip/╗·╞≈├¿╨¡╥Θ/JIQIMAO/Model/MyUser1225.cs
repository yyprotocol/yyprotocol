﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Timers;
using JIQIMAO.Common;
using JIQIMAO.Model.YYModel;
using Newtonsoft.Json;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x02000024 RID: 36
	public class MyUser1225
	{
		// Token: 0x17000092 RID: 146
		// (get) Token: 0x0600020B RID: 523 RVA: 0x00158B4E File Offset: 0x00158B4E
		// (set) Token: 0x0600020C RID: 524 RVA: 0x00158B56 File Offset: 0x00158B56
		public int index { get; set; }

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x0600020D RID: 525 RVA: 0x00158B5F File Offset: 0x00158B5F
		// (set) Token: 0x0600020E RID: 526 RVA: 0x00158B67 File Offset: 0x00158B67
		public string passport { get; set; }

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x0600020F RID: 527 RVA: 0x00158B70 File Offset: 0x00158B70
		// (set) Token: 0x06000210 RID: 528 RVA: 0x00158B78 File Offset: 0x00158B78
		public string pwd { get; set; }

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000211 RID: 529 RVA: 0x00158B81 File Offset: 0x00158B81
		// (set) Token: 0x06000212 RID: 530 RVA: 0x00158B89 File Offset: 0x00158B89
		public string pwden { get; set; }

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000213 RID: 531 RVA: 0x00158B92 File Offset: 0x00158B92
		// (set) Token: 0x06000214 RID: 532 RVA: 0x00158B9A File Offset: 0x00158B9A
		public int logintype { get; set; }

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000215 RID: 533 RVA: 0x00158BA3 File Offset: 0x00158BA3
		// (set) Token: 0x06000216 RID: 534 RVA: 0x00158BAB File Offset: 0x00158BAB
		public bool isfenghao { get; set; }

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000217 RID: 535 RVA: 0x00158BB4 File Offset: 0x00158BB4
		// (set) Token: 0x06000218 RID: 536 RVA: 0x00158BBC File Offset: 0x00158BBC
		public int loginstatus { get; set; }

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000219 RID: 537 RVA: 0x00158BC5 File Offset: 0x00158BC5
		// (set) Token: 0x0600021A RID: 538 RVA: 0x00158BCD File Offset: 0x00158BCD
		public int joinstatus { get; set; }

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x0600021B RID: 539 RVA: 0x00158BD6 File Offset: 0x00158BD6
		// (set) Token: 0x0600021C RID: 540 RVA: 0x00158BDE File Offset: 0x00158BDE
		public int status { get; set; }

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x0600021D RID: 541 RVA: 0x00163ECC File Offset: 0x00163ECC
		public string statusstr
		{
			get
			{
				if (this.isfenghao)
				{
					if (this.status != 33)
					{
						return "账号被封";
					}
					if (this.mytrace.Contains("MMCW"))
					{
						return "密码错误";
					}
					return "频道不存在";
				}
				else
				{
					if (this.status == 0)
					{
						return "";
					}
					if (this.status == 2)
					{
						if (this.mytrace.Contains("SUC"))
						{
							return "已进频道";
						}
						if (this.mytrace.Contains("登录成功"))
						{
							return "已进频道";
						}
						if (this.mytrace.Contains("切换频道"))
						{
							return "切换频道";
						}
					}
					if (this.status != 1)
					{
						return "";
					}
					if (this.mytrace.Contains("mima"))
					{
						return "无法进入";
					}
					if (this.mytrace.Contains("UF"))
					{
						return "登录频繁";
					}
					if (this.mytrace.Contains("tuichu"))
					{
						return "退出频道";
					}
					return "正在登陆";
				}
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x0600021E RID: 542 RVA: 0x00158BE7 File Offset: 0x00158BE7
		// (set) Token: 0x0600021F RID: 543 RVA: 0x00158BEF File Offset: 0x00158BEF
		public uint uid { get; set; }

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000220 RID: 544 RVA: 0x00158BF8 File Offset: 0x00158BF8
		// (set) Token: 0x06000221 RID: 545 RVA: 0x00158C00 File Offset: 0x00158C00
		public string username { get; set; }

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000222 RID: 546 RVA: 0x00158C09 File Offset: 0x00158C09
		// (set) Token: 0x06000223 RID: 547 RVA: 0x00158C11 File Offset: 0x00158C11
		public string qianming { get; set; }

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000224 RID: 548 RVA: 0x00158C1A File Offset: 0x00158C1A
		// (set) Token: 0x06000225 RID: 549 RVA: 0x00158C22 File Offset: 0x00158C22
		public uint sid { get; set; }

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000226 RID: 550 RVA: 0x00158C2B File Offset: 0x00158C2B
		// (set) Token: 0x06000227 RID: 551 RVA: 0x00158C33 File Offset: 0x00158C33
		public uint sid_l { get; set; }

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000228 RID: 552 RVA: 0x00158C3C File Offset: 0x00158C3C
		// (set) Token: 0x06000229 RID: 553 RVA: 0x00158C44 File Offset: 0x00158C44
		public uint subid { get; set; }

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x0600022A RID: 554 RVA: 0x00158C4D File Offset: 0x00158C4D
		// (set) Token: 0x0600022B RID: 555 RVA: 0x00158C55 File Offset: 0x00158C55
		public uint sidnew { get; set; }

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x0600022C RID: 556 RVA: 0x00158C5E File Offset: 0x00158C5E
		// (set) Token: 0x0600022D RID: 557 RVA: 0x00158C66 File Offset: 0x00158C66
		public uint subidnew { get; set; }

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x0600022E RID: 558 RVA: 0x00158C6F File Offset: 0x00158C6F
		// (set) Token: 0x0600022F RID: 559 RVA: 0x00158C77 File Offset: 0x00158C77
		public string nicheng { get; set; }

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000230 RID: 560 RVA: 0x00158C80 File Offset: 0x00158C80
		// (set) Token: 0x06000231 RID: 561 RVA: 0x00158C88 File Offset: 0x00158C88
		public string jifen { get; set; }

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06000232 RID: 562 RVA: 0x00158C91 File Offset: 0x00158C91
		// (set) Token: 0x06000233 RID: 563 RVA: 0x00158C99 File Offset: 0x00158C99
		public MyTcp1225 logintcp { get; set; }

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000234 RID: 564 RVA: 0x00158CA2 File Offset: 0x00158CA2
		// (set) Token: 0x06000235 RID: 565 RVA: 0x00158CAA File Offset: 0x00158CAA
		public string apip { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000236 RID: 566 RVA: 0x00158CB3 File Offset: 0x00158CB3
		// (set) Token: 0x06000237 RID: 567 RVA: 0x00158CBB File Offset: 0x00158CBB
		public int apport { get; set; }

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000238 RID: 568 RVA: 0x00158CC4 File Offset: 0x00158CC4
		// (set) Token: 0x06000239 RID: 569 RVA: 0x00158CCC File Offset: 0x00158CCC
		public int heartbeat { get; set; }

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x0600023A RID: 570 RVA: 0x00158CD5 File Offset: 0x00158CD5
		// (set) Token: 0x0600023B RID: 571 RVA: 0x00158CDD File Offset: 0x00158CDD
		public ProxyTypes pt { get; set; }

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600023C RID: 572 RVA: 0x00158CE6 File Offset: 0x00158CE6
		// (set) Token: 0x0600023D RID: 573 RVA: 0x00158CEE File Offset: 0x00158CEE
		public string daili { get; set; }

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600023E RID: 574 RVA: 0x00163FCC File Offset: 0x00163FCC
		public string dailistr
		{
			get
			{
				string result;
				try
				{
					if (this.status < 3)
					{
						if (!this.ishidedaili)
						{
							if (this.pt == ProxyTypes.None)
							{
								if (this.logintcp == null)
								{
									result = "";
								}
								else
								{
									ProxySocket clientSocket = this.logintcp.clientSocket;
									object obj;
									if (clientSocket == null)
									{
										obj = null;
									}
									else
									{
										EndPoint localEndPoint = clientSocket.LocalEndPoint;
										obj = ((localEndPoint != null) ? localEndPoint.ToString() : null);
									}
									result = (((string)obj) ?? "");
								}
							}
							else if (this.logintcp == null)
							{
								result = "";
							}
							else
							{
								ProxySocket clientSocket2 = this.logintcp.clientSocket;
								object obj2;
								if (clientSocket2 == null)
								{
									obj2 = null;
								}
								else
								{
									IPEndPoint proxyEndPoint = clientSocket2.ProxyEndPoint;
									obj2 = ((proxyEndPoint != null) ? proxyEndPoint.ToString() : null);
								}
								result = (((string)obj2) ?? "");
							}
						}
						else if (this.pt == ProxyTypes.None)
						{
							if (this.logintcp == null)
							{
								result = "";
							}
							else
							{
								ProxySocket clientSocket3 = this.logintcp.clientSocket;
								object obj3;
								if (clientSocket3 == null)
								{
									obj3 = null;
								}
								else
								{
									EndPoint localEndPoint2 = clientSocket3.LocalEndPoint;
									obj3 = ((localEndPoint2 != null) ? localEndPoint2.ToString() : null);
								}
								result = (((string)obj3) ?? "");
							}
						}
						else
						{
							result = "";
						}
					}
					else
					{
						result = "";
					}
				}
				catch
				{
					result = "...";
				}
				return result;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x0600023F RID: 575 RVA: 0x00158CF7 File Offset: 0x00158CF7
		// (set) Token: 0x06000240 RID: 576 RVA: 0x00158CFF File Offset: 0x00158CFF
		public string yanzhengma { get; set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000241 RID: 577 RVA: 0x00158D08 File Offset: 0x00158D08
		// (set) Token: 0x06000242 RID: 578 RVA: 0x00158D10 File Offset: 0x00158D10
		public int currentflag { get; set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000243 RID: 579 RVA: 0x00158D19 File Offset: 0x00158D19
		// (set) Token: 0x06000244 RID: 580 RVA: 0x00158D21 File Offset: 0x00158D21
		public bool isudblogin { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000245 RID: 581 RVA: 0x00158D2A File Offset: 0x00158D2A
		// (set) Token: 0x06000246 RID: 582 RVA: 0x00158D32 File Offset: 0x00158D32
		public byte[] yycookie { get; set; }

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000247 RID: 583 RVA: 0x00158D3B File Offset: 0x00158D3B
		// (set) Token: 0x06000248 RID: 584 RVA: 0x00164134 File Offset: 0x00164134
		public string mytrace
		{
			get
			{
				return this.string_9;
			}
			set
			{
				this.string_9 = (this.isudblogin ? "2-" : "") + value + "-" + DateTime.Now.ToString("HHmmss");
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000249 RID: 585 RVA: 0x00158D43 File Offset: 0x00158D43
		// (set) Token: 0x0600024A RID: 586 RVA: 0x00158D4B File Offset: 0x00158D4B
		public DateTime lastsendtime { get; set; }

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x0600024B RID: 587 RVA: 0x00158D54 File Offset: 0x00158D54
		// (set) Token: 0x0600024C RID: 588 RVA: 0x00158D5C File Offset: 0x00158D5C
		public DateTime lastrecivetime { get; set; }

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600024D RID: 589 RVA: 0x00158D65 File Offset: 0x00158D65
		// (set) Token: 0x0600024E RID: 590 RVA: 0x00158D6D File Offset: 0x00158D6D
		public DateTime lastonlinetime { get; set; }

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600024F RID: 591 RVA: 0x00158D76 File Offset: 0x00158D76
		// (set) Token: 0x06000250 RID: 592 RVA: 0x00158D7E File Offset: 0x00158D7E
		public DateTime jointime { get; set; }

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000251 RID: 593 RVA: 0x00158D87 File Offset: 0x00158D87
		// (set) Token: 0x06000252 RID: 594 RVA: 0x00158D8F File Offset: 0x00158D8F
		public DateTime startlogintime { get; set; }

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000253 RID: 595 RVA: 0x00164178 File Offset: 0x00164178
		public string lol
		{
			get
			{
				if (this.lastonlinetime == DateTime.MinValue)
				{
					return "";
				}
				return this.lastonlinetime.ToString("HHmm");
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000254 RID: 596 RVA: 0x00158D98 File Offset: 0x00158D98
		// (set) Token: 0x06000255 RID: 597 RVA: 0x00158DA0 File Offset: 0x00158DA0
		public string localip { get; set; }

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000256 RID: 598 RVA: 0x00158DA9 File Offset: 0x00158DA9
		// (set) Token: 0x06000257 RID: 599 RVA: 0x00158DB1 File Offset: 0x00158DB1
		public int renzhenshibai { get; set; }

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000258 RID: 600 RVA: 0x00158DBA File Offset: 0x00158DBA
		// (set) Token: 0x06000259 RID: 601 RVA: 0x00158DC2 File Offset: 0x00158DC2
		public bool isskip { get; set; }

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x0600025A RID: 602 RVA: 0x00158DCB File Offset: 0x00158DCB
		// (set) Token: 0x0600025B RID: 603 RVA: 0x00158DD3 File Offset: 0x00158DD3
		public bool istuichu { get; set; }

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x0600025C RID: 604 RVA: 0x00158DDC File Offset: 0x00158DDC
		// (set) Token: 0x0600025D RID: 605 RVA: 0x00158DE4 File Offset: 0x00158DE4
		public bool isupdate { get; set; }

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600025E RID: 606 RVA: 0x00158DED File Offset: 0x00158DED
		// (set) Token: 0x0600025F RID: 607 RVA: 0x00158DF5 File Offset: 0x00158DF5
		public string autotoken { get; set; }

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x06000260 RID: 608 RVA: 0x00158DFE File Offset: 0x00158DFE
		// (set) Token: 0x06000261 RID: 609 RVA: 0x00158E06 File Offset: 0x00158E06
		public bool isyongji { get; set; }

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000262 RID: 610 RVA: 0x00158E0F File Offset: 0x00158E0F
		// (set) Token: 0x06000263 RID: 611 RVA: 0x00158E17 File Offset: 0x00158E17
		public string pcinfo { get; set; }

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000264 RID: 612 RVA: 0x00158E20 File Offset: 0x00158E20
		// (set) Token: 0x06000265 RID: 613 RVA: 0x00158E28 File Offset: 0x00158E28
		public bool ishidedaili { get; set; }

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000266 RID: 614 RVA: 0x00158E31 File Offset: 0x00158E31
		// (set) Token: 0x06000267 RID: 615 RVA: 0x00158E39 File Offset: 0x00158E39
		public bool xiugaisuiji { get; set; }

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000268 RID: 616 RVA: 0x00158E42 File Offset: 0x00158E42
		// (set) Token: 0x06000269 RID: 617 RVA: 0x00158E4A File Offset: 0x00158E4A
		public int yongjitimes { get; set; }

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x0600026A RID: 618 RVA: 0x00158E53 File Offset: 0x00158E53
		// (set) Token: 0x0600026B RID: 619 RVA: 0x00158E5B File Offset: 0x00158E5B
		public DateTime tihaotime { get; set; }

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x0600026C RID: 620 RVA: 0x00158E64 File Offset: 0x00158E64
		// (set) Token: 0x0600026D RID: 621 RVA: 0x00158E6C File Offset: 0x00158E6C
		public bool ishunhejin { get; set; }

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600026E RID: 622 RVA: 0x00158E75 File Offset: 0x00158E75
		// (set) Token: 0x0600026F RID: 623 RVA: 0x00158E7D File Offset: 0x00158E7D
		public List<duoip> listduoip { get; set; }

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x06000270 RID: 624 RVA: 0x00158E86 File Offset: 0x00158E86
		// (set) Token: 0x06000271 RID: 625 RVA: 0x00158E8E File Offset: 0x00158E8E
		public int tihaocishu { get; set; }

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000272 RID: 626 RVA: 0x00158E97 File Offset: 0x00158E97
		// (set) Token: 0x06000273 RID: 627 RVA: 0x00158E9F File Offset: 0x00158E9F
		public bool isgongneng { get; set; }

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000274 RID: 628 RVA: 0x00158EA8 File Offset: 0x00158EA8
		// (set) Token: 0x06000275 RID: 629 RVA: 0x00158EB0 File Offset: 0x00158EB0
		public MyTcp1225 servicetcp { get; set; }

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000276 RID: 630 RVA: 0x00158EB9 File Offset: 0x00158EB9
		// (set) Token: 0x06000277 RID: 631 RVA: 0x00158EC1 File Offset: 0x00158EC1
		public bool isxianche { get; set; }

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000278 RID: 632 RVA: 0x00158ECA File Offset: 0x00158ECA
		// (set) Token: 0x06000279 RID: 633 RVA: 0x00158ED2 File Offset: 0x00158ED2
		public bool isxianchewancheng { get; set; }

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00158EDB File Offset: 0x00158EDB
		// (set) Token: 0x0600027B RID: 635 RVA: 0x00158EE3 File Offset: 0x00158EE3
		public bool isqutubiao { get; set; }

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x0600027C RID: 636 RVA: 0x00158EEC File Offset: 0x00158EEC
		// (set) Token: 0x0600027D RID: 637 RVA: 0x00158EF4 File Offset: 0x00158EF4
		public bool isloginservice { get; set; }

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600027E RID: 638 RVA: 0x00158EFD File Offset: 0x00158EFD
		// (set) Token: 0x0600027F RID: 639 RVA: 0x00158F05 File Offset: 0x00158F05
		public string serviceip { get; set; }

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x06000280 RID: 640 RVA: 0x00158F0E File Offset: 0x00158F0E
		// (set) Token: 0x06000281 RID: 641 RVA: 0x00158F16 File Offset: 0x00158F16
		public int serviceport { get; set; }

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000282 RID: 642 RVA: 0x00158F1F File Offset: 0x00158F1F
		// (set) Token: 0x06000283 RID: 643 RVA: 0x00158F27 File Offset: 0x00158F27
		public DateTime startconnectservice { get; set; }

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000284 RID: 644 RVA: 0x00158F30 File Offset: 0x00158F30
		// (set) Token: 0x06000285 RID: 645 RVA: 0x00158F37 File Offset: 0x00158F37
		public static bool zidongbuhao { get; internal set; }

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x06000286 RID: 646 RVA: 0x001641B0 File Offset: 0x001641B0
		// (remove) Token: 0x06000287 RID: 647 RVA: 0x001641E8 File Offset: 0x001641E8
		public event MyUser1225.OnYongJi YongJiEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser1225.OnYongJi onYongJi = this.onYongJi_0;
				MyUser1225.OnYongJi onYongJi2;
				do
				{
					onYongJi2 = onYongJi;
					MyUser1225.OnYongJi value2 = (MyUser1225.OnYongJi)Delegate.Combine(onYongJi2, value);
					onYongJi = Interlocked.CompareExchange<MyUser1225.OnYongJi>(ref this.onYongJi_0, value2, onYongJi2);
				}
				while (onYongJi != onYongJi2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser1225.OnYongJi onYongJi = this.onYongJi_0;
				MyUser1225.OnYongJi onYongJi2;
				do
				{
					onYongJi2 = onYongJi;
					MyUser1225.OnYongJi value2 = (MyUser1225.OnYongJi)Delegate.Remove(onYongJi2, value);
					onYongJi = Interlocked.CompareExchange<MyUser1225.OnYongJi>(ref this.onYongJi_0, value2, onYongJi2);
				}
				while (onYongJi != onYongJi2);
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x06000288 RID: 648 RVA: 0x00164220 File Offset: 0x00164220
		// (remove) Token: 0x06000289 RID: 649 RVA: 0x00164258 File Offset: 0x00164258
		public event MyUser1225.OnGetUserCount GetUserCountEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser1225.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser1225.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser1225.OnGetUserCount value2 = (MyUser1225.OnGetUserCount)Delegate.Combine(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser1225.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser1225.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser1225.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser1225.OnGetUserCount value2 = (MyUser1225.OnGetUserCount)Delegate.Remove(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser1225.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
		}

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x0600028A RID: 650 RVA: 0x00164290 File Offset: 0x00164290
		// (remove) Token: 0x0600028B RID: 651 RVA: 0x001642C8 File Offset: 0x001642C8
		public event MyUser1225.OnGetUserList GetUserListEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser1225.OnGetUserList onGetUserList = this.onGetUserList_0;
				MyUser1225.OnGetUserList onGetUserList2;
				do
				{
					onGetUserList2 = onGetUserList;
					MyUser1225.OnGetUserList value2 = (MyUser1225.OnGetUserList)Delegate.Combine(onGetUserList2, value);
					onGetUserList = Interlocked.CompareExchange<MyUser1225.OnGetUserList>(ref this.onGetUserList_0, value2, onGetUserList2);
				}
				while (onGetUserList != onGetUserList2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser1225.OnGetUserList onGetUserList = this.onGetUserList_0;
				MyUser1225.OnGetUserList onGetUserList2;
				do
				{
					onGetUserList2 = onGetUserList;
					MyUser1225.OnGetUserList value2 = (MyUser1225.OnGetUserList)Delegate.Remove(onGetUserList2, value);
					onGetUserList = Interlocked.CompareExchange<MyUser1225.OnGetUserList>(ref this.onGetUserList_0, value2, onGetUserList2);
				}
				while (onGetUserList != onGetUserList2);
			}
		}

		// Token: 0x0600028C RID: 652 RVA: 0x00158F3F File Offset: 0x00158F3F
		[CompilerGenerated]
		private DateTime method_0()
		{
			return this.dateTime_5;
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00158F47 File Offset: 0x00158F47
		[CompilerGenerated]
		private void method_1(DateTime value)
		{
			this.dateTime_5 = value;
		}

		// Token: 0x0600028E RID: 654 RVA: 0x00164300 File Offset: 0x00164300
		public MyUser1225()
		{
			this.string_9 = "";
			this.int_12 = 600;
			DateTime lastsendtime = this.lastrecivetime = DateTime.MinValue;
			DateTime lastonlinetime = this.lastsendtime = lastsendtime;
			DateTime jointime = this.lastonlinetime = lastonlinetime;
			DateTime startconnectservice = this.jointime = jointime;
			this.tihaotime = (this.startconnectservice = startconnectservice);
			this.apip = (this.daili = "");
			this.isgongneng = false;
			this.localip = "";
			this.renzhenshibai = 0;
			this.isupdate = false;
			this.isyongji = false;
			this.pcinfo = Guid.NewGuid().ToString("N").ToUpper();
			this.autotoken = "";
			this.ishidedaili = false;
			this.xiugaisuiji = false;
			this.yongjitimes = 0;
			this.method_1(DateTime.MinValue);
			this.isxianchewancheng = false;
			this.ishunhejin = false;
			this.listduoip = new List<duoip>();
			this.tihaocishu = 0;
		}

		// Token: 0x0600028F RID: 655 RVA: 0x0016441C File Offset: 0x0016441C
		private string method_2(int int_16)
		{
			string result;
			try
			{
				result = Guid.NewGuid().ToString("N").Substring(0, int_16);
			}
			catch
			{
				result = "140915bbef";
			}
			return result;
		}

		// Token: 0x06000290 RID: 656 RVA: 0x00164460 File Offset: 0x00164460
		public void StartJoin()
		{
			if (this.logintcp != null)
			{
				try
				{
					this.logintcp.SendEvent -= this.method_5;
					this.logintcp.ReciveEvent -= this.method_4;
					this.logintcp.CloseConEvent -= this.method_6;
					this.logintcp.ConEvent -= this.method_3;
				}
				catch
				{
				}
				try
				{
					this.logintcp.Dispose();
					this.logintcp = null;
				}
				catch
				{
				}
			}
			this.isxianchewancheng = false;
			this.istuichu = false;
			this.isskip = false;
			this.status = 1;
			this.joinstatus = 1;
			this.tihaotime = DateTime.MinValue;
			this.method_1(DateTime.MinValue);
			if (this.isgongneng)
			{
				if ((this.logintype == 1 && this.isudblogin) || this.logintype == 2)
				{
					this.pt = ProxyTypes.None;
					this.daili = "";
				}
			}
			else if (((this.logintype == 1 && this.isudblogin) || this.logintype == 2) && !this.isyongji)
			{
				this.pt = ProxyTypes.None;
				this.daili = "";
			}
			this.mytrace = "S-J";
			this.int_15 = 0;
			try
			{
				this.logintcp = new MyTcp1225(this.apip, this.apport, this.pt, this.daili, this.localip);
				this.logintcp.SendEvent += this.method_5;
				this.logintcp.ReciveEvent += this.method_4;
				this.logintcp.CloseConEvent += this.method_6;
				this.logintcp.ConEvent += this.method_3;
				this.logintcp.Connect();
			}
			catch
			{
				this.mytrace = "CON-ERR";
				this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
				return;
			}
			try
			{
				if (this.timer_0 == null)
				{
					this.timer_0 = new System.Timers.Timer();
					this.timer_0.Interval = 1000.0;
					this.timer_0.Elapsed += this.timer_0_Elapsed;
				}
				this.timer_0.Enabled = true;
				this.timer_0.Start();
			}
			catch
			{
			}
		}

		// Token: 0x06000291 RID: 657 RVA: 0x001646EC File Offset: 0x001646EC
		private void method_3()
		{
			try
			{
				this.int_15 = 0;
				this.method_7();
			}
			catch
			{
			}
		}

		// Token: 0x06000292 RID: 658 RVA: 0x00164720 File Offset: 0x00164720
		public void ZhuDongDK(int js)
		{
			try
			{
				if (this.timer_0 != null)
				{
					this.timer_0.Enabled = false;
					this.timer_0.Stop();
				}
			}
			catch
			{
			}
			try
			{
				this.daili = "";
				this.pt = ProxyTypes.None;
				if (this.status < 3)
				{
					this.status = 1;
				}
				this.joinstatus = js;
				this.heartbeat = 0;
				this.currentflag = 10000;
				this.lastonlinetime = DateTime.MinValue;
				if (this.logintcp != null)
				{
					this.logintcp.SendEvent -= this.method_5;
					this.logintcp.ReciveEvent -= this.method_4;
					this.logintcp.CloseConEvent -= this.method_6;
					this.logintcp.ConEvent -= this.method_3;
					this.logintcp.Dispose();
				}
				this.int_15 = 0;
			}
			catch
			{
			}
			try
			{
				if (this.isgongneng && this.servicetcp != null)
				{
					this.OnCloseConnectEvent_S();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000293 RID: 659 RVA: 0x0016485C File Offset: 0x0016485C
		private void method_4(byte[] byte_3)
		{
			this.lastrecivetime = DateTime.Now;
			try
			{
				if (byte_3 != null && byte_3.Length >= 10 && byte_3[8] == 200)
				{
					string text = bytetool.fromArray(byte_3, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2) && !(text2 == "1E74"))
					{
						if (!(text2 == "0412") && !(text2 == "0415") && !(text2 == "0287") && !(text2 == "0433"))
						{
							if (text2 == "04E5")
							{
								this.method_11(byte_3);
							}
							else if (text2 == "04D7")
							{
								this.method_14(byte_3);
							}
							else
							{
								if (text2 == "0422")
								{
									this.mytrace = "FO";
									int tihaocishu = this.tihaocishu;
									this.tihaocishu = tihaocishu + 1;
									try
									{
										if (this.status == 2)
										{
											this.LeaveChanel();
										}
										this.istuichu = true;
										this.heartbeat = 0;
										this.mytrace = "";
										this.currentflag = 10000;
										this.isudblogin = false;
										if (this.logintcp != null)
										{
											this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
										}
										goto IL_4EB;
									}
									catch
									{
										goto IL_4EB;
									}
								}
								if (text2 == "020C")
								{
									this.mytrace = "YDDL";
									this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
								}
								else
								{
									if (text2 == "0BD0")
									{
										string a;
										string a2;
										try
										{
											a = text.Substring(24, 4).ToUpper();
											a2 = text.Substring(24, 6).ToUpper();
										}
										catch
										{
											return;
										}
										if (a == "1E74")
										{
											this.Recv_Service_1E74(byte_3);
											goto IL_4EB;
										}
										if (a == "0308")
										{
											this.method_15(byte_3);
											goto IL_4EB;
										}
										if (a == "0868")
										{
											this.method_16(byte_3);
											goto IL_4EB;
										}
										if (a == "0242" && a2 == "02421F")
										{
											this.method_18(byte_3);
											goto IL_4EB;
										}
										if (a == "0302")
										{
											this.method_19(byte_3);
											goto IL_4EB;
										}
										if (a2 == "024D1F")
										{
											this.mytrace = "KO-MJK";
											try
											{
												if (this.status == 2)
												{
													this.LeaveChanel();
												}
												this.istuichu = true;
												this.heartbeat = 0;
												this.status = 0;
												this.joinstatus = 0;
												this.mytrace = "";
												this.currentflag = 10000;
												this.isudblogin = false;
												if (this.logintcp != null)
												{
													this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
												}
												goto IL_4EB;
											}
											catch
											{
												goto IL_4EB;
											}
										}
										if (!(a2 == "023501") && !(a2 == "024025") && !(a == "022C"))
										{
											if (a2 == "04220C")
											{
												this.mytrace = "2-KO";
												int tihaocishu = this.tihaocishu;
												this.tihaocishu = tihaocishu + 1;
												this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
												goto IL_4EB;
											}
											if (a == "0239")
											{
												goto IL_4EB;
											}
											if (a == "041F")
											{
												this.method_20(byte_3);
												goto IL_4EB;
											}
											if (a == "02D1")
											{
												this.method_21(byte_3);
												goto IL_4EB;
											}
											if (a == "02B1")
											{
												this.method_22(byte_3);
												goto IL_4EB;
											}
											if (a == "02B3")
											{
												this.lastonlinetime = DateTime.Now;
												goto IL_4EB;
											}
											if (a == "02B5")
											{
												this.method_23(byte_3);
												goto IL_4EB;
											}
											if (!(a == "0253"))
											{
												goto IL_4EB;
											}
											goto IL_4EB;
										}
										else
										{
											this.mytrace = "KO-UB";
											this.tihaotime = DateTime.Now;
											int tihaocishu = this.tihaocishu;
											this.tihaocishu = tihaocishu + 1;
											try
											{
												if (this.status == 2)
												{
													this.LeaveChanel();
												}
												this.istuichu = true;
												this.heartbeat = 0;
												this.status = 0;
												this.joinstatus = 0;
												this.mytrace = "";
												this.currentflag = 10000;
												this.isudblogin = false;
												if (this.logintcp != null)
												{
													this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
												}
												goto IL_4EB;
											}
											catch
											{
												goto IL_4EB;
											}
										}
									}
									if (text2 == "041F")
									{
										this.method_20(byte_3);
									}
									else if (text2 == "024D" || text2 == "0235" || text2 == "0240" || text2 == "020C")
									{
										this.mytrace = "OKO";
									}
								}
							}
						}
						else
						{
							this.method_8(byte_3);
						}
					}
				}
				IL_4EB:;
			}
			catch
			{
			}
		}

		// Token: 0x06000294 RID: 660 RVA: 0x00158048 File Offset: 0x00158048
		private void method_5()
		{
		}

		// Token: 0x06000295 RID: 661 RVA: 0x00164DF0 File Offset: 0x00164DF0
		private void method_6()
		{
			try
			{
				if (this.timer_0 != null)
				{
					this.timer_0.Enabled = false;
					this.timer_0.Stop();
				}
			}
			catch
			{
			}
			try
			{
				this.daili = "";
				this.pt = ProxyTypes.None;
				if (this.status < 3)
				{
					this.status = 1;
				}
				this.joinstatus = ((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
				this.heartbeat = 0;
				this.currentflag = 10000;
				this.lastonlinetime = DateTime.MinValue;
				if (this.logintcp != null)
				{
					this.logintcp.SendEvent -= this.method_5;
					this.logintcp.ReciveEvent -= this.method_4;
					this.logintcp.CloseConEvent -= this.method_6;
					this.logintcp.ConEvent -= this.method_3;
				}
				this.int_15 = 0;
			}
			catch
			{
			}
			try
			{
				if (this.isgongneng && this.servicetcp != null)
				{
					this.OnCloseConnectEvent_S();
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000296 RID: 662 RVA: 0x00164F30 File Offset: 0x00164F30
		private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				this.int_13++;
			}
			catch
			{
			}
			if (Interlocked.Exchange(ref this.int_14, 1) == 0)
			{
				try
				{
					if (this.status < 3)
					{
						if (this.joinstatus == 1)
						{
							this.resend();
						}
						else if (this.joinstatus == 2)
						{
							if (this.sid != 0u)
							{
								if (this.jointime != DateTime.MinValue)
								{
									DateTime jointime = this.jointime;
									if (!MyUser1225.zidongbuhao)
									{
										if (jointime.AddSeconds((double)this.int_12) < DateTime.Now && !this.isskip)
										{
											this.jointime = DateTime.Now;
											this.int_12 = rdomhelper.getrandom(1200, 2000);
											this.Send_0BD0_02411F(false);
										}
									}
									else
									{
										this.jointime = DateTime.Now;
										this.int_12 = rdomhelper.getrandom(1200, 2000);
									}
								}
								if (this.int_13 % 15 == 0)
								{
									this.Send_041E();
									if (this.isgongneng && this.isloginservice)
									{
										this.SendSH();
									}
								}
								if (this.isgongneng && !this.isloginservice && this.startconnectservice != DateTime.MinValue && this.startconnectservice.AddSeconds(23.0) < DateTime.Now)
								{
									this.OnCloseConnectEvent_S();
								}
								else if (this.isxianche && this.isudblogin && !this.isxianchewancheng)
								{
									this.method_28();
								}
							}
							else if (this.int_13 % 15 == 0)
							{
								this.Send_041E();
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref this.int_14, 0);
				}
			}
		}

		// Token: 0x06000297 RID: 663 RVA: 0x00165130 File Offset: 0x00165130
		public void resend()
		{
			try
			{
				if (this.int_15 > 15)
				{
					this.isudblogin = false;
					this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
				}
				else
				{
					if (this.currentflag == 10000)
					{
						this.int_15++;
					}
					if (this.currentflag >= 30001 && this.currentflag < 32000)
					{
						this.int_15++;
					}
					else if (this.lastsendtime != DateTime.MinValue && this.lastsendtime.AddSeconds(3.0) < DateTime.Now)
					{
						this.lastsendtime = DateTime.Now;
						this.int_15++;
						if (this.currentflag >= 20001 && this.currentflag < 21000)
						{
							this.method_7();
						}
						else if (this.currentflag >= 40001 && this.currentflag < 41000)
						{
							this.method_13();
						}
						else if (this.currentflag >= 50001 && this.currentflag < 51000)
						{
							this.Send_0BD0_0307();
						}
						else if (this.currentflag >= 55001 && this.currentflag < 56000)
						{
							this.Send_0BD0_0801();
						}
						else if (this.currentflag >= 60001 && this.currentflag < 61000)
						{
							this.Send_0BD0_02411F(false);
						}
						else if (this.currentflag >= 61001 && this.currentflag < 62000)
						{
							this.Send_0BD0_02411F(true);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000298 RID: 664 RVA: 0x00165308 File Offset: 0x00165308
		private void method_7()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(20001, 21000);
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] sendBuffer = ProtoPacket.pack<PExchangeKeyExt>(new PExchangeKeyExt(publicKey, exponent));
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x0016537C File Offset: 0x0016537C
		private void method_8(byte[] byte_3)
		{
			try
			{
				if (this.currentflag <= 30000)
				{
					byte[] array = null;
					using (ByteArray byteArray = new ByteArray(byte_3))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
						if (num != 0u)
						{
							using (ByteArray byteArray2 = new ByteArray())
							{
								protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
								array = byteArray2.Buffer;
								byteArray2.Dispose();
							}
						}
						byteArray.Dispose();
					}
					if (array == null || array.Length == 0)
					{
						throw new Exception("rsa fail");
					}
					byte[] array2 = rsautil.getInstance().decrypt(array);
					if (array2 == null)
					{
						throw new Exception("DEC");
					}
					this.logintcp.setarc(array2);
					if (this.logintype == 1)
					{
						if (this.isudblogin)
						{
							this.method_13();
						}
						else
						{
							this.method_9(false, null, null);
						}
					}
					else
					{
						this.method_10();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00165498 File Offset: 0x00165498
		private void method_9(bool bool_14 = false, byte[] byte_3 = null, byte[] byte_4 = null)
		{
			try
			{
				if (!bool_14)
				{
					this.currentflag = rdomhelper.getrandom(30001, 31000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(31000, 32000);
				}
				this.mytrace = "S-YZM";
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 1u;
				udbyyloginReq._user = bytetool.String2Bytes(this.passport);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				string s = xxtea2.Encrypt(sha1.hash(this.pwd, Encoding.ASCII).ToLower(), (this.passport + "275d0ff676c0d65114acdefbd2ad87a3").Substring(0, 16));
				udbyyloginReq._user_token = Convert.FromBase64String(s);
				if (bool_14)
				{
					udbyyloginReq._pic_id = byte_3;
					int imageType = 1;
					using (MemoryStream memoryStream = new MemoryStream(byte_4))
					{
						ImageFormat rawFormat = Image.FromStream(memoryStream).RawFormat;
						if (rawFormat.Equals(ImageFormat.Jpeg))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Png))
						{
							imageType = 4;
						}
						else if (rawFormat.Equals(ImageFormat.Bmp))
						{
							imageType = 1;
						}
						else if (rawFormat.Equals(ImageFormat.Gif))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Icon))
						{
							imageType = 5;
						}
					}
					string text = this.yanzhengma = imagetool.CreateInstance().hqCode(byte_4, imageType);
					string s2 = text;
					udbyyloginReq._pic_code = Encoding.UTF8.GetBytes(s2);
				}
				byte[] sendBuffer = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600029B RID: 667 RVA: 0x001656B0 File Offset: 0x001656B0
		private void method_10()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(30001, 31000);
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 9u;
				udbyyloginReq._user = bytetool.String2Bytes(this.username);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				udbyyloginReq._user_token = ProtoPacket.packNoHeader<CombAcctinfo>(new CombAcctinfo
				{
					acctinfo = bytetool.String2Bytes(this.pwden),
					appid_type = bytetool.String2Bytes("yycomscene")
				});
				byte[] sendBuffer = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x0600029C RID: 668 RVA: 0x001657BC File Offset: 0x001657BC
		private void method_11(byte[] byte_3)
		{
			try
			{
				if (this.currentflag <= 40000)
				{
					using (ByteArray byteArray = new ByteArray(byte_3))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_CliAPLoginAuth2Res pcs_CliAPLoginAuth2Res = new PCS_CliAPLoginAuth2Res();
						pcs_CliAPLoginAuth2Res.unmarshall(protoPacket.getBuffer());
						if (pcs_CliAPLoginAuth2Res.rescode != 200u)
						{
							throw new Exception(pcs_CliAPLoginAuth2Res.rescode.ToString());
						}
						protoPacket = ProtoPacket.unpackNoHeader(pcs_CliAPLoginAuth2Res.payLoad, pcs_CliAPLoginAuth2Res.ruri, pcs_CliAPLoginAuth2Res.rescode);
						UDBYYLoginRes udbyyloginRes = new UDBYYLoginRes();
						LoginData loginData = new LoginData();
						udbyyloginRes.unmarshall(protoPacket.getBuffer());
						if (udbyyloginRes._rescode == 18u)
						{
							this.ZhuDongDK(2);
							this.isfenghao = true;
							this.mytrace = "";
							this.status = 3;
						}
						else
						{
							string @string = Encoding.UTF8.GetString(udbyyloginRes._reason);
							if (!(@string.ToLower() == "success"))
							{
								if (@string.ToLower() == "user frozen")
								{
									this.mytrace = "UF";
								}
								else if (!(@string.ToLower() == "static_verify") && !(@string.ToLower() == "invalid piccode"))
								{
									if (@string.Contains("invalid user"))
									{
										this.mytrace = "MMCW";
										this.status = 33;
										this.isfenghao = true;
										this.joinstatus = 0;
									}
									else if (@string.ToLower() == "invalid account info")
									{
										this.mytrace = "IAI";
										if (this.logintype == 2)
										{
											logtool.delusercache_w(this.passport);
											this.ZhuDongDK(-1);
											this.loginstatus = -1;
											this.status = 0;
										}
									}
									else
									{
										this.mytrace = "U-L:" + @string;
									}
								}
								else
								{
									this.mytrace = "YZM";
									this.method_9(true, udbyyloginRes._pic_id, udbyyloginRes._pic_data);
								}
							}
							else
							{
								using (ByteArray byteArray2 = new ByteArray(udbyyloginRes._login_data))
								{
									loginData.unmarshall(byteArray2);
									byteArray2.Dispose();
								}
								this.username = Encoding.UTF8.GetString(loginData._passport);
								this.yycookie = loginData._yycookie;
								this.uid = udbyyloginRes._yyuid.low;
								try
								{
									using (ByteArray byteArray3 = new ByteArray(loginData._ticket))
									{
										byteArray3.readUnsignedInt();
										byteArray3.readUnsignedInt();
										short num = byteArray3.ReadShort();
										this.byte_1 = new byte[(int)num];
										for (int i = 0; i < (int)num; i++)
										{
											this.byte_1[i] = byteArray3.readByte();
										}
										num = byteArray3.ReadShort();
										for (int j = 0; j < (int)num; j++)
										{
											byteArray3.readByte();
										}
										num = byteArray3.ReadShort();
										this.byte_2 = new byte[(int)num];
										for (int k = 0; k < (int)num; k++)
										{
											this.byte_2[k] = byteArray3.readByte();
										}
										num = byteArray3.ReadShort();
										for (int l = 0; l < (int)num; l++)
										{
											byteArray3.readByte();
										}
										num = byteArray3.ReadShort();
										for (int m = 0; m < (int)num; m++)
										{
											byteArray3.readByte();
										}
									}
								}
								catch
								{
								}
								if (this.logintype == 1)
								{
									savepcbuser savepcbuser = new savepcbuser();
									savepcbuser.username = this.username;
									savepcbuser.cookie = Hex.fromArray(new ByteArray(this.yycookie), false);
									savepcbuser.uid = this.uid.ToString();
									try
									{
										string msg = MyEncrypt.AesEncryptor(JsonConvert.SerializeObject(savepcbuser));
										logtool.logusercache_p(this.passport, msg);
									}
									catch
									{
									}
								}
								if (this.logintype == 1 && !this.isudblogin && this.pt != ProxyTypes.None && !this.isyongji)
								{
									this.ZhuDongDK(-1);
									this.isudblogin = true;
									goto IL_3F4;
								}
								this.method_13();
							}
							byteArray.Dispose();
						}
						IL_3F4:;
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x00165C64 File Offset: 0x00165C64
		private byte[] method_12()
		{
			byte[] result;
			try
			{
				c_Data c_Data = new c_Data();
				c_Data c_Data2 = new c_Data();
				c_Data c_Data3 = new c_Data();
				c_Data.Data = this.byte_2;
				c_Data.Len = this.byte_2.Length;
				c_Data3.str = this.username;
				c_Data2.Data = new byte[800];
				c_Data2.Len = krbtool.Out(c_Data.Data, c_Data.Len, c_Data2.Data, this.byte_1, this.byte_1.Length, this.username, sha1.hash(this.pwd, Encoding.ASCII).ToLower(), 8754154);
				result = c_Data2.Data.Take(c_Data2.Len).ToArray<byte>();
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00165D34 File Offset: 0x00165D34
		private void method_13()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(40001, 41000);
				this.send04d6++;
				if (this.logintype == 1 && this.send04d6 >= 50)
				{
					logtool.delusercache_p(this.passport);
					this.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
					this.isudblogin = false;
					this.send04d6 = 0;
				}
				else
				{
					byte[] sendBuffer = (this.logintype != 1) ? ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
					{
						m_strAccount = bytetool.String2Bytes(this.username),
						m_strPassword = bytetool.String2Bytes(this.pwden),
						m_bRelogin = (this.currentflag == 40005),
						m_uAppID = 259u,
						m_uUid = 
						{
							low = Convert.ToUInt32(this.uid)
						},
						m_strCookie = this.yycookie,
						m_uCliType = 2u,
						m_strFrom = bytetool.String2Bytes("yymwebflsh"),
						m_strCliVer = bytetool.String2Bytes("yymwebflsh")
					}) : ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
					{
						m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower()),
						m_bRelogin = false,
						m_uAppID = 259u,
						m_uUid = 
						{
							low = Convert.ToUInt32(this.uid)
						},
						m_strCookie = this.yycookie,
						m_strAccount = Encoding.UTF8.GetBytes(this.username),
						m_uCliType = 2u,
						m_strCliInfo = bytetool.String2Bytes(Guid.NewGuid().ToString("N")),
						m_strFrom = bytetool.String2Bytes("8.45.0.0"),
						m_strCliVer = bytetool.String2Bytes("8.45.0.0")
					});
					this.logintcp.Send(sendBuffer, false);
					this.lastsendtime = DateTime.Now;
					this.mytrace = "A-L-" + this.send04d6.ToString();
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600029F RID: 671 RVA: 0x001C6000 File Offset: 0x001C5E00
		private void method_14(byte[] byte_3)
		{
			try
			{
				if (this.currentflag <= 50000)
				{
					using (ByteArray byteArray = new ByteArray(byte_3))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
						pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
						byteArray.Dispose();
						if (pcs_APLoginRes.m_uResCode != 200u)
						{
							throw new Exception(pcs_APLoginRes.m_uResCode.ToString());
						}
						this.Send_0BD0_02411F(false);
					}
				}
			}
			catch
			{
				int renzhenshibai = this.renzhenshibai;
				this.renzhenshibai = renzhenshibai + 1;
				if (this.logintype == 1 && this.renzhenshibai >= 3)
				{
					logtool.delusercache_p(this.passport);
					this.isudblogin = false;
					this.renzhenshibai = 0;
				}
			}
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00166038 File Offset: 0x00166038
		public void Send_0BD0_0307()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(50001, 51000);
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.method_2(0);
					byteArray.writeUnsignedInt(this.uid);
					byte[] array2 = bytetool.strToToHexByte(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					byteArray.method_2(array2.Length);
					byteArray.writeBytes(array2);
					byteArray.method_2(0);
					array = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array3 = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeBytes(bytetool.strToToHexByte("08000001030700001000000203010000"));
					byteArray2.writeUnsignedInt(this.uid);
					byteArray2.writeBytes(bytetool.strToToHexByte("0000000015000006DCCC1B00120B00000000050055496E666F1200000701000000010000000400000000001E0000081800030000000000000001003201000000010030030000000000787878FF"));
					array3 = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003070000C800"));
					byteArray3.method_2(array.Length);
					byteArray3.writeBytes(array);
					byteArray3.method_2(array3.Length);
					byteArray3.writeBytes(array3);
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00166230 File Offset: 0x00166230
		private void method_15(byte[] byte_3)
		{
			try
			{
				if (this.currentflag <= 60000)
				{
					using (ByteArray byteArray = new ByteArray(byte_3))
					{
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						int num = (int)byteArray.readUnsignedInt();
						c_Data[] array = new c_Data[num];
						for (int i = 0; i < num; i++)
						{
							array[i] = new c_Data();
							array[i].intd = (int)byteArray.readUnsignedShort();
							ushort num2 = byteArray.readUnsignedShort();
							array[i].Data = new byte[(int)num2];
							for (int j = 0; j < (int)num2; j++)
							{
								array[i].Data[j] = byteArray.readByte();
							}
							if (array[i].intd == 2)
							{
								this.nicheng = Encoding.UTF8.GetString(array[i].Data);
							}
							if (array[i].intd == 53)
							{
								this.jifen = Encoding.UTF8.GetString(array[i].Data);
							}
						}
						byteArray.Dispose();
					}
					if (this.sid != 0u)
					{
						this.Send_0BD0_0801();
					}
					else
					{
						this.send04d6 = 0;
						this.mytrace = "登录成功";
						this.jointime = DateTime.Now;
						this.currentflag = rdomhelper.getrandom(90001, 91000);
						this.int_12 = rdomhelper.getrandom(500, 1800);
						this.joinstatus = 2;
						this.status = 2;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x001663E8 File Offset: 0x001663E8
		public void Send_0BD0_0801()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(55001, 56000);
				this.sid_l = 0u;
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 4;
					byteArray.writeBytes(bytetool.strToToHexByte("0BD00700"));
					byteArray.writeUnsignedInt(200u);
					byteArray.writeBytes(bytetool.strToToHexByte("08010000"));
					byteArray.writeShort(200);
					byteArray.writeUnsignedInt(12u);
					byteArray.writeUnsignedInt(this.sid);
					byteArray.writeShort(1);
					byteArray.writeBytes(bytetool.strToToHexByte("00001980"));
					byteArray.writeShort(257);
					byteArray.writeUnsignedInt(77u);
					byteArray.writeBytes(bytetool.strToToHexByte("08000001"));
					byteArray.writeBytes(bytetool.strToToHexByte("08010000"));
					byteArray.writeBytes(bytetool.strToToHexByte("10000002"));
					byteArray.writeBytes(bytetool.strToToHexByte("03010000"));
					byteArray.writeUnsignedInt(this.uid);
					byteArray.writeUnsignedInt(0u);
					byteArray.writeBytes(bytetool.strToToHexByte("1F000006"));
					byteArray.writeBytes(bytetool.strToToHexByte("2A4F0068A0A916000000"));
					byteArray.writeUTF("channelSmanager");
					byteArray.writeBytes(bytetool.strToToHexByte("120000080C00010000000000000002003231787878FF"));
					byteArray.position = 0;
					byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x001665AC File Offset: 0x001665AC
		private void method_16(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					byte[] array = new byte[num];
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						array[num2] = byteArray.readByte();
						num2++;
					}
					using (ByteArray byteArray2 = new ByteArray(array))
					{
						byteArray2.endian = Endian.LITTLE_ENDIAN;
						byteArray2.Uncompress();
						if (byteArray2.readUnsignedInt() == 200u)
						{
							this.sid_l = byteArray2.readUnsignedInt();
							byteArray2.readUnsignedInt();
						}
						else
						{
							this.sid_l = byteArray2.readUnsignedInt();
							byteArray2.readUnsignedInt();
						}
					}
					if (this.isskip)
					{
						if (this.sid_l != 0u)
						{
							this.Send_0BD0_02411F(false);
						}
					}
					else
					{
						this.Send_0BD0_02411F(false);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x001666D8 File Offset: 0x001666D8
		private long method_17(string string_14)
		{
			char[] separator = new char[]
			{
				'.'
			};
			string[] array = string_14.Split(separator);
			return long.Parse(array[0]) << 24 | long.Parse(array[1]) << 16 | long.Parse(array[2]) << 8 | long.Parse(array[3]);
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x00166724 File Offset: 0x00166724
		public void Send_0BD0_02411F(bool ismuti = false)
		{
			try
			{
				if (ismuti)
				{
					this.currentflag = rdomhelper.getrandom(61001, 62000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(60001, 61000);
				}
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq();
				pjoinChannelReq.uid = this.uid;
				pjoinChannelReq.topsid = this.sid;
				pjoinChannelReq.subSid = this.subid;
				if (this.isskip)
				{
					MYHashMap props = pjoinChannelReq.props;
					props.put(2u.ToString(), bytetool.String2Bytes("1"));
				}
				else
				{
					MYHashMap props2 = pjoinChannelReq.props;
					props2.put(2u.ToString(), bytetool.String2Bytes("0"));
				}
				MYHashMap props3 = pjoinChannelReq.props;
				props3.put(4u.ToString(), bytetool.String2Bytes(timetool.GetTs()));
				if (ismuti)
				{
					MYHashMap props4 = pjoinChannelReq.props;
					props4.put(3u.ToString(), bytetool.String2Bytes("1"));
				}
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PJoinChannelReq>(pjoinChannelReq)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = ((this.sid_l == 0u) ? this.sid : this.sid_l);
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), bytetool.String2Bytes(this.pcinfo));
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, true);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x00166A14 File Offset: 0x00166A14
		public void skip()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(70001, 71000);
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq
				{
					uid = this.uid,
					topsid = this.sid,
					subSid = this.subid
				};
				MYHashMap props = pjoinChannelReq.props;
				props.put(2u.ToString(), bytetool.String2Bytes("0"));
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PJoinChannelReq>(pjoinChannelReq)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, true);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002A7 RID: 679 RVA: 0x00166C58 File Offset: 0x00166C58
		private void method_18(byte[] byte_3)
		{
			try
			{
				if (this.status != 2 || this.isskip)
				{
					using (ByteArray byteArray = new ByteArray(byte_3))
					{
						if (byte_3[8] != 200)
						{
							throw new Exception("J-ERR");
						}
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						uint num = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint subidnew = byteArray.readUnsignedInt();
						uint num2 = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint num3 = (uint)byteArray.readByte();
						switch (num3)
						{
						case 1u:
						case 3u:
							this.ZhuDongDK(0);
							goto IL_2E9;
						case 2u:
						case 5u:
						case 6u:
							break;
						case 4u:
							if (this.sid != num2 && this.sid != num)
							{
								this.mytrace = "GO-ON";
								goto IL_2E9;
							}
							this.send04d6 = 0;
							if (this.pt != ProxyTypes.None)
							{
								this.mytrace = "DL-SUC";
							}
							else
							{
								this.mytrace = "SUC";
							}
							this.jointime = DateTime.Now;
							this.currentflag = rdomhelper.getrandom(90001, 91000);
							this.int_12 = rdomhelper.getrandom(500, 1800);
							this.joinstatus = 2;
							this.status = 2;
							this.sidnew = num;
							this.subidnew = subidnew;
							this.yongjitimes = 0;
							if (this.isyongji)
							{
								this.method_1(DateTime.Now.AddSeconds((double)rdomhelper.getrandom(100, 300)));
								this.isyongji = false;
							}
							if (this.isskip)
							{
								this.isskip = false;
								if (!this.isgongneng || !this.isxianche)
								{
									goto IL_2E9;
								}
								if (this.isloginservice)
								{
									this.isxianchewancheng = false;
									this.method_28();
									goto IL_2E9;
								}
								this.Send_Service_1E73();
								goto IL_2E9;
							}
							else
							{
								if (this.isgongneng && !this.isloginservice)
								{
									this.Send_Service_1E73();
									goto IL_2E9;
								}
								goto IL_2E9;
							}
							break;
						case 7u:
							this.mytrace = "M-J";
							this.currentflag = rdomhelper.getrandom(61001, 62000);
							goto IL_2E9;
						default:
							if (num3 != 11u)
							{
								if (num3 == 12u)
								{
									goto IL_2E9;
								}
							}
							else if (!this.isskip)
							{
								if (this.ishunhejin)
								{
									int yongjitimes = this.yongjitimes;
									this.yongjitimes = yongjitimes + 1;
									this.mytrace = "Y-J-" + this.yongjitimes.ToString();
									if (this.yongjitimes > 3)
									{
										this.yongjitimes = 0;
										this.isyongji = true;
										this.ZhuDongDK(-1);
										goto IL_2E9;
									}
									goto IL_2E9;
								}
								else
								{
									this.mytrace = "Y-J";
									this.ZhuDongDK(-1);
									MyUser1225.OnYongJi onYongJi = this.onYongJi_0;
									if (onYongJi != null)
									{
										onYongJi();
										goto IL_2E9;
									}
									goto IL_2E9;
								}
							}
							else
							{
								this.mytrace = "Y-J";
								MyUser1225.OnYongJi onYongJi2 = this.onYongJi_0;
								if (onYongJi2 != null)
								{
									onYongJi2();
									goto IL_2E9;
								}
								goto IL_2E9;
							}
							break;
						}
						throw new Exception(this.mytrace = "mima");
						IL_2E9:
						byteArray.Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				this.mytrace = ex.Message;
			}
		}

		// Token: 0x060002A8 RID: 680 RVA: 0x00166FA8 File Offset: 0x00166FA8
		private void method_19(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					for (uint num2 = 0u; num2 < num; num2 += 1u)
					{
						byteArray.ReadShort();
						short num3 = byteArray.ReadShort();
						for (int i = 0; i < (int)num3; i++)
						{
							byteArray.readByte();
						}
					}
					if (byteArray.readUnsignedInt() == 0u)
					{
						this.isupdate = false;
					}
					else
					{
						this.xiugaisuiji = true;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002A9 RID: 681 RVA: 0x00167064 File Offset: 0x00167064
		public void Send_041E()
		{
			try
			{
				byte[] sendBuffer = ProtoPacket.pack<PCS_APPing>(new PCS_APPing());
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002AA RID: 682 RVA: 0x001670A0 File Offset: 0x001670A0
		private void method_20(byte[] byte_3)
		{
			try
			{
				int heartbeat = this.heartbeat;
				this.heartbeat = heartbeat + 1;
			}
			catch
			{
			}
		}

		// Token: 0x060002AB RID: 683 RVA: 0x001670D4 File Offset: 0x001670D4
		public void Send_Service_1E73()
		{
			try
			{
				this.startconnectservice = DateTime.Now;
				PCS_GetAPInfo obj = new PCS_GetAPInfo
				{
					m_uAppId = 260u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					}
				};
				byte[] serverName = bytetool.String2Bytes("aplbs_webyy");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PCS_GetAPInfo>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = Convert.ToUInt32(this.uid);
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002AC RID: 684 RVA: 0x001672CC File Offset: 0x001672CC
		public void Recv_Service_1E74(byte[] data)
		{
			try
			{
				byte[] bytes = data.Skip(38).Take((int)data[36]).ToArray<byte>();
				using (ByteArray byteArray = new ByteArray(data.Skip((int)(36 + data[36] + 10)).Take(5).ToArray<byte>()))
				{
					this.serviceport = (int)byteArray.ReadShort();
				}
				this.serviceip = Encoding.Default.GetString(bytes);
				this.connect_s();
			}
			catch
			{
			}
		}

		// Token: 0x060002AD RID: 685 RVA: 0x00167364 File Offset: 0x00167364
		public void GetMicList()
		{
			try
			{
				PGetMaixuListReq obj = new PGetMaixuListReq
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelMaixu");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PGetMaixuListReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002AE RID: 686 RVA: 0x0015F12C File Offset: 0x0015F12C
		private void method_21(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					new PGetMaixuListRes().unmarshall(protoPacket.getBuffer());
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002AF RID: 687 RVA: 0x00167560 File Offset: 0x00167560
		public void GetUserCount()
		{
			try
			{
				GClass1 obj = new GClass1
				{
					topSid = this.sidnew,
					sidlist = 
					{
						this.sidnew,
						this.subidnew
					}
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass1>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x00167768 File Offset: 0x00167768
		private void method_22(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint count = byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						if (this.subidnew == byteArray.readUnsignedInt())
						{
							count = byteArray.readUnsignedInt();
							IL_71:
							MyUser1225.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
							if (onGetUserCount != null)
							{
								onGetUserCount(count);
							}
							goto IL_8E;
						}
						num2++;
					}
					goto IL_71;
				}
				IL_8E:;
			}
			catch
			{
			}
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00167824 File Offset: 0x00167824
		public void GetUserList(uint pos = 0u)
		{
			try
			{
				GClass3 obj = new GClass3
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					pos = pos,
					num = 50u
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass3>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00167A24 File Offset: 0x00167A24
		private void method_23(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					List<uint> list = new List<uint>();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						list.Add(byteArray.readUnsignedInt());
						uint num3 = byteArray.readUnsignedInt();
						int num4 = 0;
						while ((long)num4 < (long)((ulong)num3))
						{
							byteArray.readByte();
							byteArray.readUnsignedInt();
							num4++;
						}
						uint num5 = byteArray.readUnsignedInt();
						int num6 = 0;
						while ((long)num6 < (long)((ulong)num5))
						{
							byteArray.readByte();
							short num7 = byteArray.ReadShort();
							byteArray.position += (int)num7;
							num6++;
						}
						num2++;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00167B30 File Offset: 0x00167B30
		public void GetUserInfo()
		{
			try
			{
				List<uint> list = new List<uint>();
				list.Add(this.uid);
				PQueryUserInfoReq obj = new PQueryUserInfoReq
				{
					uidlist = list,
					topSid = this.sidnew,
					type = 0u
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PQueryUserInfoReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x0015F96C File Offset: 0x0015F96C
		private void method_24(byte[] byte_3)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_3))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002B5 RID: 693 RVA: 0x00167D3C File Offset: 0x00167D3C
		public void LeaveChanel()
		{
			try
			{
				PLeaveChannelReq obj = new PLeaveChannelReq
				{
					topsid = this.sidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PLeaveChannelReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					sendBuffer = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x00167F2C File Offset: 0x00167F2C
		public void qiangmai()
		{
			try
			{
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq();
				pjoinChannelReq.uid = this.uid;
				pjoinChannelReq.topsid = ((this.sid_l == 0u) ? this.sid : this.sid_l);
				pjoinChannelReq.subSid = this.subid;
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						151,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						2,
						50,
						0,
						0,
						0,
						0,
						12,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						113,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						2,
						50,
						0,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						29,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						13,
						0,
						99,
						104,
						97,
						110,
						110,
						101,
						108,
						65,
						117,
						116,
						104,
						101,
						114,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue,
						148,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						3,
						102,
						0,
						0,
						0,
						0,
						17,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray2 = byteArray;
					byte[] array = new byte[4];
					array[0] = 1;
					byteArray2.writeBytes(array);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						1,
						0,
						0,
						0,
						0,
						105,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						3,
						102,
						0,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						21,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						5,
						0,
						85,
						73,
						110,
						102,
						111,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue,
						157,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						2,
						178,
						47,
						0,
						0,
						0,
						16,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray3 = byteArray;
					byte[] array2 = new byte[4];
					array2[0] = 1;
					byteArray3.writeBytes(array2);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						115,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						2,
						178,
						47,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						31,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						15,
						0,
						99,
						104,
						97,
						110,
						110,
						101,
						108,
						85,
						115,
						101,
						114,
						73,
						110,
						102,
						111,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue
					});
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x001681F8 File Offset: 0x001681F8
		public void xiamai()
		{
			try
			{
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq();
				pjoinChannelReq.uid = this.uid;
				pjoinChannelReq.topsid = ((this.sid_l == 0u) ? this.sid : this.sid_l);
				pjoinChannelReq.subSid = this.subid;
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						151,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						2,
						51,
						0,
						0,
						0,
						0,
						12,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						113,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						2,
						51,
						0,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						29,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						13,
						0,
						99,
						104,
						97,
						110,
						110,
						101,
						108,
						65,
						117,
						116,
						104,
						101,
						114,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue,
						148,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						3,
						102,
						0,
						0,
						0,
						0,
						17,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray2 = byteArray;
					byte[] array = new byte[4];
					array[0] = 1;
					byteArray2.writeBytes(array);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						1,
						0,
						0,
						0,
						0,
						105,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						3,
						102,
						0,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						21,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						5,
						0,
						85,
						73,
						110,
						102,
						111,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue,
						157,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						2,
						178,
						47,
						0,
						0,
						0,
						16,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray3 = byteArray;
					byte[] array2 = new byte[4];
					array2[0] = 1;
					byteArray3.writeBytes(array2);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						115,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						2,
						178,
						47,
						0,
						16,
						0,
						0,
						2,
						3,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						31,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						15,
						0,
						99,
						104,
						97,
						110,
						110,
						101,
						108,
						85,
						115,
						101,
						114,
						73,
						110,
						102,
						111,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						52,
						55,
						53,
						56,
						52,
						52,
						49,
						65,
						51,
						66,
						67,
						48,
						52,
						51,
						49,
						68,
						49,
						69,
						70,
						51,
						48,
						53,
						52,
						69,
						50,
						53,
						66,
						49,
						66,
						55,
						52,
						53,
						120,
						120,
						120,
						byte.MaxValue
					});
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.logintcp.Send(sendBuffer, false);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x001684C4 File Offset: 0x001684C4
		public void connect_s()
		{
			this.startconnectservice = DateTime.Now;
			if (this.servicetcp != null)
			{
				try
				{
					this.servicetcp.ReciveEvent -= this.method_25;
					this.servicetcp.CloseConEvent -= this.OnCloseConnectEvent_S;
					this.servicetcp.ConEvent -= this.OnCon_S;
				}
				catch
				{
				}
				try
				{
					this.servicetcp.Dispose();
				}
				catch
				{
				}
			}
			this.servicetcp = new MyTcp1225(this.serviceip, this.serviceport, ProxyTypes.None, "", this.localip);
			this.servicetcp.ReciveEvent += this.method_25;
			this.servicetcp.CloseConEvent += this.OnCloseConnectEvent_S;
			this.servicetcp.ConEvent += this.OnCon_S;
			this.servicetcp.Connect();
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00158048 File Offset: 0x00158048
		public void OnSendEvent_S()
		{
		}

		// Token: 0x060002BA RID: 698 RVA: 0x001685D0 File Offset: 0x001685D0
		public void OnCloseConnectEvent_S()
		{
			this.isloginservice = false;
			try
			{
				this.servicetcp.ReciveEvent -= this.method_25;
				this.servicetcp.CloseConEvent -= this.OnCloseConnectEvent_S;
				this.servicetcp.ConEvent -= this.OnCon_S;
			}
			catch
			{
			}
			try
			{
				this.servicetcp.Dispose();
			}
			catch
			{
			}
			if (this.status == 2)
			{
				this.Send_Service_1E73();
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x0016866C File Offset: 0x0016866C
		public void OnCon_S()
		{
			try
			{
				this.Send_0411_s();
			}
			catch
			{
			}
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00168694 File Offset: 0x00168694
		private void method_25(byte[] byte_3)
		{
			try
			{
				if (byte_3 != null && byte_3.Length >= 10 && byte_3[8] == 200)
				{
					string text = bytetool.fromArray(byte_3, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2))
					{
						if (!(text2 == "0412") && !(text2 == "0415") && !(text2 == "0287") && !(text2 == "0433"))
						{
							if (text2 == "04D7")
							{
								this.Recv_04D7_s(byte_3);
							}
							else if (text2 == "0BD0")
							{
								string a;
								try
								{
									text.Substring(24, 4).ToUpper();
									a = text.Substring(24, 6).ToUpper();
								}
								catch
								{
									return;
								}
								if (a == "583901" && this.isxianche)
								{
									this.isxianchewancheng = true;
								}
							}
						}
						else
						{
							this.Recv_0412_s(byte_3);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x001687BC File Offset: 0x001687BC
		public void Send_0411_s()
		{
			try
			{
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] sendBuffer = ProtoPacket.pack<PExchangeKey>(new PExchangeKey(publicKey, exponent));
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00168810 File Offset: 0x00168810
		public void Recv_0412_s(byte[] data)
		{
			try
			{
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray(data))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
					if (num != 0u)
					{
						using (ByteArray byteArray2 = new ByteArray())
						{
							protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
							array = byteArray2.Buffer;
							byteArray2.Dispose();
						}
					}
					byteArray.Dispose();
				}
				if (array == null || array.Length == 0)
				{
					throw new Exception("rsa fail");
				}
				byte[] bytes = rsautil.getInstance().decrypt(array);
				this.servicetcp.setarc(bytes);
				this.method_26();
			}
			catch
			{
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x001688E8 File Offset: 0x001688E8
		private void method_26()
		{
			try
			{
				byte[] sendBuffer;
				if (this.logintype == 1)
				{
					PCS_APLogin pcs_APLogin = new PCS_APLogin();
					pcs_APLogin.m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					if (this.yycookie != null && this.yycookie.Length != 0)
					{
						pcs_APLogin.m_bRelogin = true;
					}
					else
					{
						pcs_APLogin.m_bRelogin = false;
					}
					pcs_APLogin.m_uAppID = 260u;
					pcs_APLogin.m_uUid.low = Convert.ToUInt32(this.uid);
					pcs_APLogin.m_strCookie = this.yycookie;
					pcs_APLogin.m_strAccount = Encoding.UTF8.GetBytes(this.username);
					pcs_APLogin.m_uCliType = 2u;
					pcs_APLogin.m_strFrom = bytetool.String2Bytes("8.45.0.0");
					pcs_APLogin.m_strCliVer = bytetool.String2Bytes("8.45.0.0");
					sendBuffer = ProtoPacket.pack<PCS_APLogin>(pcs_APLogin);
				}
				else
				{
					sendBuffer = ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
					{
						m_strAccount = bytetool.String2Bytes(this.username),
						m_strPassword = bytetool.String2Bytes(this.pwden),
						m_bRelogin = false,
						m_uAppID = 260u,
						m_uUid = 
						{
							low = Convert.ToUInt32(this.uid)
						},
						m_strCookie = this.yycookie,
						m_uCliType = 2u,
						m_strFrom = bytetool.String2Bytes("yymwebflsh"),
						m_strCliVer = bytetool.String2Bytes("yymwebflsh")
					});
				}
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x00168A74 File Offset: 0x00168A74
		public void Recv_04D7_s(byte[] data)
		{
			using (ByteArray byteArray = new ByteArray(data))
			{
				ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
				PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
				pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
				byteArray.Dispose();
				if (pcs_APLoginRes.m_uResCode != 200u)
				{
					this.isloginservice = false;
					this.OnCloseConnectEvent_S();
				}
				else
				{
					this.isloginservice = true;
					if (this.isxianche)
					{
						this.method_28();
					}
					if (this.isqutubiao)
					{
						this.method_27("4000");
					}
				}
			}
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00168B0C File Offset: 0x00168B0C
		private void method_27(string string_14)
		{
			try
			{
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray2 = byteArray;
					byte[] array = new byte[16];
					array[4] = 2;
					array[8] = 1;
					byteArray2.writeBytes(array);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray3 = byteArray;
					byte[] array2 = new byte[12];
					array2[4] = 2;
					byteArray3.writeBytes(array2);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						172,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						207,
						9,
						0,
						0,
						0,
						46,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray4 = byteArray;
					byte[] array3 = new byte[16];
					array3[4] = 2;
					array3[8] = 1;
					byteArray4.writeBytes(array3);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray5 = byteArray;
					byte[] array4 = new byte[12];
					array4[4] = 2;
					byteArray5.writeBytes(array4);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						207,
						9,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray6 = byteArray;
					byte[] array5 = new byte[16];
					array5[4] = 2;
					array5[8] = 1;
					byteArray6.writeBytes(array5);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray7 = byteArray;
					byte[] array6 = new byte[12];
					array6[4] = 2;
					byteArray7.writeBytes(array6);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						203,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						77,
						0,
						0,
						0,
						22,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						45,
						0,
						0,
						0,
						45,
						0,
						0,
						0,
						88,
						228,
						5,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						17,
						0,
						2,
						0,
						0,
						0,
						1,
						0,
						1,
						0,
						48,
						2,
						0,
						4,
						0
					});
					byteArray.writeBytes(Encoding.Default.GetBytes(string_14));
					byteArray.writeBytes(new byte[6]);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						168,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						42,
						0,
						0,
						0,
						155,
						58
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						10,
						0,
						0,
						0,
						11,
						0,
						0,
						0,
						232,
						3,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue
					});
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00168FAC File Offset: 0x00168FAC
		private void method_28()
		{
			try
			{
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 4;
					byteArray.writeBytes(bytetool.strToToHexByte("0BD00700C800000058380100C8002E000000A43A"));
					byteArray.writeUnsignedInt(this.sidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0A0000000B0000004C0400000000000000000100"));
					byteArray.writeUnsignedInt(this.subidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0001000000000000370000000800000158380100100000020401000033A49F43000000001B00000702000000FF030000050031353031320004000002003336787878FF"));
					byteArray.position = 0;
					byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00169098 File Offset: 0x00169098
		public void SendSH()
		{
			try
			{
				byte[] sendBuffer = new byte[]
				{
					14,
					0,
					0,
					0,
					4,
					30,
					12,
					0,
					200,
					0,
					0,
					0,
					0,
					0
				};
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x001690DC File Offset: 0x001690DC
		public void zhibotongzhi(uint beishuauid)
		{
			try
			{
				byte[] sendBuffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						218,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						200,
						0,
						125,
						0,
						0,
						0,
						165,
						58
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sidnew)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						89,
						0,
						0,
						0,
						38,
						12,
						207,
						0,
						4,
						0,
						0,
						0,
						5,
						0,
						36,
						0
					});
					byteArray.writeBytes(new byte[]
					{
						100,
						102,
						48,
						99,
						53,
						52,
						99,
						101,
						45,
						99,
						50,
						101,
						55,
						45,
						52,
						49,
						53,
						98,
						45,
						57,
						48,
						48,
						53,
						45,
						100,
						57,
						55,
						52,
						57,
						55,
						54,
						55,
						53,
						48,
						97,
						56
					});
					byteArray.writeBytes(new byte[]
					{
						1,
						0,
						8,
						0,
						53,
						57,
						53,
						57,
						56,
						52,
						55,
						56,
						6,
						0,
						6,
						0,
						51,
						46,
						49,
						51,
						46,
						50,
						2,
						0,
						1,
						0,
						49,
						12,
						0,
						1,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(beishuauid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						67,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						8,
						0,
						0,
						7,
						0,
						0,
						0,
						0,
						31,
						0,
						0,
						8,
						25,
						0,
						3,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						2,
						0,
						54,
						50,
						2,
						0,
						0,
						0,
						1,
						0,
						50,
						3,
						0,
						0,
						0,
						0,
						0,
						120,
						120,
						120,
						byte.MaxValue
					});
					sendBuffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x001691FC File Offset: 0x001691FC
		public void daka2()
		{
			Encoding @default = Encoding.Default;
			if (Convert.ToByte(@default.GetBytes(Convert.ToUInt32(this.subidnew).ToString()).Length) == 8)
			{
				try
				{
					byte[] sendBuffer = null;
					using (ByteArray byteArray = new ByteArray())
					{
						byteArray.endian = Endian.LITTLE_ENDIAN;
						byteArray.position = 0;
						byteArray.writeBytes(new byte[]
						{
							200,
							0,
							0,
							0,
							11,
							208,
							7,
							0,
							200,
							0,
							0,
							0,
							88,
							56,
							1,
							0,
							200,
							0,
							118,
							0,
							0,
							0,
							164,
							58
						});
						byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sidnew)));
						byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
						byteArray.writeBytes(new byte[]
						{
							82,
							0,
							0,
							0,
							44,
							1,
							0,
							0,
							123,
							0,
							0,
							0,
							72,
							0,
							183,
							8,
							0,
							0,
							78,
							4,
							0,
							0,
							213,
							0,
							0,
							0,
							34,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							0,
							1,
							0,
							0,
							0,
							1,
							0,
							0,
							0,
							10,
							0
						});
						Encoding default2 = Encoding.Default;
						byteArray.writeBytes(default2.GetBytes(Convert.ToUInt32(this.subidnew).ToString()));
						ByteArray byteArray2 = byteArray;
						byte[] array = new byte[12];
						array[10] = 1;
						byteArray2.writeBytes(array);
						byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subidnew)));
						byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
						byteArray.writeBytes(new byte[]
						{
							0,
							1,
							0,
							0,
							0,
							0,
							0,
							0,
							56,
							0,
							0,
							0,
							8,
							0,
							0,
							1,
							88,
							56,
							1,
							0,
							16,
							0,
							0,
							2,
							4,
							1,
							0,
							0
						});
						byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
						byteArray.writeBytes(new byte[]
						{
							0,
							0,
							0,
							0,
							28,
							0,
							0,
							7,
							2,
							0,
							0,
							0,
							byte.MaxValue,
							3,
							0,
							0,
							5,
							0,
							49,
							53,
							48,
							49,
							50,
							0,
							4,
							0,
							0,
							3,
							0,
							49,
							49,
							48,
							120,
							120,
							120,
							byte.MaxValue
						});
						sendBuffer = byteArray.Buffer;
						byteArray.Dispose();
					}
					this.servicetcp.Send(sendBuffer, false);
					return;
				}
				catch
				{
					return;
				}
			}
			try
			{
				byte[] sendBuffer2 = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 0;
					byteArray3.writeBytes(new byte[]
					{
						200,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						200,
						0,
						118,
						0,
						0,
						0,
						164,
						58
					});
					byteArray3.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sidnew)));
					byteArray3.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray3.writeBytes(new byte[]
					{
						82,
						0,
						0,
						0,
						44,
						1,
						0,
						0,
						123,
						0,
						0,
						0,
						72,
						0,
						183,
						8,
						0,
						0,
						78,
						4,
						0,
						0,
						213,
						0,
						0,
						0,
						34,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						10,
						0
					});
					Encoding default3 = Encoding.Default;
					byteArray3.writeBytes(default3.GetBytes(Convert.ToUInt32(this.subidnew).ToString()));
					ByteArray byteArray4 = byteArray3;
					byte[] array2 = new byte[10];
					array2[8] = 1;
					byteArray4.writeBytes(array2);
					byteArray3.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subidnew)));
					byteArray3.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray3.writeBytes(new byte[]
					{
						0,
						1,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray3.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray3.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						28,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						byte.MaxValue,
						3,
						0,
						0,
						5,
						0,
						49,
						53,
						48,
						49,
						50,
						0,
						4,
						0,
						0,
						3,
						0,
						49,
						49,
						48,
						120,
						120,
						120,
						byte.MaxValue
					});
					sendBuffer2 = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				this.servicetcp.Send(sendBuffer2, false);
			}
			catch
			{
			}
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00169544 File Offset: 0x00169544
		public void shuahua(uint beishuauid, string beishuamingzi)
		{
			try
			{
				byte[] first = new byte[]
				{
					11,
					208,
					7,
					0,
					200,
					0,
					0,
					0,
					88,
					56,
					1,
					0,
					200,
					0
				};
				byte[] first2 = new byte[]
				{
					39,
					12,
					3,
					0,
					5,
					0,
					0,
					0,
					3,
					0,
					36,
					0,
					102,
					56,
					56,
					99,
					101,
					100,
					98,
					57,
					45,
					48,
					48,
					56,
					52,
					45,
					52,
					102,
					57,
					54,
					45,
					57,
					52,
					99,
					48,
					45,
					53,
					97,
					98,
					100,
					55,
					55,
					51,
					99,
					98,
					49,
					57,
					102,
					1,
					0
				};
				byte[] second = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 2;
					ByteArray byteArray2 = byteArray;
					Encoding @default = Encoding.Default;
					byteArray2[0] = Convert.ToByte(@default.GetBytes(Convert.ToUInt32(this.subidnew).ToString()).Length);
					ByteArray byteArray3 = byteArray;
					Encoding default2 = Encoding.Default;
					byteArray3.writeBytes(default2.GetBytes(Convert.ToUInt32(this.subidnew).ToString()));
					byteArray.writeBytes(new byte[]
					{
						2,
						0,
						1,
						0,
						49,
						5,
						0,
						36,
						0,
						100,
						52,
						99,
						51,
						99,
						100,
						49,
						99,
						45,
						102,
						48,
						57,
						101,
						45,
						52,
						97,
						51,
						55,
						45,
						98,
						56,
						100,
						97,
						45,
						98,
						57,
						54,
						100,
						99,
						54,
						99,
						56,
						49,
						97,
						57,
						49,
						6,
						0,
						5,
						0,
						52,
						46,
						54,
						46,
						52
					});
					second = byteArray.Buffer;
					byteArray.Dispose();
				}
				first2 = first2.Concat(second).ToArray<byte>();
				byte[] array = null;
				using (ByteArray byteArray4 = new ByteArray())
				{
					byteArray4.endian = Endian.LITTLE_ENDIAN;
					ByteArray byteArray5 = byteArray4;
					byte[] array2 = new byte[6];
					array2[0] = 134;
					array2[2] = 1;
					byteArray5.writeBytes(array2);
					byteArray4.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(beishuauid)));
					byteArray4.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						25,
						0,
						77,
						79,
						66,
						83,
						69,
						78,
						68,
						70,
						76,
						87,
						83,
						69,
						81,
						95,
						84,
						79,
						95,
						78,
						73,
						67,
						75,
						78,
						65,
						77,
						69
					});
					array = byteArray4.Buffer;
					byteArray4.Dispose();
				}
				byte[] second2 = null;
				using (ByteArray byteArray6 = new ByteArray())
				{
					byteArray6.endian = Endian.LITTLE_ENDIAN;
					byteArray6.position = 2;
					byteArray6[0] = Convert.ToByte(Encoding.UTF8.GetBytes(beishuamingzi).Length);
					byteArray6.writeBytes(Encoding.UTF8.GetBytes(beishuamingzi));
					second2 = byteArray6.Buffer;
					byteArray6.Dispose();
				}
				array = array.Concat(second2).ToArray<byte>();
				byte[] second3 = new byte[]
				{
					11,
					0,
					110,
					111,
					98,
					108,
					101,
					95,
					108,
					101,
					118,
					101,
					108,
					1,
					0,
					48,
					27,
					0,
					77,
					79,
					66,
					83,
					69,
					78,
					68,
					70,
					76,
					87,
					83,
					69,
					81,
					95,
					70,
					82,
					79,
					77,
					95,
					78,
					73,
					67,
					75,
					78,
					65,
					77,
					69
				};
				array = array.Concat(second3).ToArray<byte>();
				byte[] second4 = null;
				using (ByteArray byteArray7 = new ByteArray())
				{
					byteArray7.endian = Endian.LITTLE_ENDIAN;
					byteArray7.position = 2;
					byteArray7[0] = Convert.ToByte(Encoding.UTF8.GetBytes(this.nicheng).Length);
					byteArray7.writeBytes(Encoding.UTF8.GetBytes(this.nicheng));
					second4 = byteArray7.Buffer;
					byteArray7.Dispose();
				}
				array = array.Concat(second4).ToArray<byte>();
				array[0] = Convert.ToByte(new ByteArray(array)
				{
					endian = Endian.LITTLE_ENDIAN,
					position = 4
				}.length - 2);
				byte[] array3 = first2.Concat(array).ToArray<byte>();
				byte[] second5 = BitConverter.GetBytes(array3.Length).Concat(array3).ToArray<byte>();
				byte[] array4 = null;
				using (ByteArray byteArray8 = new ByteArray())
				{
					byteArray8.endian = Endian.LITTLE_ENDIAN;
					byteArray8.writeBytes(new byte[]
					{
						165,
						58
					});
					byteArray8.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sidnew)));
					byteArray8.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					array4 = byteArray8.Buffer;
					byteArray8.Dispose();
				}
				array4 = array4.Concat(second5).ToArray<byte>();
				byte[] second6 = null;
				using (ByteArray byteArray9 = new ByteArray())
				{
					byteArray9.endian = Endian.LITTLE_ENDIAN;
					byteArray9.writeBytes(new byte[6]);
					byteArray9.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subidnew)));
					byteArray9.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray9.writeBytes(new byte[4]);
					second6 = byteArray9.Buffer;
					byteArray9.Dispose();
				}
				array4 = array4.Concat(second6).ToArray<byte>();
				byte[] bytes = BitConverter.GetBytes(Convert.ToUInt32(array4.Length));
				byte[] second7 = null;
				using (ByteArray byteArray10 = new ByteArray())
				{
					byteArray10.endian = Endian.LITTLE_ENDIAN;
					byteArray10.writeBytes(new byte[]
					{
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray10.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray10.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray10.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sidnew)));
					byteArray10.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						56,
						69,
						56,
						49,
						51,
						55,
						55,
						55,
						68,
						69,
						69,
						53,
						65,
						68,
						50,
						70,
						49,
						69,
						66,
						65,
						69,
						49,
						52,
						48,
						67,
						48,
						70,
						57,
						57,
						53,
						56,
						52,
						120,
						120,
						120,
						byte.MaxValue
					});
					second7 = byteArray10.Buffer;
					byteArray10.Dispose();
				}
				byte[] array5 = first.Concat(bytes).ToArray<byte>();
				array5 = array5.Concat(array4).ToArray<byte>();
				array5 = array5.Concat(second7).ToArray<byte>();
				byte[] sendBuffer = BitConverter.GetBytes(array5.Length + 4).Concat(array5).ToArray<byte>();
				this.servicetcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x04000161 RID: 353
		[CompilerGenerated]
		private MyUser1225.OnYongJi onYongJi_0;

		// Token: 0x04000162 RID: 354
		[CompilerGenerated]
		private MyUser1225.OnGetUserCount onGetUserCount_0;

		// Token: 0x04000163 RID: 355
		[CompilerGenerated]
		private MyUser1225.OnGetUserList onGetUserList_0;

		// Token: 0x04000164 RID: 356
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000165 RID: 357
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000166 RID: 358
		[CompilerGenerated]
		private string string_1;

		// Token: 0x04000167 RID: 359
		[CompilerGenerated]
		private string string_2;

		// Token: 0x04000168 RID: 360
		[CompilerGenerated]
		private int int_1;

		// Token: 0x04000169 RID: 361
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x0400016A RID: 362
		[CompilerGenerated]
		private int int_2;

		// Token: 0x0400016B RID: 363
		[CompilerGenerated]
		private int int_3;

		// Token: 0x0400016C RID: 364
		[CompilerGenerated]
		private int int_4;

		// Token: 0x0400016D RID: 365
		[CompilerGenerated]
		private uint uint_0;

		// Token: 0x0400016E RID: 366
		[CompilerGenerated]
		private string string_3;

		// Token: 0x0400016F RID: 367
		[CompilerGenerated]
		private string string_4;

		// Token: 0x04000170 RID: 368
		[CompilerGenerated]
		private uint uint_1;

		// Token: 0x04000171 RID: 369
		[CompilerGenerated]
		private uint uint_2;

		// Token: 0x04000172 RID: 370
		[CompilerGenerated]
		private uint uint_3;

		// Token: 0x04000173 RID: 371
		[CompilerGenerated]
		private uint uint_4;

		// Token: 0x04000174 RID: 372
		[CompilerGenerated]
		private uint uint_5;

		// Token: 0x04000175 RID: 373
		[CompilerGenerated]
		private string string_5;

		// Token: 0x04000176 RID: 374
		[CompilerGenerated]
		private MyTcp1225 myTcp1225_0;

		// Token: 0x04000177 RID: 375
		[CompilerGenerated]
		private string string_6;

		// Token: 0x04000178 RID: 376
		[CompilerGenerated]
		private int int_5;

		// Token: 0x04000179 RID: 377
		[CompilerGenerated]
		private int int_6;

		// Token: 0x0400017A RID: 378
		[CompilerGenerated]
		private ProxyTypes proxyTypes_0;

		// Token: 0x0400017B RID: 379
		[CompilerGenerated]
		private string string_7;

		// Token: 0x0400017C RID: 380
		[CompilerGenerated]
		private string string_8;

		// Token: 0x0400017D RID: 381
		[CompilerGenerated]
		private int int_7;

		// Token: 0x0400017E RID: 382
		[CompilerGenerated]
		private bool bool_1;

		// Token: 0x0400017F RID: 383
		[CompilerGenerated]
		private byte[] byte_0;

		// Token: 0x04000180 RID: 384
		private string string_9;

		// Token: 0x04000181 RID: 385
		[CompilerGenerated]
		private DateTime dateTime_0;

		// Token: 0x04000182 RID: 386
		[CompilerGenerated]
		private DateTime dateTime_1;

		// Token: 0x04000183 RID: 387
		[CompilerGenerated]
		private DateTime dateTime_2;

		// Token: 0x04000184 RID: 388
		[CompilerGenerated]
		private DateTime dateTime_3;

		// Token: 0x04000185 RID: 389
		[CompilerGenerated]
		private DateTime dateTime_4;

		// Token: 0x04000186 RID: 390
		private System.Timers.Timer timer_0;

		// Token: 0x04000187 RID: 391
		[CompilerGenerated]
		private string string_10;

		// Token: 0x04000188 RID: 392
		[CompilerGenerated]
		private int int_8;

		// Token: 0x04000189 RID: 393
		[CompilerGenerated]
		private bool bool_2;

		// Token: 0x0400018A RID: 394
		[CompilerGenerated]
		private bool bool_3;

		// Token: 0x0400018B RID: 395
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x0400018C RID: 396
		[CompilerGenerated]
		private string string_11;

		// Token: 0x0400018D RID: 397
		[CompilerGenerated]
		private bool bool_5;

		// Token: 0x0400018E RID: 398
		[CompilerGenerated]
		private string string_12;

		// Token: 0x0400018F RID: 399
		[CompilerGenerated]
		private bool bool_6;

		// Token: 0x04000190 RID: 400
		[CompilerGenerated]
		private bool bool_7;

		// Token: 0x04000191 RID: 401
		[CompilerGenerated]
		private int int_9;

		// Token: 0x04000192 RID: 402
		[CompilerGenerated]
		private DateTime dateTime_5;

		// Token: 0x04000193 RID: 403
		[CompilerGenerated]
		private DateTime dateTime_6;

		// Token: 0x04000194 RID: 404
		[CompilerGenerated]
		private bool bool_8;

		// Token: 0x04000195 RID: 405
		[CompilerGenerated]
		private List<duoip> list_0;

		// Token: 0x04000196 RID: 406
		[CompilerGenerated]
		private int int_10;

		// Token: 0x04000197 RID: 407
		[CompilerGenerated]
		private bool bool_9;

		// Token: 0x04000198 RID: 408
		[CompilerGenerated]
		private MyTcp1225 myTcp1225_1;

		// Token: 0x04000199 RID: 409
		[CompilerGenerated]
		private bool bool_10;

		// Token: 0x0400019A RID: 410
		[CompilerGenerated]
		private bool bool_11;

		// Token: 0x0400019B RID: 411
		[CompilerGenerated]
		private bool bool_12;

		// Token: 0x0400019C RID: 412
		[CompilerGenerated]
		private bool bool_13;

		// Token: 0x0400019D RID: 413
		[CompilerGenerated]
		private string string_13;

		// Token: 0x0400019E RID: 414
		[CompilerGenerated]
		private int int_11;

		// Token: 0x0400019F RID: 415
		[CompilerGenerated]
		private DateTime dateTime_7;

		// Token: 0x040001A0 RID: 416
		private int int_12;

		// Token: 0x040001A1 RID: 417
		private volatile int int_13;

		// Token: 0x040001A2 RID: 418
		private int int_14;

		// Token: 0x040001A3 RID: 419
		private volatile int int_15;

		// Token: 0x040001A4 RID: 420
		private byte[] byte_1;

		// Token: 0x040001A5 RID: 421
		private byte[] byte_2;

		// Token: 0x040001A6 RID: 422
		public volatile int send04d6;

		// Token: 0x02000025 RID: 37
		// (Invoke) Token: 0x060002C8 RID: 712
		public delegate void OnYongJi();

		// Token: 0x02000026 RID: 38
		// (Invoke) Token: 0x060002CC RID: 716
		public delegate void OnGetUserCount(uint count);

		// Token: 0x02000027 RID: 39
		// (Invoke) Token: 0x060002D0 RID: 720
		public delegate void OnGetUserList(uint pos, List<uint> uids);
	}
}
