﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000006 RID: 6
	public class checkinfo
	{
		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001B RID: 27 RVA: 0x00158120 File Offset: 0x00158120
		// (set) Token: 0x0600001C RID: 28 RVA: 0x00158128 File Offset: 0x00158128
		public string mac { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600001D RID: 29 RVA: 0x00158131 File Offset: 0x00158131
		// (set) Token: 0x0600001E RID: 30 RVA: 0x00158139 File Offset: 0x00158139
		public int minitues { get; set; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600001F RID: 31 RVA: 0x00158142 File Offset: 0x00158142
		// (set) Token: 0x06000020 RID: 32 RVA: 0x0015814A File Offset: 0x0015814A
		public DateTime createtime { get; set; }

		// Token: 0x04000011 RID: 17
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000012 RID: 18
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000013 RID: 19
		[CompilerGenerated]
		private DateTime dateTime_0;
	}
}
