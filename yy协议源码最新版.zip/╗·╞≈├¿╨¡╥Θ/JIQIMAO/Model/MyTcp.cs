﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Timers;
using JIQIMAO.Common;
using JIQIMAO.Model.YYModel;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x02000016 RID: 22
	public class MyTcp : IDisposable
	{
		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000089 RID: 137 RVA: 0x001583BE File Offset: 0x001583BE
		public bool MyConnected
		{
			get
			{
				return this.tcpClient_0 != null && this.tcpClient_0.IsOnline();
			}
		}

		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600008A RID: 138 RVA: 0x0015BB68 File Offset: 0x0015BB68
		// (remove) Token: 0x0600008B RID: 139 RVA: 0x0015BBA0 File Offset: 0x0015BBA0
		public event MyTcp.OnConnected ConnectedEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp.OnConnected onConnected = this.onConnected_0;
				MyTcp.OnConnected onConnected2;
				do
				{
					onConnected2 = onConnected;
					MyTcp.OnConnected value2 = (MyTcp.OnConnected)Delegate.Combine(onConnected2, value);
					onConnected = Interlocked.CompareExchange<MyTcp.OnConnected>(ref this.onConnected_0, value2, onConnected2);
				}
				while (onConnected != onConnected2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp.OnConnected onConnected = this.onConnected_0;
				MyTcp.OnConnected onConnected2;
				do
				{
					onConnected2 = onConnected;
					MyTcp.OnConnected value2 = (MyTcp.OnConnected)Delegate.Remove(onConnected2, value);
					onConnected = Interlocked.CompareExchange<MyTcp.OnConnected>(ref this.onConnected_0, value2, onConnected2);
				}
				while (onConnected != onConnected2);
			}
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600008C RID: 140 RVA: 0x0015BBD8 File Offset: 0x0015BBD8
		// (remove) Token: 0x0600008D RID: 141 RVA: 0x0015BC10 File Offset: 0x0015BC10
		public event MyTcp.OnRecieved RecievedEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp.OnRecieved onRecieved = this.onRecieved_0;
				MyTcp.OnRecieved onRecieved2;
				do
				{
					onRecieved2 = onRecieved;
					MyTcp.OnRecieved value2 = (MyTcp.OnRecieved)Delegate.Combine(onRecieved2, value);
					onRecieved = Interlocked.CompareExchange<MyTcp.OnRecieved>(ref this.onRecieved_0, value2, onRecieved2);
				}
				while (onRecieved != onRecieved2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp.OnRecieved onRecieved = this.onRecieved_0;
				MyTcp.OnRecieved onRecieved2;
				do
				{
					onRecieved2 = onRecieved;
					MyTcp.OnRecieved value2 = (MyTcp.OnRecieved)Delegate.Remove(onRecieved2, value);
					onRecieved = Interlocked.CompareExchange<MyTcp.OnRecieved>(ref this.onRecieved_0, value2, onRecieved2);
				}
				while (onRecieved != onRecieved2);
			}
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600008E RID: 142 RVA: 0x0015BC48 File Offset: 0x0015BC48
		// (remove) Token: 0x0600008F RID: 143 RVA: 0x0015BC80 File Offset: 0x0015BC80
		public event MyTcp.OnHeart HeartEvent
		{
			[CompilerGenerated]
			add
			{
				MyTcp.OnHeart onHeart = this.onHeart_0;
				MyTcp.OnHeart onHeart2;
				do
				{
					onHeart2 = onHeart;
					MyTcp.OnHeart value2 = (MyTcp.OnHeart)Delegate.Combine(onHeart2, value);
					onHeart = Interlocked.CompareExchange<MyTcp.OnHeart>(ref this.onHeart_0, value2, onHeart2);
				}
				while (onHeart != onHeart2);
			}
			[CompilerGenerated]
			remove
			{
				MyTcp.OnHeart onHeart = this.onHeart_0;
				MyTcp.OnHeart onHeart2;
				do
				{
					onHeart2 = onHeart;
					MyTcp.OnHeart value2 = (MyTcp.OnHeart)Delegate.Remove(onHeart2, value);
					onHeart = Interlocked.CompareExchange<MyTcp.OnHeart>(ref this.onHeart_0, value2, onHeart2);
				}
				while (onHeart != onHeart2);
			}
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0015BCB8 File Offset: 0x0015BCB8
		public MyTcp(string ip, int port, bool isservice = false, string daili = "", ProxyTypes pt = ProxyTypes.None)
		{
			this.byte_0 = new byte[8192];
			try
			{
				this.bool_0 = isservice;
				this.proxySocket_0 = new ProxySocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				if (daili.Trim().Length > 0)
				{
					string[] array = daili.Split(new char[]
					{
						'|'
					});
					if (pt == ProxyTypes.Https)
					{
						array = daili.Split(new char[]
						{
							':'
						});
					}
					this.proxySocket_0.ProxyEndPoint = new IPEndPoint(IPAddress.Parse(array[0]), Convert.ToInt32(array[1]));
					if (array.Length > 2)
					{
						this.proxySocket_0.ProxyUser = array[2];
						this.proxySocket_0.ProxyPass = array[3];
					}
				}
				this.proxySocket_0.ProxyType = pt;
				this.arc4_0 = null;
				this.arc4_1 = null;
				IPAddress address = IPAddress.Parse(ip);
				this.ipendPoint_0 = new IPEndPoint(address, port);
				this.timer_3 = new System.Timers.Timer(20.0);
				this.timer_3.Elapsed += this.timer_3_Elapsed;
				this.timer_3.AutoReset = true;
				this.timer_0 = new System.Timers.Timer(20.0);
				this.timer_0.Elapsed += this.timer_0_Elapsed;
				this.timer_0.AutoReset = true;
				this.timer_1 = new System.Timers.Timer(15000.0);
				this.timer_1.Elapsed += this.timer_1_Elapsed;
				this.timer_1.AutoReset = true;
				this.timer_2 = new System.Timers.Timer(63000.0);
				this.timer_2.Elapsed += this.timer_2_Elapsed;
				this.timer_2.AutoReset = true;
				this.concurrentQueue_0 = new ConcurrentQueue<byte[]>();
			}
			catch (Exception ex)
			{
				throw new Exception("ctcp:" + ex.Message);
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x0015BEB8 File Offset: 0x0015BEB8
		private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MyTcp.int_1, 1) == 0)
			{
				try
				{
					if (this.tcpClient_0.Available > 0 && this.networkStream_0.CanRead)
					{
						byte[] array = new byte[8192];
						int num = this.networkStream_0.Read(array, 0, array.Length);
						if (num != 0)
						{
							byte[] bytes = array.Take(num).ToArray<byte>();
							if (this.arc4_1 != null)
							{
								this.arc4_1.decrypt(bytes);
							}
							MyTcp.OnRecieved onRecieved = this.onRecieved_0;
							if (onRecieved != null)
							{
								onRecieved(bytes);
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MyTcp.int_1, 0);
				}
			}
		}

		// Token: 0x06000092 RID: 146 RVA: 0x0015BF6C File Offset: 0x0015BF6C
		private void timer_3_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MyTcp.int_2, 1) == 0)
			{
				try
				{
					byte[] array;
					if (this.networkStream_0.CanWrite && this.concurrentQueue_0.TryDequeue(out array))
					{
						this.networkStream_0.Write(array, 0, array.Length);
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MyTcp.int_2, 0);
				}
			}
		}

		// Token: 0x06000093 RID: 147 RVA: 0x0015BFE0 File Offset: 0x0015BFE0
		private void timer_1_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MyTcp.int_3, 1) == 0)
			{
				try
				{
					if (this.bool_0)
					{
						this.Send(new byte[]
						{
							14,
							0,
							0,
							0,
							4,
							30,
							12,
							0,
							200,
							0,
							0,
							0,
							0,
							0
						});
					}
					else
					{
						this.Send(ProtoPacket.pack<PCS_APPing>(new PCS_APPing()));
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MyTcp.int_3, 0);
				}
			}
		}

		// Token: 0x06000094 RID: 148 RVA: 0x0015C05C File Offset: 0x0015C05C
		private void timer_2_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MyTcp.int_4, 1) == 0)
			{
				try
				{
					if (this.uid != 0u && this.sidnew != 0u)
					{
						try
						{
							List<uint> list = new List<uint>();
							list.Add(this.uid);
							PQueryUserInfoReq obj = new PQueryUserInfoReq
							{
								uidlist = list,
								topSid = this.sidnew,
								type = 0u
							};
							byte[] serverName = bytetool.String2Bytes("channelUserInfo");
							byte[] bytes = null;
							using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PQueryUserInfoReq>(obj)))
							{
								PContextField1 pcontextField = new PContextField1();
								pcontextField.f1 = this.sidnew;
								ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
								PAPRouter paprouter = new PAPRouter();
								paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
								paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
								paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
								paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
								paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
								paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
								paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
								paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
								paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
								MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
								mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
								MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
								mapExtentProp2.put(3u.ToString(), null);
								paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
								paprouter.m_ururi = protoPacket.getUri();
								bytes = ProtoPacket.pack<PAPRouter>(paprouter);
								byteArray.Dispose();
							}
							this.Send(bytes);
						}
						catch
						{
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MyTcp.int_4, 0);
				}
			}
		}

		// Token: 0x06000095 RID: 149 RVA: 0x001583D5 File Offset: 0x001583D5
		public void setarc(byte[] bytes)
		{
			if (this.arc4_0 == null)
			{
				this.arc4_0 = new ARC4(bytes, false);
				this.arc4_1 = new ARC4(bytes, true);
			}
		}

		// Token: 0x06000096 RID: 150 RVA: 0x0015C2C8 File Offset: 0x0015C2C8
		public void startheart()
		{
			this.timer_1.Enabled = true;
			this.timer_1.Start();
			this.timer_3.Interval = 1000.0;
			this.timer_0.Interval = 1000.0;
		}

		// Token: 0x06000097 RID: 151 RVA: 0x001583F9 File Offset: 0x001583F9
		public void stopheart()
		{
			this.timer_1.Enabled = false;
			this.timer_1.Stop();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x0015C314 File Offset: 0x0015C314
		public void Connect()
		{
			try
			{
				this.proxySocket_0.Connect(this.ipendPoint_0);
				if (this.proxySocket_0.Connected)
				{
					this.tcpClient_0 = new TcpClient();
					this.tcpClient_0.ReceiveTimeout = 3000;
					this.tcpClient_0.Client = this.proxySocket_0;
					this.networkStream_0 = this.tcpClient_0.GetStream();
					this.networkStream_0.BeginRead(this.byte_0, 0, this.byte_0.Length, new AsyncCallback(this.method_0), this.networkStream_0);
					this.timer_3.Enabled = true;
					this.timer_3.Start();
					MyTcp.OnConnected onConnected = this.onConnected_0;
					if (onConnected != null)
					{
						onConnected(true, false);
					}
				}
				else
				{
					MyTcp.OnConnected onConnected2 = this.onConnected_0;
					if (onConnected2 != null)
					{
						onConnected2(false, false);
					}
				}
			}
			catch
			{
				MyTcp.OnConnected onConnected3 = this.onConnected_0;
				if (onConnected3 != null)
				{
					onConnected3(false, false);
				}
			}
		}

		// Token: 0x06000099 RID: 153 RVA: 0x0015C410 File Offset: 0x0015C410
		private void method_0(IAsyncResult iasyncResult_0)
		{
			NetworkStream networkStream = (NetworkStream)iasyncResult_0.AsyncState;
			try
			{
				int num = networkStream.EndRead(iasyncResult_0);
				if (num > 0)
				{
					byte[] bytes = this.byte_0.Take(num).ToArray<byte>();
					if (this.arc4_1 != null)
					{
						this.arc4_1.decrypt(bytes);
					}
					MyTcp.OnRecieved onRecieved = this.onRecieved_0;
					if (onRecieved != null)
					{
						onRecieved(bytes);
					}
				}
				this.byte_0 = new byte[8192];
				networkStream.BeginRead(this.byte_0, 0, this.byte_0.Length, new AsyncCallback(this.method_0), networkStream);
			}
			catch
			{
			}
		}

		// Token: 0x0600009A RID: 154 RVA: 0x0015C4B4 File Offset: 0x0015C4B4
		public void Send(byte[] bytes)
		{
			try
			{
				if (this.arc4_0 != null)
				{
					this.arc4_0.encrypt(bytes);
				}
				this.concurrentQueue_0.Enqueue(bytes);
			}
			catch
			{
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0015C4F8 File Offset: 0x0015C4F8
		public void SendSync(byte[] bytes)
		{
			try
			{
				if (this.networkStream_0.CanWrite)
				{
					if (this.arc4_0 != null)
					{
						this.arc4_0.encrypt(bytes);
					}
					this.networkStream_0.Write(bytes, 0, bytes.Length);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0015C54C File Offset: 0x0015C54C
		protected virtual void Dispose(bool disposing)
		{
			if (!this.bool_1)
			{
				if (disposing)
				{
					try
					{
						this.timer_0.Enabled = false;
						this.timer_0.Stop();
						this.timer_0.Dispose();
					}
					catch
					{
					}
					try
					{
						this.timer_3.Enabled = false;
						this.timer_3.Stop();
						this.timer_3.Dispose();
					}
					catch
					{
					}
					try
					{
						this.timer_1.Enabled = false;
						this.timer_1.Stop();
						this.timer_1.Dispose();
					}
					catch
					{
					}
					try
					{
						this.timer_2.Enabled = false;
						this.timer_2.Stop();
						this.timer_2.Dispose();
					}
					catch
					{
					}
					try
					{
						this.tcpClient_0.GetStream().Close();
					}
					catch
					{
					}
					try
					{
						this.proxySocket_0.Close();
						this.proxySocket_0.Dispose();
					}
					catch
					{
					}
					try
					{
						this.tcpClient_0.Close();
					}
					catch
					{
					}
					this.arc4_0 = (this.arc4_1 = null);
				}
				this.bool_1 = true;
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00158412 File Offset: 0x00158412
		public void Dispose()
		{
			this.Dispose(true);
		}

		// Token: 0x04000064 RID: 100
		private bool bool_0;

		// Token: 0x04000065 RID: 101
		private TcpClient tcpClient_0;

		// Token: 0x04000066 RID: 102
		private ARC4 arc4_0;

		// Token: 0x04000067 RID: 103
		private ARC4 arc4_1;

		// Token: 0x04000068 RID: 104
		private IPEndPoint ipendPoint_0;

		// Token: 0x04000069 RID: 105
		private ProxySocket proxySocket_0;

		// Token: 0x0400006A RID: 106
		private NetworkStream networkStream_0;

		// Token: 0x0400006B RID: 107
		private System.Timers.Timer timer_0;

		// Token: 0x0400006C RID: 108
		private System.Timers.Timer timer_1;

		// Token: 0x0400006D RID: 109
		private System.Timers.Timer timer_2;

		// Token: 0x0400006E RID: 110
		private System.Timers.Timer timer_3;

		// Token: 0x0400006F RID: 111
		[CompilerGenerated]
		private MyTcp.OnConnected onConnected_0;

		// Token: 0x04000070 RID: 112
		[CompilerGenerated]
		private MyTcp.OnRecieved onRecieved_0;

		// Token: 0x04000071 RID: 113
		[CompilerGenerated]
		private MyTcp.OnHeart onHeart_0;

		// Token: 0x04000072 RID: 114
		private volatile int int_0;

		// Token: 0x04000073 RID: 115
		public uint uid;

		// Token: 0x04000074 RID: 116
		public uint sidnew;

		// Token: 0x04000075 RID: 117
		private ConcurrentQueue<byte[]> concurrentQueue_0;

		// Token: 0x04000076 RID: 118
		private byte[] byte_0;

		// Token: 0x04000077 RID: 119
		private static int int_1;

		// Token: 0x04000078 RID: 120
		private static int int_2;

		// Token: 0x04000079 RID: 121
		private static int int_3;

		// Token: 0x0400007A RID: 122
		private static int int_4;

		// Token: 0x0400007B RID: 123
		private bool bool_1;

		// Token: 0x02000017 RID: 23
		// (Invoke) Token: 0x060000A0 RID: 160
		public delegate void OnConnected(bool issuccess, bool iszhongduan = false);

		// Token: 0x02000018 RID: 24
		// (Invoke) Token: 0x060000A4 RID: 164
		public delegate void OnRecieved(byte[] bytes);

		// Token: 0x02000019 RID: 25
		// (Invoke) Token: 0x060000A8 RID: 168
		public delegate void OnHeart();
	}
}
