﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using JIQIMAO.Common;
using JIQIMAO.Model.YYModel;
using Newtonsoft.Json;
using Org.Mentalis.Network.ProxySocket;

namespace JIQIMAO.Model
{
	// Token: 0x0200001F RID: 31
	public class MyUser
	{
		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000CF RID: 207 RVA: 0x0015843F File Offset: 0x0015843F
		// (set) Token: 0x060000D0 RID: 208 RVA: 0x00158447 File Offset: 0x00158447
		public int index { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000D1 RID: 209 RVA: 0x00158450 File Offset: 0x00158450
		// (set) Token: 0x060000D2 RID: 210 RVA: 0x00158458 File Offset: 0x00158458
		public int id { get; set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000D3 RID: 211 RVA: 0x00158461 File Offset: 0x00158461
		// (set) Token: 0x060000D4 RID: 212 RVA: 0x00158469 File Offset: 0x00158469
		public string passport { get; set; }

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000D5 RID: 213 RVA: 0x00158472 File Offset: 0x00158472
		// (set) Token: 0x060000D6 RID: 214 RVA: 0x0015847A File Offset: 0x0015847A
		public string pwd { get; set; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000D7 RID: 215 RVA: 0x00158483 File Offset: 0x00158483
		// (set) Token: 0x060000D8 RID: 216 RVA: 0x0015848B File Offset: 0x0015848B
		public string pwden { get; set; }

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000D9 RID: 217 RVA: 0x00158494 File Offset: 0x00158494
		// (set) Token: 0x060000DA RID: 218 RVA: 0x0015849C File Offset: 0x0015849C
		public int logintype { get; set; }

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000DB RID: 219 RVA: 0x001584A5 File Offset: 0x001584A5
		// (set) Token: 0x060000DC RID: 220 RVA: 0x001584AD File Offset: 0x001584AD
		public bool isfenghao { get; set; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000DD RID: 221 RVA: 0x001584B6 File Offset: 0x001584B6
		// (set) Token: 0x060000DE RID: 222 RVA: 0x001584BE File Offset: 0x001584BE
		public int loginstatus { get; set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000DF RID: 223 RVA: 0x001584C7 File Offset: 0x001584C7
		// (set) Token: 0x060000E0 RID: 224 RVA: 0x001584CF File Offset: 0x001584CF
		public int joinstatus { get; set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000E1 RID: 225 RVA: 0x001584D8 File Offset: 0x001584D8
		// (set) Token: 0x060000E2 RID: 226 RVA: 0x001584E0 File Offset: 0x001584E0
		public int status { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000E3 RID: 227 RVA: 0x0015CF60 File Offset: 0x0015CF60
		public string statusstr
		{
			get
			{
				if (this.isfenghao)
				{
					if (this.status != 33)
					{
						return "封号";
					}
					if (this.mytrace == "MMCW")
					{
						return "密码错误";
					}
					return "频道不存在";
				}
				else
				{
					if (this.status == 0)
					{
						return "";
					}
					return this.status.ToString();
				}
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060000E4 RID: 228 RVA: 0x001584E9 File Offset: 0x001584E9
		// (set) Token: 0x060000E5 RID: 229 RVA: 0x001584F1 File Offset: 0x001584F1
		public uint uid { get; set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000E6 RID: 230 RVA: 0x001584FA File Offset: 0x001584FA
		// (set) Token: 0x060000E7 RID: 231 RVA: 0x00158502 File Offset: 0x00158502
		public string username { get; set; }

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x060000E8 RID: 232 RVA: 0x0015850B File Offset: 0x0015850B
		// (set) Token: 0x060000E9 RID: 233 RVA: 0x00158513 File Offset: 0x00158513
		public string qianming { get; set; }

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x060000EA RID: 234 RVA: 0x0015851C File Offset: 0x0015851C
		// (set) Token: 0x060000EB RID: 235 RVA: 0x00158524 File Offset: 0x00158524
		public uint sid { get; set; }

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x060000EC RID: 236 RVA: 0x0015852D File Offset: 0x0015852D
		// (set) Token: 0x060000ED RID: 237 RVA: 0x00158535 File Offset: 0x00158535
		public uint subid { get; set; }

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x060000EE RID: 238 RVA: 0x0015853E File Offset: 0x0015853E
		// (set) Token: 0x060000EF RID: 239 RVA: 0x00158546 File Offset: 0x00158546
		public uint sidnew { get; set; }

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x060000F0 RID: 240 RVA: 0x0015854F File Offset: 0x0015854F
		// (set) Token: 0x060000F1 RID: 241 RVA: 0x00158557 File Offset: 0x00158557
		public uint subidnew { get; set; }

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x060000F2 RID: 242 RVA: 0x00158560 File Offset: 0x00158560
		// (set) Token: 0x060000F3 RID: 243 RVA: 0x00158568 File Offset: 0x00158568
		public string nicheng { get; set; }

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x060000F4 RID: 244 RVA: 0x00158571 File Offset: 0x00158571
		// (set) Token: 0x060000F5 RID: 245 RVA: 0x00158579 File Offset: 0x00158579
		public IOCPClient logintcp { get; set; }

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060000F6 RID: 246 RVA: 0x00158582 File Offset: 0x00158582
		// (set) Token: 0x060000F7 RID: 247 RVA: 0x0015858A File Offset: 0x0015858A
		public IOCPClient servicetcp { get; set; }

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060000F8 RID: 248 RVA: 0x00158593 File Offset: 0x00158593
		// (set) Token: 0x060000F9 RID: 249 RVA: 0x0015859B File Offset: 0x0015859B
		public string apip { get; set; }

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060000FA RID: 250 RVA: 0x001585A4 File Offset: 0x001585A4
		// (set) Token: 0x060000FB RID: 251 RVA: 0x001585AC File Offset: 0x001585AC
		public int apport { get; set; }

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060000FC RID: 252 RVA: 0x001585B5 File Offset: 0x001585B5
		// (set) Token: 0x060000FD RID: 253 RVA: 0x001585BD File Offset: 0x001585BD
		public int heartbeat { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060000FE RID: 254 RVA: 0x001585C6 File Offset: 0x001585C6
		// (set) Token: 0x060000FF RID: 255 RVA: 0x001585CE File Offset: 0x001585CE
		public ProxyTypes pt { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000100 RID: 256 RVA: 0x001585D7 File Offset: 0x001585D7
		// (set) Token: 0x06000101 RID: 257 RVA: 0x001585DF File Offset: 0x001585DF
		public string daili { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000102 RID: 258 RVA: 0x001585E8 File Offset: 0x001585E8
		public string dailistr
		{
			get
			{
				if (this.logintype == 1)
				{
					return "";
				}
				return this.daili;
			}
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000103 RID: 259 RVA: 0x001585FF File Offset: 0x001585FF
		// (set) Token: 0x06000104 RID: 260 RVA: 0x00158607 File Offset: 0x00158607
		public string yanzhengma { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x06000105 RID: 261 RVA: 0x00158610 File Offset: 0x00158610
		// (set) Token: 0x06000106 RID: 262 RVA: 0x00158618 File Offset: 0x00158618
		public int currentflag { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000107 RID: 263 RVA: 0x00158621 File Offset: 0x00158621
		// (set) Token: 0x06000108 RID: 264 RVA: 0x00158629 File Offset: 0x00158629
		public bool isinqueue { get; set; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x06000109 RID: 265 RVA: 0x00158632 File Offset: 0x00158632
		// (set) Token: 0x0600010A RID: 266 RVA: 0x0015863A File Offset: 0x0015863A
		public bool isudblogin { get; set; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600010B RID: 267 RVA: 0x00158643 File Offset: 0x00158643
		// (set) Token: 0x0600010C RID: 268 RVA: 0x0015864B File Offset: 0x0015864B
		public byte[] yycookie { get; set; }

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600010D RID: 269 RVA: 0x00158654 File Offset: 0x00158654
		// (set) Token: 0x0600010E RID: 270 RVA: 0x0015865C File Offset: 0x0015865C
		public string mytrace { get; set; }

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x0600010F RID: 271 RVA: 0x00158665 File Offset: 0x00158665
		// (set) Token: 0x06000110 RID: 272 RVA: 0x0015866D File Offset: 0x0015866D
		public int jointimes { get; set; }

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000111 RID: 273 RVA: 0x00158676 File Offset: 0x00158676
		// (set) Token: 0x06000112 RID: 274 RVA: 0x0015867E File Offset: 0x0015867E
		public string loseconreason { get; set; }

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000113 RID: 275 RVA: 0x00158687 File Offset: 0x00158687
		// (set) Token: 0x06000114 RID: 276 RVA: 0x0015868F File Offset: 0x0015868F
		public DateTime startlogintime { get; set; }

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000115 RID: 277 RVA: 0x00158698 File Offset: 0x00158698
		// (set) Token: 0x06000116 RID: 278 RVA: 0x001586A0 File Offset: 0x001586A0
		public DateTime weblogintime { get; set; }

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000117 RID: 279 RVA: 0x001586A9 File Offset: 0x001586A9
		// (set) Token: 0x06000118 RID: 280 RVA: 0x001586B1 File Offset: 0x001586B1
		public DateTime startjointime { get; set; }

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x06000119 RID: 281 RVA: 0x001586BA File Offset: 0x001586BA
		// (set) Token: 0x0600011A RID: 282 RVA: 0x001586C2 File Offset: 0x001586C2
		public DateTime joinchanneltime { get; set; }

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x0600011B RID: 283 RVA: 0x001586CB File Offset: 0x001586CB
		// (set) Token: 0x0600011C RID: 284 RVA: 0x001586D3 File Offset: 0x001586D3
		public DateTime lasthearttime { get; set; }

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x0600011D RID: 285 RVA: 0x001586DC File Offset: 0x001586DC
		// (set) Token: 0x0600011E RID: 286 RVA: 0x001586E4 File Offset: 0x001586E4
		public DateTime lastsendhearttime { get; set; }

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x0600011F RID: 287 RVA: 0x001586ED File Offset: 0x001586ED
		// (set) Token: 0x06000120 RID: 288 RVA: 0x001586F5 File Offset: 0x001586F5
		public DateTime lastsendtime { get; set; }

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000121 RID: 289 RVA: 0x001586FE File Offset: 0x001586FE
		// (set) Token: 0x06000122 RID: 290 RVA: 0x00158706 File Offset: 0x00158706
		public DateTime buhaotime { get; set; }

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000123 RID: 291 RVA: 0x0015870F File Offset: 0x0015870F
		// (set) Token: 0x06000124 RID: 292 RVA: 0x00158717 File Offset: 0x00158717
		public DateTime checkinchaneltime { get; set; }

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000125 RID: 293 RVA: 0x00158720 File Offset: 0x00158720
		// (set) Token: 0x06000126 RID: 294 RVA: 0x00158728 File Offset: 0x00158728
		public DateTime lastonlinetime { get; set; }

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000127 RID: 295 RVA: 0x00158731 File Offset: 0x00158731
		// (set) Token: 0x06000128 RID: 296 RVA: 0x00158739 File Offset: 0x00158739
		public DateTime startloginservicetime { get; set; }

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000129 RID: 297 RVA: 0x0015CFC0 File Offset: 0x0015CFC0
		public string mcki
		{
			get
			{
				if (this.lasthearttime == DateTime.MinValue)
				{
					return "";
				}
				return this.lasthearttime.ToString("HHmm");
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x0600012A RID: 298 RVA: 0x0015CFF8 File Offset: 0x0015CFF8
		public string lol
		{
			get
			{
				if (this.lastonlinetime == DateTime.MinValue)
				{
					return "";
				}
				return this.lastonlinetime.ToString("HHmm");
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600012B RID: 299 RVA: 0x00158742 File Offset: 0x00158742
		// (set) Token: 0x0600012C RID: 300 RVA: 0x0015874A File Offset: 0x0015874A
		public bool isgongneng { get; set; }

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600012D RID: 301 RVA: 0x00158753 File Offset: 0x00158753
		// (set) Token: 0x0600012E RID: 302 RVA: 0x0015875B File Offset: 0x0015875B
		public bool isxianche { get; set; }

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600012F RID: 303 RVA: 0x00158764 File Offset: 0x00158764
		// (set) Token: 0x06000130 RID: 304 RVA: 0x0015876C File Offset: 0x0015876C
		public bool isqutubiao { get; set; }

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000131 RID: 305 RVA: 0x00158775 File Offset: 0x00158775
		// (set) Token: 0x06000132 RID: 306 RVA: 0x0015877D File Offset: 0x0015877D
		public bool isloginservice { get; set; }

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000133 RID: 307 RVA: 0x00158786 File Offset: 0x00158786
		// (set) Token: 0x06000134 RID: 308 RVA: 0x0015878E File Offset: 0x0015878E
		public string serviceip { get; set; }

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000135 RID: 309 RVA: 0x00158797 File Offset: 0x00158797
		// (set) Token: 0x06000136 RID: 310 RVA: 0x0015879F File Offset: 0x0015879F
		public int serviceport { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000137 RID: 311 RVA: 0x001587A8 File Offset: 0x001587A8
		// (set) Token: 0x06000138 RID: 312 RVA: 0x001587B0 File Offset: 0x001587B0
		public DateTime lastservicehearttime { get; set; }

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x06000139 RID: 313 RVA: 0x0015D030 File Offset: 0x0015D030
		// (remove) Token: 0x0600013A RID: 314 RVA: 0x0015D068 File Offset: 0x0015D068
		public event MyUser.OnGetUserCount GetUserCountEvent
		{
			[CompilerGenerated]
			add
			{
				MyUser.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser.OnGetUserCount value2 = (MyUser.OnGetUserCount)Delegate.Combine(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
			[CompilerGenerated]
			remove
			{
				MyUser.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
				MyUser.OnGetUserCount onGetUserCount2;
				do
				{
					onGetUserCount2 = onGetUserCount;
					MyUser.OnGetUserCount value2 = (MyUser.OnGetUserCount)Delegate.Remove(onGetUserCount2, value);
					onGetUserCount = Interlocked.CompareExchange<MyUser.OnGetUserCount>(ref this.onGetUserCount_0, value2, onGetUserCount2);
				}
				while (onGetUserCount != onGetUserCount2);
			}
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0015D0A0 File Offset: 0x0015D0A0
		public void SendSH()
		{
			try
			{
				byte[] data = new byte[]
				{
					14,
					0,
					0,
					0,
					4,
					30,
					12,
					0,
					200,
					0,
					0,
					0,
					0,
					0
				};
				this.servicetcp.Send(data);
				this.lastservicehearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x0600013C RID: 316 RVA: 0x0015D0EC File Offset: 0x0015D0EC
		public MyUser()
		{
			DateTime joinchanneltime = this.lasthearttime = DateTime.MinValue;
			DateTime startjointime = this.joinchanneltime = joinchanneltime;
			DateTime weblogintime = this.startjointime = startjointime;
			DateTime startlogintime = this.weblogintime = weblogintime;
			DateTime lastservicehearttime = this.startlogintime = startlogintime;
			DateTime lastsendtime = this.lastservicehearttime = lastservicehearttime;
			DateTime buhaotime = this.lastsendtime = lastsendtime;
			DateTime checkinchaneltime = this.buhaotime = buhaotime;
			DateTime lastonlinetime = this.checkinchaneltime = checkinchaneltime;
			DateTime startloginservicetime = this.lastonlinetime = lastonlinetime;
			this.lastsendhearttime = (this.startloginservicetime = startloginservicetime);
			this.isxianche = false;
			this.isqutubiao = false;
			this.isudblogin = false;
			this.isfenghao = false;
			this.isloginservice = false;
			this.isinqueue = false;
			this.isgongneng = false;
			this.currentflag = 10000;
			string yanzhengma = this.username = "";
			string mytrace = this.yanzhengma = yanzhengma;
			this.daili = (this.mytrace = mytrace);
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0015D21C File Offset: 0x0015D21C
		public void resend()
		{
			try
			{
				if (this.lastsendtime != DateTime.MinValue && this.lastsendtime.AddSeconds(3.0) < DateTime.Now)
				{
					this.lastsendtime = DateTime.Now;
					if (this.currentflag >= 20001 && this.currentflag < 21000)
					{
						this.method_3();
					}
					else if (this.currentflag >= 40001 && this.currentflag < 41000)
					{
						this.method_8();
					}
					else if (this.currentflag >= 50001 && this.currentflag < 51000)
					{
						this.Send_0BD0_0307();
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0015D2E8 File Offset: 0x0015D2E8
		public void join()
		{
			try
			{
				if (this.logintype == 2)
				{
					this.pt = ProxyTypes.None;
					this.daili = "";
				}
				else if (this.logintype == 1 && this.isudblogin)
				{
					this.pt = ProxyTypes.None;
					this.daili = "";
				}
				this.heartbeat = 0;
				this.isinqueue = false;
				this.startjointime = DateTime.Now;
				this.currentflag = rdomhelper.getrandom(10001, 11000);
				this.logintcp = new IOCPClient(this.apip, this.apport, false, this.daili, this.pt);
				this.logintcp.ConnectedEvent += this.OnConnected;
				this.logintcp.RecievedEvent += this.method_0;
				this.logintcp.Connect();
			}
			catch
			{
				this.joinstatus = 0;
			}
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0015D3DC File Offset: 0x0015D3DC
		public void OnConnected(bool issuccess, bool iszhongduan = false)
		{
			if (!issuccess)
			{
				try
				{
					if (this.status != 0)
					{
						this.status = 1;
					}
					this.joinstatus = 0;
					this.currentflag = 10000;
					this.isinqueue = false;
					this.heartbeat = 0;
					this.isloginservice = false;
					this.startjointime = DateTime.MinValue;
					this.lastonlinetime = DateTime.MinValue;
					try
					{
						this.logintcp.ConnectedEvent -= this.OnConnected;
						this.logintcp.RecievedEvent -= this.method_0;
					}
					catch
					{
					}
					if (iszhongduan)
					{
						this.isudblogin = false;
						this.checkinchaneltime = DateTime.MinValue;
					}
					if (this.logintcp != null)
					{
						this.logintcp.DisConnect();
					}
					if (this.servicetcp != null)
					{
						try
						{
							this.servicetcp.ConnectedEvent -= this.OnConnected;
							this.servicetcp.RecievedEvent -= this.method_0;
						}
						catch
						{
						}
						this.servicetcp.DisConnect();
					}
					return;
				}
				catch
				{
					return;
				}
			}
			this.method_3();
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0015D510 File Offset: 0x0015D510
		private void method_0(byte[] byte_1)
		{
			try
			{
				if (byte_1[8] == 200 && byte_1[9] == 0)
				{
					this.byteArray_0 = null;
					this.byteArray_0 = new ByteArray();
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						this.int_11 = byteArray.ReadInt();
					}
					this.byteArray_0.writeBytes(byte_1);
				}
				else if (this.byteArray_0 != null && this.byteArray_0.length > 0 && this.byteArray_0.length < this.int_11)
				{
					this.byteArray_0.writeBytes(byte_1);
				}
				if (this.byteArray_0 != null && this.byteArray_0.length >= this.int_11)
				{
					this.int_11 = 0;
					this.method_2(this.byteArray_0.Buffer);
				}
			}
			catch
			{
				this.byteArray_0 = null;
				this.int_11 = 0;
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x00158048 File Offset: 0x00158048
		private void method_1()
		{
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0015D604 File Offset: 0x0015D604
		private void method_2(byte[] byte_1)
		{
			try
			{
				if (byte_1 != null && byte_1.Length >= 10 && byte_1[8] == 200)
				{
					string text = bytetool.fromArray(byte_1, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2) && !(text2 == "1E74"))
					{
						if (!(text2 == "0412") && !(text2 == "0415") && !(text2 == "0287") && !(text2 == "0433"))
						{
							if (text2 == "04E5")
							{
								this.method_7(byte_1);
							}
							else if (text2 == "04D7")
							{
								this.method_9(byte_1);
							}
							else if (text2 == "0422")
							{
								this.mytrace = "FO";
								this.OnConnected(false, true);
								this.isudblogin = false;
							}
							else if (text2 == "0BD0")
							{
								string text3;
								string a;
								try
								{
									text3 = text.Substring(24, 4).ToUpper();
									a = text.Substring(24, 6).ToUpper();
								}
								catch
								{
									return;
								}
								if (text3 == "1E74")
								{
									this.Recv_Service_1E74(byte_1);
								}
								else if (text3 == "0308")
								{
									this.method_10(byte_1);
								}
								else if (!(text3 == "0868"))
								{
									if (text3 == "0242" && a == "02421F")
									{
										this.method_11(byte_1);
									}
									else if (!(text3 == "0302"))
									{
										if (!(text3 == "024D") && !(text3 == "0235") && !(text3 == "0240") && !(text3 == "020C") && !(text3 == "0422"))
										{
											if (text3 == "022C")
											{
												this.mytrace = "YDD";
											}
											else if (!(text3 == "0239"))
											{
												if (text3 == "041F")
												{
													this.method_12(byte_1);
												}
												else if (text3 == "02D1")
												{
													this.method_13(byte_1);
												}
												else if (text3 == "02B1")
												{
													this.method_14(byte_1);
												}
												else if (text3 == "02B3")
												{
													this.checkinchaneltime = DateTime.Now;
												}
												else if (text3 == "02B5")
												{
													this.method_15(byte_1);
												}
												else if (text3 == "0248")
												{
													this.OnConnected(false, true);
												}
											}
										}
										else
										{
											this.loseconreason = "KO:" + text3;
											this.OnConnected(false, true);
											this.isudblogin = false;
										}
									}
								}
							}
							else if (text2 == "041F")
							{
								this.method_12(byte_1);
							}
							else if (text2 == "024D" || text2 == "0235" || text2 == "0240" || text2 == "020C")
							{
								this.loseconreason = "OKO:" + text2;
								this.OnConnected(false, true);
							}
						}
						else
						{
							this.method_4(byte_1);
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0015D9B0 File Offset: 0x0015D9B0
		private void method_3()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(20001, 21000);
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] data = ProtoPacket.pack<PExchangeKeyExt>(new PExchangeKeyExt(publicKey, exponent));
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0015DA24 File Offset: 0x0015DA24
		private void method_4(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 30000)
				{
					byte[] array = null;
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
						if (num != 0u)
						{
							using (ByteArray byteArray2 = new ByteArray())
							{
								protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
								array = byteArray2.Buffer;
								byteArray2.Dispose();
							}
						}
						byteArray.Dispose();
					}
					if (array == null || array.Length == 0)
					{
						throw new Exception("rsa fail");
					}
					byte[] array2 = rsautil.getInstance().decrypt(array);
					if (array2 == null)
					{
						throw new Exception("DEC");
					}
					this.logintcp.setarc(array2);
					if (this.logintype == 1)
					{
						if (this.isudblogin)
						{
							this.method_8();
						}
						else
						{
							this.method_5(false, null, null);
						}
					}
					else
					{
						this.method_6();
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0015DB40 File Offset: 0x0015DB40
		private void method_5(bool bool_6 = false, byte[] byte_1 = null, byte[] byte_2 = null)
		{
			try
			{
				if (!bool_6)
				{
					this.currentflag = rdomhelper.getrandom(30001, 31000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(31000, 32000);
				}
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 1u;
				udbyyloginReq._user = bytetool.String2Bytes(this.passport);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				string s = xxtea2.Encrypt(sha1.hash(this.pwd, Encoding.ASCII).ToLower(), (this.passport + "275d0ff676c0d65114acdefbd2ad87a3").Substring(0, 16));
				udbyyloginReq._user_token = Convert.FromBase64String(s);
				if (bool_6)
				{
					udbyyloginReq._pic_id = byte_1;
					int imageType = 1;
					using (MemoryStream memoryStream = new MemoryStream(byte_2))
					{
						ImageFormat rawFormat = Image.FromStream(memoryStream).RawFormat;
						if (rawFormat.Equals(ImageFormat.Jpeg))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Png))
						{
							imageType = 4;
						}
						else if (rawFormat.Equals(ImageFormat.Bmp))
						{
							imageType = 1;
						}
						else if (rawFormat.Equals(ImageFormat.Gif))
						{
							imageType = 2;
						}
						else if (rawFormat.Equals(ImageFormat.Icon))
						{
							imageType = 5;
						}
					}
					string text = this.yanzhengma = imagetool.CreateInstance().hqCode(byte_2, imageType);
					string s2 = text;
					udbyyloginReq._pic_code = Encoding.UTF8.GetBytes(s2);
				}
				byte[] data = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0015DD4C File Offset: 0x0015DD4C
		private void method_6()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(30001, 31000);
				UDBYYLoginReq udbyyloginReq = new UDBYYLoginReq();
				udbyyloginReq._appid = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._user_token_type = 9u;
				udbyyloginReq._user = bytetool.String2Bytes(this.username);
				udbyyloginReq._ver_str = bytetool.String2Bytes("yymwebflsh");
				udbyyloginReq._ver_int = uint.MaxValue;
				udbyyloginReq._terminal_type = new MyUInt64(2u, 0u);
				udbyyloginReq._apptype = 6u;
				udbyyloginReq._lcid = 2052u;
				udbyyloginReq._user_token = ProtoPacket.packNoHeader<CombAcctinfo>(new CombAcctinfo
				{
					acctinfo = bytetool.String2Bytes(this.pwden),
					appid_type = bytetool.String2Bytes("yycomscene")
				});
				byte[] data = ProtoPacket.pack<PCS_CliAPLoginAuth2>(new PCS_CliAPLoginAuth2
				{
					ruri = 2281u,
					payLoad = ProtoPacket.packNoHeader<UDBYYLoginReq>(udbyyloginReq)
				});
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0015DE54 File Offset: 0x0015DE54
		private void method_7(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 40000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_CliAPLoginAuth2Res pcs_CliAPLoginAuth2Res = new PCS_CliAPLoginAuth2Res();
						pcs_CliAPLoginAuth2Res.unmarshall(protoPacket.getBuffer());
						if (pcs_CliAPLoginAuth2Res.rescode != 200u)
						{
							throw new Exception(pcs_CliAPLoginAuth2Res.rescode.ToString());
						}
						protoPacket = ProtoPacket.unpackNoHeader(pcs_CliAPLoginAuth2Res.payLoad, pcs_CliAPLoginAuth2Res.ruri, pcs_CliAPLoginAuth2Res.rescode);
						UDBYYLoginRes udbyyloginRes = new UDBYYLoginRes();
						LoginData loginData = new LoginData();
						udbyyloginRes.unmarshall(protoPacket.getBuffer());
						if (udbyyloginRes._rescode == 18u)
						{
							this.isfenghao = true;
							this.status = 3;
						}
						else
						{
							string @string = Encoding.UTF8.GetString(udbyyloginRes._reason);
							if (!(@string.ToLower() == "success"))
							{
								if (@string.ToLower() == "user frozen")
								{
									throw new Exception("UF");
								}
								if (!(@string.ToLower() == "static_verify") && !(@string.ToLower() == "invalid piccode"))
								{
									if (!@string.Contains("invalid user"))
									{
										throw new Exception(@string);
									}
									this.OnConnected(false, false);
									this.mytrace = "MMCW";
									this.status = 33;
									this.isfenghao = true;
									this.joinstatus = 0;
								}
								else
								{
									this.mytrace = "YZM";
									this.method_5(true, udbyyloginRes._pic_id, udbyyloginRes._pic_data);
								}
							}
							else
							{
								using (ByteArray byteArray2 = new ByteArray(udbyyloginRes._login_data))
								{
									loginData.unmarshall(byteArray2);
									byteArray2.Dispose();
								}
								this.username = Encoding.UTF8.GetString(loginData._passport);
								this.yycookie = loginData._yycookie;
								this.uid = udbyyloginRes._yyuid.low;
								string cookie = Hex.fromArray(new ByteArray(this.yycookie), false);
								if (this.logintype == 1)
								{
									savepcbuser savepcbuser = new savepcbuser();
									savepcbuser.username = this.username;
									savepcbuser.cookie = cookie;
									savepcbuser.uid = this.uid.ToString();
									try
									{
										string msg = MyEncrypt.AesEncryptor(JsonConvert.SerializeObject(savepcbuser));
										logtool.logusercache_p(this.passport, msg);
									}
									catch
									{
									}
								}
								if (this.logintype == 1 && !this.isudblogin && this.pt != ProxyTypes.None)
								{
									this.isudblogin = true;
									this.OnConnected(false, false);
									this.joinstatus = -1;
									goto IL_280;
								}
								this.method_8();
							}
							byteArray.Dispose();
						}
						IL_280:;
					}
				}
			}
			catch (Exception ex)
			{
				this.mytrace = ex.Message;
			}
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0015E164 File Offset: 0x0015E164
		private void method_8()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(40001, 41000);
				byte[] data = (this.logintype != 1) ? ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
				{
					m_strAccount = bytetool.String2Bytes(this.username),
					m_strPassword = bytetool.String2Bytes(this.pwden),
					m_bRelogin = (this.currentflag == 40005),
					m_uAppID = 259u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					},
					m_strCookie = this.yycookie,
					m_uCliType = 2u,
					m_strFrom = bytetool.String2Bytes("yymwebflsh"),
					m_strCliVer = bytetool.String2Bytes("yymwebflsh")
				}) : ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
				{
					m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower()),
					m_bRelogin = false,
					m_uAppID = 259u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					},
					m_strCookie = this.yycookie,
					m_strAccount = Encoding.UTF8.GetBytes(this.username),
					m_uCliType = 2u,
					m_strFrom = bytetool.String2Bytes("8.45.0.0"),
					m_strCliVer = bytetool.String2Bytes("8.45.0.0")
				});
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0015E300 File Offset: 0x0015E300
		private void method_9(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 50000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
						PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
						pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
						byteArray.Dispose();
						if (pcs_APLoginRes.m_uResCode != 200u)
						{
							if (this.logintype == 1)
							{
								this.isudblogin = false;
							}
							throw new Exception(pcs_APLoginRes.m_uResCode.ToString());
						}
						this.Send_0BD0_0307();
					}
				}
			}
			catch (Exception)
			{
				if (this.logintype == 1)
				{
					logtool.delusercache_p(this.passport);
					this.isudblogin = false;
				}
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0015E3C4 File Offset: 0x0015E3C4
		public void Send_0BD0_0307()
		{
			try
			{
				this.currentflag = rdomhelper.getrandom(50001, 51000);
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.method_2(0);
					byteArray.writeUnsignedInt(this.uid);
					byte[] array2 = bytetool.strToToHexByte(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					byteArray.method_2(array2.Length);
					byteArray.writeBytes(array2);
					byteArray.method_2(0);
					array = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array3 = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeBytes(bytetool.strToToHexByte("08000001030700001000000203010000"));
					byteArray2.writeUnsignedInt(this.uid);
					byteArray2.writeBytes(bytetool.strToToHexByte("0000000015000006DCCC1B00120B00000000050055496E666F1200000701000000010000000400000000001E0000081800030000000000000001003201000000010030030000000000787878FF"));
					array3 = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] data = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003070000C800"));
					byteArray3.method_2(array.Length);
					byteArray3.writeBytes(array);
					byteArray3.method_2(array3.Length);
					byteArray3.writeBytes(array3);
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					data = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0015E5BC File Offset: 0x0015E5BC
		private void method_10(byte[] byte_1)
		{
			try
			{
				if (this.currentflag <= 60000)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						int num = (int)byteArray.readUnsignedInt();
						c_Data[] array = new c_Data[num];
						for (int i = 0; i < num; i++)
						{
							array[i] = new c_Data();
							array[i].intd = (int)byteArray.readUnsignedShort();
							ushort num2 = byteArray.readUnsignedShort();
							array[i].Data = new byte[(int)num2];
							for (int j = 0; j < (int)num2; j++)
							{
								array[i].Data[j] = byteArray.readByte();
							}
							if (array[i].intd == 2)
							{
								this.nicheng = Encoding.UTF8.GetString(array[i].Data);
							}
						}
						byteArray.Dispose();
					}
					this.currentflag = rdomhelper.getrandom(60001, 61000);
					this.isinqueue = true;
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0015E6E8 File Offset: 0x0015E6E8
		public void Send_0BD0_02411F(bool ismuti = false)
		{
			try
			{
				if (ismuti)
				{
					this.currentflag = rdomhelper.getrandom(70001, 71000);
				}
				else
				{
					this.currentflag = rdomhelper.getrandom(60001, 61000);
				}
				PJoinChannelReq pjoinChannelReq = new PJoinChannelReq();
				pjoinChannelReq.uid = this.uid;
				pjoinChannelReq.topsid = this.sid;
				pjoinChannelReq.subSid = this.subid;
				MYHashMap props = pjoinChannelReq.props;
				props.put(2u.ToString(), bytetool.String2Bytes("0"));
				if (ismuti)
				{
					MYHashMap props2 = pjoinChannelReq.props;
					props2.put(3u.ToString(), bytetool.String2Bytes("1"));
				}
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PJoinChannelReq>(pjoinChannelReq)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
				this.lastsendtime = DateTime.Now;
				this.buhaotime = DateTime.Now;
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0015E978 File Offset: 0x0015E978
		private void method_11(byte[] byte_1)
		{
			try
			{
				if (this.status != 2)
				{
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						if (byte_1[8] != 200)
						{
							throw new Exception("ERR");
						}
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						byteArray.readUnsignedShort();
						byteArray.readUnsignedInt();
						uint num = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint subidnew = byteArray.readUnsignedInt();
						uint num2 = byteArray.readUnsignedInt();
						byteArray.readUnsignedInt();
						uint num3 = (uint)byteArray.readByte();
						if (num3 <= 7u)
						{
							if (num3 != 4u)
							{
								if (num3 == 7u)
								{
									this.mytrace = "M-J";
									this.Send_0BD0_02411F(true);
									goto IL_230;
								}
							}
							else
							{
								if (this.sid != num2 && this.sid != num)
								{
									this.mytrace = "GOON";
									goto IL_230;
								}
								this.mytrace = "SUC";
								this.currentflag = rdomhelper.getrandom(90001, 91000);
								this.joinchanneltime = DateTime.Now;
								this.lasthearttime = DateTime.Now;
								this.checkinchaneltime = DateTime.Now;
								this.joinstatus = 2;
								this.status = 2;
								this.isinqueue = false;
								int jointimes = this.jointimes;
								this.jointimes = jointimes + 1;
								if (this.sidnew == 0u)
								{
									this.sidnew = num;
								}
								if (this.subidnew == 0u)
								{
									this.subidnew = subidnew;
								}
								if (this.isgongneng)
								{
									this.Send_Service_1E73();
								}
								if (this.logintcp != null)
								{
									this.logintcp.startheart();
									goto IL_230;
								}
								goto IL_230;
							}
						}
						else if (num3 != 11u)
						{
							if (num3 == 12u)
							{
								this.OnConnected(false, false);
								this.isfenghao = true;
								this.status = 33;
								this.mytrace = "频道不存在";
								goto IL_230;
							}
						}
						else
						{
							this.mytrace = "Y-J";
							this.currentflag = rdomhelper.getrandom(98001, 99000);
							this.joinchanneltime = DateTime.Now;
							this.lasthearttime = DateTime.Now;
							this.checkinchaneltime = DateTime.Now;
							this.joinstatus = 2;
							this.status = 2;
							if (this.sidnew == 0u)
							{
								this.sidnew = num;
							}
							if (this.subidnew == 0u)
							{
								this.subidnew = subidnew;
								goto IL_230;
							}
							goto IL_230;
						}
						throw new Exception("JERR:" + num3);
						IL_230:
						byteArray.Dispose();
					}
				}
			}
			catch (Exception ex)
			{
				this.mytrace = ex.Message;
			}
		}

		// Token: 0x0600014E RID: 334 RVA: 0x0015EC10 File Offset: 0x0015EC10
		public void Send_041E()
		{
			try
			{
				this.lasthearttime = DateTime.Now;
				byte[] data = ProtoPacket.pack<PCS_APPing>(new PCS_APPing());
				this.logintcp.Send(data);
				this.lastsendhearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x0600014F RID: 335 RVA: 0x0015EC60 File Offset: 0x0015EC60
		private void method_12(byte[] byte_1)
		{
			try
			{
				int heartbeat = this.heartbeat;
				this.heartbeat = heartbeat + 1;
				this.lasthearttime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0015ECA0 File Offset: 0x0015ECA0
		public void Send_Service_1E73()
		{
			try
			{
				this.startloginservicetime = DateTime.Now;
				PCS_GetAPInfo obj = new PCS_GetAPInfo
				{
					m_uAppId = 260u,
					m_uUid = 
					{
						low = Convert.ToUInt32(this.uid)
					}
				};
				byte[] serverName = bytetool.String2Bytes("aplbs_webyy");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PCS_GetAPInfo>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sid;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = Convert.ToUInt32(this.uid);
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0015EE98 File Offset: 0x0015EE98
		public void Recv_Service_1E74(byte[] data)
		{
			try
			{
				byte[] bytes = data.Skip(38).Take((int)data[36]).ToArray<byte>();
				using (ByteArray byteArray = new ByteArray(data.Skip((int)(36 + data[36] + 10)).Take(5).ToArray<byte>()))
				{
					this.serviceport = (int)byteArray.ReadShort();
				}
				this.serviceip = Encoding.Default.GetString(bytes);
				this.connect_s();
			}
			catch
			{
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0015EF30 File Offset: 0x0015EF30
		public void GetMicList()
		{
			try
			{
				PGetMaixuListReq obj = new PGetMaixuListReq
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelMaixu");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PGetMaixuListReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0015F12C File Offset: 0x0015F12C
		private void method_13(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					new PGetMaixuListRes().unmarshall(protoPacket.getBuffer());
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0015F18C File Offset: 0x0015F18C
		public void GetUserCount()
		{
			try
			{
				GClass1 obj = new GClass1
				{
					topSid = this.sidnew,
					sidlist = 
					{
						this.sidnew,
						this.subidnew
					}
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass1>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0015F394 File Offset: 0x0015F394
		private void method_14(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint count = byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						if (this.subidnew == byteArray.readUnsignedInt())
						{
							count = byteArray.readUnsignedInt();
							IL_71:
							MyUser.OnGetUserCount onGetUserCount = this.onGetUserCount_0;
							if (onGetUserCount != null)
							{
								onGetUserCount(count);
							}
							goto IL_8E;
						}
						num2++;
					}
					goto IL_71;
				}
				IL_8E:;
			}
			catch
			{
			}
		}

		// Token: 0x06000156 RID: 342 RVA: 0x0015F450 File Offset: 0x0015F450
		public void GetUserList(uint count, uint pos = 0u)
		{
			try
			{
				GClass3 obj = new GClass3
				{
					topSid = this.sidnew,
					subSid = this.subidnew,
					pos = pos,
					num = count
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<GClass3>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0015F650 File Offset: 0x0015F650
		private void method_15(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					uint num = byteArray.readUnsignedInt();
					List<uint> list = new List<uint>();
					int num2 = 0;
					while ((long)num2 < (long)((ulong)num))
					{
						list.Add(byteArray.readUnsignedInt());
						uint num3 = byteArray.readUnsignedInt();
						int num4 = 0;
						while ((long)num4 < (long)((ulong)num3))
						{
							byteArray.readByte();
							byteArray.readUnsignedInt();
							num4++;
						}
						uint num5 = byteArray.readUnsignedInt();
						int num6 = 0;
						while ((long)num6 < (long)((ulong)num5))
						{
							byteArray.readByte();
							short num7 = byteArray.ReadShort();
							byteArray.position += (int)num7;
							num6++;
						}
						num2++;
					}
					list.Add(this.uid);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0015F768 File Offset: 0x0015F768
		public byte[] GetUserInfo()
		{
			byte[] result;
			try
			{
				List<uint> list = new List<uint>();
				list.Add(this.uid);
				PQueryUserInfoReq obj = new PQueryUserInfoReq
				{
					uidlist = list,
					topSid = this.sidnew,
					type = 0u
				};
				byte[] serverName = bytetool.String2Bytes("channelUserInfo");
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PQueryUserInfoReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					array = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				result = array;
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0015F96C File Offset: 0x0015F96C
		private void method_16(byte[] byte_1)
		{
			try
			{
				using (ByteArray byteArray = new ByteArray(byte_1))
				{
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
					byteArray.ReadShort();
					byteArray.readUnsignedInt();
					byteArray.readUnsignedInt();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0015F9E0 File Offset: 0x0015F9E0
		public void LeaveChanel()
		{
			try
			{
				new List<uint>().Add(this.uid);
				PLeaveChannelReq obj = new PLeaveChannelReq
				{
					topsid = this.sidnew,
					uid = this.uid
				};
				byte[] serverName = bytetool.String2Bytes("channelAuther");
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray(ProtoPacket.pack<PLeaveChannelReq>(obj)))
				{
					PContextField1 pcontextField = new PContextField1();
					pcontextField.f1 = this.sidnew;
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					PAPRouter paprouter = new PAPRouter();
					paprouter.m_objAPHdr.m_pAppUID = new CAppUID();
					paprouter.m_objAPHdr.m_pAppUID.m_uAppID = 259u;
					paprouter.m_objAPHdr.m_pAppUID.m_uUID.low = this.uid;
					paprouter.m_objAPHdr.m_pRoutingKey = new CRoutingKey();
					paprouter.m_objAPHdr.m_pRoutingKey.m_uRealUri = protoPacket.getUri();
					paprouter.m_objAPHdr.m_pCompressionInfo = new CCompressionInfo();
					paprouter.m_objAPHdr.m_pClientInfo = new CClientInfo();
					paprouter.m_objAPHdr.m_pClientInfo.m_serverName = serverName;
					paprouter.m_objAPHdr.m_pExtentProp = new CExtentProp();
					MYHashMap mapExtentProp = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp.put(1u.ToString(), ProtoPacket.packNoHeader<PContextField1>(pcontextField));
					MYHashMap mapExtentProp2 = paprouter.m_objAPHdr.m_pExtentProp.m_mapExtentProp;
					mapExtentProp2.put(3u.ToString(), null);
					paprouter.m_strLoad = protoPacket.getBuffer().Buffer;
					paprouter.m_ururi = protoPacket.getUri();
					data = ProtoPacket.pack<PAPRouter>(paprouter);
					byteArray.Dispose();
				}
				this.logintcp.Send(data);
				this.logintcp.stopheart();
				IOCPClient servicetcp = this.servicetcp;
				if (servicetcp != null)
				{
					servicetcp.stopheart();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0015FC00 File Offset: 0x0015FC00
		public void connect_s()
		{
			this.servicetcp = new IOCPClient(this.serviceip, this.serviceport, true, "", ProxyTypes.None);
			this.servicetcp.ConnectedEvent += this.OnConnected_s;
			this.servicetcp.RecievedEvent += this.method_17;
			this.servicetcp.Connect();
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0015FC64 File Offset: 0x0015FC64
		public void OnConnected_s(bool issuccess, bool isduankai = false)
		{
			if (issuccess)
			{
				this.Send_0411_s();
				return;
			}
			this.servicetcp.ConnectedEvent -= this.OnConnected_s;
			this.servicetcp.RecievedEvent -= this.method_17;
			this.isloginservice = false;
			this.servicetcp.DisConnect();
			if (this.status == 2)
			{
				this.Send_Service_1E73();
			}
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0015FCCC File Offset: 0x0015FCCC
		private void method_17(byte[] byte_1)
		{
			try
			{
				if (byte_1[8] == 200 && byte_1[9] == 0)
				{
					this.byteArray_1 = null;
					this.byteArray_1 = new ByteArray();
					using (ByteArray byteArray = new ByteArray(byte_1))
					{
						this.int_12 = byteArray.ReadInt();
					}
					this.byteArray_1.writeBytes(byte_1);
				}
				else if (this.byteArray_1 != null && this.byteArray_1.length > 0 && this.byteArray_1.length < this.int_12)
				{
					this.byteArray_1.writeBytes(byte_1);
				}
				if (this.byteArray_1 != null && this.byteArray_1.length >= this.int_12)
				{
					this.int_12 = 0;
					this.method_18(this.byteArray_1.Buffer);
				}
			}
			catch
			{
				this.byteArray_1 = null;
				this.int_12 = 0;
			}
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0015FDC0 File Offset: 0x0015FDC0
		private void method_18(byte[] byte_1)
		{
			try
			{
				if (byte_1 != null && byte_1.Length >= 10 && byte_1[8] == 200)
				{
					string text = bytetool.fromArray(byte_1, false);
					string text2 = "";
					try
					{
						text2 = text.Substring(8, 4).ToUpper();
					}
					catch
					{
					}
					if (!string.IsNullOrWhiteSpace(text2) && !(text2 == "1E74") && text2 == "0BD0")
					{
						try
						{
							text.Substring(24, 4).ToUpper();
							text.Substring(24, 6).ToUpper();
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0015FE74 File Offset: 0x0015FE74
		public void Send_0411_s()
		{
			try
			{
				byte[] publicKey = rsautil.getInstance().getPublicKey();
				byte[] exponent = rsautil.getInstance().getExponent();
				byte[] data = ProtoPacket.pack<PExchangeKey>(new PExchangeKey(publicKey, exponent));
				this.servicetcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0015FEC8 File Offset: 0x0015FEC8
		public void Recv_0412_s(byte[] data)
		{
			try
			{
				byte[] array = null;
				using (ByteArray byteArray = new ByteArray(data))
				{
					ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
					uint num = (uint)protoPacket.getBuffer().readUnsignedShort();
					if (num != 0u)
					{
						using (ByteArray byteArray2 = new ByteArray())
						{
							protoPacket.getBuffer().readBytes(byteArray2, 0u, num);
							array = byteArray2.Buffer;
							byteArray2.Dispose();
						}
					}
					byteArray.Dispose();
				}
				if (array == null || array.Length == 0)
				{
					throw new Exception("rsa fail");
				}
				byte[] bytes = rsautil.getInstance().decrypt(array);
				this.servicetcp.setarc(bytes);
				this.method_19();
			}
			catch
			{
			}
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0015FFA0 File Offset: 0x0015FFA0
		private void method_19()
		{
			try
			{
				byte[] data;
				if (this.logintype == 1)
				{
					PCS_APLogin pcs_APLogin = new PCS_APLogin();
					pcs_APLogin.m_strPassword = bytetool.String2Bytes(sha1.hash(this.pwd, Encoding.ASCII).ToLower());
					if (this.yycookie != null && this.yycookie.Length != 0)
					{
						pcs_APLogin.m_bRelogin = true;
					}
					else
					{
						pcs_APLogin.m_bRelogin = false;
					}
					pcs_APLogin.m_uAppID = 260u;
					pcs_APLogin.m_uUid.low = Convert.ToUInt32(this.uid);
					pcs_APLogin.m_strCookie = this.yycookie;
					pcs_APLogin.m_strAccount = Encoding.UTF8.GetBytes(this.username);
					pcs_APLogin.m_uCliType = 2u;
					pcs_APLogin.m_strFrom = bytetool.String2Bytes("8.45.0.0");
					pcs_APLogin.m_strCliVer = bytetool.String2Bytes("8.45.0.0");
					data = ProtoPacket.pack<PCS_APLogin>(pcs_APLogin);
				}
				else
				{
					data = ProtoPacket.pack<PCS_APLogin>(new PCS_APLogin
					{
						m_strAccount = bytetool.String2Bytes(this.username),
						m_strPassword = bytetool.String2Bytes(this.pwden),
						m_bRelogin = false,
						m_uAppID = 260u,
						m_uUid = 
						{
							low = Convert.ToUInt32(this.uid)
						},
						m_strCookie = this.yycookie,
						m_uCliType = 2u,
						m_strFrom = bytetool.String2Bytes("yymwebflsh"),
						m_strCliVer = bytetool.String2Bytes("yymwebflsh")
					});
				}
				this.servicetcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0016012C File Offset: 0x0016012C
		public void Recv_04D7_s(byte[] data)
		{
			using (ByteArray byteArray = new ByteArray(data))
			{
				ProtoPacket protoPacket = ProtoPacket.unpack(byteArray.Buffer);
				PCS_APLoginRes pcs_APLoginRes = new PCS_APLoginRes();
				pcs_APLoginRes.unmarshall(protoPacket.getBuffer());
				byteArray.Dispose();
				if (pcs_APLoginRes.m_uResCode != 200u)
				{
					this.isudblogin = false;
					this.OnConnected_s(false, false);
				}
				else
				{
					this.lastservicehearttime = DateTime.Now;
					this.isloginservice = true;
					if (this.servicetcp != null)
					{
						this.servicetcp.startheart();
					}
					if (this.isqutubiao)
					{
						this.method_20();
					}
					if (this.isxianche)
					{
						this.method_21();
					}
				}
			}
		}

		// Token: 0x06000163 RID: 355 RVA: 0x001601E0 File Offset: 0x001601E0
		private void method_20()
		{
			try
			{
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 0;
					byteArray.writeBytes(new byte[]
					{
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray2 = byteArray;
					byte[] array = new byte[16];
					array[4] = 2;
					array[8] = 1;
					byteArray2.writeBytes(array);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray3 = byteArray;
					byte[] array2 = new byte[12];
					array2[4] = 2;
					byteArray3.writeBytes(array2);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						172,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						207,
						9,
						0,
						0,
						0,
						46,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray4 = byteArray;
					byte[] array3 = new byte[16];
					array3[4] = 2;
					array3[8] = 1;
					byteArray4.writeBytes(array3);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray5 = byteArray;
					byte[] array4 = new byte[12];
					array4[4] = 2;
					byteArray5.writeBytes(array4);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						207,
						9,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						56,
						0,
						0,
						0,
						88,
						206,
						9,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					ByteArray byteArray6 = byteArray;
					byte[] array5 = new byte[16];
					array5[4] = 2;
					array5[8] = 1;
					byteArray6.writeBytes(array5);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					ByteArray byteArray7 = byteArray;
					byte[] array6 = new byte[12];
					array6[4] = 2;
					byteArray7.writeBytes(array6);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						0,
						0,
						203,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						77,
						0,
						0,
						0,
						22,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						45,
						0,
						0,
						0,
						45,
						0,
						0,
						0,
						88,
						228,
						5,
						0,
						200,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						1,
						0,
						0,
						0,
						1,
						0,
						17,
						0,
						2,
						0,
						0,
						0,
						1,
						0,
						1,
						0,
						48,
						2,
						0,
						4,
						0
					});
					byteArray.writeBytes(Encoding.Default.GetBytes("4000"));
					byteArray.writeBytes(new byte[6]);
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue,
						168,
						0,
						0,
						0,
						11,
						208,
						7,
						0,
						200,
						0,
						0,
						0,
						88,
						56,
						1,
						0,
						0,
						0,
						42,
						0,
						0,
						0,
						155,
						58
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						10,
						0,
						0,
						0,
						11,
						0,
						0,
						0,
						232,
						3,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.subid)));
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						100,
						0,
						0,
						0,
						8,
						0,
						0,
						1,
						88,
						56,
						1,
						0,
						16,
						0,
						0,
						2,
						4,
						1,
						0,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.uid)));
					byteArray.writeBytes(new byte[]
					{
						0,
						0,
						0,
						0,
						16,
						0,
						0,
						6,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						0,
						56,
						0,
						0,
						7,
						2,
						0,
						0,
						0,
						1,
						0,
						0,
						0,
						4,
						0
					});
					byteArray.writeBytes(BitConverter.GetBytes(Convert.ToUInt32(this.sid)));
					byteArray.writeBytes(new byte[]
					{
						3,
						0,
						0,
						0,
						32,
						0,
						57,
						65,
						54,
						52,
						57,
						51,
						48,
						48,
						52,
						65,
						55,
						70,
						68,
						53,
						53,
						69,
						53,
						68,
						68,
						68,
						51,
						52,
						50,
						67,
						65,
						56,
						69,
						57,
						67,
						54,
						52,
						54,
						120,
						120,
						120,
						byte.MaxValue
					});
					data = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00160684 File Offset: 0x00160684
		private void method_21()
		{
			try
			{
				byte[] data = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.position = 4;
					byteArray.writeBytes(bytetool.strToToHexByte("0BD00700C800000058380100C8002E000000A43A"));
					byteArray.writeUnsignedInt(this.sidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0A0000000B0000004C0400000000000000000100"));
					byteArray.writeUnsignedInt(this.subidnew);
					byteArray.writeUnsignedInt(Convert.ToUInt32(this.uid));
					byteArray.writeBytes(bytetool.strToToHexByte("0001000000000000370000000800000158380100100000020401000033A49F43000000001B00000702000000FF030000050031353031320004000002003336787878FF"));
					byteArray.position = 0;
					byteArray.writeUnsignedInt(Convert.ToUInt32(byteArray.length));
					data = byteArray.Buffer;
					byteArray.Dispose();
				}
				this.servicetcp.Send(data);
			}
			catch
			{
			}
		}

		// Token: 0x04000087 RID: 135
		[CompilerGenerated]
		private MyUser.OnGetUserCount onGetUserCount_0;

		// Token: 0x04000088 RID: 136
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000089 RID: 137
		[CompilerGenerated]
		private int int_1;

		// Token: 0x0400008A RID: 138
		[CompilerGenerated]
		private string string_0;

		// Token: 0x0400008B RID: 139
		[CompilerGenerated]
		private string string_1;

		// Token: 0x0400008C RID: 140
		[CompilerGenerated]
		private string string_2;

		// Token: 0x0400008D RID: 141
		[CompilerGenerated]
		private int int_2;

		// Token: 0x0400008E RID: 142
		[CompilerGenerated]
		private bool bool_0;

		// Token: 0x0400008F RID: 143
		[CompilerGenerated]
		private int int_3;

		// Token: 0x04000090 RID: 144
		[CompilerGenerated]
		private int int_4;

		// Token: 0x04000091 RID: 145
		[CompilerGenerated]
		private int int_5;

		// Token: 0x04000092 RID: 146
		[CompilerGenerated]
		private uint uint_0;

		// Token: 0x04000093 RID: 147
		[CompilerGenerated]
		private string HtyCcnsyl5;

		// Token: 0x04000094 RID: 148
		[CompilerGenerated]
		private string string_3;

		// Token: 0x04000095 RID: 149
		[CompilerGenerated]
		private uint uint_1;

		// Token: 0x04000096 RID: 150
		[CompilerGenerated]
		private uint uint_2;

		// Token: 0x04000097 RID: 151
		[CompilerGenerated]
		private uint uint_3;

		// Token: 0x04000098 RID: 152
		[CompilerGenerated]
		private uint uint_4;

		// Token: 0x04000099 RID: 153
		[CompilerGenerated]
		private string string_4;

		// Token: 0x0400009A RID: 154
		[CompilerGenerated]
		private IOCPClient iocpclient_0;

		// Token: 0x0400009B RID: 155
		[CompilerGenerated]
		private IOCPClient iocpclient_1;

		// Token: 0x0400009C RID: 156
		[CompilerGenerated]
		private string string_5;

		// Token: 0x0400009D RID: 157
		[CompilerGenerated]
		private int int_6;

		// Token: 0x0400009E RID: 158
		[CompilerGenerated]
		private int int_7;

		// Token: 0x0400009F RID: 159
		[CompilerGenerated]
		private ProxyTypes proxyTypes_0;

		// Token: 0x040000A0 RID: 160
		[CompilerGenerated]
		private string string_6;

		// Token: 0x040000A1 RID: 161
		[CompilerGenerated]
		private string string_7;

		// Token: 0x040000A2 RID: 162
		[CompilerGenerated]
		private int int_8;

		// Token: 0x040000A3 RID: 163
		[CompilerGenerated]
		private bool bool_1;

		// Token: 0x040000A4 RID: 164
		[CompilerGenerated]
		private bool bool_2;

		// Token: 0x040000A5 RID: 165
		[CompilerGenerated]
		private byte[] byte_0;

		// Token: 0x040000A6 RID: 166
		[CompilerGenerated]
		private string string_8;

		// Token: 0x040000A7 RID: 167
		[CompilerGenerated]
		private int int_9;

		// Token: 0x040000A8 RID: 168
		[CompilerGenerated]
		private string string_9;

		// Token: 0x040000A9 RID: 169
		[CompilerGenerated]
		private DateTime dateTime_0;

		// Token: 0x040000AA RID: 170
		[CompilerGenerated]
		private DateTime dateTime_1;

		// Token: 0x040000AB RID: 171
		[CompilerGenerated]
		private DateTime dateTime_2;

		// Token: 0x040000AC RID: 172
		[CompilerGenerated]
		private DateTime dateTime_3;

		// Token: 0x040000AD RID: 173
		[CompilerGenerated]
		private DateTime dateTime_4;

		// Token: 0x040000AE RID: 174
		[CompilerGenerated]
		private DateTime dateTime_5;

		// Token: 0x040000AF RID: 175
		[CompilerGenerated]
		private DateTime dateTime_6;

		// Token: 0x040000B0 RID: 176
		[CompilerGenerated]
		private DateTime dateTime_7;

		// Token: 0x040000B1 RID: 177
		[CompilerGenerated]
		private DateTime dateTime_8;

		// Token: 0x040000B2 RID: 178
		[CompilerGenerated]
		private DateTime dateTime_9;

		// Token: 0x040000B3 RID: 179
		[CompilerGenerated]
		private DateTime dateTime_10;

		// Token: 0x040000B4 RID: 180
		[CompilerGenerated]
		private bool bool_3;

		// Token: 0x040000B5 RID: 181
		[CompilerGenerated]
		private bool uyoCjdHyQg;

		// Token: 0x040000B6 RID: 182
		[CompilerGenerated]
		private bool bool_4;

		// Token: 0x040000B7 RID: 183
		[CompilerGenerated]
		private bool bool_5;

		// Token: 0x040000B8 RID: 184
		[CompilerGenerated]
		private string string_10;

		// Token: 0x040000B9 RID: 185
		[CompilerGenerated]
		private int int_10;

		// Token: 0x040000BA RID: 186
		[CompilerGenerated]
		private DateTime dateTime_11;

		// Token: 0x040000BB RID: 187
		private ByteArray byteArray_0;

		// Token: 0x040000BC RID: 188
		private int int_11;

		// Token: 0x040000BD RID: 189
		private ByteArray byteArray_1;

		// Token: 0x040000BE RID: 190
		private int int_12;

		// Token: 0x02000020 RID: 32
		// (Invoke) Token: 0x06000166 RID: 358
		public delegate void OnGetUserCount(uint count);
	}
}
