﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x02000030 RID: 48
	public class UserCache
	{
		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060002FA RID: 762 RVA: 0x00159060 File Offset: 0x00159060
		// (set) Token: 0x060002FB RID: 763 RVA: 0x00159068 File Offset: 0x00159068
		public int Id { get; set; }

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060002FC RID: 764 RVA: 0x00159071 File Offset: 0x00159071
		// (set) Token: 0x060002FD RID: 765 RVA: 0x00159079 File Offset: 0x00159079
		public string Passport { get; set; }

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060002FE RID: 766 RVA: 0x00159082 File Offset: 0x00159082
		// (set) Token: 0x060002FF RID: 767 RVA: 0x0015908A File Offset: 0x0015908A
		public string PWD { get; set; }

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x06000300 RID: 768 RVA: 0x00159093 File Offset: 0x00159093
		// (set) Token: 0x06000301 RID: 769 RVA: 0x0015909B File Offset: 0x0015909B
		public string WebCache { get; set; }

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x06000302 RID: 770 RVA: 0x001590A4 File Offset: 0x001590A4
		// (set) Token: 0x06000303 RID: 771 RVA: 0x001590AC File Offset: 0x001590AC
		public string PCCache { get; set; }

		// Token: 0x04000202 RID: 514
		[CompilerGenerated]
		private int int_0;

		// Token: 0x04000203 RID: 515
		[CompilerGenerated]
		private string string_0;

		// Token: 0x04000204 RID: 516
		[CompilerGenerated]
		private string string_1;

		// Token: 0x04000205 RID: 517
		[CompilerGenerated]
		private string string_2;

		// Token: 0x04000206 RID: 518
		[CompilerGenerated]
		private string string_3;
	}
}
