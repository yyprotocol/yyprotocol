﻿using System;
using System.Runtime.CompilerServices;

namespace JIQIMAO.Model
{
	// Token: 0x0200002D RID: 45
	public class sendrequest
	{
		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060002F5 RID: 757 RVA: 0x0015904F File Offset: 0x0015904F
		// (set) Token: 0x060002F6 RID: 758 RVA: 0x00159057 File Offset: 0x00159057
		public string json { get; set; }

		// Token: 0x040001FF RID: 511
		[CompilerGenerated]
		private string string_0;
	}
}
