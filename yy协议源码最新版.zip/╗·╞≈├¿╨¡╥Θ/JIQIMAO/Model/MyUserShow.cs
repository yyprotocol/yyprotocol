﻿using System;

namespace JIQIMAO.Model
{
	// Token: 0x02000028 RID: 40
	public class MyUserShow
	{
	}
}
