﻿using System;
using System.Linq;
using System.Net.Sockets;
using System.Threading;

namespace JIQIMAO.Model
{
	// Token: 0x0200000E RID: 14
	public class InitTcp
	{
		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000045 RID: 69 RVA: 0x0015821C File Offset: 0x0015821C
		public bool connected
		{
			get
			{
				return this.client != null && this.client.IsOnline();
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x0015B340 File Offset: 0x0015B340
		public InitTcp(string ip, int port)
		{
			this.client = new TcpClient(AddressFamily.InterNetwork);
			this.client.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Linger, new LingerOption(true, 0));
			this.client.ReceiveTimeout = 5000;
			this.string_0 = ip;
			this.int_0 = port;
			this.arc4_0 = null;
			this.arc4_1 = null;
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00158233 File Offset: 0x00158233
		public void setarc(byte[] bytes)
		{
			if (this.arc4_0 == null)
			{
				this.arc4_0 = new ARC4(bytes, false);
				this.arc4_1 = new ARC4(bytes, true);
			}
		}

		// Token: 0x06000048 RID: 72 RVA: 0x0015B3AC File Offset: 0x0015B3AC
		public bool connect()
		{
			bool result;
			try
			{
				this.client.Connect(this.string_0, this.int_0);
				this.networkStream_0 = this.client.GetStream();
				result = true;
			}
			catch
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000049 RID: 73 RVA: 0x0015B3FC File Offset: 0x0015B3FC
		public bool send(byte[] bytes)
		{
			bool result;
			try
			{
				if (!this.client.Connected && !this.client.IsOnline())
				{
					throw new Exception("连接断开");
				}
				if (this.networkStream_0.CanWrite)
				{
					if (this.arc4_0 != null)
					{
						this.arc4_0.encrypt(bytes);
					}
					this.networkStream_0.Write(bytes, 0, bytes.Length);
					result = true;
				}
				else
				{
					result = false;
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return result;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x0015B47C File Offset: 0x0015B47C
		public byte[] recive()
		{
			byte[] result;
			try
			{
				if (!this.client.Connected && !this.client.IsOnline())
				{
					throw new Exception("tcp close");
				}
				if (this.client.Available > 0)
				{
					if (this.networkStream_0.CanRead)
					{
						byte[] array = new byte[16384];
						int num = this.networkStream_0.Read(array, 0, array.Length);
						Thread.Sleep(50);
						if (num != 0)
						{
							byte[] array2 = array.Take(num).ToArray<byte>();
							if (this.arc4_1 != null)
							{
								this.arc4_1.decrypt(array2);
							}
							result = array2;
						}
						else
						{
							result = null;
						}
					}
					else
					{
						result = null;
					}
				}
				else
				{
					result = null;
				}
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x0015B538 File Offset: 0x0015B538
		public void dispose()
		{
			try
			{
				if (this.networkStream_0 != null)
				{
					this.networkStream_0.Close();
					this.networkStream_0.Dispose();
					this.networkStream_0 = null;
				}
				if (this.client != null)
				{
					this.client.Client.Shutdown(SocketShutdown.Both);
					this.client.Client.Close();
					this.client.Close();
					this.client = null;
				}
				this.arc4_0 = (this.arc4_1 = null);
			}
			catch
			{
				this.networkStream_0 = null;
				this.client = null;
			}
		}

		// Token: 0x04000036 RID: 54
		public TcpClient client;

		// Token: 0x04000037 RID: 55
		private NetworkStream networkStream_0;

		// Token: 0x04000038 RID: 56
		private ARC4 arc4_0;

		// Token: 0x04000039 RID: 57
		private ARC4 arc4_1;

		// Token: 0x0400003A RID: 58
		private string string_0;

		// Token: 0x0400003B RID: 59
		private int int_0;
	}
}
