﻿using System;

namespace JIQIMAO.Model
{
	// Token: 0x02000003 RID: 3
	public class ARC4
	{
		// Token: 0x06000008 RID: 8 RVA: 0x00158085 File Offset: 0x00158085
		public ARC4(byte[] key = null, bool d = false)
		{
			if (key != null)
			{
				this.byte_0 = new byte[256];
				this.init(key);
				if (d)
				{
					this.init(key);
				}
			}
		}

		// Token: 0x06000009 RID: 9 RVA: 0x0015A8A4 File Offset: 0x0015A8A4
		public void init(byte[] key)
		{
			for (int i = 0; i < 256; i++)
			{
				this.byte_0[i] = (byte)i;
			}
			int num = 0;
			for (int j = 0; j < 256; j++)
			{
				num = (num + (int)this.byte_0[j] + (int)key[j % key.Length] & 255);
				int num2 = (int)this.byte_0[j];
				this.byte_0[j] = this.byte_0[num];
				this.byte_0[num] = (byte)num2;
			}
			this.int_0 = 0;
			this.int_1 = 0;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x0015A928 File Offset: 0x0015A928
		public void encrypt(byte[] block)
		{
			int i = 0;
			while (i < block.Length)
			{
				int num = i++;
				block[num] = (byte)((uint)block[num] ^ this.next());
			}
		}

		// Token: 0x0600000B RID: 11 RVA: 0x001580B1 File Offset: 0x001580B1
		public void decrypt(byte[] bytes)
		{
			this.encrypt(bytes);
		}

		// Token: 0x0600000C RID: 12 RVA: 0x0015A954 File Offset: 0x0015A954
		public uint next()
		{
			this.int_0 = (this.int_0 + 1 & 255);
			this.int_1 = (this.int_1 + (int)this.byte_0[this.int_0] & 255);
			int num = (int)this.byte_0[this.int_0];
			this.byte_0[this.int_0] = this.byte_0[this.int_1];
			this.byte_0[this.int_1] = (byte)num;
			return (uint)this.byte_0[num + (int)this.byte_0[this.int_0] & 255];
		}

		// Token: 0x04000002 RID: 2
		private int int_0;

		// Token: 0x04000003 RID: 3
		private int int_1;

		// Token: 0x04000004 RID: 4
		private byte[] byte_0;
	}
}
