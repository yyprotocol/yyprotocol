﻿namespace ns1
{
	// Token: 0x0200009F RID: 159
	public partial class MainForm : global::System.Windows.Forms.Form
	{
		// Token: 0x06000567 RID: 1383 RVA: 0x0015A57C File Offset: 0x0015A57C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x00175C30 File Offset: 0x00175C30
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle = new global::System.Windows.Forms.DataGridViewCellStyle();
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new global::System.Windows.Forms.DataGridViewCellStyle();
			global::System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new global::System.Windows.Forms.DataGridViewCellStyle();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ns1.MainForm));
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.labelOverTime = new global::System.Windows.Forms.Label();
			this.mygrid = new global::System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn_8 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_9 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_10 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_11 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CF = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_12 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_13 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.CKI = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Trace = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_14 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_15 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn_16 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.groupBox6 = new global::System.Windows.Forms.GroupBox();
			this.tzdaka = new global::System.Windows.Forms.Button();
			this.daka = new global::System.Windows.Forms.Button();
			this.tingzhizhibotongzhi = new global::System.Windows.Forms.Button();
			this.zhibotongzhi = new global::System.Windows.Forms.Button();
			this.label17 = new global::System.Windows.Forms.Label();
			this.shuahuasudu = new global::System.Windows.Forms.TextBox();
			this.label16 = new global::System.Windows.Forms.Label();
			this.btn_tingzhishuahua = new global::System.Windows.Forms.Button();
			this.btn_songhua = new global::System.Windows.Forms.Button();
			this.txt_shuahuauid = new global::System.Windows.Forms.TextBox();
			this.label15 = new global::System.Windows.Forms.Label();
			this.lblshijizaixian = new global::System.Windows.Forms.Label();
			this.groupBox4 = new global::System.Windows.Forms.GroupBox();
			this.buhao = new global::System.Windows.Forms.CheckBox();
			this.ckbhttplocal = new global::System.Windows.Forms.CheckBox();
			this.checkBox_0 = new global::System.Windows.Forms.CheckBox();
			this.ckbhttpurl = new global::System.Windows.Forms.CheckBox();
			this.ckbhunhe = new global::System.Windows.Forms.CheckBox();
			this.groupBox7 = new global::System.Windows.Forms.GroupBox();
			this.label12 = new global::System.Windows.Forms.Label();
			this.label13 = new global::System.Windows.Forms.Label();
			this.label14 = new global::System.Windows.Forms.Label();
			this.xhfen = new global::System.Windows.Forms.NumericUpDown();
			this.xhshi = new global::System.Windows.Forms.NumericUpDown();
			this.xhtian = new global::System.Windows.Forms.NumericUpDown();
			this.label11 = new global::System.Windows.Forms.Label();
			this.label10 = new global::System.Windows.Forms.Label();
			this.label9 = new global::System.Windows.Forms.Label();
			this.shfen = new global::System.Windows.Forms.NumericUpDown();
			this.shshi = new global::System.Windows.Forms.NumericUpDown();
			this.shtian = new global::System.Windows.Forms.NumericUpDown();
			this.ckbdsxh = new global::System.Windows.Forms.CheckBox();
			this.ckbdssh = new global::System.Windows.Forms.CheckBox();
			this.label6 = new global::System.Windows.Forms.Label();
			this.label7 = new global::System.Windows.Forms.Label();
			this.txtfeng = new global::System.Windows.Forms.TextBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.lblauthtime = new global::System.Windows.Forms.Label();
			this.lbllastbuhao = new global::System.Windows.Forms.Label();
			this.lblver = new global::System.Windows.Forms.Label();
			this.lbldaoqi = new global::System.Windows.Forms.Label();
			this.groupBox1 = new global::System.Windows.Forms.GroupBox();
			this.rdbweb = new global::System.Windows.Forms.RadioButton();
			this.rdbpc = new global::System.Windows.Forms.RadioButton();
			this.lblpath = new global::System.Windows.Forms.Label();
			this.groupBox3 = new global::System.Windows.Forms.GroupBox();
			this.nvxing = new global::System.Windows.Forms.Button();
			this.nanxing = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.button1 = new global::System.Windows.Forms.Button();
			this.btnchonglian = new global::System.Windows.Forms.Button();
			this.btntingzhixiugai = new global::System.Windows.Forms.Button();
			this.btndaochu = new global::System.Windows.Forms.Button();
			this.btntuichu = new global::System.Windows.Forms.Button();
			this.btnqiehuan = new global::System.Windows.Forms.Button();
			this.btnresetsudu = new global::System.Windows.Forms.Button();
			this.btnsuijixingbie = new global::System.Windows.Forms.Button();
			this.btndaoruqianming = new global::System.Windows.Forms.Button();
			this.groupBox5 = new global::System.Windows.Forms.GroupBox();
			this.button3 = new global::System.Windows.Forms.Button();
			this.txthanhuajiange = new global::System.Windows.Forms.TextBox();
			this.label8 = new global::System.Windows.Forms.Label();
			this.butiao = new global::System.Windows.Forms.CheckBox();
			this.btndaoruhanhua = new global::System.Windows.Forms.Button();
			this.ckbhanhua = new global::System.Windows.Forms.CheckBox();
			this.ckbxianche = new global::System.Windows.Forms.CheckBox();
			this.ckbqutubiao = new global::System.Windows.Forms.CheckBox();
			this.ckbgongneng = new global::System.Windows.Forms.CheckBox();
			this.txtjin = new global::System.Windows.Forms.TextBox();
			this.txtsudu = new global::System.Windows.Forms.TextBox();
			this.btndaorumajia = new global::System.Windows.Forms.Button();
			this.label4 = new global::System.Windows.Forms.Label();
			this.txtzong = new global::System.Windows.Forms.TextBox();
			this.btnjoin = new global::System.Windows.Forms.Button();
			this.sfnEqZowcK = new global::System.Windows.Forms.TextBox();
			this.btndaoru = new global::System.Windows.Forms.Button();
			this.label3 = new global::System.Windows.Forms.Label();
			this.txtsid = new global::System.Windows.Forms.TextBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.groupBox2 = new global::System.Windows.Forms.GroupBox();
			this.lblhulian = new global::System.Windows.Forms.Label();
			this.ckbhulian = new global::System.Windows.Forms.CheckBox();
			this.checkBox_1 = new global::System.Windows.Forms.CheckBox();
			this.groupBox8 = new global::System.Windows.Forms.GroupBox();
			this.txtshanghao = new global::System.Windows.Forms.TextBox();
			this.groupBox9 = new global::System.Windows.Forms.GroupBox();
			this.txtxiahao = new global::System.Windows.Forms.TextBox();
			this.groupBox_0 = new global::System.Windows.Forms.GroupBox();
			this.ckbduoip = new global::System.Windows.Forms.CheckBox();
			this.openFileDialog_0 = new global::System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog_0 = new global::System.Windows.Forms.SaveFileDialog();
			this.groupBox_1 = new global::System.Windows.Forms.GroupBox();
			this.groupBox_2 = new global::System.Windows.Forms.GroupBox();
			this.txtzuishaoshuliang = new global::System.Windows.Forms.TextBox();
			this.ckbzhinenghuanhao = new global::System.Windows.Forms.CheckBox();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panel1.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.mygrid).BeginInit();
			this.groupBox6.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox7.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.xhfen).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.xhshi).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.xhtian).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.shfen).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.shshi).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.shtian).BeginInit();
			this.panel2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.groupBox_0.SuspendLayout();
			this.groupBox_1.SuspendLayout();
			this.groupBox_2.SuspendLayout();
			base.SuspendLayout();
			this.panel1.Controls.Add(this.labelOverTime);
			this.panel1.Controls.Add(this.mygrid);
			this.panel1.Controls.Add(this.groupBox6);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.groupBox1);
			this.panel1.Controls.Add(this.lblpath);
			this.panel1.Controls.Add(this.groupBox3);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new global::System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(812, 552);
			this.panel1.TabIndex = 0;
			this.labelOverTime.AutoSize = true;
			this.labelOverTime.ForeColor = global::System.Drawing.SystemColors.MenuHighlight;
			this.labelOverTime.Location = new global::System.Drawing.Point(566, 535);
			this.labelOverTime.Name = "labelOverTime";
			this.labelOverTime.Size = new global::System.Drawing.Size(53, 12);
			this.labelOverTime.TabIndex = 7;
			this.labelOverTime.Text = "过期时间";
			this.mygrid.AllowUserToAddRows = false;
			this.mygrid.AllowUserToDeleteRows = false;
			this.mygrid.BackgroundColor = global::System.Drawing.SystemColors.Window;
			this.mygrid.BorderStyle = global::System.Windows.Forms.BorderStyle.Fixed3D;
			dataGridViewCellStyle.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle.BackColor = global::System.Drawing.SystemColors.Control;
			dataGridViewCellStyle.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			dataGridViewCellStyle.ForeColor = global::System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle.SelectionBackColor = global::System.Drawing.Color.CadetBlue;
			dataGridViewCellStyle.SelectionForeColor = global::System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle.WrapMode = global::System.Windows.Forms.DataGridViewTriState.True;
			this.mygrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle;
			this.mygrid.ColumnHeadersHeight = 20;
			this.mygrid.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[]
			{
				this.dataGridViewTextBoxColumn_8,
				this.dataGridViewTextBoxColumn_9,
				this.dataGridViewTextBoxColumn_10,
				this.dataGridViewTextBoxColumn_11,
				this.CF,
				this.dataGridViewTextBoxColumn_12,
				this.dataGridViewTextBoxColumn_13,
				this.CKI,
				this.Trace,
				this.dataGridViewTextBoxColumn_14,
				this.dataGridViewTextBoxColumn_15,
				this.dataGridViewTextBoxColumn_16
			});
			dataGridViewCellStyle2.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle2.BackColor = global::System.Drawing.SystemColors.Window;
			dataGridViewCellStyle2.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			dataGridViewCellStyle2.ForeColor = global::System.Drawing.SystemColors.ControlText;
			dataGridViewCellStyle2.SelectionBackColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			dataGridViewCellStyle2.SelectionForeColor = global::System.Drawing.SystemColors.HotTrack;
			dataGridViewCellStyle2.WrapMode = global::System.Windows.Forms.DataGridViewTriState.False;
			this.mygrid.DefaultCellStyle = dataGridViewCellStyle2;
			this.mygrid.GridColor = global::System.Drawing.SystemColors.GradientInactiveCaption;
			this.mygrid.Location = new global::System.Drawing.Point(213, 22);
			this.mygrid.Name = "mygrid";
			this.mygrid.ReadOnly = true;
			dataGridViewCellStyle3.Alignment = global::System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
			dataGridViewCellStyle3.BackColor = global::System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			dataGridViewCellStyle3.ForeColor = global::System.Drawing.SystemColors.WindowText;
			dataGridViewCellStyle3.SelectionBackColor = global::System.Drawing.SystemColors.Control;
			dataGridViewCellStyle3.SelectionForeColor = global::System.Drawing.SystemColors.HighlightText;
			dataGridViewCellStyle3.WrapMode = global::System.Windows.Forms.DataGridViewTriState.True;
			this.mygrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
			this.mygrid.RowHeadersVisible = false;
			this.mygrid.RowTemplate.Height = 18;
			this.mygrid.RowTemplate.Resizable = global::System.Windows.Forms.DataGridViewTriState.False;
			this.mygrid.ScrollBars = global::System.Windows.Forms.ScrollBars.Vertical;
			this.mygrid.Size = new global::System.Drawing.Size(596, 437);
			this.mygrid.TabIndex = 4;
			this.dataGridViewTextBoxColumn_8.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_8.DataPropertyName = "index";
			this.dataGridViewTextBoxColumn_8.FillWeight = 106.599f;
			this.dataGridViewTextBoxColumn_8.Frozen = true;
			this.dataGridViewTextBoxColumn_8.HeaderText = "序号";
			this.dataGridViewTextBoxColumn_8.Name = "序号";
			this.dataGridViewTextBoxColumn_8.ReadOnly = true;
			this.dataGridViewTextBoxColumn_8.Resizable = global::System.Windows.Forms.DataGridViewTriState.True;
			this.dataGridViewTextBoxColumn_8.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_8.Width = 40;
			this.dataGridViewTextBoxColumn_9.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_9.DataPropertyName = "passport";
			this.dataGridViewTextBoxColumn_9.Frozen = true;
			this.dataGridViewTextBoxColumn_9.HeaderText = "账号";
			this.dataGridViewTextBoxColumn_9.Name = "用户名";
			this.dataGridViewTextBoxColumn_9.ReadOnly = true;
			this.dataGridViewTextBoxColumn_9.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_10.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_10.DataPropertyName = "nicheng";
			this.dataGridViewTextBoxColumn_10.FillWeight = 76.98668f;
			this.dataGridViewTextBoxColumn_10.HeaderText = "马甲";
			this.dataGridViewTextBoxColumn_10.Name = "马甲";
			this.dataGridViewTextBoxColumn_10.ReadOnly = true;
			this.dataGridViewTextBoxColumn_10.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_11.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_11.DataPropertyName = "sid";
			this.dataGridViewTextBoxColumn_11.FillWeight = 77.84281f;
			this.dataGridViewTextBoxColumn_11.HeaderText = "主频道号";
			this.dataGridViewTextBoxColumn_11.Name = "主频道号";
			this.dataGridViewTextBoxColumn_11.ReadOnly = true;
			this.dataGridViewTextBoxColumn_11.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_11.Width = 75;
			this.CF.DataPropertyName = "currentflag";
			this.CF.HeaderText = "CF";
			this.CF.Name = "CF";
			this.CF.ReadOnly = true;
			this.CF.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.CF.Visible = false;
			this.CF.Width = 44;
			this.dataGridViewTextBoxColumn_12.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_12.DataPropertyName = "yanzhengma";
			this.dataGridViewTextBoxColumn_12.FillWeight = 253.0257f;
			this.dataGridViewTextBoxColumn_12.HeaderText = "验证码";
			this.dataGridViewTextBoxColumn_12.Name = "验证码";
			this.dataGridViewTextBoxColumn_12.ReadOnly = true;
			this.dataGridViewTextBoxColumn_12.Resizable = global::System.Windows.Forms.DataGridViewTriState.False;
			this.dataGridViewTextBoxColumn_12.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_12.Width = 50;
			this.dataGridViewTextBoxColumn_13.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_13.DataPropertyName = "statusstr";
			this.dataGridViewTextBoxColumn_13.FillWeight = 76.98668f;
			this.dataGridViewTextBoxColumn_13.HeaderText = "状态";
			this.dataGridViewTextBoxColumn_13.Name = "状态";
			this.dataGridViewTextBoxColumn_13.ReadOnly = true;
			this.dataGridViewTextBoxColumn_13.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_13.Width = 60;
			this.CKI.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.CKI.DataPropertyName = "lol";
			this.CKI.HeaderText = "LOL";
			this.CKI.Name = "CKI";
			this.CKI.ReadOnly = true;
			this.CKI.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.CKI.Visible = false;
			this.CKI.Width = 42;
			this.Trace.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.Trace.DataPropertyName = "mytrace";
			this.Trace.HeaderText = "Trace";
			this.Trace.Name = "Trace";
			this.Trace.ReadOnly = true;
			this.Trace.Visible = false;
			this.Trace.Width = 80;
			this.dataGridViewTextBoxColumn_14.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_14.DataPropertyName = "heartbeat";
			this.dataGridViewTextBoxColumn_14.FillWeight = 76.98668f;
			this.dataGridViewTextBoxColumn_14.HeaderText = "心跳";
			this.dataGridViewTextBoxColumn_14.Name = "心跳";
			this.dataGridViewTextBoxColumn_14.ReadOnly = true;
			this.dataGridViewTextBoxColumn_14.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_14.Width = 43;
			this.dataGridViewTextBoxColumn_15.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
			this.dataGridViewTextBoxColumn_15.DataPropertyName = "jifen";
			this.dataGridViewTextBoxColumn_15.FillWeight = 30f;
			this.dataGridViewTextBoxColumn_15.HeaderText = "积分";
			this.dataGridViewTextBoxColumn_15.Name = "积分";
			this.dataGridViewTextBoxColumn_15.ReadOnly = true;
			this.dataGridViewTextBoxColumn_15.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.dataGridViewTextBoxColumn_15.Width = 45;
			this.dataGridViewTextBoxColumn_16.AutoSizeMode = global::System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn_16.DataPropertyName = "dailistr";
			this.dataGridViewTextBoxColumn_16.HeaderText = "登录IP";
			this.dataGridViewTextBoxColumn_16.Name = "连接IP";
			this.dataGridViewTextBoxColumn_16.ReadOnly = true;
			this.dataGridViewTextBoxColumn_16.SortMode = global::System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
			this.groupBox6.Controls.Add(this.tzdaka);
			this.groupBox6.Controls.Add(this.daka);
			this.groupBox6.Controls.Add(this.tingzhizhibotongzhi);
			this.groupBox6.Controls.Add(this.zhibotongzhi);
			this.groupBox6.Controls.Add(this.label17);
			this.groupBox6.Controls.Add(this.shuahuasudu);
			this.groupBox6.Controls.Add(this.label16);
			this.groupBox6.Controls.Add(this.btn_tingzhishuahua);
			this.groupBox6.Controls.Add(this.btn_songhua);
			this.groupBox6.Controls.Add(this.txt_shuahuauid);
			this.groupBox6.Controls.Add(this.label15);
			this.groupBox6.Controls.Add(this.lblshijizaixian);
			this.groupBox6.Controls.Add(this.groupBox4);
			this.groupBox6.Controls.Add(this.ckbhunhe);
			this.groupBox6.Controls.Add(this.groupBox7);
			this.groupBox6.Controls.Add(this.label6);
			this.groupBox6.Controls.Add(this.label7);
			this.groupBox6.Controls.Add(this.txtfeng);
			this.groupBox6.Controls.Add(this.label5);
			this.groupBox6.Location = new global::System.Drawing.Point(10, 452);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new global::System.Drawing.Size(799, 80);
			this.groupBox6.TabIndex = 6;
			this.groupBox6.TabStop = false;
			this.tzdaka.Location = new global::System.Drawing.Point(261, 46);
			this.tzdaka.Name = "tzdaka";
			this.tzdaka.Size = new global::System.Drawing.Size(67, 20);
			this.tzdaka.TabIndex = 41;
			this.tzdaka.Text = "停止打卡";
			this.tzdaka.UseVisualStyleBackColor = true;
			this.tzdaka.Click += new global::System.EventHandler(this.tzdaka_Click);
			this.daka.Location = new global::System.Drawing.Point(261, 19);
			this.daka.Name = "daka";
			this.daka.Size = new global::System.Drawing.Size(67, 20);
			this.daka.TabIndex = 40;
			this.daka.Text = "娱乐打卡";
			this.daka.UseVisualStyleBackColor = true;
			this.daka.Click += new global::System.EventHandler(this.daka_Click);
			this.tingzhizhibotongzhi.Location = new global::System.Drawing.Point(188, 46);
			this.tingzhizhibotongzhi.Name = "tingzhizhibotongzhi";
			this.tingzhizhibotongzhi.Size = new global::System.Drawing.Size(67, 20);
			this.tingzhizhibotongzhi.TabIndex = 39;
			this.tingzhizhibotongzhi.Text = "停止通知";
			this.tingzhizhibotongzhi.UseVisualStyleBackColor = true;
			this.tingzhizhibotongzhi.Click += new global::System.EventHandler(this.tingzhizhibotongzhi_Click);
			this.zhibotongzhi.Location = new global::System.Drawing.Point(188, 19);
			this.zhibotongzhi.Name = "zhibotongzhi";
			this.zhibotongzhi.Size = new global::System.Drawing.Size(67, 20);
			this.zhibotongzhi.TabIndex = 38;
			this.zhibotongzhi.Text = "直播通知";
			this.zhibotongzhi.UseVisualStyleBackColor = true;
			this.zhibotongzhi.Click += new global::System.EventHandler(this.zhibotongzhi_Click);
			this.label17.AutoSize = true;
			this.label17.Location = new global::System.Drawing.Point(10, 23);
			this.label17.Name = "label17";
			this.label17.Size = new global::System.Drawing.Size(41, 12);
			this.label17.TabIndex = 37;
			this.label17.Text = "速度：";
			this.shuahuasudu.Location = new global::System.Drawing.Point(56, 20);
			this.shuahuasudu.Name = "shuahuasudu";
			this.shuahuasudu.Size = new global::System.Drawing.Size(49, 21);
			this.shuahuasudu.TabIndex = 36;
			this.shuahuasudu.Text = "500";
			this.label16.AutoSize = true;
			this.label16.Location = new global::System.Drawing.Point(10, 53);
			this.label16.Name = "label16";
			this.label16.Size = new global::System.Drawing.Size(41, 12);
			this.label16.TabIndex = 35;
			this.label16.Text = "YY号：";
			this.btn_tingzhishuahua.Location = new global::System.Drawing.Point(115, 47);
			this.btn_tingzhishuahua.Name = "btn_tingzhishuahua";
			this.btn_tingzhishuahua.Size = new global::System.Drawing.Size(67, 20);
			this.btn_tingzhishuahua.TabIndex = 34;
			this.btn_tingzhishuahua.Text = "停止刷花";
			this.btn_tingzhishuahua.UseVisualStyleBackColor = true;
			this.btn_tingzhishuahua.Click += new global::System.EventHandler(this.btn_tingzhishuahua_Click);
			this.btn_songhua.Location = new global::System.Drawing.Point(115, 18);
			this.btn_songhua.Name = "btn_songhua";
			this.btn_songhua.Size = new global::System.Drawing.Size(67, 20);
			this.btn_songhua.TabIndex = 33;
			this.btn_songhua.Text = "开始刷花";
			this.btn_songhua.UseVisualStyleBackColor = true;
			this.btn_songhua.Click += new global::System.EventHandler(this.btn_songhua_Click);
			this.txt_shuahuauid.Location = new global::System.Drawing.Point(56, 47);
			this.txt_shuahuauid.Name = "txt_shuahuauid";
			this.txt_shuahuauid.Size = new global::System.Drawing.Size(49, 21);
			this.txt_shuahuauid.TabIndex = 31;
			this.label15.AutoSize = true;
			this.label15.Location = new global::System.Drawing.Point(338, 49);
			this.label15.Name = "label15";
			this.label15.Size = new global::System.Drawing.Size(65, 12);
			this.label15.TabIndex = 14;
			this.label15.Text = "频道监控：";
			this.lblshijizaixian.BackColor = global::System.Drawing.SystemColors.Control;
			this.lblshijizaixian.BorderStyle = global::System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblshijizaixian.Cursor = global::System.Windows.Forms.Cursors.IBeam;
			this.lblshijizaixian.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.lblshijizaixian.ForeColor = global::System.Drawing.SystemColors.WindowText;
			this.lblshijizaixian.Location = new global::System.Drawing.Point(410, 43);
			this.lblshijizaixian.Name = "lblshijizaixian";
			this.lblshijizaixian.Size = new global::System.Drawing.Size(60, 21);
			this.lblshijizaixian.TabIndex = 3;
			this.lblshijizaixian.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.groupBox4.Controls.Add(this.buhao);
			this.groupBox4.Controls.Add(this.ckbhttplocal);
			this.groupBox4.Controls.Add(this.checkBox_0);
			this.groupBox4.Controls.Add(this.ckbhttpurl);
			this.groupBox4.Location = new global::System.Drawing.Point(714, 10);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new global::System.Drawing.Size(85, 64);
			this.groupBox4.TabIndex = 4;
			this.groupBox4.TabStop = false;
			this.buhao.AutoSize = true;
			this.buhao.Checked = true;
			this.buhao.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.buhao.Location = new global::System.Drawing.Point(6, 11);
			this.buhao.Name = "buhao";
			this.buhao.Size = new global::System.Drawing.Size(72, 16);
			this.buhao.TabIndex = 6;
			this.buhao.Text = "锁频补号";
			this.buhao.UseVisualStyleBackColor = true;
			this.buhao.CheckedChanged += new global::System.EventHandler(this.buhao_CheckedChanged);
			this.ckbhttplocal.AutoSize = true;
			this.ckbhttplocal.Location = new global::System.Drawing.Point(72, 999);
			this.ckbhttplocal.Name = "ckbhttplocal";
			this.ckbhttplocal.Size = new global::System.Drawing.Size(84, 16);
			this.ckbhttplocal.TabIndex = 2;
			this.ckbhttplocal.Text = "http/https";
			this.ckbhttplocal.UseVisualStyleBackColor = true;
			this.ckbhttplocal.CheckedChanged += new global::System.EventHandler(this.ckbhttplocal_CheckedChanged);
			this.checkBox_0.AutoSize = true;
			this.checkBox_0.Location = new global::System.Drawing.Point(6, 47);
			this.checkBox_0.Name = "checkBox_0";
			this.checkBox_0.Size = new global::System.Drawing.Size(36, 16);
			this.checkBox_0.TabIndex = 5;
			this.checkBox_0.Text = "s5";
			this.checkBox_0.UseVisualStyleBackColor = true;
			this.checkBox_0.CheckedChanged += new global::System.EventHandler(this.checkBox_0_CheckedChanged);
			this.ckbhttpurl.AutoSize = true;
			this.ckbhttpurl.Location = new global::System.Drawing.Point(6, 29);
			this.ckbhttpurl.Name = "ckbhttpurl";
			this.ckbhttpurl.Size = new global::System.Drawing.Size(42, 16);
			this.ckbhttpurl.TabIndex = 1;
			this.ckbhttpurl.Text = "API";
			this.ckbhttpurl.UseVisualStyleBackColor = true;
			this.ckbhttpurl.CheckedChanged += new global::System.EventHandler(this.ckbhttpurl_CheckedChanged);
			this.ckbhunhe.AutoSize = true;
			this.ckbhunhe.Checked = true;
			this.ckbhunhe.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.ckbhunhe.Location = new global::System.Drawing.Point(143, 9999);
			this.ckbhunhe.Name = "ckbhunhe";
			this.ckbhunhe.Size = new global::System.Drawing.Size(60, 16);
			this.ckbhunhe.TabIndex = 21;
			this.ckbhunhe.Text = "混合进";
			this.ckbhunhe.UseVisualStyleBackColor = true;
			this.groupBox7.Controls.Add(this.label12);
			this.groupBox7.Controls.Add(this.label13);
			this.groupBox7.Controls.Add(this.label14);
			this.groupBox7.Controls.Add(this.xhfen);
			this.groupBox7.Controls.Add(this.xhshi);
			this.groupBox7.Controls.Add(this.xhtian);
			this.groupBox7.Controls.Add(this.label11);
			this.groupBox7.Controls.Add(this.label10);
			this.groupBox7.Controls.Add(this.label9);
			this.groupBox7.Controls.Add(this.shfen);
			this.groupBox7.Controls.Add(this.shshi);
			this.groupBox7.Controls.Add(this.shtian);
			this.groupBox7.Controls.Add(this.ckbdsxh);
			this.groupBox7.Controls.Add(this.ckbdssh);
			this.groupBox7.Location = new global::System.Drawing.Point(484, 10);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new global::System.Drawing.Size(223, 62);
			this.groupBox7.TabIndex = 7;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "定时下号";
			this.label12.AutoSize = true;
			this.label12.Location = new global::System.Drawing.Point(193, 44);
			this.label12.Name = "label12";
			this.label12.Size = new global::System.Drawing.Size(17, 12);
			this.label12.TabIndex = 20;
			this.label12.Text = "分";
			this.label13.AutoSize = true;
			this.label13.Location = new global::System.Drawing.Point(138, 44);
			this.label13.Name = "label13";
			this.label13.Size = new global::System.Drawing.Size(17, 12);
			this.label13.TabIndex = 19;
			this.label13.Text = "时";
			this.label14.AutoSize = true;
			this.label14.Location = new global::System.Drawing.Point(82, 46);
			this.label14.Name = "label14";
			this.label14.Size = new global::System.Drawing.Size(17, 12);
			this.label14.TabIndex = 18;
			this.label14.Text = "天";
			this.xhfen.Location = new global::System.Drawing.Point(156, 39);
			global::System.Windows.Forms.NumericUpDown numericUpDown = this.xhfen;
			int[] array = new int[4];
			array[0] = 59;
			numericUpDown.Maximum = new decimal(array);
			this.xhfen.Name = "xhfen";
			this.xhfen.Size = new global::System.Drawing.Size(35, 21);
			this.xhfen.TabIndex = 17;
			this.xhshi.Location = new global::System.Drawing.Point(102, 39);
			global::System.Windows.Forms.NumericUpDown numericUpDown2 = this.xhshi;
			int[] array2 = new int[4];
			array2[0] = 23;
			numericUpDown2.Maximum = new decimal(array2);
			this.xhshi.Name = "xhshi";
			this.xhshi.Size = new global::System.Drawing.Size(35, 21);
			this.xhshi.TabIndex = 16;
			this.xhtian.Location = new global::System.Drawing.Point(42, 39);
			global::System.Windows.Forms.NumericUpDown numericUpDown3 = this.xhtian;
			int[] array3 = new int[4];
			array3[0] = 999;
			numericUpDown3.Maximum = new decimal(array3);
			this.xhtian.Name = "xhtian";
			this.xhtian.Size = new global::System.Drawing.Size(40, 21);
			this.xhtian.TabIndex = 15;
			global::System.Windows.Forms.NumericUpDown numericUpDown4 = this.xhtian;
			int[] array4 = new int[4];
			array4[0] = 30;
			numericUpDown4.Value = new decimal(array4);
			this.label11.AutoSize = true;
			this.label11.Location = new global::System.Drawing.Point(193, 19);
			this.label11.Name = "label11";
			this.label11.Size = new global::System.Drawing.Size(17, 12);
			this.label11.TabIndex = 14;
			this.label11.Text = "分";
			this.label10.AutoSize = true;
			this.label10.Location = new global::System.Drawing.Point(138, 19);
			this.label10.Name = "label10";
			this.label10.Size = new global::System.Drawing.Size(17, 12);
			this.label10.TabIndex = 13;
			this.label10.Text = "时";
			this.label9.AutoSize = true;
			this.label9.Location = new global::System.Drawing.Point(82, 21);
			this.label9.Name = "label9";
			this.label9.Size = new global::System.Drawing.Size(17, 12);
			this.label9.TabIndex = 12;
			this.label9.Text = "天";
			this.shfen.Location = new global::System.Drawing.Point(156, 14);
			global::System.Windows.Forms.NumericUpDown numericUpDown5 = this.shfen;
			int[] array5 = new int[4];
			array5[0] = 59;
			numericUpDown5.Maximum = new decimal(array5);
			this.shfen.Name = "shfen";
			this.shfen.Size = new global::System.Drawing.Size(35, 21);
			this.shfen.TabIndex = 11;
			this.shshi.Location = new global::System.Drawing.Point(102, 14);
			global::System.Windows.Forms.NumericUpDown numericUpDown6 = this.shshi;
			int[] array6 = new int[4];
			array6[0] = 23;
			numericUpDown6.Maximum = new decimal(array6);
			this.shshi.Name = "shshi";
			this.shshi.Size = new global::System.Drawing.Size(35, 21);
			this.shshi.TabIndex = 10;
			this.shtian.Location = new global::System.Drawing.Point(42, 14);
			global::System.Windows.Forms.NumericUpDown numericUpDown7 = this.shtian;
			int[] array7 = new int[4];
			array7[0] = 999;
			numericUpDown7.Maximum = new decimal(array7);
			this.shtian.Name = "shtian";
			this.shtian.Size = new global::System.Drawing.Size(40, 21);
			this.shtian.TabIndex = 9;
			this.ckbdsxh.AutoSize = true;
			this.ckbdsxh.Location = new global::System.Drawing.Point(7, 42);
			this.ckbdsxh.Name = "ckbdsxh";
			this.ckbdsxh.Size = new global::System.Drawing.Size(36, 16);
			this.ckbdsxh.TabIndex = 8;
			this.ckbdsxh.Text = "下";
			this.ckbdsxh.UseVisualStyleBackColor = true;
			this.ckbdsxh.CheckedChanged += new global::System.EventHandler(this.ckbdsxh_CheckedChanged);
			this.ckbdsxh.Click += new global::System.EventHandler(this.ckbdsxh_Click);
			this.ckbdssh.AutoSize = true;
			this.ckbdssh.Location = new global::System.Drawing.Point(7, 17);
			this.ckbdssh.Name = "ckbdssh";
			this.ckbdssh.Size = new global::System.Drawing.Size(36, 16);
			this.ckbdssh.TabIndex = 6;
			this.ckbdssh.Text = "上";
			this.ckbdssh.UseVisualStyleBackColor = true;
			this.ckbdssh.CheckedChanged += new global::System.EventHandler(this.ckbdssh_CheckedChanged);
			this.label6.AutoSize = true;
			this.label6.Location = new global::System.Drawing.Point(201, 999);
			this.label6.Name = "label6";
			this.label6.Size = new global::System.Drawing.Size(65, 12);
			this.label6.TabIndex = 9;
			this.label6.Text = "已进频道：";
			this.label7.AutoSize = true;
			this.label7.Location = new global::System.Drawing.Point(201, 999);
			this.label7.Name = "label7";
			this.label7.Size = new global::System.Drawing.Size(65, 12);
			this.label7.TabIndex = 7;
			this.label7.Text = "账号总数：";
			this.txtfeng.Enabled = false;
			this.txtfeng.Location = new global::System.Drawing.Point(410, 17);
			this.txtfeng.Name = "txtfeng";
			this.txtfeng.Size = new global::System.Drawing.Size(60, 21);
			this.txtfeng.TabIndex = 12;
			this.label5.AutoSize = true;
			this.label5.Location = new global::System.Drawing.Point(338, 22);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(65, 12);
			this.label5.TabIndex = 11;
			this.label5.Text = "封号数量：";
			this.panel2.Controls.Add(this.lblauthtime);
			this.panel2.Controls.Add(this.lbllastbuhao);
			this.panel2.Controls.Add(this.lblver);
			this.panel2.Controls.Add(this.lbldaoqi);
			this.panel2.Location = new global::System.Drawing.Point(252, 9999);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(758, 26);
			this.panel2.TabIndex = 11;
			this.lblauthtime.AutoSize = true;
			this.lblauthtime.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblauthtime.Location = new global::System.Drawing.Point(560, 8);
			this.lblauthtime.Name = "lblauthtime";
			this.lblauthtime.Size = new global::System.Drawing.Size(37, 14);
			this.lblauthtime.TabIndex = 7;
			this.lblauthtime.Text = "00:00";
			this.lbllastbuhao.AutoSize = true;
			this.lbllastbuhao.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lbllastbuhao.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.lbllastbuhao.ForeColor = global::System.Drawing.Color.Black;
			this.lbllastbuhao.Location = new global::System.Drawing.Point(660, 8);
			this.lbllastbuhao.Name = "lbllastbuhao";
			this.lbllastbuhao.Size = new global::System.Drawing.Size(13, 14);
			this.lbllastbuhao.TabIndex = 5;
			this.lbllastbuhao.Text = "0";
			this.lblver.AutoSize = true;
			this.lblver.BorderStyle = global::System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblver.Location = new global::System.Drawing.Point(600, 8);
			this.lblver.Name = "lblver";
			this.lblver.Size = new global::System.Drawing.Size(55, 14);
			this.lblver.TabIndex = 2;
			this.lblver.Text = "9.28.0.0";
			this.lbldaoqi.AutoSize = true;
			this.lbldaoqi.Dock = global::System.Windows.Forms.DockStyle.Right;
			this.lbldaoqi.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 134);
			this.lbldaoqi.ForeColor = global::System.Drawing.Color.Black;
			this.lbldaoqi.Location = new global::System.Drawing.Point(704, 0);
			this.lbldaoqi.Name = "lbldaoqi";
			this.lbldaoqi.Padding = new global::System.Windows.Forms.Padding(0, 8, 0, 0);
			this.lbldaoqi.RightToLeft = global::System.Windows.Forms.RightToLeft.No;
			this.lbldaoqi.Size = new global::System.Drawing.Size(54, 20);
			this.lbldaoqi.TabIndex = 1;
			this.lbldaoqi.Text = "label10";
			this.lbldaoqi.Visible = false;
			this.groupBox1.Controls.Add(this.rdbweb);
			this.groupBox1.Controls.Add(this.rdbpc);
			this.groupBox1.Location = new global::System.Drawing.Point(812, 999);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new global::System.Drawing.Size(109, 38);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "选择端口";
			this.rdbweb.AutoSize = true;
			this.rdbweb.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.rdbweb.Location = new global::System.Drawing.Point(56, 16);
			this.rdbweb.Name = "rdbweb";
			this.rdbweb.Size = new global::System.Drawing.Size(41, 16);
			this.rdbweb.TabIndex = 2;
			this.rdbweb.Text = "WEB";
			this.rdbweb.UseVisualStyleBackColor = true;
			this.rdbweb.CheckedChanged += new global::System.EventHandler(this.rdbweb_CheckedChanged);
			this.rdbpc.AutoSize = true;
			this.rdbpc.Checked = true;
			this.rdbpc.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.rdbpc.Location = new global::System.Drawing.Point(12, 16);
			this.rdbpc.Name = "rdbpc";
			this.rdbpc.Size = new global::System.Drawing.Size(35, 16);
			this.rdbpc.TabIndex = 0;
			this.rdbpc.TabStop = true;
			this.rdbpc.Text = "PC";
			this.rdbpc.UseVisualStyleBackColor = true;
			this.rdbpc.CheckedChanged += new global::System.EventHandler(this.rdbpc_CheckedChanged);
			this.lblpath.AutoSize = true;
			this.lblpath.Location = new global::System.Drawing.Point(13, 535);
			this.lblpath.Name = "lblpath";
			this.lblpath.Size = new global::System.Drawing.Size(41, 12);
			this.lblpath.TabIndex = 0;
			this.lblpath.Text = "label9";
			this.groupBox3.Controls.Add(this.nvxing);
			this.groupBox3.Controls.Add(this.nanxing);
			this.groupBox3.Controls.Add(this.button2);
			this.groupBox3.Controls.Add(this.button1);
			this.groupBox3.Controls.Add(this.btnchonglian);
			this.groupBox3.Controls.Add(this.btntingzhixiugai);
			this.groupBox3.Controls.Add(this.btndaochu);
			this.groupBox3.Controls.Add(this.btntuichu);
			this.groupBox3.Controls.Add(this.btnqiehuan);
			this.groupBox3.Controls.Add(this.btnresetsudu);
			this.groupBox3.Controls.Add(this.btnsuijixingbie);
			this.groupBox3.Controls.Add(this.btndaoruqianming);
			this.groupBox3.Controls.Add(this.groupBox5);
			this.groupBox3.Controls.Add(this.txtjin);
			this.groupBox3.Controls.Add(this.txtsudu);
			this.groupBox3.Controls.Add(this.btndaorumajia);
			this.groupBox3.Controls.Add(this.label4);
			this.groupBox3.Controls.Add(this.txtzong);
			this.groupBox3.Controls.Add(this.btnjoin);
			this.groupBox3.Controls.Add(this.sfnEqZowcK);
			this.groupBox3.Controls.Add(this.btndaoru);
			this.groupBox3.Controls.Add(this.label3);
			this.groupBox3.Controls.Add(this.txtsid);
			this.groupBox3.Controls.Add(this.label2);
			this.groupBox3.Controls.Add(this.label1);
			this.groupBox3.Location = new global::System.Drawing.Point(6, 10);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new global::System.Drawing.Size(201, 449);
			this.groupBox3.TabIndex = 3;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "功能";
			this.nvxing.Enabled = false;
			this.nvxing.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.nvxing.Location = new global::System.Drawing.Point(109, 167);
			this.nvxing.Name = "nvxing";
			this.nvxing.Size = new global::System.Drawing.Size(74, 28);
			this.nvxing.TabIndex = 25;
			this.nvxing.Text = "修改女性";
			this.nvxing.UseVisualStyleBackColor = true;
			this.nvxing.Click += new global::System.EventHandler(this.nvxing_Click);
			this.nanxing.Enabled = false;
			this.nanxing.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.nanxing.Location = new global::System.Drawing.Point(22, 167);
			this.nanxing.Name = "nanxing";
			this.nanxing.Size = new global::System.Drawing.Size(74, 28);
			this.nanxing.TabIndex = 24;
			this.nanxing.Text = "修改男性";
			this.nanxing.UseVisualStyleBackColor = true;
			this.nanxing.Click += new global::System.EventHandler(this.nanxing_Click);
			this.button2.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.button2.Location = new global::System.Drawing.Point(108, 269);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(74, 28);
			this.button2.TabIndex = 23;
			this.button2.Text = "开始下麦";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.button1.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.button1.Location = new global::System.Drawing.Point(22, 269);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(74, 28);
			this.button1.TabIndex = 22;
			this.button1.Text = "开始抢麦";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.btnchonglian.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btnchonglian.Location = new global::System.Drawing.Point(108, 300);
			this.btnchonglian.Name = "btnchonglian";
			this.btnchonglian.Size = new global::System.Drawing.Size(74, 28);
			this.btnchonglian.TabIndex = 19;
			this.btnchonglian.Text = "重新连接";
			this.btnchonglian.UseVisualStyleBackColor = true;
			this.btnchonglian.Click += new global::System.EventHandler(this.btnchonglian_Click);
			this.btntingzhixiugai.Enabled = false;
			this.btntingzhixiugai.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btntingzhixiugai.Location = new global::System.Drawing.Point(109, 201);
			this.btntingzhixiugai.Name = "btntingzhixiugai";
			this.btntingzhixiugai.Size = new global::System.Drawing.Size(74, 28);
			this.btntingzhixiugai.TabIndex = 20;
			this.btntingzhixiugai.Text = "停止修改";
			this.btntingzhixiugai.UseVisualStyleBackColor = true;
			this.btntingzhixiugai.Click += new global::System.EventHandler(this.btntingzhixiugai_Click);
			this.btndaochu.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btndaochu.Location = new global::System.Drawing.Point(22, 300);
			this.btndaochu.Name = "btndaochu";
			this.btndaochu.Size = new global::System.Drawing.Size(74, 28);
			this.btndaochu.TabIndex = 11;
			this.btndaochu.Text = "导出正常";
			this.btndaochu.UseVisualStyleBackColor = true;
			this.btndaochu.Click += new global::System.EventHandler(this.btndaochu_Click);
			this.btntuichu.Enabled = false;
			this.btntuichu.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btntuichu.Location = new global::System.Drawing.Point(108, 235);
			this.btntuichu.Name = "btntuichu";
			this.btntuichu.Size = new global::System.Drawing.Size(74, 28);
			this.btntuichu.TabIndex = 13;
			this.btntuichu.Text = "退出频道";
			this.btntuichu.UseVisualStyleBackColor = true;
			this.btntuichu.Click += new global::System.EventHandler(this.btntuichu_Click);
			this.btnqiehuan.Enabled = false;
			this.btnqiehuan.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btnqiehuan.Location = new global::System.Drawing.Point(22, 235);
			this.btnqiehuan.Name = "btnqiehuan";
			this.btnqiehuan.Size = new global::System.Drawing.Size(74, 28);
			this.btnqiehuan.TabIndex = 14;
			this.btnqiehuan.Text = "切换频道";
			this.btnqiehuan.UseVisualStyleBackColor = true;
			this.btnqiehuan.Click += new global::System.EventHandler(this.btnqiehuan_Click);
			this.btnresetsudu.Location = new global::System.Drawing.Point(119, 66);
			this.btnresetsudu.Name = "btnresetsudu";
			this.btnresetsudu.Size = new global::System.Drawing.Size(60, 23);
			this.btnresetsudu.TabIndex = 13;
			this.btnresetsudu.Text = "设置";
			this.btnresetsudu.UseVisualStyleBackColor = true;
			this.btnresetsudu.Click += new global::System.EventHandler(this.btnresetsudu_Click);
			this.btnsuijixingbie.Enabled = false;
			this.btnsuijixingbie.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btnsuijixingbie.Location = new global::System.Drawing.Point(22, 201);
			this.btnsuijixingbie.Name = "btnsuijixingbie";
			this.btnsuijixingbie.Size = new global::System.Drawing.Size(74, 28);
			this.btnsuijixingbie.TabIndex = 18;
			this.btnsuijixingbie.Text = "性别随机";
			this.btnsuijixingbie.UseVisualStyleBackColor = true;
			this.btnsuijixingbie.Click += new global::System.EventHandler(this.btnsuijixingbie_Click);
			this.btndaoruqianming.Enabled = false;
			this.btndaoruqianming.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btndaoruqianming.Location = new global::System.Drawing.Point(109, 133);
			this.btndaoruqianming.Name = "btndaoruqianming";
			this.btndaoruqianming.Size = new global::System.Drawing.Size(74, 28);
			this.btndaoruqianming.TabIndex = 17;
			this.btndaoruqianming.Text = "导入签名";
			this.btndaoruqianming.UseVisualStyleBackColor = true;
			this.btndaoruqianming.Click += new global::System.EventHandler(this.btndaoruqianming_Click);
			this.groupBox5.Controls.Add(this.button3);
			this.groupBox5.Controls.Add(this.txthanhuajiange);
			this.groupBox5.Controls.Add(this.label8);
			this.groupBox5.Controls.Add(this.butiao);
			this.groupBox5.Controls.Add(this.btndaoruhanhua);
			this.groupBox5.Controls.Add(this.ckbhanhua);
			this.groupBox5.Controls.Add(this.ckbxianche);
			this.groupBox5.Controls.Add(this.ckbqutubiao);
			this.groupBox5.Controls.Add(this.ckbgongneng);
			this.groupBox5.Location = new global::System.Drawing.Point(8, 334);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new global::System.Drawing.Size(184, 109);
			this.groupBox5.TabIndex = 5;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "高级功能";
			this.button3.Location = new global::System.Drawing.Point(120, 84);
			this.button3.Name = "button3";
			this.button3.Size = new global::System.Drawing.Size(44, 23);
			this.button3.TabIndex = 22;
			this.button3.Text = "设置";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new global::System.EventHandler(this.button3_Click);
			this.txthanhuajiange.Enabled = false;
			this.txthanhuajiange.Location = new global::System.Drawing.Point(69, 86);
			this.txthanhuajiange.Name = "txthanhuajiange";
			this.txthanhuajiange.Size = new global::System.Drawing.Size(45, 21);
			this.txthanhuajiange.TabIndex = 8;
			this.txthanhuajiange.Text = "5000";
			this.label8.AutoSize = true;
			this.label8.Location = new global::System.Drawing.Point(6, 89);
			this.label8.Name = "label8";
			this.label8.Size = new global::System.Drawing.Size(65, 12);
			this.label8.TabIndex = 7;
			this.label8.Text = "打字速度：";
			this.butiao.AutoSize = true;
			this.butiao.Checked = true;
			this.butiao.CheckState = global::System.Windows.Forms.CheckState.Indeterminate;
			this.butiao.Enabled = false;
			this.butiao.FlatStyle = global::System.Windows.Forms.FlatStyle.Popup;
			this.butiao.Location = new global::System.Drawing.Point(59, 999);
			this.butiao.Name = "butiao";
			this.butiao.Size = new global::System.Drawing.Size(82, 16);
			this.butiao.TabIndex = 21;
			this.butiao.Text = "锁定子频道";
			this.butiao.UseVisualStyleBackColor = true;
			this.btndaoruhanhua.Enabled = false;
			this.btndaoruhanhua.Location = new global::System.Drawing.Point(12, 56);
			this.btndaoruhanhua.Name = "btndaoruhanhua";
			this.btndaoruhanhua.Size = new global::System.Drawing.Size(159, 28);
			this.btndaoruhanhua.TabIndex = 6;
			this.btndaoruhanhua.Text = "导入随机打字文本";
			this.btndaoruhanhua.UseVisualStyleBackColor = true;
			this.btndaoruhanhua.Click += new global::System.EventHandler(this.btndaoruhanhua_Click);
			this.ckbhanhua.AutoSize = true;
			this.ckbhanhua.Enabled = false;
			this.ckbhanhua.Location = new global::System.Drawing.Point(111, 17);
			this.ckbhanhua.Name = "ckbhanhua";
			this.ckbhanhua.Size = new global::System.Drawing.Size(48, 16);
			this.ckbhanhua.TabIndex = 5;
			this.ckbhanhua.Text = "打字";
			this.ckbhanhua.UseVisualStyleBackColor = true;
			this.ckbhanhua.CheckedChanged += new global::System.EventHandler(this.ckbhanhua_CheckedChanged);
			this.ckbxianche.AutoSize = true;
			this.ckbxianche.Enabled = false;
			this.ckbxianche.Location = new global::System.Drawing.Point(111, 39);
			this.ckbxianche.Name = "ckbxianche";
			this.ckbxianche.Size = new global::System.Drawing.Size(48, 16);
			this.ckbxianche.TabIndex = 4;
			this.ckbxianche.Text = "显车";
			this.ckbxianche.UseVisualStyleBackColor = true;
			this.ckbqutubiao.AutoSize = true;
			this.ckbqutubiao.Enabled = false;
			this.ckbqutubiao.Location = new global::System.Drawing.Point(8, 39);
			this.ckbqutubiao.Name = "ckbqutubiao";
			this.ckbqutubiao.Size = new global::System.Drawing.Size(60, 16);
			this.ckbqutubiao.TabIndex = 3;
			this.ckbqutubiao.Text = "去图标";
			this.ckbqutubiao.UseVisualStyleBackColor = true;
			this.ckbgongneng.AutoSize = true;
			this.ckbgongneng.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.ckbgongneng.Location = new global::System.Drawing.Point(8, 17);
			this.ckbgongneng.Name = "ckbgongneng";
			this.ckbgongneng.Size = new global::System.Drawing.Size(72, 16);
			this.ckbgongneng.TabIndex = 2;
			this.ckbgongneng.Text = "开启功能";
			this.ckbgongneng.UseVisualStyleBackColor = true;
			this.ckbgongneng.CheckedChanged += new global::System.EventHandler(this.ckbgongneng_CheckedChanged);
			this.txtjin.Enabled = false;
			this.txtjin.Location = new global::System.Drawing.Point(151, 39);
			this.txtjin.Name = "txtjin";
			this.txtjin.Size = new global::System.Drawing.Size(41, 21);
			this.txtjin.TabIndex = 10;
			this.txtsudu.Location = new global::System.Drawing.Point(81, 68);
			this.txtsudu.Name = "txtsudu";
			this.txtsudu.Size = new global::System.Drawing.Size(32, 21);
			this.txtsudu.TabIndex = 6;
			this.txtsudu.Text = "200";
			this.btndaorumajia.Enabled = false;
			this.btndaorumajia.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btndaorumajia.Location = new global::System.Drawing.Point(22, 133);
			this.btndaorumajia.Name = "btndaorumajia";
			this.btndaorumajia.Size = new global::System.Drawing.Size(74, 28);
			this.btndaorumajia.TabIndex = 15;
			this.btndaorumajia.Text = "导入马甲";
			this.btndaorumajia.UseVisualStyleBackColor = true;
			this.btndaorumajia.Click += new global::System.EventHandler(this.btndaorumajia_Click);
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(7, 71);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(65, 12);
			this.label4.TabIndex = 5;
			this.label4.Text = "登陆速度：";
			this.txtzong.Enabled = false;
			this.txtzong.Location = new global::System.Drawing.Point(151, 12);
			this.txtzong.Name = "txtzong";
			this.txtzong.Size = new global::System.Drawing.Size(41, 21);
			this.txtzong.TabIndex = 8;
			this.btnjoin.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btnjoin.Location = new global::System.Drawing.Point(108, 99);
			this.btnjoin.Name = "btnjoin";
			this.btnjoin.Size = new global::System.Drawing.Size(74, 28);
			this.btnjoin.TabIndex = 12;
			this.btnjoin.Text = "进入频道";
			this.btnjoin.UseVisualStyleBackColor = true;
			this.btnjoin.Click += new global::System.EventHandler(this.btnjoin_Click);
			this.sfnEqZowcK.Location = new global::System.Drawing.Point(77, 39);
			this.sfnEqZowcK.Name = "sfnEqZowcK";
			this.sfnEqZowcK.Size = new global::System.Drawing.Size(65, 21);
			this.sfnEqZowcK.TabIndex = 4;
			this.btndaoru.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 134);
			this.btndaoru.Location = new global::System.Drawing.Point(22, 99);
			this.btndaoru.Name = "btndaoru";
			this.btndaoru.Size = new global::System.Drawing.Size(74, 28);
			this.btndaoru.TabIndex = 10;
			this.btndaoru.Text = "导入账号";
			this.btndaoru.UseVisualStyleBackColor = true;
			this.btndaoru.Click += new global::System.EventHandler(this.btndaoru_Click);
			this.label3.AutoSize = true;
			this.label3.Location = new global::System.Drawing.Point(19, 43);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(53, 12);
			this.label3.TabIndex = 3;
			this.label3.Text = "子频道：";
			this.txtsid.Location = new global::System.Drawing.Point(77, 12);
			this.txtsid.Name = "txtsid";
			this.txtsid.Size = new global::System.Drawing.Size(65, 21);
			this.txtsid.TabIndex = 2;
			this.label2.AutoSize = true;
			this.label2.Location = new global::System.Drawing.Point(30, 17);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(41, 12);
			this.label2.TabIndex = 1;
			this.label2.Text = "频道：";
			this.label1.AutoSize = true;
			this.label1.Location = new global::System.Drawing.Point(6, 26);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(0, 12);
			this.label1.TabIndex = 0;
			this.groupBox2.Controls.Add(this.lblhulian);
			this.groupBox2.Controls.Add(this.ckbhulian);
			this.groupBox2.Location = new global::System.Drawing.Point(95, 9999);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new global::System.Drawing.Size(122, 38);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "互联";
			this.groupBox2.Visible = false;
			this.lblhulian.AutoSize = true;
			this.lblhulian.ForeColor = global::System.Drawing.Color.Green;
			this.lblhulian.Location = new global::System.Drawing.Point(53, 18);
			this.lblhulian.Name = "lblhulian";
			this.lblhulian.Size = new global::System.Drawing.Size(41, 12);
			this.lblhulian.TabIndex = 1;
			this.lblhulian.Text = "label1";
			this.ckbhulian.AutoSize = true;
			this.ckbhulian.Location = new global::System.Drawing.Point(5, 16);
			this.ckbhulian.Name = "ckbhulian";
			this.ckbhulian.Size = new global::System.Drawing.Size(48, 16);
			this.ckbhulian.TabIndex = 0;
			this.ckbhulian.Text = "开启";
			this.ckbhulian.UseVisualStyleBackColor = true;
			this.ckbhulian.CheckedChanged += new global::System.EventHandler(this.ckbhulian_CheckedChanged);
			this.ckbhulian.Click += new global::System.EventHandler(this.ckbhulian_Click);
			this.checkBox_1.AutoSize = true;
			this.checkBox_1.Location = new global::System.Drawing.Point(4, 18);
			this.checkBox_1.Name = "checkBox_1";
			this.checkBox_1.Size = new global::System.Drawing.Size(54, 16);
			this.checkBox_1.TabIndex = 5;
			this.checkBox_1.Text = "spoof";
			this.checkBox_1.UseVisualStyleBackColor = true;
			this.checkBox_1.CheckedChanged += new global::System.EventHandler(this.checkBox_1_CheckedChanged);
			this.groupBox8.Controls.Add(this.txtshanghao);
			this.groupBox8.Location = new global::System.Drawing.Point(0, 9999);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new global::System.Drawing.Size(323, 40);
			this.groupBox8.TabIndex = 8;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "上号链接";
			this.groupBox8.Visible = false;
			this.txtshanghao.Location = new global::System.Drawing.Point(6, 13);
			this.txtshanghao.Name = "txtshanghao";
			this.txtshanghao.Size = new global::System.Drawing.Size(315, 21);
			this.txtshanghao.TabIndex = 0;
			this.groupBox9.Controls.Add(this.txtxiahao);
			this.groupBox9.Location = new global::System.Drawing.Point(353, 9999);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new global::System.Drawing.Size(323, 40);
			this.groupBox9.TabIndex = 9;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "下号链接";
			this.groupBox9.Visible = false;
			this.txtxiahao.Location = new global::System.Drawing.Point(6, 13);
			this.txtxiahao.Name = "txtxiahao";
			this.txtxiahao.Size = new global::System.Drawing.Size(315, 21);
			this.txtxiahao.TabIndex = 1;
			this.groupBox_0.Controls.Add(this.ckbduoip);
			this.groupBox_0.Location = new global::System.Drawing.Point(237, 9999);
			this.groupBox_0.Name = "groupBox_0";
			this.groupBox_0.Size = new global::System.Drawing.Size(101, 40);
			this.groupBox_0.TabIndex = 10;
			this.groupBox_0.TabStop = false;
			this.groupBox_0.Text = "监控";
			this.ckbduoip.AutoSize = true;
			this.ckbduoip.Checked = true;
			this.ckbduoip.CheckState = global::System.Windows.Forms.CheckState.Checked;
			this.ckbduoip.Location = new global::System.Drawing.Point(4, 9999);
			this.ckbduoip.Name = "ckbduoip";
			this.ckbduoip.Size = new global::System.Drawing.Size(48, 16);
			this.ckbduoip.TabIndex = 6;
			this.ckbduoip.Text = "多IP";
			this.ckbduoip.UseVisualStyleBackColor = true;
			this.openFileDialog_0.FileName = "openFileDialog1";
			this.groupBox_1.Controls.Add(this.checkBox_1);
			this.groupBox_1.Location = new global::System.Drawing.Point(342, 9999);
			this.groupBox_1.Name = "groupBox_1";
			this.groupBox_1.Size = new global::System.Drawing.Size(109, 40);
			this.groupBox_1.TabIndex = 6;
			this.groupBox_1.TabStop = false;
			this.groupBox_1.Text = "FF";
			this.groupBox_2.Controls.Add(this.txtzuishaoshuliang);
			this.groupBox_2.Controls.Add(this.ckbzhinenghuanhao);
			this.groupBox_2.Location = new global::System.Drawing.Point(342, 9999);
			this.groupBox_2.Name = "groupBox_2";
			this.groupBox_2.Size = new global::System.Drawing.Size(106, 40);
			this.groupBox_2.TabIndex = 12;
			this.groupBox_2.TabStop = false;
			this.groupBox_2.Text = "智能换号";
			this.groupBox_2.Visible = false;
			this.txtzuishaoshuliang.Enabled = false;
			this.txtzuishaoshuliang.Location = new global::System.Drawing.Point(42, 14);
			this.txtzuishaoshuliang.Name = "txtzuishaoshuliang";
			this.txtzuishaoshuliang.Size = new global::System.Drawing.Size(56, 21);
			this.txtzuishaoshuliang.TabIndex = 7;
			this.txtzuishaoshuliang.Text = "0";
			this.ckbzhinenghuanhao.AutoSize = true;
			this.ckbzhinenghuanhao.Enabled = false;
			this.ckbzhinenghuanhao.Location = new global::System.Drawing.Point(4, 19);
			this.ckbzhinenghuanhao.Name = "ckbzhinenghuanhao";
			this.ckbzhinenghuanhao.Size = new global::System.Drawing.Size(36, 16);
			this.ckbzhinenghuanhao.TabIndex = 6;
			this.ckbzhinenghuanhao.Text = "开";
			this.ckbzhinenghuanhao.UseVisualStyleBackColor = true;
			this.timer1.Interval = 1800000;
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 12f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			base.ClientSize = new global::System.Drawing.Size(812, 552);
			base.Controls.Add(this.groupBox_2);
			base.Controls.Add(this.groupBox_1);
			base.Controls.Add(this.groupBox_0);
			base.Controls.Add(this.groupBox9);
			base.Controls.Add(this.groupBox8);
			base.Controls.Add(this.groupBox2);
			base.Controls.Add(this.panel1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "MainForm";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			base.Load += new global::System.EventHandler(this.MainForm_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.mygrid).EndInit();
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.xhfen).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.xhshi).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.xhtian).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.shfen).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.shshi).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.shtian).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.groupBox8.PerformLayout();
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			this.groupBox_0.ResumeLayout(false);
			this.groupBox_0.PerformLayout();
			this.groupBox_1.ResumeLayout(false);
			this.groupBox_1.PerformLayout();
			this.groupBox_2.ResumeLayout(false);
			this.groupBox_2.PerformLayout();
			base.ResumeLayout(false);
		}

		// Token: 0x04000424 RID: 1060
		private global::System.ComponentModel.IContainer icontainer_0;

		// Token: 0x04000425 RID: 1061
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x04000426 RID: 1062
		private global::System.Windows.Forms.GroupBox groupBox1;

		// Token: 0x04000427 RID: 1063
		private global::System.Windows.Forms.RadioButton rdbweb;

		// Token: 0x04000428 RID: 1064
		private global::System.Windows.Forms.RadioButton rdbpc;

		// Token: 0x04000429 RID: 1065
		private global::System.Windows.Forms.GroupBox groupBox2;

		// Token: 0x0400042A RID: 1066
		private global::System.Windows.Forms.CheckBox ckbhulian;

		// Token: 0x0400042B RID: 1067
		private global::System.Windows.Forms.Label lblhulian;

		// Token: 0x0400042C RID: 1068
		private global::System.Windows.Forms.GroupBox groupBox3;

		// Token: 0x0400042D RID: 1069
		private global::System.Windows.Forms.Label label1;

		// Token: 0x0400042E RID: 1070
		private global::System.Windows.Forms.TextBox txtfeng;

		// Token: 0x0400042F RID: 1071
		private global::System.Windows.Forms.TextBox txtsudu;

		// Token: 0x04000430 RID: 1072
		private global::System.Windows.Forms.Label label5;

		// Token: 0x04000431 RID: 1073
		private global::System.Windows.Forms.Label label4;

		// Token: 0x04000432 RID: 1074
		private global::System.Windows.Forms.TextBox txtjin;

		// Token: 0x04000433 RID: 1075
		private global::System.Windows.Forms.TextBox sfnEqZowcK;

		// Token: 0x04000434 RID: 1076
		private global::System.Windows.Forms.Label label6;

		// Token: 0x04000435 RID: 1077
		private global::System.Windows.Forms.Label label3;

		// Token: 0x04000436 RID: 1078
		private global::System.Windows.Forms.TextBox txtzong;

		// Token: 0x04000437 RID: 1079
		private global::System.Windows.Forms.TextBox txtsid;

		// Token: 0x04000438 RID: 1080
		private global::System.Windows.Forms.Label label7;

		// Token: 0x04000439 RID: 1081
		private global::System.Windows.Forms.Label label2;

		// Token: 0x0400043A RID: 1082
		private global::System.Windows.Forms.GroupBox groupBox4;

		// Token: 0x0400043B RID: 1083
		private global::System.Windows.Forms.CheckBox checkBox_0;

		// Token: 0x0400043C RID: 1084
		private global::System.Windows.Forms.CheckBox checkBox_1;

		// Token: 0x0400043D RID: 1085
		private global::System.Windows.Forms.CheckBox ckbhttpurl;

		// Token: 0x0400043E RID: 1086
		private global::System.Windows.Forms.GroupBox groupBox5;

		// Token: 0x0400043F RID: 1087
		private global::System.Windows.Forms.CheckBox ckbxianche;

		// Token: 0x04000440 RID: 1088
		private global::System.Windows.Forms.CheckBox ckbqutubiao;

		// Token: 0x04000441 RID: 1089
		private global::System.Windows.Forms.CheckBox ckbgongneng;

		// Token: 0x04000442 RID: 1090
		private global::System.Windows.Forms.TextBox txthanhuajiange;

		// Token: 0x04000443 RID: 1091
		private global::System.Windows.Forms.Label label8;

		// Token: 0x04000444 RID: 1092
		private global::System.Windows.Forms.Button btndaoruhanhua;

		// Token: 0x04000445 RID: 1093
		private global::System.Windows.Forms.CheckBox ckbhanhua;

		// Token: 0x04000446 RID: 1094
		private global::System.Windows.Forms.GroupBox groupBox6;

		// Token: 0x04000447 RID: 1095
		private global::System.Windows.Forms.Button btnsuijixingbie;

		// Token: 0x04000448 RID: 1096
		private global::System.Windows.Forms.Button btndaoruqianming;

		// Token: 0x04000449 RID: 1097
		private global::System.Windows.Forms.Button btndaorumajia;

		// Token: 0x0400044A RID: 1098
		private global::System.Windows.Forms.Button btnqiehuan;

		// Token: 0x0400044B RID: 1099
		private global::System.Windows.Forms.Button btntuichu;

		// Token: 0x0400044C RID: 1100
		private global::System.Windows.Forms.Button btnjoin;

		// Token: 0x0400044D RID: 1101
		private global::System.Windows.Forms.Button btndaochu;

		// Token: 0x0400044E RID: 1102
		private global::System.Windows.Forms.Button btndaoru;

		// Token: 0x0400044F RID: 1103
		private global::System.Windows.Forms.GroupBox groupBox7;

		// Token: 0x04000450 RID: 1104
		private global::System.Windows.Forms.CheckBox ckbdsxh;

		// Token: 0x04000451 RID: 1105
		private global::System.Windows.Forms.CheckBox ckbdssh;

		// Token: 0x04000452 RID: 1106
		private global::System.Windows.Forms.GroupBox groupBox8;

		// Token: 0x04000453 RID: 1107
		private global::System.Windows.Forms.TextBox txtshanghao;

		// Token: 0x04000454 RID: 1108
		private global::System.Windows.Forms.GroupBox groupBox9;

		// Token: 0x04000455 RID: 1109
		private global::System.Windows.Forms.TextBox txtxiahao;

		// Token: 0x04000456 RID: 1110
		private global::System.Windows.Forms.GroupBox groupBox_0;

		// Token: 0x04000457 RID: 1111
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x04000458 RID: 1112
		private global::System.Windows.Forms.Label lbldaoqi;

		// Token: 0x04000459 RID: 1113
		private global::System.Windows.Forms.Label lblpath;

		// Token: 0x0400045A RID: 1114
		private global::System.Windows.Forms.OpenFileDialog openFileDialog_0;

		// Token: 0x0400045B RID: 1115
		private global::System.Windows.Forms.SaveFileDialog saveFileDialog_0;

		// Token: 0x0400045C RID: 1116
		private global::System.Windows.Forms.DataGridView mygrid;

		// Token: 0x0400045D RID: 1117
		private global::System.Windows.Forms.GroupBox groupBox_1;

		// Token: 0x0400045E RID: 1118
		private global::System.Windows.Forms.CheckBox ckbhttplocal;

		// Token: 0x0400045F RID: 1119
		private global::System.Windows.Forms.Label lblshijizaixian;

		// Token: 0x04000460 RID: 1120
		private global::System.Windows.Forms.Label lbllastbuhao;

		// Token: 0x04000461 RID: 1121
		private global::System.Windows.Forms.CheckBox ckbduoip;

		// Token: 0x04000462 RID: 1122
		private global::System.Windows.Forms.Label lblauthtime;

		// Token: 0x04000463 RID: 1123
		private global::System.Windows.Forms.Label label12;

		// Token: 0x04000464 RID: 1124
		private global::System.Windows.Forms.Label label13;

		// Token: 0x04000465 RID: 1125
		private global::System.Windows.Forms.Label label14;

		// Token: 0x04000466 RID: 1126
		private global::System.Windows.Forms.NumericUpDown xhfen;

		// Token: 0x04000467 RID: 1127
		private global::System.Windows.Forms.NumericUpDown xhshi;

		// Token: 0x04000468 RID: 1128
		private global::System.Windows.Forms.NumericUpDown xhtian;

		// Token: 0x04000469 RID: 1129
		private global::System.Windows.Forms.Label label11;

		// Token: 0x0400046A RID: 1130
		private global::System.Windows.Forms.Label label10;

		// Token: 0x0400046B RID: 1131
		private global::System.Windows.Forms.Label label9;

		// Token: 0x0400046C RID: 1132
		private global::System.Windows.Forms.NumericUpDown shfen;

		// Token: 0x0400046D RID: 1133
		private global::System.Windows.Forms.NumericUpDown shshi;

		// Token: 0x0400046E RID: 1134
		private global::System.Windows.Forms.NumericUpDown shtian;

		// Token: 0x0400046F RID: 1135
		private global::System.Windows.Forms.Button btnchonglian;

		// Token: 0x04000470 RID: 1136
		private global::System.Windows.Forms.Button btnresetsudu;

		// Token: 0x04000471 RID: 1137
		private global::System.Windows.Forms.Button btntingzhixiugai;

		// Token: 0x04000472 RID: 1138
		private global::System.Windows.Forms.CheckBox ckbhunhe;

		// Token: 0x04000473 RID: 1139
		private global::System.Windows.Forms.Label lblver;

		// Token: 0x04000474 RID: 1140
		private global::System.Windows.Forms.GroupBox groupBox_2;

		// Token: 0x04000475 RID: 1141
		private global::System.Windows.Forms.TextBox txtzuishaoshuliang;

		// Token: 0x04000476 RID: 1142
		private global::System.Windows.Forms.CheckBox ckbzhinenghuanhao;

		// Token: 0x0400047E RID: 1150
		private global::System.Windows.Forms.Label label15;

		// Token: 0x0400047F RID: 1151
		private global::System.Windows.Forms.Label labelOverTime;

		// Token: 0x04000480 RID: 1152
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000481 RID: 1153
		private global::System.ComponentModel.IContainer components;

		// Token: 0x04000482 RID: 1154
		private global::System.Windows.Forms.CheckBox butiao;

		// Token: 0x04000483 RID: 1155
		private global::System.Windows.Forms.Button btn_tingzhishuahua;

		// Token: 0x04000484 RID: 1156
		private global::System.Windows.Forms.Button btn_songhua;

		// Token: 0x04000485 RID: 1157
		private global::System.Windows.Forms.TextBox txt_shuahuauid;

		// Token: 0x04000487 RID: 1159
		private global::System.Windows.Forms.Label label16;

		// Token: 0x04000488 RID: 1160
		private global::System.Windows.Forms.Button button1;

		// Token: 0x04000489 RID: 1161
		private global::System.Windows.Forms.Button button2;

		// Token: 0x0400048A RID: 1162
		private global::System.Windows.Forms.Label label17;

		// Token: 0x0400048B RID: 1163
		private global::System.Windows.Forms.TextBox shuahuasudu;

		// Token: 0x0400048D RID: 1165
		private global::System.Windows.Forms.Button nvxing;

		// Token: 0x0400048E RID: 1166
		private global::System.Windows.Forms.Button nanxing;

		// Token: 0x0400048F RID: 1167
		private global::System.Windows.Forms.Button zhibotongzhi;

		// Token: 0x04000490 RID: 1168
		private global::System.Windows.Forms.Button tingzhizhibotongzhi;

		// Token: 0x04000491 RID: 1169
		private global::System.Windows.Forms.Button button3;

		// Token: 0x04000492 RID: 1170
		private global::System.Windows.Forms.Button tzdaka;

		// Token: 0x04000493 RID: 1171
		private global::System.Windows.Forms.Button daka;

		// Token: 0x04000494 RID: 1172
		private global::System.Windows.Forms.CheckBox buhao;

		// Token: 0x04000495 RID: 1173
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_8;

		// Token: 0x04000496 RID: 1174
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_9;

		// Token: 0x04000497 RID: 1175
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_10;

		// Token: 0x04000498 RID: 1176
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_11;

		// Token: 0x04000499 RID: 1177
		private global::System.Windows.Forms.DataGridViewTextBoxColumn CF;

		// Token: 0x0400049A RID: 1178
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_12;

		// Token: 0x0400049B RID: 1179
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_13;

		// Token: 0x0400049C RID: 1180
		private global::System.Windows.Forms.DataGridViewTextBoxColumn CKI;

		// Token: 0x0400049D RID: 1181
		private global::System.Windows.Forms.DataGridViewTextBoxColumn Trace;

		// Token: 0x0400049E RID: 1182
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_14;

		// Token: 0x0400049F RID: 1183
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_15;

		// Token: 0x040004A0 RID: 1184
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn_16;
	}
}
