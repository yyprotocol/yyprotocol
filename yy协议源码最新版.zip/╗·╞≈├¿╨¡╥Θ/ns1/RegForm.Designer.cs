﻿namespace ns1
{
	// Token: 0x020000B0 RID: 176
	public partial class RegForm : global::System.Windows.Forms.Form
	{
		// Token: 0x060005DD RID: 1501 RVA: 0x0017D3EC File Offset: 0x0017D3EC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::ns1.RegForm));
			this.button1 = new global::System.Windows.Forms.Button();
			this.Cancel = new global::System.Windows.Forms.Button();
			this.OK = new global::System.Windows.Forms.Button();
			this.label5 = new global::System.Windows.Forms.Label();
			this.label4 = new global::System.Windows.Forms.Label();
			this.label2 = new global::System.Windows.Forms.Label();
			this.textBox2 = new global::System.Windows.Forms.TextBox();
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			base.SuspendLayout();
			this.button1.Location = new global::System.Drawing.Point(360, 77);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(59, 23);
			this.button1.TabIndex = 14;
			this.button1.Text = "复制";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new global::System.EventHandler(this.button1_Click_1);
			this.Cancel.Location = new global::System.Drawing.Point(226, 211);
			this.Cancel.Name = "Cancel";
			this.Cancel.Size = new global::System.Drawing.Size(86, 33);
			this.Cancel.TabIndex = 12;
			this.Cancel.Text = "取消";
			this.Cancel.UseVisualStyleBackColor = true;
			this.Cancel.Click += new global::System.EventHandler(this.Cancel_Click_1);
			this.OK.Location = new global::System.Drawing.Point(114, 211);
			this.OK.Name = "OK";
			this.OK.Size = new global::System.Drawing.Size(86, 33);
			this.OK.TabIndex = 13;
			this.OK.Text = "确定";
			this.OK.UseVisualStyleBackColor = true;
			this.OK.Click += new global::System.EventHandler(this.OK_Click_1);
			this.label5.AutoSize = true;
			this.label5.Location = new global::System.Drawing.Point(151, 36);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(77, 12);
			this.label5.TabIndex = 10;
			this.label5.Text = "以获取注册码";
			this.label4.AutoSize = true;
			this.label4.Location = new global::System.Drawing.Point(30, 36);
			this.label4.Name = "label4";
			this.label4.Size = new global::System.Drawing.Size(125, 12);
			this.label4.TabIndex = 11;
			this.label4.Text = "请将机器码发送给卖家";
			this.label2.AutoSize = true;
			this.label2.ForeColor = global::System.Drawing.Color.Red;
			this.label2.Location = new global::System.Drawing.Point(30, 18);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(149, 12);
			this.label2.TabIndex = 9;
			this.label2.Text = "软件尚未注册或注册已过期";
			this.textBox2.Location = new global::System.Drawing.Point(30, 128);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new global::System.Drawing.Size(381, 66);
			this.textBox2.TabIndex = 7;
			this.textBox1.Location = new global::System.Drawing.Point(30, 78);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new global::System.Drawing.Size(324, 21);
			this.textBox1.TabIndex = 8;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 134);
			this.label3.Location = new global::System.Drawing.Point(28, 113);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(44, 12);
			this.label3.TabIndex = 5;
			this.label3.Text = "注册码";
			this.label1.AutoSize = true;
			this.label1.Font = new global::System.Drawing.Font("宋体", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 134);
			this.label1.Location = new global::System.Drawing.Point(28, 63);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(51, 12);
			this.label1.TabIndex = 6;
			this.label1.Text = "机器码:";
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Inherit;
			this.AutoSize = true;
			base.ClientSize = new global::System.Drawing.Size(437, 262);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.Cancel);
			base.Controls.Add(this.OK);
			base.Controls.Add(this.label5);
			base.Controls.Add(this.label4);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.textBox2);
			base.Controls.Add(this.textBox1);
			base.Controls.Add(this.label3);
			base.Controls.Add(this.label1);
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "RegForm";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "机器猫协议注册授权";
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040004F6 RID: 1270
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040004F7 RID: 1271
		private global::System.Windows.Forms.Button Cancel;

		// Token: 0x040004F8 RID: 1272
		private global::System.Windows.Forms.Button OK;

		// Token: 0x040004F9 RID: 1273
		private global::System.Windows.Forms.Label label5;

		// Token: 0x040004FA RID: 1274
		private global::System.Windows.Forms.Label label4;

		// Token: 0x040004FB RID: 1275
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040004FC RID: 1276
		private global::System.Windows.Forms.TextBox textBox2;

		// Token: 0x040004FD RID: 1277
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040004FE RID: 1278
		private global::System.Windows.Forms.Label label3;

		// Token: 0x040004FF RID: 1279
		private global::System.Windows.Forms.Label label1;
	}
}
