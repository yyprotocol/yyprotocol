﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using JIQIMAO.Common;
using JIQIMAO.Model;
using JIQIMAO.Model.YYModel;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;
using Org.Mentalis.Network.ProxySocket;

namespace ns1
{
	// Token: 0x0200009F RID: 159
	public partial class MainForm : Form
	{
		// Token: 0x0600052A RID: 1322 RVA: 0x00170EEC File Offset: 0x00170EEC
		private void method_0()
		{
			try
			{
				this.timer_9.Enabled = true;
				this.timer_9.Start();
				this.timer_10.Enabled = true;
				this.timer_10.Start();
				this.timer_11.Enabled = true;
				this.timer_11.Start();
				this.timer_2.Enabled = true;
				this.timer_2.Start();
				this.timer_12.Enabled = true;
				this.timer_12.Start();
				this.timer_8.Enabled = true;
				this.timer_8.Start();
			}
			catch
			{
			}
		}

		// Token: 0x0600052B RID: 1323 RVA: 0x00170F98 File Offset: 0x00170F98
		private void method_1()
		{
			try
			{
				this.timer_9.Enabled = false;
				this.timer_9.Stop();
				this.timer_10.Enabled = false;
				this.timer_10.Stop();
				this.timer_11.Enabled = false;
				this.timer_11.Stop();
				this.timer_2.Enabled = false;
				this.timer_2.Stop();
				this.timer_12.Enabled = false;
				this.timer_12.Stop();
				this.timer_8.Enabled = false;
				this.timer_8.Stop();
			}
			catch
			{
			}
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00171044 File Offset: 0x00171044
		private void method_2()
		{
			this.timer_0 = new System.Timers.Timer(3000.0);
			this.timer_0.Elapsed += this.timer_0_Elapsed;
			this.timer_0.AutoReset = true;
			this.timer_1 = new System.Timers.Timer(3000.0);
			this.timer_1.Elapsed += this.timer_1_Elapsed;
			this.timer_1.AutoReset = true;
			this.timer_1.Enabled = true;
			this.timer_1.Start();
			this.timer_3 = new System.Timers.Timer(30000.0);
			this.timer_3.Elapsed += this.timer_3_Elapsed;
			this.timer_3.AutoReset = true;
			this.timer_3.Enabled = true;
			this.timer_3.Start();
			this.timer_4 = new System.Timers.Timer(60000.0);
			this.timer_4.Elapsed += this.timer_4_Elapsed;
			this.timer_4.AutoReset = true;
			this.timer_4.Enabled = true;
			this.timer_4.Start();
			this.timer_5 = new System.Timers.Timer(60000.0);
			this.timer_5.Elapsed += this.timer_5_Elapsed;
			this.timer_5.AutoReset = true;
			this.timer_5.Enabled = true;
			this.timer_5.Start();
			this.timer_6 = new System.Timers.Timer(60000.0);
			this.timer_6.Elapsed += this.timer_6_Elapsed;
			this.timer_6.AutoReset = true;
			this.timer_6.Enabled = true;
			this.timer_6.Start();
			this.timer_9 = new System.Timers.Timer(1000.0);
			this.timer_9.Elapsed += this.timer_9_Elapsed;
			this.timer_9.AutoReset = true;
			this.timer_10 = new System.Timers.Timer(1000.0);
			this.timer_10.Elapsed += this.timer_10_Elapsed;
			this.timer_10.AutoReset = true;
			this.timer_11 = new System.Timers.Timer(3000.0);
			this.timer_11.Elapsed += this.timer_11_Elapsed;
			this.timer_11.AutoReset = true;
			this.timer_2 = new System.Timers.Timer(1000.0);
			this.timer_2.Elapsed += this.timer_2_Elapsed;
			this.timer_2.AutoReset = true;
			this.timer_12 = new System.Timers.Timer(4000.0);
			this.timer_12.Elapsed += this.timer_12_Elapsed;
			this.timer_12.AutoReset = true;
			this.timer_8 = new System.Timers.Timer(90000.0);
			this.timer_8.Elapsed += this.timer_8_Elapsed;
			this.timer_8.AutoReset = true;
		}

		// Token: 0x0600052D RID: 1325 RVA: 0x00171358 File Offset: 0x00171358
		private void timer_0_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_6, 1) == 0)
			{
				try
				{
					this.mygrid.BeginInvoke(new MethodInvoker(this.method_17));
					if (this.concurrentBag_0 != null && this.concurrentBag_0.Count > 0)
					{
						this.int_3 = this.concurrentBag_0.Count;
						this.int_4 = this.concurrentBag_0.Count((MyUser1225 p) => p.status == 2 && !p.isfenghao && !p.isskip);
						this.int_5 = this.concurrentBag_0.Count((MyUser1225 p) => p.isfenghao);
						this.txtzong.BeginInvoke(new MethodInvoker(this.method_18));
						this.txtjin.BeginInvoke(new MethodInvoker(this.method_19));
						this.txtfeng.BeginInvoke(new MethodInvoker(this.method_20));
						base.BeginInvoke(new MethodInvoker(this.method_21));
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_6, 0);
				}
			}
		}

		// Token: 0x0600052E RID: 1326 RVA: 0x001714BC File Offset: 0x001714BC
		private void timer_1_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_7, 1) == 0)
			{
				try
				{
					string path = "C:\\Windows\\wips.txt";
					if (this.rdbweb.Checked)
					{
						path = "C:\\Windows\\wips.txt";
					}
					if (File.Exists(path))
					{
						string[] array = File.ReadAllLines(path);
						ConcurrentBag<myip> concurrentBag = new ConcurrentBag<myip>();
						string[] array2 = array;
						foreach (string text in array2)
						{
							if (!string.IsNullOrWhiteSpace(text))
							{
								myip myip = new myip();
								try
								{
									string[] array4 = text.Split(new char[]
									{
										'|'
									});
									int[] array5 = new int[2];
									myip.ip = array4[0];
									array5[0] = Convert.ToInt32(array4[1].Split(new char[]
									{
										','
									})[0]);
									array5[1] = Convert.ToInt32(array4[1].Split(new char[]
									{
										','
									})[1]);
									myip.ports = array5;
									concurrentBag.Add(myip);
								}
								catch
								{
								}
							}
						}
						if (concurrentBag.Count > 0)
						{
							this.concurrentBag_1 = concurrentBag;
							this.timer_1.Interval = 15000.0;
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_7, 0);
				}
			}
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x00171640 File Offset: 0x00171640
		private void timer_3_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_8, 1) == 0)
			{
				try
				{
					if (this.ckbhulian.Checked)
					{
						int num = this.method_4();
						string strHl = "";
						switch (num)
						{
						case 0:
							strHl = "监控中...";
							break;
						case 1:
							strHl = "上号";
							break;
						case 2:
							strHl = "下号";
							break;
						}
						if (num != 0)
						{
							this.lblhulian.BeginInvoke(new MethodInvoker(delegate()
							{
								try
								{
									this.lblhulian.Text = strHl;
								}
								catch
								{
								}
							}));
							if (num == 1 && this.btnjoin.Enabled)
							{
								this.btnjoin_Click(sender, e);
							}
							else if (num == 2 && this.btntuichu.Enabled)
							{
								this.btntuichu_Click(sender, e);
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_8, 0);
				}
			}
		}

		// Token: 0x06000530 RID: 1328 RVA: 0x00171744 File Offset: 0x00171744
		private void timer_4_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_9, 1) == 0)
			{
				try
				{
					this.int_0--;
					if (this.int_0 <= 0)
					{
						base.Close();
						Application.ExitThread();
					}
					this.dateTime_0 = DateTime.Now;
					this.int_0 = 99999999;
					if (this.int_0 <= 0)
					{
						base.Close();
						Application.ExitThread();
					}
					this.lbldaoqi.BeginInvoke(new MethodInvoker(this.method_22));
					this.lblauthtime.BeginInvoke(new MethodInvoker(this.method_23));
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_9, 0);
				}
			}
		}

		// Token: 0x06000531 RID: 1329 RVA: 0x0017180C File Offset: 0x0017180C
		private void timer_9_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_10, 1) == 0)
			{
				try
				{
					if (!this.bool_0)
					{
						IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
						where p.loginstatus == 0 && !p.isfenghao
						select p;
						if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
						{
							using (IEnumerator<MyUser1225> enumerator = enumerable.Reverse<MyUser1225>().GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									MyUser1225 item = enumerator.Current;
									try
									{
										if (this.bool_0)
										{
											break;
										}
										item.logintype = (this.rdbpc.Checked ? 1 : 2);
										item.status = 1;
										item.loginstatus = 1;
										item.startlogintime = DateTime.Now;
										item.sid = this.rQaQnYbAnm;
										item.subid = this.uint_0;
										item.isgongneng = this.ckbgongneng.Checked;
										item.isqutubiao = this.ckbqutubiao.Checked;
										item.isxianche = this.ckbxianche.Checked;
										Task.Factory.StartNew(delegate()
										{
											this.ldfekfAwP(item);
										});
									}
									catch
									{
									}
									Thread.Sleep(this.int_1);
								}
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_10, 0);
				}
			}
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x00171A08 File Offset: 0x00171A08
		private void timer_10_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_11, 1) == 0)
			{
				try
				{
					if (!this.bool_0)
					{
						IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
						where p.loginstatus == -1 && !p.isfenghao
						select p;
						if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
						{
							using (IEnumerator<MyUser1225> enumerator = enumerable.GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									MyUser1225 item = enumerator.Current;
									try
									{
										if (this.bool_0)
										{
											break;
										}
										item.status = 1;
										item.loginstatus = 1;
										item.startlogintime = DateTime.Now;
										Task.Factory.StartNew(delegate()
										{
											this.ldfekfAwP(item);
										});
									}
									catch
									{
									}
									Thread.Sleep(this.int_1);
								}
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_11, 0);
				}
			}
		}

		// Token: 0x06000533 RID: 1331 RVA: 0x00171B44 File Offset: 0x00171B44
		private void timer_11_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_12, 1) == 0)
			{
				try
				{
					if (!this.bool_0)
					{
						IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
						where p.loginstatus == 1 && p.startlogintime != DateTime.MinValue && p.startlogintime.AddMinutes(1.0) < DateTime.Now && !p.isfenghao
						select p;
						if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
						{
							foreach (MyUser1225 myUser in enumerable)
							{
								if (this.bool_0)
								{
									break;
								}
								try
								{
									if (myUser.loginstatus == 1)
									{
										myUser.loginstatus = ((this.random_0.NextDouble() > 0.5) ? -1 : 0);
									}
								}
								catch
								{
								}
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_12, 0);
				}
			}
		}

		// Token: 0x06000534 RID: 1332 RVA: 0x00171C48 File Offset: 0x00171C48
		private void ldfekfAwP(MyUser1225 myUser1225_0)
		{
			try
			{
				if (this.rdbpc.Checked)
				{
					myUser1225_0.loginstatus = 2;
				}
				else
				{
					object arg = this.method_3(myUser1225_0);
					if (MainForm.<>o__188.<>p__1 == null)
					{
						MainForm.<>o__188.<>p__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(MainForm), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
						}));
					}
					Func<CallSite, object, bool> target = MainForm.<>o__188.<>p__1.Target;
					CallSite <>p__ = MainForm.<>o__188.<>p__1;
					if (MainForm.<>o__188.<>p__0 == null)
					{
						MainForm.<>o__188.<>p__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.Equal, typeof(MainForm), new CSharpArgumentInfo[]
						{
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
							CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
						}));
					}
					if (target(<>p__, MainForm.<>o__188.<>p__0.Target(MainForm.<>o__188.<>p__0, arg, null)))
					{
						string text = "";
						if (!this.ckbhttpurl.Checked && !this.ckbhttplocal.Checked)
						{
							myUser1225_0.daili = "";
						}
						else
						{
							if (this.list_0.Count > 0)
							{
								text = this.list_0[this.random_0.Next(0, this.list_0.Count)];
							}
							myUser1225_0.daili = text;
						}
						loginret loginret = new loginret();
						if (new weblogin(myUser1225_0, text).userlogin(loginret))
						{
							string ck_username = loginret.ck_username;
							string ck_udb_l = loginret.ck_udb_l;
							string uid = loginret.uid;
							myUser1225_0.uid = Convert.ToUInt32(uid);
							myUser1225_0.username = ck_username;
							myUser1225_0.pwden = ck_udb_l;
							myUser1225_0.yanzhengma = loginret.vcode;
							savewebuser savewebuser = new savewebuser();
							savewebuser.username = ck_username;
							savewebuser.pwd = ck_udb_l;
							savewebuser.uid = uid;
							try
							{
								string msg = MyEncrypt.AesEncryptor(JsonConvert.SerializeObject(savewebuser));
								logtool.logusercache_w(myUser1225_0.passport, msg);
							}
							catch
							{
							}
							myUser1225_0.loginstatus = 2;
						}
						else if (loginret.isfenghao)
						{
							myUser1225_0.isfenghao = true;
							myUser1225_0.status = 3;
						}
						else
						{
							myUser1225_0.loginstatus = -1;
						}
					}
					else
					{
						if (MainForm.<>o__188.<>p__3 == null)
						{
							MainForm.<>o__188.<>p__3 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
						}
						Func<CallSite, object, string> target2 = MainForm.<>o__188.<>p__3.Target;
						CallSite <>p__2 = MainForm.<>o__188.<>p__3;
						if (MainForm.<>o__188.<>p__2 == null)
						{
							MainForm.<>o__188.<>p__2 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "uid", typeof(MainForm), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						string value = target2(<>p__2, MainForm.<>o__188.<>p__2.Target(MainForm.<>o__188.<>p__2, arg));
						if (MainForm.<>o__188.<>p__5 == null)
						{
							MainForm.<>o__188.<>p__5 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
						}
						Func<CallSite, object, string> target3 = MainForm.<>o__188.<>p__5.Target;
						CallSite <>p__3 = MainForm.<>o__188.<>p__5;
						if (MainForm.<>o__188.<>p__4 == null)
						{
							MainForm.<>o__188.<>p__4 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "username", typeof(MainForm), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						string username = target3(<>p__3, MainForm.<>o__188.<>p__4.Target(MainForm.<>o__188.<>p__4, arg));
						if (MainForm.<>o__188.<>p__7 == null)
						{
							MainForm.<>o__188.<>p__7 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
						}
						Func<CallSite, object, string> target4 = MainForm.<>o__188.<>p__7.Target;
						CallSite <>p__4 = MainForm.<>o__188.<>p__7;
						if (MainForm.<>o__188.<>p__6 == null)
						{
							MainForm.<>o__188.<>p__6 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "pwd", typeof(MainForm), new CSharpArgumentInfo[]
							{
								CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
							}));
						}
						string pwden = target4(<>p__4, MainForm.<>o__188.<>p__6.Target(MainForm.<>o__188.<>p__6, arg));
						myUser1225_0.uid = Convert.ToUInt32(value);
						myUser1225_0.username = username;
						myUser1225_0.pwden = pwden;
						myUser1225_0.loginstatus = 2;
					}
				}
			}
			catch
			{
				myUser1225_0.loginstatus = ((this.random_0.NextDouble() > 0.5) ? -1 : 0);
			}
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0017206C File Offset: 0x0017206C
		[return: Dynamic]
		private dynamic method_3(MyUser1225 myUser1225_0)
		{
			object result;
			try
			{
				string path = Application.StartupPath + "\\Cache2\\" + string.Format("{0}.txt", myUser1225_0.passport);
				if (!File.Exists(path))
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<object>(MyEncrypt.AesDecryptor(File.ReadAllText(path)));
				}
			}
			catch (Exception)
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000536 RID: 1334 RVA: 0x001720D0 File Offset: 0x001720D0
		[return: Dynamic]
		public dynamic getpcuser(MyUser1225 uu)
		{
			object result;
			try
			{
				string path = string.Format(Application.StartupPath + "\\Cache1\\{0}.txt", uu.passport);
				if (!File.Exists(path))
				{
					result = null;
				}
				else
				{
					result = JsonConvert.DeserializeObject<object>(MyEncrypt.AesDecryptor(File.ReadAllText(path)));
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000537 RID: 1335 RVA: 0x00172130 File Offset: 0x00172130
		private void timer_5_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				if (this.ckbdssh.Checked && !(this.dateTime_1 == DateTime.MinValue) && this.btnjoin.Enabled && DateTime.Now > this.dateTime_1)
				{
					this.btnjoin_Click(sender, e);
					this.timer_5.Enabled = false;
					this.timer_5.Stop();
					this.ckbdssh.BeginInvoke(new MethodInvoker(this.method_24));
					this.dateTime_1 = DateTime.MinValue;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000538 RID: 1336 RVA: 0x001721D4 File Offset: 0x001721D4
		private void timer_6_Elapsed(object sender, ElapsedEventArgs e)
		{
			try
			{
				if (this.ckbdsxh.Checked && !(this.dateTime_2 == DateTime.MinValue) && this.btntuichu.Enabled && DateTime.Now > this.dateTime_2)
				{
					this.btntuichu_Click(sender, e);
					this.timer_6.Enabled = false;
					this.timer_6.Stop();
					this.ckbdsxh.BeginInvoke(new MethodInvoker(this.method_25));
					this.dateTime_2 = DateTime.MinValue;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000539 RID: 1337 RVA: 0x00172278 File Offset: 0x00172278
		private void timer_2_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_13, 1) == 0)
			{
				try
				{
					string path = "";
					if (this.ckbhttpurl.Checked || this.ckbhttplocal.Checked)
					{
						if (this.ckbhttpurl.Checked)
						{
							path = Application.StartupPath + "\\https.txt";
							if (File.Exists(path))
							{
								if (File.Exists(Application.StartupPath + "\\api.txt") && File.ReadAllText(Application.StartupPath + "\\api.txt").Contains("123.207.144.61"))
								{
									this.bool_1 = true;
								}
								if (!this.bool_1)
								{
									string[] array = File.ReadAllLines(path);
									List<string> list = new List<string>();
									string[] array2 = array;
									foreach (string text in array2)
									{
										if (!string.IsNullOrWhiteSpace(text))
										{
											list.Add(text);
										}
									}
									if (list.Count > 0)
									{
										this.list_0 = list;
									}
								}
								else
								{
									string[] array4 = MyEncrypt.AesDecryptor(File.ReadAllText(path)).Split(new string[]
									{
										Environment.NewLine,
										"\r\n",
										"\\r\\n"
									}, StringSplitOptions.RemoveEmptyEntries);
									if (array4 != null && array4.Count<string>() > 0)
									{
										List<string> list2 = new List<string>();
										string[] array5 = array4;
										foreach (string text2 in array5)
										{
											IPAddress ipaddress;
											if (text2.Split(new char[]
											{
												':'
											}).Length > 1 && IPAddress.TryParse(text2.Split(new char[]
											{
												':'
											})[0], out ipaddress))
											{
												list2.Add(text2);
											}
										}
										if (list2.Count > 0)
										{
											this.list_0 = list2;
										}
									}
								}
							}
						}
						else if (this.ckbhttplocal.Checked)
						{
							path = Application.StartupPath + "\\http.txt";
							if (File.Exists(path))
							{
								string[] array7 = File.ReadAllLines(path);
								List<string> list3 = new List<string>();
								string[] array8 = array7;
								foreach (string text3 in array8)
								{
									if (!string.IsNullOrWhiteSpace(text3))
									{
										list3.Add(text3);
									}
								}
								if (list3.Count > 0)
								{
									this.list_0 = list3;
								}
							}
						}
					}
					if (this.checkBox_1.Checked || this.checkBox_0.Checked)
					{
						if (this.checkBox_1.Checked)
						{
							path = Application.StartupPath + "\\spoof.txt";
						}
						else if (this.checkBox_0.Checked)
						{
							path = Application.StartupPath + "\\s5.txt";
						}
						if (File.Exists(path))
						{
							string text4 = File.ReadAllText(path);
							if (this.checkBox_1.Checked)
							{
								text4 = MyEncrypt.AesDecryptor(text4);
							}
							string[] array10 = text4.Split(new string[]
							{
								Environment.NewLine,
								"\r\n",
								"\\r\\n"
							}, StringSplitOptions.RemoveEmptyEntries);
							if (array10 != null && array10.Count<string>() > 0)
							{
								List<string> list4 = new List<string>();
								string[] array11 = array10;
								foreach (string text5 in array11)
								{
									if (!string.IsNullOrWhiteSpace(text5))
									{
										list4.Add(text5.Replace(":", "|"));
									}
								}
								if (list4.Count > 0)
								{
									this.list_1 = list4;
								}
							}
						}
					}
					if (this.list_0.Count > 0 || this.list_1.Count > 0)
					{
						this.timer_2.Interval = 8000.0;
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_13, 0);
				}
			}
		}

		// Token: 0x0600053A RID: 1338 RVA: 0x00172644 File Offset: 0x00172644
		private void timer_12_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_14, 1) == 0)
			{
				try
				{
					if (!this.bool_0 && this.list_2.Count != 0)
					{
						IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
						where p.status == 2 && p.isloginservice
						select p;
						if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
						{
							using (IEnumerator<MyUser1225> enumerator = enumerable.GetEnumerator())
							{
								while (enumerator.MoveNext())
								{
									MyUser1225 item = enumerator.Current;
									if (this.bool_0)
									{
										break;
									}
									try
									{
										Task.Factory.StartNew(delegate()
										{
											this.method_16(item);
										});
									}
									catch
									{
									}
									Thread.Sleep(this.int_2);
								}
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_14, 0);
				}
			}
		}

		// Token: 0x0600053B RID: 1339 RVA: 0x00172760 File Offset: 0x00172760
		private int method_4()
		{
			int result;
			try
			{
				uint num;
				if (!uint.TryParse(this.txtsid.Text.Trim(), out num))
				{
					num = 0u;
				}
				uint num2;
				if (!uint.TryParse(this.sfnEqZowcK.Text.Trim(), out num2))
				{
					num2 = 0u;
				}
				string s = string.Format("{2}-{0}-{1}", num, num2, this.string_0);
				string text = Convert.ToBase64String(Encoding.Default.GetBytes(s));
				text = text.Replace("+", "").Replace("/", "").Replace("=", "");
				string string_ = "http://118.89.226.148:8889/getstatus?sn=" + text;
				result = Convert.ToInt32(this.method_5(string_));
			}
			catch
			{
				result = 0;
			}
			return result;
		}

		// Token: 0x0600053C RID: 1340 RVA: 0x00172838 File Offset: 0x00172838
		private string method_5(string string_2)
		{
			HttpWebRequest httpWebRequest = null;
			string result;
			try
			{
				httpWebRequest = (HttpWebRequest)WebRequest.Create(string_2);
				httpWebRequest.Method = "GET";
				using (Stream responseStream = ((HttpWebResponse)httpWebRequest.GetResponse()).GetResponseStream())
				{
					using (StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			catch (Exception)
			{
				result = "";
			}
			finally
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
			}
			return result;
		}

		// Token: 0x0600053D RID: 1341 RVA: 0x001728E0 File Offset: 0x001728E0
		private void timer_8_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (Interlocked.Exchange(ref MainForm.int_15, 1) == 0)
			{
				try
				{
					if (!this.bool_0)
					{
						IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
						where p.status == 2 && !p.isfenghao
						select p;
						if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
						{
							enumerable.ToList<MyUser1225>()[this.random_0.Next(0, enumerable.Count<MyUser1225>())].GetUserCount();
							this.int_16++;
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref MainForm.int_15, 0);
				}
			}
		}

		// Token: 0x0600053E RID: 1342 RVA: 0x0015A517 File Offset: 0x0015A517
		private static bool smethod_0(object object_0, object object_1, object object_2, SslPolicyErrors sslPolicyErrors_0)
		{
			return true;
		}

		// Token: 0x0600053F RID: 1343 RVA: 0x001C60D4 File Offset: 0x001C5ED4
		public MainForm(int shengyu, DateTime checktime, DateTime overTime, bool xc = false)
		{
			this.concurrentBag_0 = new ConcurrentBag<MyUser1225>();
			this.concurrentBag_1 = new ConcurrentBag<myip>();
			this.string_0 = "";
			this.dateTime_0 = DateTime.MinValue;
			this.int_0 = -1;
			this.string_1 = Guid.NewGuid().ToString();
			this.int_1 = 500;
			this.int_2 = 5000;
			this.dateTime_1 = DateTime.MinValue;
			this.dateTime_2 = DateTime.MinValue;
			this.list_4 = new List<uint>();
			this.list_5 = new List<uint>();
			this.yongjiobj_0 = new yongjiobj();
			this.bool_3 = true;
			try
			{
				if (Process.GetProcessesByName("识别").ToList<Process>().Count == 0)
				{
					MessageBox.Show("识别 未开启，不能打开软件！", "提示信息");
					Environment.Exit(0);
				}
				else
				{
					ThreadPool.SetMaxThreads(2048, 4056);
					this.InitializeComponent();
					this.labelOverTime.Text = "Shark凯破解版本";
					this.int_0 = shengyu;
					this.dateTime_0 = checktime;
					this.list_0 = new List<string>();
					this.list_0 = new List<string>();
					this.list_1 = new List<string>();
					this.random_0 = new Random();
					this.list_2 = new List<string>();
					this.mygrid.AutoGenerateColumns = false;
					this.bool_2 = xc;
					if (!this.bool_2)
					{
						this.ckbxianche.Hide();
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000540 RID: 1344 RVA: 0x00172B38 File Offset: 0x00172B38
		private void MainForm_Load(object sender, EventArgs e)
		{
			try
			{
				this.lblpath.Text = (this.lbldaoqi.Text = "");
				this.lblhulian.Text = "";
				this.groupBox8.Hide();
				this.groupBox9.Hide();
				this.panel1.Height += 40;
				this.method_2();
				try
				{
					this.list_3 = new List<string>();
					List<IPAddress> list = (from ip in Dns.GetHostAddresses(Dns.GetHostName())
					where ip.AddressFamily == AddressFamily.InterNetwork
					select ip).ToList<IPAddress>();
					if (list != null && list.Count > 0)
					{
						foreach (IPAddress ipaddress in list)
						{
							this.list_3.Add(ipaddress.ToString());
						}
					}
					string path = "C:\\Windows\\ips.txt";
					if (!File.Exists(path))
					{
						path = "C:\\Windows\\ips.txt";
					}
					if (File.Exists(path))
					{
						try
						{
							string[] array = File.ReadAllLines(path);
							List<string> list2 = new List<string>();
							string[] array2 = array;
							foreach (string text in array2)
							{
								try
								{
									IPAddress ipaddress2;
									if (IPAddress.TryParse(text, out ipaddress2))
									{
										list2.Add(text);
									}
								}
								catch
								{
								}
							}
							if (list2.Count > 0)
							{
								this.list_3 = list2;
							}
						}
						catch
						{
						}
					}
					this.lbllastbuhao.Text = this.list_3.Count.ToString();
				}
				catch
				{
				}
				this.method_6();
			}
			catch
			{
				MessageBox.Show("启动出错！");
				base.Close();
				Application.Exit();
			}
		}

		// Token: 0x06000541 RID: 1345 RVA: 0x00172D70 File Offset: 0x00172D70
		private void method_6()
		{
			try
			{
				string path = Application.StartupPath + "\\设置.txt";
				if (File.Exists(path))
				{
					string text = File.ReadAllText(path);
					if (!string.IsNullOrWhiteSpace(text))
					{
						string[] array = text.Split(new char[]
						{
							'|'
						});
						if (array.Length > 1)
						{
							string a = array[1].Trim();
							if (a == "1")
							{
								this.ckbhttpurl.Checked = true;
							}
							else if (a == "2")
							{
								this.ckbhttplocal.Checked = true;
							}
							else if (a == "3")
							{
								this.checkBox_1.Checked = true;
							}
							else if (a == "4")
							{
								this.checkBox_0.Checked = true;
							}
						}
						if (array.Length != 0)
						{
							string a2 = array[0].Trim();
							if (a2 == "1")
							{
								this.rdbpc.Checked = true;
							}
							else if (a2 == "2")
							{
								this.rdbweb.Checked = true;
							}
						}
						if (array.Length > 2)
						{
							if (array[2].Trim() == "1")
							{
								this.ckbgongneng.Checked = true;
								this.txt_shuahuauid.Enabled = true;
								this.shuahuasudu.Enabled = true;
								this.btn_songhua.Enabled = true;
								this.btn_tingzhishuahua.Enabled = true;
								this.zhibotongzhi.Enabled = true;
								this.tingzhizhibotongzhi.Enabled = true;
								this.daka.Enabled = true;
								this.tzdaka.Enabled = true;
								if (array.Length > 3)
								{
									if (array[3].Trim() == "1")
									{
										this.ckbqutubiao.Checked = true;
									}
									else
									{
										this.ckbqutubiao.Checked = false;
									}
								}
								if (array.Length > 4)
								{
									if (array[4].Trim() == "1" && this.ckbxianche.Visible)
									{
										this.ckbxianche.Checked = true;
									}
									else
									{
										this.ckbxianche.Checked = false;
									}
								}
								if (array.Length > 5)
								{
									if (array[5].Trim() == "1")
									{
										this.ckbhanhua.Checked = true;
									}
									else
									{
										this.ckbhanhua.Checked = false;
									}
								}
								if (array.Length > 7)
								{
									this.txthanhuajiange.Text = array[7].ToString();
								}
							}
							else
							{
								this.ckbgongneng.Checked = false;
								this.txt_shuahuauid.Enabled = false;
								this.shuahuasudu.Enabled = false;
								this.btn_songhua.Enabled = false;
								this.btn_tingzhishuahua.Enabled = false;
								this.zhibotongzhi.Enabled = false;
								this.tingzhizhibotongzhi.Enabled = false;
								this.daka.Enabled = false;
								this.tzdaka.Enabled = false;
							}
						}
						if (array.Length > 6)
						{
							this.txtsudu.Text = array[6].ToString();
						}
						if (array.Length > 8)
						{
							if (array[8].Trim() == "1")
							{
								this.ckbhunhe.Checked = true;
							}
							else
							{
								this.ckbhunhe.Checked = false;
							}
							if (array[9].Trim() == "1")
							{
								this.buhao.Checked = true;
							}
							else
							{
								this.buhao.Checked = false;
							}
						}
						if (array.Length > 10)
						{
							this.txtsid.Text = array[10].ToString();
						}
						if (array.Length > 11)
						{
							this.sfnEqZowcK.Text = array[11].ToString();
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000542 RID: 1346 RVA: 0x0017310C File Offset: 0x0017310C
		private void ckbhulian_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				CheckBox checkBox = (CheckBox)sender;
				if (checkBox.Checked)
				{
					uint num;
					if (!uint.TryParse(this.txtsid.Text.Trim(), out num))
					{
						MessageBox.Show("主频道错误");
						checkBox.Checked = !checkBox.Checked;
					}
					else
					{
						uint num2;
						if (!uint.TryParse(this.sfnEqZowcK.Text.Trim(), out num2))
						{
							num2 = 0u;
						}
						string s = string.Format("{2}-{0}-{1}", num, num2, this.string_0);
						string text = Convert.ToBase64String(Encoding.Default.GetBytes(s));
						text = text.Replace("+", "").Replace("/", "").Replace("=", "");
						this.groupBox8.Show();
						this.groupBox9.Show();
						this.panel1.Height -= 40;
						this.lblhulian.Text = "监控中...";
						this.txtshanghao.Text = "http://118.89.226.148:8889/shanghao?sn=" + text;
						this.txtxiahao.Text = "http://118.89.226.148:8889/xiahao?sn=" + text;
						this.txtsid.Enabled = false;
					}
				}
				else if (this.lblhulian.Text.Length >= 2)
				{
					this.groupBox8.Hide();
					this.groupBox9.Hide();
					this.panel1.Height += 40;
					this.lblhulian.Text = "";
					this.txtsid.Enabled = true;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000543 RID: 1347 RVA: 0x001732D0 File Offset: 0x001732D0
		private void ckbhttpurl_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((CheckBox)sender).Checked)
				{
					CheckBox checkBox = this.checkBox_0;
					CheckBox checkBox2 = this.checkBox_1;
					this.ckbhttplocal.Checked = false;
					checkBox2.Checked = false;
					checkBox.Checked = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000544 RID: 1348 RVA: 0x00173328 File Offset: 0x00173328
		private void checkBox_1_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((CheckBox)sender).Checked)
				{
					CheckBox checkBox = this.ckbhttpurl;
					CheckBox checkBox2 = this.ckbhttplocal;
					this.checkBox_0.Checked = false;
					checkBox2.Checked = false;
					checkBox.Checked = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000545 RID: 1349 RVA: 0x00173380 File Offset: 0x00173380
		private void checkBox_0_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((CheckBox)sender).Checked)
				{
					CheckBox checkBox = this.ckbhttpurl;
					CheckBox checkBox2 = this.ckbhttplocal;
					this.checkBox_1.Checked = false;
					checkBox2.Checked = false;
					checkBox.Checked = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x001733D8 File Offset: 0x001733D8
		private void ckbgongneng_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				CheckBox checkBox = (CheckBox)sender;
				CheckBox checkBox2 = this.ckbqutubiao;
				CheckBox checkBox3 = this.ckbxianche;
				CheckBox checkBox4 = this.ckbhanhua;
				Button button = this.btndaoruhanhua;
				bool enabled = this.txthanhuajiange.Enabled = checkBox.Checked;
				bool enabled2 = button.Enabled = enabled;
				bool flag = checkBox4.Enabled = enabled2;
				bool flag2 = checkBox3.Enabled = flag;
				checkBox2.Enabled = flag2;
				this.txt_shuahuauid.Enabled = true;
				this.shuahuasudu.Enabled = true;
				this.btn_songhua.Enabled = true;
				this.btn_tingzhishuahua.Enabled = true;
				this.zhibotongzhi.Enabled = true;
				this.tingzhizhibotongzhi.Enabled = true;
				this.daka.Enabled = true;
				this.tzdaka.Enabled = true;
				if (!checkBox.Checked)
				{
					CheckBox checkBox5 = this.ckbqutubiao;
					CheckBox checkBox6 = this.ckbhanhua;
					flag = (this.ckbxianche.Checked = checkBox.Checked);
					flag2 = (checkBox6.Checked = flag);
					checkBox5.Checked = flag2;
					this.list_2.Clear();
					this.btndaoruhanhua.Text = "导入随机打字文本";
					this.txt_shuahuauid.Enabled = false;
					this.shuahuasudu.Enabled = false;
					this.btn_songhua.Enabled = false;
					this.btn_tingzhishuahua.Enabled = false;
					this.zhibotongzhi.Enabled = false;
					this.tingzhizhibotongzhi.Enabled = false;
					this.daka.Enabled = false;
					this.tzdaka.Enabled = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000547 RID: 1351 RVA: 0x001735A0 File Offset: 0x001735A0
		private void ckbhanhua_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (!this.ckbhanhua.Checked)
				{
					this.list_2.Clear();
					this.btndaoruhanhua.Text = "导入随机打字文本";
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000548 RID: 1352 RVA: 0x001735EC File Offset: 0x001735EC
		private void method_7(uint uint_1)
		{
			try
			{
				if ((ulong)uint_1 >= (ulong)((long)this.int_4))
				{
					this.lblshijizaixian.BeginInvoke(new MethodInvoker(delegate()
					{
						try
						{
							this.lblshijizaixian.Text = uint_1.ToString();
							this.lblshijizaixian.ForeColor = Color.Black;
						}
						catch
						{
						}
					}));
				}
				else
				{
					this.lblshijizaixian.BeginInvoke(new MethodInvoker(delegate()
					{
						try
						{
							this.lblshijizaixian.Text = uint_1.ToString();
							this.lblshijizaixian.ForeColor = Color.Black;
						}
						catch
						{
						}
					}));
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x00173664 File Offset: 0x00173664
		private void method_8(uint uint_1, List<uint> list_6)
		{
			try
			{
				if (this.list_4.Contains(uint_1))
				{
					List<uint> obj = this.list_4;
					lock (obj)
					{
						this.list_4.Remove(uint_1);
					}
					List<uint> obj2 = this.list_5;
					lock (obj2)
					{
						this.list_5.AddRange(list_6);
					}
					if (this.list_4.Count == 0)
					{
						int bc = 0;
						foreach (MyUser1225 myUser in this.concurrentBag_0)
						{
							if (myUser.status == 2 && myUser.jointime.AddMinutes(8.0) < DateTime.Now && !this.list_5.Contains(myUser.uid))
							{
								myUser.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
								int bc2 = bc;
								bc = bc2 + 1;
							}
						}
						this.lbllastbuhao.BeginInvoke(new MethodInvoker(delegate()
						{
							try
							{
								this.lbllastbuhao.Text = DateTime.Now.ToString("HH:mm:ss") + "-" + bc.ToString();
							}
							catch
							{
							}
						}));
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600054A RID: 1354 RVA: 0x0017381C File Offset: 0x0017381C
		private void method_9()
		{
			try
			{
				this.yongjiobj_0.isyongji = true;
				this.yongjiobj_0.ctime = DateTime.Now;
			}
			catch
			{
			}
		}

		// Token: 0x0600054B RID: 1355 RVA: 0x0017385C File Offset: 0x0017385C
		private void btndaoru_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.openFileDialog_0.ShowDialog() == DialogResult.OK)
				{
					this.lblpath.Text = this.openFileDialog_0.FileName;
					this.concurrentBag_0 = new ConcurrentBag<MyUser1225>();
					string[] source = File.ReadAllLines(this.lblpath.Text);
					int num = 1;
					foreach (string text in source.Distinct<string>())
					{
						try
						{
							string passport = text.Split(new string[]
							{
								"----"
							}, StringSplitOptions.RemoveEmptyEntries)[0].Trim();
							string pwd = text.Split(new string[]
							{
								"----"
							}, StringSplitOptions.RemoveEmptyEntries)[1].Trim();
							MyUser1225 myUser = new MyUser1225();
							myUser.passport = passport;
							myUser.pwd = pwd;
							myUser.index = num;
							myUser.GetUserCountEvent += this.method_7;
							myUser.YongJiEvent += this.method_9;
							this.concurrentBag_0.Add(myUser);
							num++;
						}
						catch
						{
						}
					}
					try
					{
						this.mygrid.BeginInvoke(new MethodInvoker(this.method_26));
						this.txtzong.BeginInvoke(new MethodInvoker(this.method_27));
						this.timer_0.Enabled = true;
						this.timer_0.Start();
					}
					catch
					{
					}
				}
			}
			catch
			{
				MessageBox.Show("导入失败，请检查文件！");
			}
		}

		// Token: 0x0600054C RID: 1356 RVA: 0x00173A38 File Offset: 0x00173A38
		private void btndaochu_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.concurrentBag_0 != null && this.concurrentBag_0.Count > 0)
				{
					this.saveFileDialog_0.FileName = string.Format("{0}.txt", DateTime.Now.ToString("yyyyMMddHHmmss"));
					if (this.saveFileDialog_0.ShowDialog() == DialogResult.OK)
					{
						StringBuilder stringBuilder = new StringBuilder();
						foreach (MyUser1225 myUser in this.concurrentBag_0)
						{
							if (!myUser.isfenghao)
							{
								stringBuilder.AppendFormat("{0}----{1}", myUser.passport, myUser.pwd);
								stringBuilder.AppendLine();
							}
						}
						using (StreamWriter streamWriter = new StreamWriter(this.saveFileDialog_0.FileName, false))
						{
							streamWriter.Write(stringBuilder.ToString());
						}
						MessageBox.Show("导出成功");
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600054D RID: 1357 RVA: 0x00173B58 File Offset: 0x00173B58
		private void method_10()
		{
			try
			{
				string s = string.Format("{0}-{1}", this.rQaQnYbAnm, this.uint_0);
				string text = Convert.ToBase64String(Encoding.Default.GetBytes(s));
				text = text.Replace("+", "").Replace("/", "");
				string path = Application.StartupPath + string.Format("{0}.txt", text);
				if (File.Exists(path))
				{
					DateTime t = Convert.ToDateTime(File.ReadAllText(path).Trim());
					if (t > DateTime.Now)
					{
						this.ckbdsxh.Checked = true;
						this.dateTime_2 = t;
					}
					else
					{
						File.Delete(path);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600054E RID: 1358 RVA: 0x00173C24 File Offset: 0x00173C24
		private void btnjoin_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.concurrentBag_0 == null || this.concurrentBag_0.Count == 0)
				{
					throw new Exception("导入账号!");
				}
				if (!uint.TryParse(this.txtsid.Text.Trim(), out this.rQaQnYbAnm))
				{
					throw new Exception("写频道号!");
				}
				if (!uint.TryParse(this.sfnEqZowcK.Text.Trim(), out this.uint_0))
				{
					this.sfnEqZowcK.Text = "";
					this.uint_0 = 0u;
				}
				if (!int.TryParse(this.txtsudu.Text.Trim(), out this.int_1))
				{
					this.txtsudu.Text = "500";
					this.int_1 = 500;
				}
				if (this.ckbhttplocal.Checked)
				{
					string path = Application.StartupPath + "\\http.txt";
					if (!File.Exists(path))
					{
						throw new Exception("未找到文件 http.txt！");
					}
					string[] array = File.ReadAllLines(path);
					List<string> list = new List<string>();
					string[] array2 = array;
					foreach (string text in array2)
					{
						if (!string.IsNullOrWhiteSpace(text))
						{
							list.Add(text);
						}
					}
					if (list.Count <= 0)
					{
						throw new Exception("导入代理http失败！");
					}
					this.list_0 = list;
					this.timer_2.Interval = 8000.0;
				}
				if (this.checkBox_1.Checked)
				{
					string path2 = Application.StartupPath + "\\spoof.txt";
					if (!File.Exists(path2))
					{
						throw new Exception("未找到文件 spoof.txt！");
					}
					string[] array4 = MyEncrypt.AesDecryptor(File.ReadAllText(path2)).Split(new string[]
					{
						Environment.NewLine,
						"\r\n",
						"\\r\\n"
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array4 == null || array4.Count<string>() <= 0)
					{
						throw new Exception("导入spoof失败！");
					}
					string[] array5 = array4;
					foreach (string text2 in array5)
					{
						if (!string.IsNullOrWhiteSpace(text2))
						{
							this.list_1.Add(text2);
						}
					}
					this.timer_2.Interval = 8000.0;
				}
				else if (this.checkBox_0.Checked)
				{
					string path3 = Application.StartupPath + "\\s5.txt";
					if (!File.Exists(path3))
					{
						throw new Exception("未找到文件！");
					}
					string[] array7 = File.ReadAllText(path3).Split(new string[]
					{
						Environment.NewLine,
						"\r\n",
						"\\r\\n"
					}, StringSplitOptions.RemoveEmptyEntries);
					if (array7 == null || array7.Count<string>() <= 0)
					{
						throw new Exception("导入s5失败！");
					}
					string[] array8 = array7;
					foreach (string text3 in array8)
					{
						if (!string.IsNullOrWhiteSpace(text3))
						{
							this.list_1.Add(text3);
						}
					}
					this.timer_2.Interval = 8000.0;
				}
				if (this.ckbhanhua.Checked)
				{
					if (!int.TryParse(this.txthanhuajiange.Text.Trim(), out this.int_2))
					{
						this.txthanhuajiange.Text = "5000";
					}
					this.int_2 = Convert.ToInt32(this.txthanhuajiange.Text);
				}
				this.method_0();
				this.method_10();
				if (this.bool_0)
				{
					this.bool_0 = false;
					RadioButton radioButton = this.rdbpc;
					RadioButton radioButton2 = this.rdbweb;
					CheckBox checkBox = this.ckbgongneng;
					CheckBox checkBox2 = this.ckbhanhua;
					CheckBox checkBox3 = this.ckbxianche;
					CheckBox checkBox4 = this.ckbqutubiao;
					this.btnjoin.Enabled = false;
					checkBox4.Enabled = false;
					checkBox3.Enabled = false;
					checkBox2.Enabled = false;
					checkBox.Enabled = false;
					radioButton2.Enabled = false;
					radioButton.Enabled = false;
					Button button = this.btntuichu;
					Button button2 = this.btnqiehuan;
					Button button3 = this.btnsuijixingbie;
					Button button4 = this.btndaorumajia;
					Button button5 = this.nanxing;
					Button button6 = this.nvxing;
					this.btntingzhixiugai.Enabled = true;
					this.btndaoruqianming.Enabled = true;
					button6.Enabled = true;
					button5.Enabled = true;
					button4.Enabled = true;
					button3.Enabled = true;
					button2.Enabled = true;
					button.Enabled = true;
				}
				else
				{
					if (this.bool_3)
					{
						Task.Factory.StartNew(new Action(this.method_28));
						Task.Factory.StartNew(new Action(this.method_29));
						this.bool_3 = false;
					}
					RadioButton radioButton3 = this.rdbpc;
					RadioButton radioButton4 = this.rdbweb;
					CheckBox checkBox5 = this.ckbgongneng;
					CheckBox checkBox6 = this.ckbhanhua;
					CheckBox checkBox7 = this.ckbxianche;
					CheckBox checkBox8 = this.ckbqutubiao;
					this.btnjoin.Enabled = false;
					checkBox8.Enabled = false;
					checkBox7.Enabled = false;
					checkBox6.Enabled = false;
					checkBox5.Enabled = false;
					radioButton4.Enabled = false;
					radioButton3.Enabled = false;
					Button button7 = this.btntuichu;
					Button button8 = this.btnqiehuan;
					Button button9 = this.btnsuijixingbie;
					Button button10 = this.btndaorumajia;
					Button button11 = this.nanxing;
					Button button12 = this.nvxing;
					this.btndaoruqianming.Enabled = true;
					this.btntingzhixiugai.Enabled = true;
					button10.Enabled = true;
					button9.Enabled = true;
					button8.Enabled = true;
					button7.Enabled = true;
					button12.Enabled = true;
					button11.Enabled = true;
					this.method_11();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x0600054F RID: 1359 RVA: 0x001741D4 File Offset: 0x001741D4
		private void method_11()
		{
			try
			{
				StringBuilder stringBuilder = new StringBuilder("");
				if (this.rdbpc.Checked)
				{
					stringBuilder.Append("1");
				}
				else if (this.rdbweb.Checked)
				{
					stringBuilder.Append("2");
				}
				stringBuilder.Append("|");
				if (this.ckbhttpurl.Checked)
				{
					stringBuilder.Append("1");
				}
				else if (this.ckbhttplocal.Checked)
				{
					stringBuilder.Append("2");
				}
				else if (this.checkBox_1.Checked)
				{
					stringBuilder.Append("3");
				}
				else if (this.checkBox_0.Checked)
				{
					stringBuilder.Append("4");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				if (this.ckbgongneng.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				if (this.ckbqutubiao.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				if (this.ckbxianche.Visible && this.ckbxianche.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				if (this.ckbhanhua.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				stringBuilder.Append(this.int_1.ToString());
				stringBuilder.Append("|");
				stringBuilder.Append(this.txthanhuajiange.Text.Trim());
				stringBuilder.Append("|");
				if (this.ckbhunhe.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				if (this.buhao.Checked)
				{
					stringBuilder.Append("1");
				}
				else
				{
					stringBuilder.Append("0");
				}
				stringBuilder.Append("|");
				stringBuilder.Append(this.txtsid.Text.Trim());
				stringBuilder.Append("|");
				stringBuilder.Append(this.sfnEqZowcK.Text.Trim());
				string text = stringBuilder.ToString();
				if (!string.IsNullOrWhiteSpace(text))
				{
					loghelper.log(Application.StartupPath + "\\设置.txt", text);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000550 RID: 1360 RVA: 0x001744B0 File Offset: 0x001744B0
		private void btntuichu_Click(object sender, EventArgs e)
		{
			try
			{
				this.bool_0 = true;
				this.btnjoin.Enabled = true;
				Button button = this.btntuichu;
				Button button2 = this.btnqiehuan;
				Button button3 = this.btnsuijixingbie;
				Button button4 = this.btndaorumajia;
				Button button5 = this.nanxing;
				Button button6 = this.nvxing;
				this.ckbgongneng.Enabled = true;
				this.btndaoruqianming.Enabled = false;
				button4.Enabled = false;
				button3.Enabled = false;
				button2.Enabled = false;
				button.Enabled = false;
				button6.Enabled = false;
				button5.Enabled = false;
				Task.Factory.StartNew(new Action(this.method_30));
				this.method_1();
			}
			catch
			{
			}
		}

		// Token: 0x06000551 RID: 1361 RVA: 0x00174574 File Offset: 0x00174574
		private void btnqiehuan_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.concurrentBag_0 == null || this.concurrentBag_0.Count == 0)
				{
					throw new Exception("导入账号!");
				}
				uint num;
				if (!uint.TryParse(this.txtsid.Text.Trim(), out num))
				{
					throw new Exception("写频道号!");
				}
				uint num2;
				if (!uint.TryParse(this.sfnEqZowcK.Text.Trim(), out num2))
				{
					this.sfnEqZowcK.Text = "";
					num2 = 0u;
				}
				this.rQaQnYbAnm = num;
				this.uint_0 = num2;
				if (!int.TryParse(this.txtsudu.Text.Trim(), out this.int_1))
				{
					this.txtsudu.Text = "500";
					this.int_1 = 500;
				}
				this.btnqiehuan.Enabled = false;
				this.btntuichu.Enabled = false;
				Task.Factory.StartNew(new Action(this.method_31));
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		// Token: 0x06000552 RID: 1362 RVA: 0x0015A51A File Offset: 0x0015A51A
		private void btnsuijixingbie_Click(object sender, EventArgs e)
		{
			this.btnsuijixingbie.Enabled = false;
			this.nanxing.Enabled = false;
			this.nvxing.Enabled = false;
			Task.Factory.StartNew(new Action(this.method_33));
		}

		// Token: 0x06000553 RID: 1363 RVA: 0x00174690 File Offset: 0x00174690
		private void btndaorumajia_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.openFileDialog_0.ShowDialog() == DialogResult.OK && this.openFileDialog_0.FileName.Length > 0)
				{
					string[] nicks = File.ReadAllLines(this.openFileDialog_0.FileName);
					if (nicks.Length == 0)
					{
						MessageBox.Show("文件无效");
					}
					else
					{
						this.btndaorumajia.Enabled = false;
						Task.Factory.StartNew(delegate()
						{
							foreach (MyUser1225 myUser in this.concurrentBag_0.Reverse<MyUser1225>())
							{
								myUser.isupdate = true;
							}
							for (;;)
							{
								IEnumerable<MyUser1225> source = this.concurrentBag_0;
								Func<MyUser1225, bool> predicate;
								if ((predicate = MainForm.<>c.<>9__219_1) == null)
								{
									predicate = (MainForm.<>c.<>9__219_1 = ((MyUser1225 p) => !p.isfenghao && p.currentflag > 50000 && p.isupdate));
								}
								IEnumerable<MyUser1225> enumerable = source.Where(predicate);
								if (enumerable == null || enumerable.Count<MyUser1225>() == 0)
								{
									break;
								}
								foreach (MyUser1225 myUser2 in enumerable.Reverse<MyUser1225>())
								{
									try
									{
										if (myUser2.xiugaisuiji)
										{
											myUser2.nicheng = nicks[this.random_0.Next(0, nicks.Length)];
										}
										else
										{
											myUser2.nicheng = nicks[myUser2.index % nicks.Length];
										}
										this.method_14(myUser2);
										Thread.Sleep(15);
									}
									catch
									{
									}
								}
								Thread.Sleep(3000);
							}
							this.btndaorumajia.BeginInvoke(new MethodInvoker(this.method_35));
						});
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000554 RID: 1364 RVA: 0x00174730 File Offset: 0x00174730
		private void btndaoruqianming_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.openFileDialog_0.ShowDialog() == DialogResult.OK && this.openFileDialog_0.FileName.Length > 0)
				{
					string[] qms = File.ReadAllLines(this.openFileDialog_0.FileName);
					if (qms.Length == 0)
					{
						MessageBox.Show("文件无效");
					}
					else
					{
						this.btndaoruqianming.Enabled = false;
						Task.Factory.StartNew(delegate()
						{
							foreach (MyUser1225 myUser in this.concurrentBag_0.Reverse<MyUser1225>())
							{
								myUser.isupdate = true;
							}
							for (;;)
							{
								IEnumerable<MyUser1225> source = this.concurrentBag_0;
								Func<MyUser1225, bool> predicate;
								if ((predicate = MainForm.<>c.<>9__220_1) == null)
								{
									predicate = (MainForm.<>c.<>9__220_1 = ((MyUser1225 p) => !p.isfenghao && p.currentflag > 50000 && p.isupdate));
								}
								IEnumerable<MyUser1225> enumerable = source.Where(predicate);
								if (enumerable == null || enumerable.Count<MyUser1225>() == 0)
								{
									break;
								}
								foreach (MyUser1225 myUser2 in enumerable.Reverse<MyUser1225>())
								{
									try
									{
										if (myUser2.xiugaisuiji)
										{
											myUser2.qianming = qms[this.random_0.Next(0, qms.Length)];
										}
										else
										{
											myUser2.qianming = qms[myUser2.index % qms.Length];
										}
										this.method_15(myUser2);
										Thread.Sleep(15);
									}
									catch
									{
									}
								}
								Thread.Sleep(3000);
							}
							this.btndaoruqianming.BeginInvoke(new MethodInvoker(this.method_36));
						});
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000555 RID: 1365 RVA: 0x001747D0 File Offset: 0x001747D0
		private void btndaoruhanhua_Click(object sender, EventArgs e)
		{
			try
			{
				if (this.openFileDialog_0.ShowDialog() == DialogResult.OK && this.openFileDialog_0.FileName.Length > 0)
				{
					string[] array = File.ReadAllLines(this.openFileDialog_0.FileName);
					this.list_2.Clear();
					string[] array2 = array;
					foreach (string text in array2)
					{
						if (text.Trim().Length > 0)
						{
							this.list_2.Add(text);
						}
					}
					this.btndaoruhanhua.BeginInvoke(new MethodInvoker(this.method_37));
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000556 RID: 1366 RVA: 0x0017487C File Offset: 0x0017487C
		private void method_12(MyUser1225 myUser1225_0)
		{
			byte[] array = null;
			using (ByteArray byteArray = new ByteArray())
			{
				byteArray.endian = Endian.LITTLE_ENDIAN;
				byteArray.method_2(2);
				byteArray.method_2(0);
				byteArray.writeUTF("13");
				byteArray.method_2(1);
				byteArray.writeUTF(myUser1225_0.sidnew.ToString());
				array = byteArray.Buffer;
				byteArray.Dispose();
			}
			byte[] array2 = null;
			using (ByteArray byteArray2 = new ByteArray())
			{
				byteArray2.endian = Endian.LITTLE_ENDIAN;
				byteArray2.writeBytes(bytetool.strToToHexByte("0008"));
				byteArray2.writeShort(array.Length);
				byteArray2.writeBytes(array);
				array2 = byteArray2.Buffer;
				byteArray2.Dispose();
			}
			byte[] array3 = null;
			using (ByteArray byteArray3 = new ByteArray())
			{
				byteArray3.endian = Endian.LITTLE_ENDIAN;
				byteArray3.writeBytes(bytetool.strToToHexByte("08000001"));
				byteArray3.writeBytes(bytetool.strToToHexByte("02471F001000000203010000"));
				byteArray3.method_3(myUser1225_0.uid);
				byteArray3.method_2(0);
				byteArray3.writeBytes(bytetool.strToToHexByte("1D000006010800000000DCB90001"));
				byteArray3.writeUTF("channelAuther");
				byteArray3.writeBytes(bytetool.strToToHexByte("1200000701000000010000000400"));
				byteArray3.writeUnsignedInt(myUser1225_0.sidnew);
				byteArray3.writeShort(array2.Length + 2);
				byteArray3.writeBytes(array2);
				byteArray3.writeBytes(bytetool.strToToHexByte("787878FF"));
				array3 = byteArray3.Buffer;
				byteArray3.Dispose();
			}
			byte[] sendBuffer = null;
			using (ByteArray byteArray4 = new ByteArray())
			{
				byteArray4.endian = Endian.LITTLE_ENDIAN;
				byteArray4.position = 4;
				byteArray4.writeBytes(bytetool.strToToHexByte("0BD00700"));
				byteArray4.method_2(200);
				byteArray4.writeBytes(bytetool.strToToHexByte("02471F00"));
				byteArray4.writeShort(200);
				byteArray4.method_2(8);
				byteArray4.writeUnsignedInt(myUser1225_0.uid);
				byteArray4.writeUnsignedInt(myUser1225_0.sidnew);
				byteArray4.method_2(array3.Length);
				byteArray4.writeBytes(array3);
				byteArray4.position = 0;
				byteArray4.writeUnsignedInt(Convert.ToUInt32(byteArray4.length));
				sendBuffer = byteArray4.Buffer;
				byteArray4.Dispose();
			}
			myUser1225_0.logintcp.Send(sendBuffer, false);
		}

		// Token: 0x06000557 RID: 1367 RVA: 0x00174B08 File Offset: 0x00174B08
		private void method_13(MyUser1225 myUser1225_0)
		{
			try
			{
				byte[] buffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.writeShort(5);
					byteArray.writeUTF((this.random_0.NextDouble() > 0.5) ? "1" : "0");
					buffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeUnsignedInt(1u);
					byteArray2.writeBytes(buffer);
					array = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003020000C800"));
					byteArray3.writeUnsignedInt((uint)array.Length);
					byteArray3.writeBytes(array);
					byteArray3.writeUnsignedInt(98u);
					byteArray3.writeBytes(bytetool.strToToHexByte("08000001030200001000000203010000"));
					byteArray3.writeUnsignedInt(myUser1225_0.uid);
					byteArray3.writeBytes(bytetool.strToToHexByte("00000000150000068CC63500120800000000050055496E666F1200000701000000010000000400000000001F000008190003000000000000000200323701000000010030030000000000787878FF"));
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				myUser1225_0.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x00174CCC File Offset: 0x00174CCC
		private void method_131(MyUser1225 myUser1225_0)
		{
			try
			{
				byte[] buffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.writeShort(5);
					byteArray.writeUTF("1");
					buffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeUnsignedInt(1u);
					byteArray2.writeBytes(buffer);
					array = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003020000C800"));
					byteArray3.writeUnsignedInt((uint)array.Length);
					byteArray3.writeBytes(array);
					byteArray3.writeUnsignedInt(98u);
					byteArray3.writeBytes(bytetool.strToToHexByte("08000001030200001000000203010000"));
					byteArray3.writeUnsignedInt(myUser1225_0.uid);
					byteArray3.writeBytes(bytetool.strToToHexByte("00000000150000068CC63500120800000000050055496E666F1200000701000000010000000400000000001F000008190003000000000000000200323701000000010030030000000000787878FF"));
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				myUser1225_0.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00174E74 File Offset: 0x00174E74
		private void method_132(MyUser1225 myUser1225_0)
		{
			try
			{
				byte[] buffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.writeShort(5);
					byteArray.writeUTF("0");
					buffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeUnsignedInt(1u);
					byteArray2.writeBytes(buffer);
					array = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003020000C800"));
					byteArray3.writeUnsignedInt((uint)array.Length);
					byteArray3.writeBytes(array);
					byteArray3.writeUnsignedInt(98u);
					byteArray3.writeBytes(bytetool.strToToHexByte("08000001030200001000000203010000"));
					byteArray3.writeUnsignedInt(myUser1225_0.uid);
					byteArray3.writeBytes(bytetool.strToToHexByte("00000000150000068CC63500120800000000050055496E666F1200000701000000010000000400000000001F000008190003000000000000000200323701000000010030030000000000787878FF"));
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				myUser1225_0.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x0017501C File Offset: 0x0017501C
		private void method_14(MyUser1225 myUser1225_0)
		{
			try
			{
				byte[] buffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.writeShort(2);
					byteArray.writeUTF(myUser1225_0.nicheng);
					buffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeUnsignedInt(1u);
					byteArray2.writeBytes(buffer);
					array = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003020000C800"));
					byteArray3.writeUnsignedInt((uint)array.Length);
					byteArray3.writeBytes(array);
					byteArray3.writeUnsignedInt(98u);
					byteArray3.writeBytes(bytetool.strToToHexByte("08000001030200001000000203010000"));
					byteArray3.writeUnsignedInt(myUser1225_0.uid);
					byteArray3.writeBytes(bytetool.strToToHexByte("00000000150000068CC63500120800000000050055496E666F1200000701000000010000000400000000001F000008190003000000000000000200323701000000010030030000000000787878FF"));
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				myUser1225_0.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x001751C4 File Offset: 0x001751C4
		private void ckbhttplocal_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((CheckBox)sender).Checked)
				{
					CheckBox checkBox = this.checkBox_0;
					CheckBox checkBox2 = this.checkBox_1;
					this.ckbhttpurl.Checked = false;
					checkBox2.Checked = false;
					checkBox.Checked = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x0017521C File Offset: 0x0017521C
		private void rdbpc_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((RadioButton)sender).Checked)
				{
					CheckBox checkBox = this.ckbhttpurl;
					this.ckbhttplocal.Checked = false;
					checkBox.Checked = false;
					CheckBox checkBox2 = this.ckbhttpurl;
					this.ckbhttplocal.Enabled = true;
					checkBox2.Enabled = true;
					CheckBox checkBox3 = this.checkBox_1;
					this.checkBox_0.Checked = false;
					checkBox3.Checked = false;
					CheckBox checkBox4 = this.checkBox_1;
					this.checkBox_0.Enabled = true;
					checkBox4.Enabled = true;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x001752B4 File Offset: 0x001752B4
		private void rdbweb_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((RadioButton)sender).Checked)
				{
					CheckBox checkBox = this.checkBox_1;
					this.checkBox_0.Checked = false;
					checkBox.Checked = false;
					CheckBox checkBox2 = this.checkBox_1;
					this.checkBox_0.Enabled = false;
					checkBox2.Enabled = false;
					CheckBox checkBox3 = this.ckbhttpurl;
					this.ckbhttplocal.Enabled = true;
					checkBox3.Enabled = true;
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x00175334 File Offset: 0x00175334
		private void ckbdsxh_CheckedChanged(object sender, EventArgs e)
		{
			this.timer_6 = new System.Timers.Timer(60000.0);
			this.timer_6.Elapsed += this.timer_6_Elapsed;
			this.timer_6.AutoReset = true;
			this.timer_6.Enabled = true;
			this.timer_6.Start();
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x00158048 File Offset: 0x00158048
		private void ckbhulian_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x00175390 File Offset: 0x00175390
		private void ckbdssh_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				if (((CheckBox)sender).Checked)
				{
					this.dateTime_1 = DateTime.Now.AddDays((double)((int)this.shtian.Value)).AddHours((double)((int)this.shshi.Value)).AddMinutes((double)((int)this.shfen.Value));
				}
				else
				{
					this.dateTime_1 = DateTime.MinValue;
					NumericUpDown numericUpDown = this.shtian;
					NumericUpDown numericUpDown2 = this.shshi;
					NumericUpDown numericUpDown3 = this.shfen;
					decimal num = 0m;
					numericUpDown3.Value = num;
					decimal value = num;
					numericUpDown.Value = (numericUpDown2.Value = value);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x00175460 File Offset: 0x00175460
		private void ckbdsxh_Click(object sender, EventArgs e)
		{
			try
			{
				uint num;
				if (!uint.TryParse(this.txtsid.Text.Trim(), out num))
				{
					num = 0u;
				}
				uint num2;
				if (!uint.TryParse(this.sfnEqZowcK.Text.Trim(), out num2))
				{
					num2 = 0u;
				}
				CheckBox checkBox = (CheckBox)sender;
				string s = string.Format("{0}-{1}", num, num2);
				string text = Convert.ToBase64String(Encoding.Default.GetBytes(s));
				text = text.Replace("+", "").Replace("/", "");
				string path = Application.StartupPath + string.Format("{0}.txt", text);
				if (checkBox.Checked)
				{
					this.dateTime_2 = DateTime.Now.AddDays((double)((int)this.xhtian.Value)).AddHours((double)((int)this.xhshi.Value)).AddMinutes((double)((int)this.xhfen.Value));
					using (FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.Write))
					{
						using (StreamWriter streamWriter = new StreamWriter(fileStream))
						{
							streamWriter.Write(this.dateTime_2.ToString("yyyy-MM-dd HH:mm"));
							streamWriter.Flush();
							streamWriter.Close();
							streamWriter.Dispose();
						}
						fileStream.Close();
						fileStream.Dispose();
						goto IL_189;
					}
				}
				this.dateTime_2 = DateTime.MinValue;
				if (File.Exists(path))
				{
					File.Delete(path);
				}
				IL_189:;
			}
			catch
			{
			}
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x0015A557 File Offset: 0x0015A557
		private void btnchonglian_Click(object sender, EventArgs e)
		{
			this.btnchonglian.Enabled = false;
			Task.Factory.StartNew(new Action(this.bMoQvhfFik));
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x00175648 File Offset: 0x00175648
		private void btnresetsudu_Click(object sender, EventArgs e)
		{
			try
			{
				if (!int.TryParse(this.txtsudu.Text.Trim(), out this.int_1))
				{
					this.txtsudu.Text = "500";
					this.int_1 = 500;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x001756A4 File Offset: 0x001756A4
		private void btntingzhixiugai_Click(object sender, EventArgs e)
		{
			try
			{
				Task.Factory.StartNew(new Action(this.method_39));
			}
			catch
			{
			}
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x001756E0 File Offset: 0x001756E0
		private void method_15(MyUser1225 myUser1225_0)
		{
			try
			{
				byte[] buffer = null;
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.writeShort(54);
					byteArray.writeUTF(myUser1225_0.qianming);
					buffer = byteArray.Buffer;
					byteArray.Dispose();
				}
				byte[] array = null;
				using (ByteArray byteArray2 = new ByteArray())
				{
					byteArray2.endian = Endian.LITTLE_ENDIAN;
					byteArray2.writeUnsignedInt(1u);
					byteArray2.writeBytes(buffer);
					array = byteArray2.Buffer;
					byteArray2.Dispose();
				}
				byte[] sendBuffer = null;
				using (ByteArray byteArray3 = new ByteArray())
				{
					byteArray3.endian = Endian.LITTLE_ENDIAN;
					byteArray3.position = 4;
					byteArray3.writeBytes(bytetool.strToToHexByte("0BD00700C800000003020000C800"));
					byteArray3.writeUnsignedInt((uint)array.Length);
					byteArray3.writeBytes(array);
					byteArray3.writeUnsignedInt(98u);
					byteArray3.writeBytes(bytetool.strToToHexByte("08000001030200001000000203010000"));
					byteArray3.writeUnsignedInt(myUser1225_0.uid);
					byteArray3.writeBytes(bytetool.strToToHexByte("00000000150000068CC63500120800000000050055496E666F1200000701000000010000000400000000001F000008190003000000000000000200323701000000010030030000000000787878FF"));
					byteArray3.position = 0;
					byteArray3.writeUnsignedInt(Convert.ToUInt32(byteArray3.length));
					sendBuffer = byteArray3.Buffer;
					byteArray3.Dispose();
				}
				myUser1225_0.logintcp.Send(sendBuffer, false);
			}
			catch
			{
			}
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x0017588C File Offset: 0x0017588C
		private void method_16(MyUser1225 myUser1225_0)
		{
			try
			{
				string s = this.list_2[this.random_0.Next(0, this.list_2.Count)] + "  ";
				List<byte> list = Encoding.Unicode.GetBytes(s).ToList<byte>();
				List<byte> second = BitConverter.GetBytes(myUser1225_0.sidnew).ToList<byte>();
				List<byte> second2 = BitConverter.GetBytes(myUser1225_0.subidnew).ToList<byte>();
				List<byte> second3 = Encoding.Default.GetBytes("5060").ToList<byte>();
				List<byte> second4 = BitConverter.GetBytes(myUser1225_0.uid).ToList<byte>();
				List<byte> list2 = Encoding.UTF8.GetBytes(myUser1225_0.nicheng).ToList<byte>();
				List<byte> first = new byte[]
				{
					11,
					208,
					7,
					0,
					200,
					0,
					0,
					0,
					88,
					56,
					1,
					0,
					0,
					0
				}.ToList<byte>();
				byte[] array = new byte[6];
				array[0] = 132;
				array[4] = 31;
				List<byte> list3 = array.Concat(second).Concat(second4).ToList<byte>();
				byte[] array2 = new byte[8];
				array2[0] = 100;
				array2[4] = 100;
				List<byte> list4 = array2.ToList<byte>();
				List<byte> first2 = new byte[]
				{
					88,
					94,
					47,
					0,
					200,
					0
				}.Concat(second4).Concat(second).Concat(second2).ToList<byte>();
				byte[] array3 = new byte[2];
				array3[0] = 34;
				List<byte> first3 = array3.Concat(bytetool.strToToHexByte("000000010C000000530069006D00530075006E0000000000F0FFFFFF")).ToList<byte>();
				byte[] array4 = new byte[4];
				array4[0] = 10;
				IEnumerable<byte> first4 = array4.Concat(list);
				byte[] array5 = new byte[7];
				array5[2] = 1;
				array5[4] = 48;
				List<byte> list5 = first4.Concat(array5).ToList<byte>();
				list5[0] = (byte)(list.Count - 2);
				List<byte> list6 = first3.Concat(list5).ToList<byte>();
				list6[0] = (byte)(list6.Count - 7);
				byte[] array6 = new byte[2];
				array6[0] = 18;
				List<byte> list7 = array6.Concat(list2).Concat(new byte[]
				{
					2,
					0,
					0,
					0,
					6,
					0,
					4,
					0
				}.ToList<byte>()).Concat(second3).Concat(new byte[]
				{
					3,
					0,
					1,
					0,
					49,
					0,
					0,
					0,
					0
				}).ToList<byte>();
				list7[0] = (byte)list2.Count;
				List<byte> list8 = first2.Concat(list6).Concat(list7).ToList<byte>();
				list4[0] = (byte)list8.Count;
				list4[4] = (byte)list8.Count;
				List<byte> list9 = new byte[2].Concat(second2).Concat(second4).Concat(new byte[4]).ToList<byte>();
				list3[0] = (byte)(list3.Count + list4.Count + list8.Count + list9.Count - 4);
				List<byte> second5 = new byte[]
				{
					100,
					0,
					0,
					0,
					8,
					0,
					0,
					1,
					88,
					56,
					1,
					0,
					16,
					0,
					0,
					2,
					4,
					1,
					0,
					0
				}.Concat(second4).Concat(new byte[]
				{
					0,
					0,
					0,
					0,
					16,
					0,
					0,
					6,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					0,
					56,
					0,
					0,
					7,
					2,
					0,
					0,
					0,
					1,
					0,
					0,
					0,
					4,
					0
				}).Concat(second2).Concat(new byte[]
				{
					3,
					0,
					0,
					0,
					32,
					0,
					50,
					56,
					49,
					67,
					49,
					48,
					65,
					50,
					70,
					57,
					51,
					66,
					65,
					57,
					65,
					55,
					57,
					66,
					51,
					50,
					69,
					51,
					67,
					56,
					55,
					67,
					51,
					50,
					48,
					50,
					56,
					48,
					120,
					120,
					120,
					byte.MaxValue
				}).ToList<byte>();
				byte[] array7 = first.Concat(list3).Concat(list4).Concat(list8).Concat(list9).Concat(second5).ToList<byte>().ToArray();
				using (ByteArray byteArray = new ByteArray())
				{
					byteArray.endian = Endian.LITTLE_ENDIAN;
					byteArray.method_2(array7.Length + 4);
					byteArray.writeBytes(array7);
					myUser1225_0.servicetcp.Send(byteArray.Buffer, false);
					byteArray.Dispose();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x0017A204 File Offset: 0x0017A204
		[CompilerGenerated]
		private void method_17()
		{
			try
			{
				if (Form.ActiveForm == this)
				{
					this.mygrid.Refresh();
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600056B RID: 1387 RVA: 0x0017A23C File Offset: 0x0017A23C
		[CompilerGenerated]
		private void method_18()
		{
			try
			{
				this.txtzong.Text = this.int_3.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x0600056C RID: 1388 RVA: 0x0017A274 File Offset: 0x0017A274
		[CompilerGenerated]
		private void method_19()
		{
			try
			{
				this.txtjin.Text = this.int_4.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x0600056D RID: 1389 RVA: 0x0017A2AC File Offset: 0x0017A2AC
		[CompilerGenerated]
		private void method_20()
		{
			try
			{
				this.txtfeng.Text = this.int_5.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x0600056E RID: 1390 RVA: 0x0017A2E4 File Offset: 0x0017A2E4
		[CompilerGenerated]
		private void method_21()
		{
			try
			{
				if (this.ckbdsxh.Checked && this.dateTime_2 != DateTime.MinValue)
				{
					int num = (int)(this.dateTime_2 - DateTime.Now).TotalHours;
					object[] array = new object[4];
					array[0] = this.rQaQnYbAnm.ToString();
					array[1] = this.int_4;
					object[] array2 = array;
					array2[2] = (num / 24).ToString();
					array2[3] = (num % 24).ToString();
					this.Text = string.Format("{0} - {1} - {2}天{3}小时", array2);
				}
				else
				{
					this.Text = string.Format("{0} - {1}", this.rQaQnYbAnm.ToString(), this.int_4);
				}
			}
			catch
			{
			}
		}

		// Token: 0x0600056F RID: 1391 RVA: 0x0017A3BC File Offset: 0x0017A3BC
		[CompilerGenerated]
		private void method_22()
		{
			try
			{
				this.lbldaoqi.Text = string.Format("到期：{0}", timetool.getstr(this.int_0));
				if (this.int_0 > 1440)
				{
					this.lbldaoqi.ForeColor = Color.Green;
				}
				else
				{
					this.lbldaoqi.ForeColor = Color.Red;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000570 RID: 1392 RVA: 0x0017A430 File Offset: 0x0017A430
		[CompilerGenerated]
		private void method_23()
		{
			try
			{
				this.lblauthtime.Text = this.dateTime_0.ToString("HH:mm");
			}
			catch
			{
			}
		}

		// Token: 0x06000571 RID: 1393 RVA: 0x0017A470 File Offset: 0x0017A470
		[CompilerGenerated]
		private void method_24()
		{
			try
			{
				this.ckbdssh.Checked = false;
			}
			catch
			{
			}
		}

		// Token: 0x06000572 RID: 1394 RVA: 0x0017A4A0 File Offset: 0x0017A4A0
		[CompilerGenerated]
		private void method_25()
		{
			try
			{
				this.ckbdsxh.Checked = false;
			}
			catch
			{
			}
		}

		// Token: 0x06000573 RID: 1395 RVA: 0x0017A4D0 File Offset: 0x0017A4D0
		[CompilerGenerated]
		private void method_26()
		{
			try
			{
				this.mygrid.DataSource = (from p in this.concurrentBag_0
				orderby p.index
				select p).ToArray<MyUser1225>();
			}
			catch
			{
			}
		}

		// Token: 0x06000574 RID: 1396 RVA: 0x0017A52C File Offset: 0x0017A52C
		[CompilerGenerated]
		private void method_27()
		{
			try
			{
				this.txtzong.Text = this.concurrentBag_0.Count.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x06000575 RID: 1397 RVA: 0x0017A56C File Offset: 0x0017A56C
		[CompilerGenerated]
		private void method_28()
		{
			for (;;)
			{
				try
				{
					if (this.bool_0 || this.concurrentBag_1 == null || this.concurrentBag_1.Count == 0)
					{
						Thread.Sleep(3000);
						continue;
					}
					IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
					where p.loginstatus == 2 && p.joinstatus == 0 && !p.isfenghao
					select p;
					if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
					{
						foreach (MyUser1225 myUser in enumerable.Reverse<MyUser1225>())
						{
							try
							{
								while (this.yongjiobj_0.isyongji && this.yongjiobj_0.ctime.AddSeconds(10.0) > DateTime.Now && !this.ckbhunhe.Checked)
								{
									Thread.Sleep(1000);
								}
								this.yongjiobj_0.isyongji = false;
								if (!this.bool_0 && !(this.dateTime_0.AddMinutes(5.0) < DateTime.Now) && ((!this.checkBox_1.Checked && !this.checkBox_0.Checked) || (this.list_1 != null && this.list_1.Count != 0)) && ((!this.ckbhttpurl.Checked && !this.ckbhttplocal.Checked) || (this.list_0 != null && this.list_0.Count != 0)))
								{
									if (this.ckbduoip.Checked)
									{
										if (this.list_3 != null && this.list_3.Count > 0)
										{
											myUser.localip = this.list_3[myUser.index % this.list_3.Count];
										}
									}
									else
									{
										myUser.localip = "";
									}
									myip myip = this.concurrentBag_1.ToList<myip>()[myUser.index % this.concurrentBag_1.Count];
									myUser.apip = myip.ip;
									myUser.apport = myip.ports[0];
									if (this.rdbpc.Checked && this.list_0.Count > 0 && (this.ckbhttpurl.Checked || this.ckbhttplocal.Checked))
									{
										myUser.pt = ProxyTypes.Https;
										myUser.daili = this.list_0[myUser.index % this.list_0.Count];
									}
									else if (!this.checkBox_1.Checked && !this.checkBox_0.Checked)
									{
										myUser.pt = ProxyTypes.None;
										myUser.daili = "";
									}
									else
									{
										myUser.pt = ProxyTypes.Socks5;
										myUser.daili = this.list_1[myUser.index % this.list_1.Count];
									}
									if (!myUser.isudblogin && myUser.logintype == 1)
									{
										try
										{
											object arg = this.getpcuser(myUser);
											if (MainForm.<>o__253.<>p__1 == null)
											{
												MainForm.<>o__253.<>p__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(MainForm), new CSharpArgumentInfo[]
												{
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
												}));
											}
											Func<CallSite, object, bool> target = MainForm.<>o__253.<>p__1.Target;
											CallSite <>p__ = MainForm.<>o__253.<>p__1;
											if (MainForm.<>o__253.<>p__0 == null)
											{
												MainForm.<>o__253.<>p__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(MainForm), new CSharpArgumentInfo[]
												{
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
												}));
											}
											if (target(<>p__, MainForm.<>o__253.<>p__0.Target(MainForm.<>o__253.<>p__0, arg, null)))
											{
												if (MainForm.<>o__253.<>p__3 == null)
												{
													MainForm.<>o__253.<>p__3 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target2 = MainForm.<>o__253.<>p__3.Target;
												CallSite <>p__2 = MainForm.<>o__253.<>p__3;
												if (MainForm.<>o__253.<>p__2 == null)
												{
													MainForm.<>o__253.<>p__2 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "uid", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string value = target2(<>p__2, MainForm.<>o__253.<>p__2.Target(MainForm.<>o__253.<>p__2, arg));
												if (MainForm.<>o__253.<>p__5 == null)
												{
													MainForm.<>o__253.<>p__5 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target3 = MainForm.<>o__253.<>p__5.Target;
												CallSite <>p__3 = MainForm.<>o__253.<>p__5;
												if (MainForm.<>o__253.<>p__4 == null)
												{
													MainForm.<>o__253.<>p__4 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "username", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string username = target3(<>p__3, MainForm.<>o__253.<>p__4.Target(MainForm.<>o__253.<>p__4, arg));
												if (MainForm.<>o__253.<>p__7 == null)
												{
													MainForm.<>o__253.<>p__7 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target4 = MainForm.<>o__253.<>p__7.Target;
												CallSite <>p__4 = MainForm.<>o__253.<>p__7;
												if (MainForm.<>o__253.<>p__6 == null)
												{
													MainForm.<>o__253.<>p__6 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "cookie", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string arg2 = target4(<>p__4, MainForm.<>o__253.<>p__6.Target(MainForm.<>o__253.<>p__6, arg));
												if (MainForm.<>o__253.<>p__9 == null)
												{
													MainForm.<>o__253.<>p__9 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target5 = MainForm.<>o__253.<>p__9.Target;
												CallSite <>p__5 = MainForm.<>o__253.<>p__9;
												if (MainForm.<>o__253.<>p__8 == null)
												{
													MainForm.<>o__253.<>p__8 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "at", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string text = target5(<>p__5, MainForm.<>o__253.<>p__8.Target(MainForm.<>o__253.<>p__8, arg));
												myUser.username = username;
												myUser.uid = Convert.ToUInt32(value);
												myUser.yycookie = Hex.toArray(arg2).Buffer;
												myUser.autotoken = ((text == null) ? "" : text);
												myUser.isudblogin = true;
											}
											else
											{
												myUser.isudblogin = false;
											}
										}
										catch
										{
										}
									}
									if (this.checkBox_1.Checked)
									{
										myUser.ishidedaili = true;
									}
									else
									{
										myUser.ishidedaili = false;
									}
									myUser.sid = this.rQaQnYbAnm;
									myUser.subid = this.uint_0;
									myUser.status = 1;
									myUser.joinstatus = 1;
									myUser.lastsendtime = DateTime.Now;
									myUser.ishunhejin = this.ckbhunhe.Checked;
									myUser.StartJoin();
									Thread.Sleep(this.int_1);
									continue;
								}
							}
							catch
							{
								myUser.status = 1;
								myUser.joinstatus = -1;
								continue;
							}
							break;
						}
					}
				}
				catch
				{
				}
				Thread.Sleep(1000);
			}
		}

		// Token: 0x06000576 RID: 1398 RVA: 0x0017ACA0 File Offset: 0x0017ACA0
		[CompilerGenerated]
		private void method_29()
		{
			for (;;)
			{
				try
				{
					if (this.bool_0 || this.concurrentBag_1 == null || this.concurrentBag_1.Count == 0)
					{
						Thread.Sleep(3000);
						continue;
					}
					IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
					where p.loginstatus == 2 && p.joinstatus == -1 && !p.isfenghao
					select p;
					if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
					{
						foreach (MyUser1225 myUser in enumerable.Reverse<MyUser1225>())
						{
							try
							{
								while (this.yongjiobj_0.isyongji && this.yongjiobj_0.ctime.AddSeconds(10.0) > DateTime.Now && !this.ckbhunhe.Checked)
								{
									Thread.Sleep(1000);
								}
								this.yongjiobj_0.isyongji = false;
								if (!this.bool_0 && !(this.dateTime_0.AddMinutes(5.0) < DateTime.Now) && ((!this.checkBox_1.Checked && !this.checkBox_0.Checked) || this.list_1.Count != 0) && ((!this.ckbhttpurl.Checked && !this.ckbhttplocal.Checked) || (this.list_0 != null && this.list_0.Count != 0)))
								{
									if (this.ckbduoip.Checked)
									{
										if (this.list_3 != null && this.list_3.Count > 0)
										{
											myUser.localip = this.list_3[myUser.index % this.list_3.Count];
										}
									}
									else
									{
										myUser.localip = "";
									}
									myip myip = this.concurrentBag_1.ToList<myip>()[myUser.index % this.concurrentBag_1.Count];
									myUser.apip = myip.ip;
									myUser.apport = myip.ports[0];
									if (this.rdbpc.Checked && this.list_0.Count > 0 && (this.ckbhttpurl.Checked || this.ckbhttplocal.Checked))
									{
										myUser.pt = ProxyTypes.Https;
										myUser.daili = this.list_0[myUser.index % this.list_0.Count];
									}
									else if (!this.checkBox_1.Checked && !this.checkBox_0.Checked)
									{
										myUser.pt = ProxyTypes.None;
										myUser.daili = "";
									}
									else
									{
										myUser.pt = ProxyTypes.Socks5;
										myUser.daili = this.list_1[myUser.index % this.list_1.Count];
									}
									if (!myUser.isudblogin && myUser.logintype == 1)
									{
										try
										{
											object arg = this.getpcuser(myUser);
											if (MainForm.<>o__254.<>p__1 == null)
											{
												MainForm.<>o__254.<>p__1 = CallSite<Func<CallSite, object, bool>>.Create(Binder.UnaryOperation(CSharpBinderFlags.None, ExpressionType.IsTrue, typeof(MainForm), new CSharpArgumentInfo[]
												{
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
												}));
											}
											Func<CallSite, object, bool> target = MainForm.<>o__254.<>p__1.Target;
											CallSite <>p__ = MainForm.<>o__254.<>p__1;
											if (MainForm.<>o__254.<>p__0 == null)
											{
												MainForm.<>o__254.<>p__0 = CallSite<Func<CallSite, object, object, object>>.Create(Binder.BinaryOperation(CSharpBinderFlags.None, ExpressionType.NotEqual, typeof(MainForm), new CSharpArgumentInfo[]
												{
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null),
													CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.Constant, null)
												}));
											}
											if (target(<>p__, MainForm.<>o__254.<>p__0.Target(MainForm.<>o__254.<>p__0, arg, null)))
											{
												if (MainForm.<>o__254.<>p__3 == null)
												{
													MainForm.<>o__254.<>p__3 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target2 = MainForm.<>o__254.<>p__3.Target;
												CallSite <>p__2 = MainForm.<>o__254.<>p__3;
												if (MainForm.<>o__254.<>p__2 == null)
												{
													MainForm.<>o__254.<>p__2 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "uid", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string value = target2(<>p__2, MainForm.<>o__254.<>p__2.Target(MainForm.<>o__254.<>p__2, arg));
												if (MainForm.<>o__254.<>p__5 == null)
												{
													MainForm.<>o__254.<>p__5 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target3 = MainForm.<>o__254.<>p__5.Target;
												CallSite <>p__3 = MainForm.<>o__254.<>p__5;
												if (MainForm.<>o__254.<>p__4 == null)
												{
													MainForm.<>o__254.<>p__4 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "username", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string username = target3(<>p__3, MainForm.<>o__254.<>p__4.Target(MainForm.<>o__254.<>p__4, arg));
												if (MainForm.<>o__254.<>p__7 == null)
												{
													MainForm.<>o__254.<>p__7 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target4 = MainForm.<>o__254.<>p__7.Target;
												CallSite <>p__4 = MainForm.<>o__254.<>p__7;
												if (MainForm.<>o__254.<>p__6 == null)
												{
													MainForm.<>o__254.<>p__6 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "cookie", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string arg2 = target4(<>p__4, MainForm.<>o__254.<>p__6.Target(MainForm.<>o__254.<>p__6, arg));
												if (MainForm.<>o__254.<>p__9 == null)
												{
													MainForm.<>o__254.<>p__9 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof(string), typeof(MainForm)));
												}
												Func<CallSite, object, string> target5 = MainForm.<>o__254.<>p__9.Target;
												CallSite <>p__5 = MainForm.<>o__254.<>p__9;
												if (MainForm.<>o__254.<>p__8 == null)
												{
													MainForm.<>o__254.<>p__8 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "at", typeof(MainForm), new CSharpArgumentInfo[]
													{
														CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null)
													}));
												}
												string text = target5(<>p__5, MainForm.<>o__254.<>p__8.Target(MainForm.<>o__254.<>p__8, arg));
												myUser.username = username;
												myUser.uid = Convert.ToUInt32(value);
												myUser.yycookie = Hex.toArray(arg2).Buffer;
												myUser.autotoken = ((text == null) ? "" : text);
												myUser.isudblogin = true;
											}
											else
											{
												myUser.isudblogin = false;
											}
										}
										catch
										{
										}
									}
									if (this.checkBox_1.Checked)
									{
										myUser.ishidedaili = true;
									}
									else
									{
										myUser.ishidedaili = false;
									}
									myUser.sid = this.rQaQnYbAnm;
									myUser.subid = this.uint_0;
									myUser.status = 1;
									myUser.joinstatus = 1;
									myUser.lastsendtime = DateTime.Now;
									myUser.ishunhejin = this.ckbhunhe.Checked;
									myUser.StartJoin();
									Thread.Sleep(this.int_1);
									continue;
								}
							}
							catch
							{
								myUser.status = 1;
								myUser.joinstatus = -1;
								continue;
							}
							break;
						}
					}
				}
				catch
				{
				}
				Thread.Sleep(1000);
			}
		}

		// Token: 0x06000577 RID: 1399 RVA: 0x0017B3C8 File Offset: 0x0017B3C8
		[CompilerGenerated]
		private void method_30()
		{
			foreach (MyUser1225 myUser in from p in this.concurrentBag_0.Reverse<MyUser1225>()
			where !p.isfenghao
			select p)
			{
				try
				{
					if (myUser.status == 2)
					{
						myUser.LeaveChanel();
					}
					myUser.istuichu = true;
					myUser.heartbeat = 0;
					myUser.status = 0;
					myUser.joinstatus = 0;
					myUser.mytrace = "tuichu";
					myUser.currentflag = 10000;
					myUser.isudblogin = false;
					if (myUser.logintcp != null)
					{
						myUser.ZhuDongDK((rdomhelper.getrandom(0, 100) <= 50) ? -1 : 0);
					}
				}
				catch
				{
				}
				Thread.Sleep(15);
			}
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x0017B4BC File Offset: 0x0017B4BC
		[CompilerGenerated]
		private void method_98()
		{
			foreach (MyUser1225 myUser in (from p in this.concurrentBag_0
			where p.status == 2
			select p).Reverse<MyUser1225>())
			{
				try
				{
					myUser.qiangmai();
					Thread.Sleep(15);
				}
				catch
				{
				}
			}
			this.button1.BeginInvoke(new MethodInvoker(this.method_99));
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x0017B564 File Offset: 0x0017B564
		[CompilerGenerated]
		private void method_99()
		{
			try
			{
				this.button1.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x0017B594 File Offset: 0x0017B594
		[CompilerGenerated]
		private void method_100()
		{
			foreach (MyUser1225 myUser in (from p in this.concurrentBag_0
			where p.status == 2
			select p).Reverse<MyUser1225>())
			{
				try
				{
					myUser.xiamai();
					Thread.Sleep(15);
				}
				catch
				{
				}
			}
			this.button2.BeginInvoke(new MethodInvoker(this.method_101));
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x0017B63C File Offset: 0x0017B63C
		[CompilerGenerated]
		private void method_101()
		{
			try
			{
				this.button2.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x0017B66C File Offset: 0x0017B66C
		[CompilerGenerated]
		private void method_31()
		{
			foreach (MyUser1225 myUser in this.concurrentBag_0.Reverse<MyUser1225>())
			{
				try
				{
					if (myUser.status == 2)
					{
						myUser.mytrace = "切换频道";
						myUser.LeaveChanel();
					}
					myUser.sid = this.rQaQnYbAnm;
					myUser.subid = this.uint_0;
					myUser.isskip = true;
				}
				catch
				{
				}
				Thread.Sleep(15);
			}
			Thread.Sleep(3000);
			for (;;)
			{
				IEnumerable<MyUser1225> source = this.concurrentBag_0;
				Func<MyUser1225, bool> predicate;
				if ((predicate = MainForm.<>c.<>9__260_0) == null)
				{
					predicate = (MainForm.<>c.<>9__260_0 = ((MyUser1225 p) => !p.isfenghao && p.isskip && p.status == 2));
				}
				IEnumerable<MyUser1225> enumerable = source.Where(predicate);
				if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
				{
					foreach (MyUser1225 myUser2 in enumerable.Reverse<MyUser1225>())
					{
						while (this.yongjiobj_0.isyongji && this.yongjiobj_0.ctime.AddSeconds(5.0) > DateTime.Now)
						{
							Thread.Sleep(1000);
						}
						this.yongjiobj_0.isyongji = false;
						if (myUser2.isskip && myUser2.status == 2 && myUser2.lastsendtime.AddSeconds(3.0) < DateTime.Now)
						{
							myUser2.Send_0BD0_02411F(false);
							Thread.Sleep(15);
						}
					}
				}
				if (enumerable == null || enumerable.Count<MyUser1225>() == 0)
				{
					break;
				}
				Thread.Sleep(1000);
			}
			if (!this.btnqiehuan.Enabled && !this.bool_0)
			{
				this.btnqiehuan.BeginInvoke(new MethodInvoker(this.method_32));
			}
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x0017B874 File Offset: 0x0017B874
		[CompilerGenerated]
		private void method_shuahua()
		{
			for (;;)
			{
				if (!this.bool_0)
				{
					IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
					where p.status == 2 && p.isloginservice
					select p;
					if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
					{
						using (IEnumerator<MyUser1225> enumerator = enumerable.GetEnumerator())
						{
							while (enumerator.MoveNext())
							{
								MyUser1225 item = enumerator.Current;
								if (this.bool_0)
								{
									break;
								}
								if (!this.btn_tingzhishuahua.Enabled)
								{
									break;
								}
								try
								{
									Task.Factory.StartNew(delegate()
									{
										new MyUser1225();
										item.shuahua(uint.Parse(this.shuahuauid), this.beishuahuamingzi);
									});
								}
								catch
								{
								}
								Thread.Sleep(this.int_123);
							}
						}
					}
				}
				if (!this.btn_tingzhishuahua.Enabled)
				{
					break;
				}
				Thread.Sleep(3000);
			}
			if (!this.btn_tingzhishuahua.Enabled)
			{
				this.btn_tingzhishuahua.BeginInvoke(new MethodInvoker(this.method_songhua));
			}
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x0017B9A0 File Offset: 0x0017B9A0
		[CompilerGenerated]
		private void method_311()
		{
			if (!this.bool_0)
			{
				IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
				where p.status == 2 && p.isloginservice
				select p;
				if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
				{
					using (IEnumerator<MyUser1225> enumerator = enumerable.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							MyUser1225 item = enumerator.Current;
							if (this.bool_0)
							{
								break;
							}
							if (!this.tingzhizhibotongzhi.Enabled)
							{
								break;
							}
							try
							{
								Task.Factory.StartNew(delegate()
								{
									new MyUser1225();
									item.zhibotongzhi(uint.Parse(this.shuahuauid));
								});
							}
							catch
							{
							}
							Thread.Sleep(this.int_123);
						}
					}
				}
			}
			this.zhibotongzhi.BeginInvoke(new MethodInvoker(this.method_9999));
		}

		// Token: 0x0600057F RID: 1407 RVA: 0x0017BAA0 File Offset: 0x0017BAA0
		[CompilerGenerated]
		private void method_3111()
		{
			if (!this.bool_0)
			{
				IEnumerable<MyUser1225> enumerable = from p in this.concurrentBag_0
				where p.status == 2 && p.isloginservice
				select p;
				if (enumerable != null && enumerable.Count<MyUser1225>() > 0)
				{
					using (IEnumerator<MyUser1225> enumerator = enumerable.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							MyUser1225 item = enumerator.Current;
							if (this.bool_0)
							{
								break;
							}
							if (!this.tzdaka.Enabled)
							{
								break;
							}
							try
							{
								Task.Factory.StartNew(delegate()
								{
									new MyUser1225();
									item.daka2();
								});
							}
							catch
							{
							}
							Thread.Sleep(this.int_123);
						}
					}
				}
			}
			this.daka.BeginInvoke(new MethodInvoker(this.method_99999));
		}

		// Token: 0x06000580 RID: 1408 RVA: 0x0017BB94 File Offset: 0x0017BB94
		[CompilerGenerated]
		private void method_99999()
		{
			try
			{
				this.daka.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000581 RID: 1409 RVA: 0x0017BBC4 File Offset: 0x0017BBC4
		[CompilerGenerated]
		private void method_9999()
		{
			try
			{
				this.zhibotongzhi.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x0017BBF4 File Offset: 0x0017BBF4
		[CompilerGenerated]
		private void method_32()
		{
			try
			{
				this.btnqiehuan.Enabled = true;
				this.btntuichu.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000583 RID: 1411 RVA: 0x0017BC30 File Offset: 0x0017BC30
		[CompilerGenerated]
		private void method_songhua()
		{
			try
			{
				this.btn_songhua.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000584 RID: 1412 RVA: 0x0017BC60 File Offset: 0x0017BC60
		[CompilerGenerated]
		private void method_33()
		{
			foreach (MyUser1225 myUser1225_ in (from p in this.concurrentBag_0
			where p.status == 2
			select p).Reverse<MyUser1225>())
			{
				try
				{
					this.method_13(myUser1225_);
					Thread.Sleep(15);
				}
				catch
				{
				}
			}
			this.btnsuijixingbie.BeginInvoke(new MethodInvoker(this.method_34));
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x0017BD08 File Offset: 0x0017BD08
		[CompilerGenerated]
		private void method_34()
		{
			try
			{
				this.btnsuijixingbie.Enabled = true;
				this.nanxing.Enabled = true;
				this.nvxing.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000586 RID: 1414 RVA: 0x0017BD50 File Offset: 0x0017BD50
		[CompilerGenerated]
		private void method_88()
		{
			foreach (MyUser1225 myUser1225_ in (from p in this.concurrentBag_0
			where p.status == 2
			select p).Reverse<MyUser1225>())
			{
				try
				{
					this.method_131(myUser1225_);
					Thread.Sleep(15);
				}
				catch
				{
				}
			}
			this.btnsuijixingbie.BeginInvoke(new MethodInvoker(this.method_881));
		}

		// Token: 0x06000587 RID: 1415 RVA: 0x0017BD08 File Offset: 0x0017BD08
		[CompilerGenerated]
		private void method_881()
		{
			try
			{
				this.btnsuijixingbie.Enabled = true;
				this.nanxing.Enabled = true;
				this.nvxing.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x0017BDF8 File Offset: 0x0017BDF8
		[CompilerGenerated]
		private void method_77()
		{
			foreach (MyUser1225 myUser1225_ in (from p in this.concurrentBag_0
			where p.status == 2
			select p).Reverse<MyUser1225>())
			{
				try
				{
					this.method_132(myUser1225_);
					Thread.Sleep(15);
				}
				catch
				{
				}
			}
			this.btnsuijixingbie.BeginInvoke(new MethodInvoker(this.method_771));
		}

		// Token: 0x06000589 RID: 1417 RVA: 0x0017BD08 File Offset: 0x0017BD08
		[CompilerGenerated]
		private void method_771()
		{
			try
			{
				this.btnsuijixingbie.Enabled = true;
				this.nanxing.Enabled = true;
				this.nvxing.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600058A RID: 1418 RVA: 0x0017BEA0 File Offset: 0x0017BEA0
		[CompilerGenerated]
		private void method_35()
		{
			try
			{
				this.btndaorumajia.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600058B RID: 1419 RVA: 0x0017BED0 File Offset: 0x0017BED0
		[CompilerGenerated]
		private void method_36()
		{
			try
			{
				this.btndaoruqianming.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600058C RID: 1420 RVA: 0x0017BF00 File Offset: 0x0017BF00
		[CompilerGenerated]
		private void method_37()
		{
			try
			{
				this.btndaoruhanhua.Text = this.list_2.Count.ToString();
			}
			catch
			{
			}
		}

		// Token: 0x0600058D RID: 1421 RVA: 0x0017BF40 File Offset: 0x0017BF40
		[CompilerGenerated]
		private void bMoQvhfFik()
		{
			foreach (MyUser1225 myUser in from uu in this.concurrentBag_0
			where uu.status < 2 || uu.isskip
			select uu)
			{
				if (myUser.status < 2 || myUser.isskip)
				{
					try
					{
						if (myUser.logintype == 1)
						{
							logtool.delusercache_p(myUser.passport);
						}
						else
						{
							logtool.delusercache_w(myUser.passport);
						}
						myUser.isskip = false;
						myUser.ZhuDongDK(0);
						myUser.isupdate = false;
						myUser.isudblogin = false;
						myUser.send04d6 = 0;
						myUser.tihaotime = DateTime.MinValue;
					}
					catch
					{
					}
					Thread.Sleep(10);
				}
			}
			this.btnchonglian.BeginInvoke(new MethodInvoker(this.method_38));
		}

		// Token: 0x0600058E RID: 1422 RVA: 0x0017C040 File Offset: 0x0017C040
		[CompilerGenerated]
		private void method_38()
		{
			try
			{
				this.btnchonglian.Enabled = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600058F RID: 1423 RVA: 0x0017C070 File Offset: 0x0017C070
		[CompilerGenerated]
		private void method_39()
		{
			try
			{
				foreach (MyUser1225 myUser in from p in this.concurrentBag_0
				where p.isupdate
				select p)
				{
					myUser.isupdate = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000590 RID: 1424 RVA: 0x0017C0F4 File Offset: 0x0017C0F4
		private void timer1_Tick(object sender, EventArgs e)
		{
			try
			{
				RegForm regForm = new RegForm();
				if (!regForm.SoftKeyIsOK())
				{
					Environment.Exit(0);
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x06000591 RID: 1425 RVA: 0x0017C12C File Offset: 0x0017C12C
		public static string Between(string str, string leftstr, string rightstr)
		{
			int num = str.IndexOf(leftstr) + leftstr.Length;
			return str.Substring(num, str.IndexOf(rightstr, num) - num);
		}

		// Token: 0x06000592 RID: 1426 RVA: 0x0017C15C File Offset: 0x0017C15C
		public string GetPostString(string url, string data)
		{
			string result;
			try
			{
				byte[] bytes = Encoding.GetEncoding("utf-8").GetBytes(data);
				HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
				httpWebRequest.Method = "POST";
				httpWebRequest.ContentType = "application/x-www-form-urlencoded";
				httpWebRequest.ContentLength = (long)bytes.Length;
				httpWebRequest.Proxy = null;
				Stream requestStream = httpWebRequest.GetRequestStream();
				requestStream.Write(bytes, 0, bytes.Length);
				requestStream.Close();
				using (StreamReader streamReader = new StreamReader(((HttpWebResponse)httpWebRequest.GetResponse()).GetResponseStream(), Encoding.GetEncoding("utf-8")))
				{
					result = streamReader.ReadToEnd();
				}
			}
			catch (Exception ex)
			{
				result = ex.Message;
			}
			return result;
		}

		// Token: 0x06000593 RID: 1427 RVA: 0x0017C228 File Offset: 0x0017C228
		private void huoquuid()
		{
			if (this.txt_shuahuauid.Text != "")
			{
				string text = Convert.ToInt64((DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds).ToString();
				string s = text;
				byte[] array = Encoding.Default.GetBytes(s);
				array = new SHA1CryptoServiceProvider().ComputeHash(array);
				StringBuilder stringBuilder = new StringBuilder();
				byte[] array2 = array;
				foreach (byte b in array2)
				{
					stringBuilder.AppendFormat("{0:x2}", b);
				}
				string postString = this.GetPostString("http://m.yy.com/zone/" + this.txt_shuahuauid.Text + "/getUserIdByAccount.action", string.Concat(new string[]
				{
					"account=",
					this.txt_shuahuauid.Text,
					"&uid=undefined&userMac=%7B%22m%22%3A%22",
					stringBuilder.ToString(),
					"%22%2C%22t%22%3A",
					text,
					"%7D"
				}));
				this.shuahuauid = MainForm.Between(postString, "\"uid\":\"", "\"}");
				if (this.shuahuauid != "")
				{
					string postString2 = this.GetPostString("http://m.yy.com/live/getUserInfos.action?uid=" + this.shuahuauid, "uid=" + this.shuahuauid);
					this.beishuahuamingzi = MainForm.Between(postString2, "\"nick\":\"", "\",");
				}
			}
		}

		// Token: 0x06000594 RID: 1428 RVA: 0x0017C3A8 File Offset: 0x0017C3A8
		private void btn_songhua_Click(object sender, EventArgs e)
		{
			if (!int.TryParse(this.shuahuasudu.Text.Trim(), out this.int_123))
			{
				this.shuahuasudu.Text = "500";
				this.int_123 = 500;
			}
			this.btn_songhua.Enabled = false;
			this.btn_tingzhishuahua.Enabled = true;
			this.huoquuid();
			Task.Factory.StartNew(new Action(this.method_shuahua));
		}

		// Token: 0x06000595 RID: 1429 RVA: 0x0015A59B File Offset: 0x0015A59B
		private void btn_tingzhishuahua_Click(object sender, EventArgs e)
		{
			this.btn_songhua.Enabled = true;
			this.btn_tingzhishuahua.Enabled = false;
		}

		// Token: 0x06000596 RID: 1430 RVA: 0x0017C424 File Offset: 0x0017C424
		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				this.button1.Enabled = false;
				Task.Factory.StartNew(new Action(this.method_98));
			}
			catch
			{
			}
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x0017C46C File Offset: 0x0017C46C
		private void button2_Click(object sender, EventArgs e)
		{
			try
			{
				this.button2.Enabled = false;
				Task.Factory.StartNew(new Action(this.method_100));
			}
			catch
			{
			}
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x0015A5B5 File Offset: 0x0015A5B5
		private void nanxing_Click(object sender, EventArgs e)
		{
			this.btnsuijixingbie.Enabled = false;
			this.nanxing.Enabled = false;
			this.nvxing.Enabled = false;
			Task.Factory.StartNew(new Action(this.method_88));
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x0015A5F2 File Offset: 0x0015A5F2
		private void nvxing_Click(object sender, EventArgs e)
		{
			this.btnsuijixingbie.Enabled = false;
			this.nanxing.Enabled = false;
			this.nvxing.Enabled = false;
			Task.Factory.StartNew(new Action(this.method_77));
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x0017C4B4 File Offset: 0x0017C4B4
		private void zhibotongzhi_Click(object sender, EventArgs e)
		{
			this.huoquuid();
			this.tingzhizhibotongzhi.Enabled = true;
			this.zhibotongzhi.Enabled = false;
			if (!int.TryParse(this.shuahuasudu.Text.Trim(), out this.int_123))
			{
				this.shuahuasudu.Text = "500";
				this.int_123 = 500;
			}
			Task.Factory.StartNew(new Action(this.method_311));
		}

		// Token: 0x0600059B RID: 1435 RVA: 0x0015A62F File Offset: 0x0015A62F
		private void tingzhizhibotongzhi_Click(object sender, EventArgs e)
		{
			this.tingzhizhibotongzhi.Enabled = false;
			this.zhibotongzhi.Enabled = true;
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x0017C530 File Offset: 0x0017C530
		private void button3_Click(object sender, EventArgs e)
		{
			if (!int.TryParse(this.txthanhuajiange.Text.Trim(), out this.int_2))
			{
				this.txthanhuajiange.Text = "5000";
			}
			this.int_2 = Convert.ToInt32(this.txthanhuajiange.Text);
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x0017C580 File Offset: 0x0017C580
		private void daka_Click(object sender, EventArgs e)
		{
			this.tzdaka.Enabled = true;
			this.daka.Enabled = false;
			if (!int.TryParse(this.shuahuasudu.Text.Trim(), out this.int_123))
			{
				this.shuahuasudu.Text = "500";
				this.int_123 = 500;
			}
			Task.Factory.StartNew(new Action(this.method_3111));
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x0015A649 File Offset: 0x0015A649
		private void tzdaka_Click(object sender, EventArgs e)
		{
			this.tzdaka.Enabled = false;
			this.daka.Enabled = true;
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x0017C5F4 File Offset: 0x0017C5F4
		private void buhao_CheckedChanged(object sender, EventArgs e)
		{
			try
			{
				CheckBox checkBox = (CheckBox)sender;
				if (!checkBox.Checked)
				{
					MyUser1225.zidongbuhao = true;
				}
				else
				{
					MyUser1225.zidongbuhao = false;
				}
			}
			catch
			{
			}
		}

		// Token: 0x040003F0 RID: 1008
		private Random random_0;

		// Token: 0x040003F1 RID: 1009
		public string shuahuauid;

		// Token: 0x040003F2 RID: 1010
		private string string_0;

		// Token: 0x040003F3 RID: 1011
		private bool bool_0;

		// Token: 0x040003F4 RID: 1012
		private DateTime dateTime_0;

		// Token: 0x040003F5 RID: 1013
		private int int_0;

		// Token: 0x040003F6 RID: 1014
		private string string_1;

		// Token: 0x040003F7 RID: 1015
		private int int_1;

		// Token: 0x040003F8 RID: 1016
		private uint rQaQnYbAnm;

		// Token: 0x040003F9 RID: 1017
		private uint uint_0;

		// Token: 0x040003FA RID: 1018
		private ConcurrentBag<MyUser1225> concurrentBag_0;

		// Token: 0x040003FB RID: 1019
		private ConcurrentBag<myip> concurrentBag_1;

		// Token: 0x040003FC RID: 1020
		private List<string> list_0;

		// Token: 0x040003FD RID: 1021
		private List<string> list_1;

		// Token: 0x040003FE RID: 1022
		private int int_2;

		// Token: 0x040003FF RID: 1023
		private List<string> list_2;

		// Token: 0x04000400 RID: 1024
		private int int_3;

		// Token: 0x04000401 RID: 1025
		private int int_4;

		// Token: 0x04000402 RID: 1026
		private int int_5;

		// Token: 0x04000403 RID: 1027
		private List<string> list_3;

		// Token: 0x04000404 RID: 1028
		private DateTime dateTime_1;

		// Token: 0x04000405 RID: 1029
		private DateTime dateTime_2;

		// Token: 0x04000406 RID: 1030
		private System.Timers.Timer timer_0;

		// Token: 0x04000407 RID: 1031
		private System.Timers.Timer timer_1;

		// Token: 0x04000408 RID: 1032
		private System.Timers.Timer timer_2;

		// Token: 0x04000409 RID: 1033
		private System.Timers.Timer timer_3;

		// Token: 0x0400040A RID: 1034
		private System.Timers.Timer timer_4;

		// Token: 0x0400040B RID: 1035
		private System.Timers.Timer timer_5;

		// Token: 0x0400040C RID: 1036
		private System.Timers.Timer timer_6;

		// Token: 0x0400040D RID: 1037
		private System.Timers.Timer timer_7;

		// Token: 0x0400040E RID: 1038
		private System.Timers.Timer timer_8;

		// Token: 0x0400040F RID: 1039
		private System.Timers.Timer timer_9;

		// Token: 0x04000410 RID: 1040
		private System.Timers.Timer timer_10;

		// Token: 0x04000411 RID: 1041
		private System.Timers.Timer timer_11;

		// Token: 0x04000412 RID: 1042
		private System.Timers.Timer timer_12;

		// Token: 0x04000413 RID: 1043
		private static int int_6;

		// Token: 0x04000414 RID: 1044
		private static int int_7;

		// Token: 0x04000415 RID: 1045
		private static int int_8;

		// Token: 0x04000416 RID: 1046
		private static int int_9;

		// Token: 0x04000417 RID: 1047
		private static int int_10;

		// Token: 0x04000418 RID: 1048
		private static int int_11;

		// Token: 0x04000419 RID: 1049
		private static int int_12;

		// Token: 0x0400041A RID: 1050
		private bool bool_1;

		// Token: 0x0400041B RID: 1051
		private static int int_13;

		// Token: 0x0400041C RID: 1052
		private static int int_14;

		// Token: 0x0400041D RID: 1053
		private static int int_15;

		// Token: 0x0400041E RID: 1054
		private volatile int int_16;

		// Token: 0x0400041F RID: 1055
		private bool bool_2;

		// Token: 0x04000420 RID: 1056
		private List<uint> list_4;

		// Token: 0x04000421 RID: 1057
		private List<uint> list_5;

		// Token: 0x04000422 RID: 1058
		private yongjiobj yongjiobj_0;

		// Token: 0x04000423 RID: 1059
		private bool bool_3;

		// Token: 0x04000477 RID: 1143
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_0;

		// Token: 0x04000478 RID: 1144
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_1;

		// Token: 0x04000479 RID: 1145
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_2;

		// Token: 0x0400047A RID: 1146
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_3;

		// Token: 0x0400047B RID: 1147
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_4;

		// Token: 0x0400047C RID: 1148
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_5;

		// Token: 0x0400047D RID: 1149
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_6;

		// Token: 0x04000486 RID: 1158
		private DataGridViewTextBoxColumn dataGridViewTextBoxColumn_7;

		// Token: 0x0400048C RID: 1164
		private string beishuahuamingzi;

		// Token: 0x040004A1 RID: 1185
		private int int_123;
	}
}
