﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Encrypt;
using Hardware;

namespace ns1
{
	// Token: 0x020000B0 RID: 176
	public partial class RegForm : Form
	{
		// Token: 0x17000113 RID: 275
		// (get) Token: 0x060005DB RID: 1499 RVA: 0x0015A7D4 File Offset: 0x0015A7D4
		// (set) Token: 0x060005DC RID: 1500 RVA: 0x0015A7DC File Offset: 0x0015A7DC
		public DateTime timeOver { get; set; }

		// Token: 0x060005DE RID: 1502 RVA: 0x0017D9F0 File Offset: 0x0017D9F0
		public RegForm()
		{
			this.InitializeComponent();
			HardwareInfo hardwareInfo = new HardwareInfo();
			this.textBox1.Text = DEncrypt.Encrypt(hardwareInfo.GetCpuID() + hardwareInfo.GetHardDiskID());
			Crypto3DES.Encoding = Encoding.UTF8;
		}

		// Token: 0x060005DF RID: 1503 RVA: 0x0017DA50 File Offset: 0x0017DA50
		public bool SoftKeyIsOK()
		{
			return true;
		}

		// Token: 0x060005E0 RID: 1504 RVA: 0x0017DA60 File Offset: 0x0017DA60
		private void OK_Click_1(object sender, EventArgs e)
		{
			string text = this.textBox2.Text;
			string text2 = this.textBox1.Text;
			Crypto3DES.Decrypt3DES(text).Split(new char[]
			{
				'#'
			});
			File.WriteAllText(this.lin, text);
			MessageBox.Show("恭喜,软件注册成功!", "成功", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			base.DialogResult = DialogResult.OK;
			base.Close();
		}

		// Token: 0x060005E1 RID: 1505 RVA: 0x0015A7E5 File Offset: 0x0015A7E5
		private void button1_Click_1(object sender, EventArgs e)
		{
			Clipboard.SetDataObject(this.textBox1.Text, true);
			MessageBox.Show("复制机器码成功!", "成功", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
		}

		// Token: 0x060005E2 RID: 1506 RVA: 0x0015A80B File Offset: 0x0015A80B
		private void Cancel_Click_1(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x040004F5 RID: 1269
		private string lin = Application.CommonAppDataPath + "\\lincense.lic";
	}
}
