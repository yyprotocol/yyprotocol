﻿using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using JIQIMAO.Common;
using JIQIMAO.Model;

namespace ns1
{
	// Token: 0x020000AF RID: 175
	internal static class Program
	{
		// Token: 0x060005D2 RID: 1490 RVA: 0x0017CB00 File Offset: 0x0017CB00
		[STAThread]
		private static void Main()
		{
			try
			{
				try
				{
					string path = Application.StartupPath + "\\Cache2";
					if (!Directory.Exists(path))
					{
						Directory.CreateDirectory(path);
					}
				}
				catch
				{
				}
				try
				{
					string path2 = Application.StartupPath + "\\Cache1";
					if (!Directory.Exists(path2))
					{
						Directory.CreateDirectory(path2);
					}
				}
				catch
				{
				}
				try
				{
					string startupPath = Application.StartupPath;
					if (!Directory.Exists(startupPath))
					{
						Directory.CreateDirectory(startupPath);
					}
				}
				catch
				{
				}
				try
				{
					string startupPath2 = Application.StartupPath;
					if (!Directory.Exists(startupPath2))
					{
						Directory.CreateDirectory(startupPath2);
					}
				}
				catch
				{
				}
				Application.EnableVisualStyles();
				Application.SetCompatibleTextRenderingDefault(false);
				RegForm regForm = new RegForm();
				if (!regForm.SoftKeyIsOK() && regForm.ShowDialog() != DialogResult.OK)
				{
					Environment.Exit(0);
				}
				else
				{
					ServicePointManager.DefaultConnectionLimit = int.MaxValue;
					System.Timers.Timer timer = new System.Timers.Timer(60000.0);
					timer.Elapsed += new ElapsedEventHandler(Program.KjaHtSyPm);
					timer.AutoReset = true;
					timer.Enabled = true;
					timer.Start();
					DateTime now = DateTime.Now;
					Application.Run(new MainForm(99999999, now, regForm.timeOver, true));
				}
			}
			catch
			{
				Application.Exit();
			}
		}

		// Token: 0x060005D4 RID: 1492 RVA: 0x0017CCA4 File Offset: 0x0017CCA4
		private static void smethod_0(object object_0, object object_1)
		{
			if (Interlocked.Exchange(ref Program.int_0, 1) == 0)
			{
				try
				{
					ConcurrentBag<myip> concurrentBag = new ConcurrentBag<myip>();
					new initip(concurrentBag).getwebipsnew("0", "0");
					if (concurrentBag.Count > 0)
					{
						StringBuilder stringBuilder = new StringBuilder();
						foreach (myip myip in concurrentBag)
						{
							try
							{
								stringBuilder.AppendLine(string.Format("{0}|{1},{2}", myip.ip, myip.ports[0], myip.ports[1]));
							}
							catch
							{
							}
						}
						string text = stringBuilder.ToString();
						if (text.Trim().Length > 0)
						{
							logtool.logips_p(text);
						}
					}
				}
				catch (Exception)
				{
				}
				finally
				{
					Interlocked.Exchange(ref Program.int_0, 0);
				}
			}
		}

		// Token: 0x060005D5 RID: 1493 RVA: 0x0017CDB0 File Offset: 0x0017CDB0
		private static void smethod_1(object object_0, object object_1)
		{
			if (Interlocked.Exchange(ref Program.int_1, 1) == 0)
			{
				try
				{
					ConcurrentBag<myip> concurrentBag = new ConcurrentBag<myip>();
					new initip(5, concurrentBag).getapips();
					if (concurrentBag.Count > 0)
					{
						StringBuilder stringBuilder = new StringBuilder();
						foreach (myip myip in concurrentBag)
						{
							try
							{
								stringBuilder.AppendLine(string.Format("{0}|{1},{2}", myip.ip, myip.ports[0], myip.ports[1]));
							}
							catch
							{
							}
						}
						string text = stringBuilder.ToString();
						if (text.Trim().Length > 0)
						{
							logtool.logips_w(text);
						}
					}
				}
				catch (Exception)
				{
				}
				finally
				{
					Interlocked.Exchange(ref Program.int_1, 0);
				}
			}
		}

		// Token: 0x060005D6 RID: 1494 RVA: 0x00158048 File Offset: 0x00158048
		private static void KjaHtSyPm(object object_0, object object_1)
		{
		}

		// Token: 0x060005D7 RID: 1495 RVA: 0x0017CEB4 File Offset: 0x0017CEB4
		private static void smethod_2(object object_0, object object_1)
		{
			if (Interlocked.Exchange(ref Program.int_3, 1) == 0)
			{
				try
				{
					string path = Application.StartupPath + "\\api.txt";
					if (File.Exists(path))
					{
						string text = File.ReadAllText(path);
						if (!string.IsNullOrWhiteSpace(text))
						{
							string[] array = text.Split(new char[]
							{
								'|'
							});
							int num;
							if (array.Length > 1 && int.TryParse(array[1], out num) && num > 5000)
							{
								Program.vhdidnWqf.Interval = (double)num;
							}
							if (array[0].ToString().ToLower().Contains("http") && array[0].ToString().ToLower().Contains("//"))
							{
								Program.gprapeUlj(array[0]);
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref Program.int_3, 0);
				}
			}
		}

		// Token: 0x060005D8 RID: 1496 RVA: 0x0017CF9C File Offset: 0x0017CF9C
		private static void smethod_3(object object_0, object object_1)
		{
			if (Interlocked.Exchange(ref Program.int_4, 1) == 0)
			{
				try
				{
					string path = Application.StartupPath + "\\config_p_qp.txt";
					if (File.Exists(path))
					{
						string text = File.ReadAllText(path);
						if (!string.IsNullOrWhiteSpace(text))
						{
							string[] array = text.Split(new char[]
							{
								'|'
							});
							int num;
							if (array.Length > 1 && int.TryParse(array[1], out num) && num > 5000)
							{
								Program.timer_0.Interval = (double)num;
							}
							if (array[0].ToString().ToLower().Contains("http") && array[0].ToString().ToLower().Contains("//"))
							{
								Program.smethod_4(array[0]);
							}
						}
					}
				}
				catch
				{
				}
				finally
				{
					Interlocked.Exchange(ref Program.int_4, 0);
				}
			}
		}

		// Token: 0x060005D9 RID: 1497 RVA: 0x0017D084 File Offset: 0x0017D084
		private static void gprapeUlj(string string_1)
		{
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			try
			{
				httpWebRequest = (WebRequest.Create(string_1) as HttpWebRequest);
				httpWebRequest.Method = "GET";
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
				HttpWebResponse httpWebResponse2;
				httpWebResponse = (httpWebResponse2 = (httpWebRequest.GetResponse() as HttpWebResponse));
				try
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						throw new Exception("获取代理出错");
					}
					string text = "";
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream))
						{
							text = streamReader.ReadToEnd();
						}
					}
					if (text.Length < 4)
					{
						throw new Exception("获取代理出错");
					}
					text = text.Replace("\"", "");
					if (!string.IsNullOrWhiteSpace(text) && text.Length > 4)
					{
						logtool.logproxy_http(text);
					}
					else
					{
						string[] array = text.Split(new string[]
						{
							Environment.NewLine,
							"\r\n",
							"\\r\\n"
						}, StringSplitOptions.RemoveEmptyEntries);
						StringBuilder stringBuilder = new StringBuilder();
						string[] array2 = array;
						foreach (string text2 in array2)
						{
							IPAddress ipaddress;
							if (text2.Split(new char[]
							{
								':'
							}).Length > 1 && IPAddress.TryParse(text2.Split(new char[]
							{
								':'
							})[0], out ipaddress))
							{
								stringBuilder.AppendLine(text2);
							}
						}
						string text3 = stringBuilder.ToString();
						if (text3.Trim().Length > 0)
						{
							logtool.logproxy_http(text3);
						}
					}
				}
				finally
				{
					if (httpWebResponse2 != null)
					{
						((IDisposable)httpWebResponse2).Dispose();
					}
				}
			}
			catch (Exception)
			{
			}
			finally
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Dispose();
				}
			}
		}

		// Token: 0x060005DA RID: 1498 RVA: 0x0017D2B4 File Offset: 0x0017D2B4
		private static void smethod_4(string string_1)
		{
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			try
			{
				httpWebRequest = (WebRequest.Create(string_1) as HttpWebRequest);
				httpWebRequest.Method = "GET";
				httpWebRequest.ServicePoint.Expect100Continue = false;
				httpWebRequest.ServicePoint.UseNagleAlgorithm = false;
				using (httpWebResponse = (httpWebRequest.GetResponse() as HttpWebResponse))
				{
					if (httpWebResponse.StatusCode != HttpStatusCode.OK)
					{
						throw new Exception("获取代理出错");
					}
					string text = "";
					using (Stream responseStream = httpWebResponse.GetResponseStream())
					{
						using (StreamReader streamReader = new StreamReader(responseStream))
						{
							text = streamReader.ReadToEnd();
						}
					}
					if (text.Length < 4)
					{
						throw new Exception("获取代理出错");
					}
					text = text.Replace("\"", "");
					if (!string.IsNullOrWhiteSpace(text))
					{
						logtool.logproxy_s5(text);
					}
				}
			}
			catch (Exception)
			{
			}
			finally
			{
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Dispose();
				}
			}
		}

		// Token: 0x040004ED RID: 1261
		private static string string_0;

		// Token: 0x040004EE RID: 1262
		private static System.Timers.Timer vhdidnWqf;

		// Token: 0x040004EF RID: 1263
		private static System.Timers.Timer timer_0;

		// Token: 0x040004F0 RID: 1264
		private static int int_0;

		// Token: 0x040004F1 RID: 1265
		private static int int_1;

		// Token: 0x040004F2 RID: 1266
		private static int int_2;

		// Token: 0x040004F3 RID: 1267
		private static int int_3;

		// Token: 0x040004F4 RID: 1268
		private static int int_4;
	}
}
