﻿using System;

namespace ns0
{
	// Token: 0x0200009D RID: 157
	public class Get51Code : MarshalByRefObject
	{
		// Token: 0x06000520 RID: 1312 RVA: 0x0015A4D4 File Offset: 0x0015A4D4
		public Get51Code()
		{
			ImageTool.CreateInstance();
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00170DE4 File Offset: 0x00170DE4
		public string HQCode(byte[] bytes, int imagetype)
		{
			string result;
			try
			{
				result = ImageTool.CreateInstance().hqCode(bytes, imagetype);
			}
			catch
			{
				result = "";
			}
			return result;
		}
	}
}
