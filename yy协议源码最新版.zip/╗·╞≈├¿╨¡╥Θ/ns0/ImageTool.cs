﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200009E RID: 158
	public class ImageTool
	{
		// Token: 0x06000522 RID: 1314
		[DllImport("QQ826021457.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
		public static extern int www_51ocr_com_InitOCR(string templatefile);

		// Token: 0x06000523 RID: 1315
		[DllImport("QQ826021457.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
		public static extern int www_51ocr_com_RECOG_1(string imagefile, StringBuilder text);

		// Token: 0x06000524 RID: 1316
		[DllImport("QQ826021457.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Ansi)]
		public static extern int www_51ocr_com_RECOG_2(byte[] imagebuf, int size, int type, StringBuilder text);

		// Token: 0x06000525 RID: 1317 RVA: 0x0015A4E2 File Offset: 0x0015A4E2
		private ImageTool()
		{
			ImageTool.www_51ocr_com_InitOCR(Application.StartupPath + "\\shibiek.dll");
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x0015A4FF File Offset: 0x0015A4FF
		public static ImageTool CreateInstance()
		{
			if (ImageTool.imageTool_0 == null)
			{
				ImageTool.imageTool_0 = new ImageTool();
			}
			return ImageTool.imageTool_0;
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x00170E1C File Offset: 0x00170E1C
		public string hqCode(byte[] bytes, int imageType = 1)
		{
			string result;
			try
			{
				StringBuilder stringBuilder = new StringBuilder("0000000000", 80);
				ImageTool.www_51ocr_com_RECOG_2(bytes, bytes.Length, imageType, stringBuilder);
				result = stringBuilder.ToString();
			}
			catch (Exception)
			{
				result = "";
			}
			return result;
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x00170E68 File Offset: 0x00170E68
		public byte[] method_0(Bitmap bitmap)
		{
			byte[] result;
			try
			{
				using (MemoryStream memoryStream = new MemoryStream())
				{
					bitmap.Save(memoryStream, ImageFormat.Bmp);
					byte[] array = new byte[memoryStream.Length];
					memoryStream.Seek(0L, SeekOrigin.Begin);
					memoryStream.Read(array, 0, Convert.ToInt32(memoryStream.Length));
					result = array;
				}
			}
			catch
			{
				result = null;
			}
			return result;
		}

		// Token: 0x040003EF RID: 1007
		private static ImageTool imageTool_0;
	}
}
