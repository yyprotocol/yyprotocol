﻿using System;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;

namespace Hardware
{
	// Token: 0x020000B2 RID: 178
	public class HardwareInfo
	{
		// Token: 0x060005E7 RID: 1511 RVA: 0x0015A812 File Offset: 0x0015A812
		public string GetHostName()
		{
			return Dns.GetHostName();
		}

		// Token: 0x060005E8 RID: 1512 RVA: 0x0017DE5C File Offset: 0x0017DE5C
		public string GetCpuID()
		{
			string result;
			try
			{
				ManagementClass managementClass = new ManagementClass("Win32_Processor");
				ManagementObjectCollection instances = managementClass.GetInstances();
				string text = null;
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = instances.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject.Properties["ProcessorId"].Value.ToString();
					}
				}
				result = text;
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060005E9 RID: 1513 RVA: 0x0017DEF0 File Offset: 0x0017DEF0
		public string GetHardDiskID()
		{
			string result;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
				string text = null;
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["SerialNumber"].ToString().Trim();
					}
				}
				result = text;
			}
			catch
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060005EA RID: 1514 RVA: 0x0017DF7C File Offset: 0x0017DF7C
		public string GetMacAddress()
		{
			string text = "";
			try
			{
				HardwareInfo.NCB ncb = default(HardwareInfo.NCB);
				ncb.ncb_command = 55;
				int num = Marshal.SizeOf(typeof(HardwareInfo.LANA_ENUM));
				ncb.ncb_buffer = Marshal.AllocHGlobal(num);
				ncb.ncb_length = (ushort)num;
				char c = HardwareInfo.Win32API.Netbios(ref ncb);
				HardwareInfo.LANA_ENUM lana_ENUM = (HardwareInfo.LANA_ENUM)Marshal.PtrToStructure(ncb.ncb_buffer, typeof(HardwareInfo.LANA_ENUM));
				Marshal.FreeHGlobal(ncb.ncb_buffer);
				if (c != '\0')
				{
					return "";
				}
				for (int i = 0; i < (int)lana_ENUM.length; i++)
				{
					ncb.ncb_command = 50;
					ncb.ncb_lana_num = lana_ENUM.lana[i];
					if (HardwareInfo.Win32API.Netbios(ref ncb) != '\0')
					{
						return "";
					}
					ncb.ncb_command = 51;
					ncb.ncb_lana_num = lana_ENUM.lana[i];
					ncb.ncb_callname[0] = 42;
					num = Marshal.SizeOf(typeof(HardwareInfo.ADAPTER_STATUS)) + Marshal.SizeOf(typeof(HardwareInfo.NAME_BUFFER)) * 30;
					ncb.ncb_buffer = Marshal.AllocHGlobal(num);
					ncb.ncb_length = (ushort)num;
					c = HardwareInfo.Win32API.Netbios(ref ncb);
					HardwareInfo.ASTAT astat;
					astat.adapt = (HardwareInfo.ADAPTER_STATUS)Marshal.PtrToStructure(ncb.ncb_buffer, typeof(HardwareInfo.ADAPTER_STATUS));
					Marshal.FreeHGlobal(ncb.ncb_buffer);
					if (c == '\0')
					{
						if (i > 0)
						{
							text += ":";
						}
						text = string.Format("{0,2:X}{1,2:X}{2,2:X}{3,2:X}{4,2:X}{5,2:X}", new object[]
						{
							astat.adapt.adapter_address[0],
							astat.adapt.adapter_address[1],
							astat.adapt.adapter_address[2],
							astat.adapt.adapter_address[3],
							astat.adapt.adapter_address[4],
							astat.adapt.adapter_address[5]
						});
					}
				}
			}
			catch
			{
			}
			return text.Replace(' ', '0');
		}

		// Token: 0x020000B3 RID: 179
		public enum NCBCONST
		{
			// Token: 0x04000502 RID: 1282
			NCBNAMSZ = 16,
			// Token: 0x04000503 RID: 1283
			MAX_LANA = 254,
			// Token: 0x04000504 RID: 1284
			NCBENUM = 55,
			// Token: 0x04000505 RID: 1285
			NRC_GOODRET = 0,
			// Token: 0x04000506 RID: 1286
			NCBRESET = 50,
			// Token: 0x04000507 RID: 1287
			NCBASTAT,
			// Token: 0x04000508 RID: 1288
			NUM_NAMEBUF = 30
		}

		// Token: 0x020000B4 RID: 180
		public struct ADAPTER_STATUS
		{
			// Token: 0x04000509 RID: 1289
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
			public byte[] adapter_address;

			// Token: 0x0400050A RID: 1290
			public byte rev_major;

			// Token: 0x0400050B RID: 1291
			public byte reserved0;

			// Token: 0x0400050C RID: 1292
			public byte adapter_type;

			// Token: 0x0400050D RID: 1293
			public byte rev_minor;

			// Token: 0x0400050E RID: 1294
			public ushort duration;

			// Token: 0x0400050F RID: 1295
			public ushort frmr_recv;

			// Token: 0x04000510 RID: 1296
			public ushort frmr_xmit;

			// Token: 0x04000511 RID: 1297
			public ushort iframe_recv_err;

			// Token: 0x04000512 RID: 1298
			public ushort xmit_aborts;

			// Token: 0x04000513 RID: 1299
			public uint xmit_success;

			// Token: 0x04000514 RID: 1300
			public uint recv_success;

			// Token: 0x04000515 RID: 1301
			public ushort iframe_xmit_err;

			// Token: 0x04000516 RID: 1302
			public ushort recv_buff_unavail;

			// Token: 0x04000517 RID: 1303
			public ushort t1_timeouts;

			// Token: 0x04000518 RID: 1304
			public ushort ti_timeouts;

			// Token: 0x04000519 RID: 1305
			public uint reserved1;

			// Token: 0x0400051A RID: 1306
			public ushort free_ncbs;

			// Token: 0x0400051B RID: 1307
			public ushort max_cfg_ncbs;

			// Token: 0x0400051C RID: 1308
			public ushort max_ncbs;

			// Token: 0x0400051D RID: 1309
			public ushort xmit_buf_unavail;

			// Token: 0x0400051E RID: 1310
			public ushort max_dgram_size;

			// Token: 0x0400051F RID: 1311
			public ushort pending_sess;

			// Token: 0x04000520 RID: 1312
			public ushort max_cfg_sess;

			// Token: 0x04000521 RID: 1313
			public ushort max_sess;

			// Token: 0x04000522 RID: 1314
			public ushort max_sess_pkt_size;

			// Token: 0x04000523 RID: 1315
			public ushort name_count;
		}

		// Token: 0x020000B5 RID: 181
		public struct NAME_BUFFER
		{
			// Token: 0x04000524 RID: 1316
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] name;

			// Token: 0x04000525 RID: 1317
			public byte name_num;

			// Token: 0x04000526 RID: 1318
			public byte name_flags;
		}

		// Token: 0x020000B6 RID: 182
		public struct NCB
		{
			// Token: 0x04000527 RID: 1319
			public byte ncb_command;

			// Token: 0x04000528 RID: 1320
			public byte ncb_retcode;

			// Token: 0x04000529 RID: 1321
			public byte ncb_lsn;

			// Token: 0x0400052A RID: 1322
			public byte ncb_num;

			// Token: 0x0400052B RID: 1323
			public IntPtr ncb_buffer;

			// Token: 0x0400052C RID: 1324
			public ushort ncb_length;

			// Token: 0x0400052D RID: 1325
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] ncb_callname;

			// Token: 0x0400052E RID: 1326
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
			public byte[] ncb_name;

			// Token: 0x0400052F RID: 1327
			public byte ncb_rto;

			// Token: 0x04000530 RID: 1328
			public byte ncb_sto;

			// Token: 0x04000531 RID: 1329
			public IntPtr ncb_post;

			// Token: 0x04000532 RID: 1330
			public byte ncb_lana_num;

			// Token: 0x04000533 RID: 1331
			public byte ncb_cmd_cplt;

			// Token: 0x04000534 RID: 1332
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
			public byte[] ncb_reserve;

			// Token: 0x04000535 RID: 1333
			public IntPtr ncb_event;
		}

		// Token: 0x020000B7 RID: 183
		public struct LANA_ENUM
		{
			// Token: 0x04000536 RID: 1334
			public byte length;

			// Token: 0x04000537 RID: 1335
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 254)]
			public byte[] lana;
		}

		// Token: 0x020000B8 RID: 184
		[StructLayout(LayoutKind.Auto)]
		public struct ASTAT
		{
			// Token: 0x04000538 RID: 1336
			public HardwareInfo.ADAPTER_STATUS adapt;

			// Token: 0x04000539 RID: 1337
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
			public HardwareInfo.NAME_BUFFER[] NameBuff;
		}

		// Token: 0x020000B9 RID: 185
		public class Win32API
		{
			// Token: 0x060005EC RID: 1516
			[DllImport("NETAPI32.DLL")]
			public static extern char Netbios(ref HardwareInfo.NCB ncb);
		}
	}
}
