﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSScriptControl
{
	// Token: 0x020000DC RID: 220
	[CompilerGenerated]
	[Guid("0E59F1D3-1FBE-11D0-8FF2-00A0D10038BC")]
	[TypeIdentifier]
	[ComImport]
	public interface IScriptControl
	{
		// Token: 0x17000114 RID: 276
		// (get) Token: 0x060005F9 RID: 1529
		// (set) Token: 0x060005FA RID: 1530
		[DispId(1500)]
		string Language { [DispId(1500)] [MethodImpl(MethodImplOptions.InternalCall)] [return: MarshalAs(UnmanagedType.BStr)] get; [DispId(1500)] [MethodImpl(MethodImplOptions.InternalCall)] [param: MarshalAs(UnmanagedType.BStr)] set; }

		// Token: 0x060005FB RID: 1531
		void _VtblGap1_8();

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x060005FC RID: 1532
		// (set) Token: 0x060005FD RID: 1533
		[DispId(1505)]
		bool UseSafeSubset { [DispId(1505)] [MethodImpl(MethodImplOptions.InternalCall)] get; [DispId(1505)] [MethodImpl(MethodImplOptions.InternalCall)] set; }

		// Token: 0x060005FE RID: 1534
		void _VtblGap2_7();

		// Token: 0x060005FF RID: 1535
		[DispId(2000)]
		[MethodImpl(MethodImplOptions.InternalCall)]
		void AddCode([MarshalAs(UnmanagedType.BStr)] [In] string Code);

		// Token: 0x06000600 RID: 1536
		[DispId(2001)]
		[MethodImpl(MethodImplOptions.InternalCall)]
		[return: MarshalAs(UnmanagedType.Struct)]
		object Eval([MarshalAs(UnmanagedType.BStr)] [In] string Expression);
	}
}
