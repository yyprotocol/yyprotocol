﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSScriptControl
{
	// Token: 0x020000DB RID: 219
	[TypeIdentifier("0e59f1d2-1fbe-11d0-8ff2-00a0d10038bc", "MSScriptControl.DScriptControlSource_Event")]
	[CompilerGenerated]
	[ComEventInterface(typeof(DScriptControlSource), typeof(DScriptControlSource))]
	[ComImport]
	public interface DScriptControlSource_Event
	{
	}
}
