﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSScriptControl
{
	// Token: 0x020000DA RID: 218
	[TypeIdentifier]
	[InterfaceType(2)]
	[CompilerGenerated]
	[Guid("8B167D60-8605-11D0-ABCB-00A0C90FFFC0")]
	[ComImport]
	public interface DScriptControlSource
	{
	}
}
