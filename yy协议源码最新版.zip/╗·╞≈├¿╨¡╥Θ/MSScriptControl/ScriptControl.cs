﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace MSScriptControl
{
	// Token: 0x020000DD RID: 221
	[TypeIdentifier]
	[CoClass(typeof(object))]
	[Guid("0E59F1D3-1FBE-11D0-8FF2-00A0D10038BC")]
	[CompilerGenerated]
	[ComImport]
	public interface ScriptControl : DScriptControlSource_Event, IScriptControl
	{
	}
}
