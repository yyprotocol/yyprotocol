﻿using System;

namespace dummy_ptr
{
	// Token: 0x020000DE RID: 222
	internal abstract class {f5c1660b-2242-452b-a5cc-b8f28efe259a}
	{
		// Token: 0x06000601 RID: 1537
		public abstract void mp000465();

		// Token: 0x06000602 RID: 1538
		public abstract void mp000466();
	}
}
