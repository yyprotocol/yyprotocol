﻿using System;
using System.Security.Cryptography;
using System.Text;

// Token: 0x02000002 RID: 2
public class Crypto3DES
{
	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000003 RID: 3 RVA: 0x00158052 File Offset: 0x00158052
	public static string Key
	{
		get
		{
			return "20130711";
		}
	}

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000004 RID: 4 RVA: 0x00158059 File Offset: 0x00158059
	// (set) Token: 0x06000005 RID: 5 RVA: 0x00158071 File Offset: 0x00158071
	public static Encoding Encoding
	{
		get
		{
			if (Crypto3DES.encoding == null)
			{
				Crypto3DES.encoding = Encoding.UTF8;
			}
			return Crypto3DES.encoding;
		}
		set
		{
			Crypto3DES.encoding = value;
		}
	}

	// Token: 0x06000006 RID: 6 RVA: 0x0015A848 File Offset: 0x0015A848
	public static string Decrypt3DES(string strString)
	{
		ICryptoTransform cryptoTransform = new DESCryptoServiceProvider
		{
			Key = Encoding.UTF8.GetBytes(Crypto3DES.Key),
			Mode = CipherMode.ECB,
			Padding = PaddingMode.Zeros
		}.CreateDecryptor();
		byte[] array = Convert.FromBase64String(strString);
		return Encoding.UTF8.GetString(cryptoTransform.TransformFinalBlock(array, 0, array.Length));
	}

	// Token: 0x04000001 RID: 1
	private static Encoding encoding = Encoding.UTF8;
}
