﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
}
